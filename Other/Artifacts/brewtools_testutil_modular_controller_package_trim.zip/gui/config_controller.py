from __future__ import annotations


class WindowConfigController:
    """Handles UI configuration collection and persistence without using MainWindow as the write host."""

    def __init__(self, window, builder):
        self.window = window
        self.builder = builder

    def build_config(self):
        return self.builder.build()

    def save_settings_to_state(self, *, validate: bool = True) -> None:
        if validate and not self.window.validation_controller.can_apply(show_status=False):
            return
        self.window.commands.apply_configuration(self.build_config(), persist=False)

    def save_settings(self, *args) -> None:
        if (
            self.window.ui_state.control_combo_sync_block
            or self.window.ui_state.loading_settings
            or self.window.ui_state.loading_twin_widgets
            or self.window.ui_state.loading_scheduler_ui
        ):
            return
        if not self.window.validation_controller.can_apply(show_status=True):
            return
        self.save_settings_to_state(validate=False)
        result = self.window.commands.apply_configuration(self.build_config(), persist=True)
        self.window.settings = self.window.core.settings
        self.window.statusBar().showMessage(result.message)
        self.window.runtime_bridge.refresh_footer()
        self.window.runtime_bridge.refresh_control_panel()
        self.window.runtime_bridge.refresh_relay_panel()

    def on_bitrate_changed(self, *args) -> None:
        self.save_settings()
        self.window.brew_controller.populate_channels()
