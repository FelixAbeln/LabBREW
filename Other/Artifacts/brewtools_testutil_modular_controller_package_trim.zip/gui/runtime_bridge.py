from __future__ import annotations


class WindowRuntimeBridge:
    """Coordinates cross-panel refresh and runtime-driven GUI updates."""

    def __init__(self, window):
        self.window = window
        self.refresh = None

    def set_refresh_coordinator(self, refresh) -> None:
        self.refresh = refresh

    def refresh_footer(self) -> None:
        if self.refresh is not None:
            self.refresh.footer.refresh()

    def refresh_table(self) -> None:
        if self.refresh is not None:
            self.refresh.devices.refresh_table()

    def on_frame(self, frame, obj) -> None:
        if self.refresh is not None:
            self.refresh.devices.on_frame(frame, obj)

    def refresh_control_panel(self) -> None:
        if self.refresh is not None:
            self.refresh.control.refresh()

    def refresh_safety_panel(self) -> None:
        if self.refresh is not None:
            self.refresh.safety.refresh()

    def refresh_twin_panel(self) -> None:
        if self.refresh is not None:
            self.refresh.twin.refresh()

    def refresh_scheduler_panel(self) -> None:
        if self.refresh is not None:
            self.refresh.scheduler.refresh()

    def refresh_relay_panel(self) -> None:
        if self.refresh is not None:
            self.refresh.relays.refresh()

    def refresh_sources(self) -> None:
        self.window.source_controller.refresh_all_sources()


    def update_agitator_runtime(self) -> None:
        self.window.commands.update_agitator_runtime()


    def refresh_all(self) -> None:
        self.refresh_footer()
        self.refresh_table()
        self.refresh_control_panel()
        self.refresh_safety_panel()
        self.refresh_twin_panel()
        self.refresh_scheduler_panel()
        self.refresh_relay_panel()

    def on_runtime_cycle_completed(self) -> None:
        snap = self.window.queries.snapshot()
        self.window.ui_state.loading_scheduler_ui = True
        try:
            changed = self.window.control_panel.apply_scheduler_targets(
                snap.controls.temperature.setpoint,
                snap.controls.pressure.setpoint,
                snap.controls.pressure.allow_add_gas,
                snap.controls.agitator.on,
                snap.controls.agitator.duty_cycle,
            )
        finally:
            self.window.ui_state.loading_scheduler_ui = False
        if changed:
            self.window.config_controller.save_settings_to_state()
        self.refresh_control_panel()
        self.refresh_safety_panel()
        self.refresh_scheduler_panel()
        self.refresh_relay_panel()
        self.refresh_footer()
