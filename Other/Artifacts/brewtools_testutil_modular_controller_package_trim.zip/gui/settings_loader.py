from __future__ import annotations

class WindowSettingsLoader:
    """Applies persisted settings into panel-level field adapters instead of making MainWindow the field-by-field owner."""

    def __init__(self, window):
        self.window = window

    def apply(self) -> None:
        w = self.window
        s = w.settings
        w.ui_state.loading_settings = True

        w.editors.brew.apply_settings(s)
        w.editors.control.apply_settings(s)
        w.editors.relay.apply_settings(s)
        w.editors.safety.apply_settings(s)
        w.editors.twin.apply_settings(s)
        w.editors.scheduler.apply_settings(s)

        w.config_controller.save_settings_to_state(validate=False)
        w.ui_state.loading_twin_widgets = True
        try:
            if s.twin.fmu_path:
                w.commands.load_twin_model(s.twin.fmu_path)
            w.twin_panel.rebuild_variable_widgets()
            w.source_controller.refresh_all_sources()
            w.config_controller.save_settings_to_state(validate=False)
        finally:
            w.ui_state.loading_twin_widgets = False
        w.ui_state.loading_scheduler_ui = False
        w.runtime_bridge.refresh_footer()
        w.validation_controller.validate_current(decorate=True, show_status=False)
