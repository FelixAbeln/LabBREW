from __future__ import annotations

from application.normalization import normalize_control_source_key
from gui.config_adapters import ApplicationConfigBuilder
from gui.config_controller import WindowConfigController
from gui.controllers import (
    BrewPanelController,
    ControlSourcesController,
    RelayPanelController,
    SchedulerPanelController,
    TwinSourcesController,
    WindowSourceController,
)
from gui.constants import OUTPUT_LABELS
from gui.intent_dispatcher import WindowIntentDispatcher
from gui.panel_editors import build_main_window_editors
from gui.panel_facades import build_panel_facades
from gui.runtime_bridge import WindowRuntimeBridge
from gui.safety_rules_controller import SafetyRulesController
from gui.settings_loader import WindowSettingsLoader
from gui.ui_state import WindowUIState
from gui.validation_controller import WindowValidationController
from gui.window_session import MainWindowSession
from gui.window_shell import MainWindowShell


class MainWindowComposer:
    """Builds the window collaborator graph and shell widgets."""

    def __init__(self, window):
        self.window = window

    def compose(self) -> None:
        w = self.window
        self._create_state(w)
        self._create_controllers(w)
        self._build_shell(w)
        self._create_runtime_collaborators(w)

    def _create_state(self, w) -> None:
        w.ui_state = WindowUIState(
            pending_temp_source_key=normalize_control_source_key(w.settings.temp_controller.source_key),
            pending_pressure_source_key=normalize_control_source_key(w.settings.pressure_controller.source_key),
        )
        w.safety_rules_controller = SafetyRulesController()
        w.OUTPUT_LABELS = OUTPUT_LABELS
        w.relay_channel_rows = {}

    def _create_controllers(self, w) -> None:
        w._config_builder = ApplicationConfigBuilder(w)
        w.config_controller = WindowConfigController(w, w._config_builder)
        w.brew_controller = BrewPanelController(w)
        w.relay_controller = RelayPanelController(w)
        w.scheduler_controller = SchedulerPanelController(w)
        w.control_sources_controller = ControlSourcesController(w)
        w.twin_sources_controller = TwinSourcesController(w)
        w.source_controller = WindowSourceController(w.control_sources_controller, w.twin_sources_controller)
        w.settings_loader = WindowSettingsLoader(w)

    def _build_shell(self, w) -> None:
        w._panel_facades = build_panel_facades(w)
        w.shell = MainWindowShell(w)
        w.shell.build()
        w.editors = build_main_window_editors(w)
        w.shell.wire_signals()

    def _create_runtime_collaborators(self, w) -> None:
        w.runtime_bridge = WindowRuntimeBridge(w)
        w.intent_dispatcher = WindowIntentDispatcher(w)
        w.validation_controller = WindowValidationController(w)
        w.session = MainWindowSession(w)
        w.session.bind_runtime_events()
