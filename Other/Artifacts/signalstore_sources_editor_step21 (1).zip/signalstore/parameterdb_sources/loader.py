from __future__ import annotations

import importlib.util
import uuid
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any

from .base import DataSourceSpec


@dataclass(slots=True)
class LoadedSourceType:
    source_type: str
    folder: str
    ui_spec: dict[str, Any] | None = None


class DataSourceRegistry:
    def __init__(self) -> None:
        self._specs: dict[str, DataSourceSpec] = {}
        self._ui_specs: dict[str, dict[str, Any]] = {}

    def register(self, spec: DataSourceSpec, ui_spec: dict[str, Any] | None = None) -> None:
        self._specs[spec.source_type] = spec
        if ui_spec is not None:
            self._ui_specs[spec.source_type] = ui_spec

    def get(self, source_type: str) -> DataSourceSpec:
        try:
            return self._specs[source_type]
        except KeyError as exc:
            raise KeyError(f"Unknown data source type '{source_type}'") from exc

    def list_types(self) -> list[str]:
        return sorted(self._specs)

    def list_ui(self) -> dict[str, dict[str, Any]]:
        return {k: {
            "source_type": k,
            "display_name": v.get("display_name", k),
            "description": v.get("description", ""),
        } for k, v in self._ui_specs.items()}

    def get_ui_spec(self, source_type: str) -> dict[str, Any]:
        try:
            return dict(self._ui_specs[source_type])
        except KeyError as exc:
            raise KeyError(f"Unknown data source type '{source_type}'") from exc


def _load_py_module(pyfile: Path) -> ModuleType:
    module_name = f"source_{pyfile.stem}_{uuid.uuid4().hex[:8]}"
    spec = importlib.util.spec_from_file_location(module_name, pyfile)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module from '{pyfile}'")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _extract_ui_spec(ui_module: Any | None) -> dict[str, Any] | None:
    if ui_module is None:
        return None
    if hasattr(ui_module, "get_ui_spec"):
        return ui_module.get_ui_spec()
    if hasattr(ui_module, "UI_SPEC"):
        return dict(ui_module.UI_SPEC)
    return None


def load_source_folder(folder: str | Path, registry: DataSourceRegistry) -> LoadedSourceType:
    path = Path(folder)
    service_file = path / "service.py"
    ui_file = path / "ui.py"
    if not service_file.exists():
        raise FileNotFoundError(f"Missing service.py in '{path}'")

    service_module = _load_py_module(service_file)
    ui_module = _load_py_module(ui_file) if ui_file.exists() else None
    spec = getattr(service_module, "SOURCE", None)
    if spec is None:
        raise ValueError(f"'{service_file}' must define SOURCE")
    ui_spec = _extract_ui_spec(ui_module)
    registry.register(spec, ui_spec)
    return LoadedSourceType(source_type=spec.source_type, folder=str(path), ui_spec=ui_spec)


def autodiscover_sources(root: str | Path, registry: DataSourceRegistry) -> list[str]:
    path = Path(root)
    if not path.exists():
        return []
    loaded: list[str] = []
    for child in sorted(path.iterdir()):
        if not child.is_dir() or child.name.startswith("_"):
            continue
        try:
            info = load_source_folder(child, registry)
            loaded.append(info.source_type)
        except Exception:
            continue
    return loaded
