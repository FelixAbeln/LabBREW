from __future__ import annotations

from .engine import ScanEngine
from .event_broker import EventBroker
from .loader import PluginRegistry, autodiscover_plugins
from .server import SignalTCPServer
from .store import ParameterStore


def build_service(host: str = '127.0.0.1', port: int = 8765, period_s: float = 0.05, plugin_root: str = './plugins'):
    registry = PluginRegistry()
    loaded = autodiscover_plugins(plugin_root, registry)
    broker = EventBroker()
    store = ParameterStore(event_broker=broker)
    engine = ScanEngine(period_s=period_s, store=store)
    server = SignalTCPServer(host, port, engine, registry, broker)
    return engine, server, registry, loaded


def main() -> None:
    from pathlib import Path
    import argparse
    parser = argparse.ArgumentParser(description='RealtimeDB Service')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--period', type=float, default=0.05)
    parser.add_argument('--plugin-root', default='./plugins')
    args = parser.parse_args()

    plugin_root = Path(args.plugin_root).resolve()
    plugin_root.mkdir(parents=True, exist_ok=True)
    engine, server, registry, loaded = build_service(args.host, args.port, args.period, str(plugin_root))
    print(f'[INFO] Plugin root: {plugin_root}')
    print(f'[INFO] Loaded plugins: {loaded}')
    engine.start()
    import threading
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    print(f'[INFO] Service running on {args.host}:{args.port}')

    def shutdown(*_):
        print('[INFO] Shutting down...')
        server.shutdown()
        server.server_close()
        engine.stop()
        raise SystemExit(0)

    import signal, time
    signal.signal(signal.SIGINT, shutdown)
    if hasattr(signal, 'SIGTERM'):
        signal.signal(signal.SIGTERM, shutdown)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        shutdown()
