from __future__ import annotations

import argparse
import json
import queue
import threading
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
from typing import Any

from realtimedb_service.client import SignalClient
from realtimedb_service.plugin_ui import deep_copy_payload, get_by_path, set_by_path


class ParameterEditor(tk.Toplevel):
    def __init__(self, master: tk.Misc, client: SignalClient, plugin_ui: dict[str, Any], mode: str, record: dict[str, Any] | None = None) -> None:
        super().__init__(master)
        self.client = client
        self.plugin_ui = plugin_ui
        self.mode = mode
        self.record = deep_copy_payload(record or {})
        self.field_vars: dict[str, tuple[tk.Variable | tk.Text, dict[str, Any]]] = {}
        self.result = False
        self.parameter_names = []
        try:
            self.parameter_names = self.client.list_parameters()
        except Exception:
            pass

        title = f"{mode.title()} {plugin_ui.get('display_name', plugin_ui.get('plugin_type'))}"
        self.title(title)
        self.geometry("700x720")
        self.transient(master)
        self.grab_set()

        body = ttk.Frame(self, padding=10)
        body.pack(fill=tk.BOTH, expand=True)

        canvas = tk.Canvas(body, highlightthickness=0)
        scrollbar = ttk.Scrollbar(body, orient="vertical", command=canvas.yview)
        self.scroll_frame = ttk.Frame(canvas)
        self.scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self._build_form()

        button_bar = ttk.Frame(self, padding=(10, 0, 10, 10))
        button_bar.pack(fill=tk.X)
        ttk.Button(button_bar, text="Save", command=self.on_save).pack(side=tk.RIGHT, padx=4)
        ttk.Button(button_bar, text="Cancel", command=self.destroy).pack(side=tk.RIGHT)

    def _base_data(self) -> dict[str, Any]:
        if self.mode == "create":
            defaults = deep_copy_payload(self.plugin_ui.get("create", {}).get("defaults", {}))
            return {
                "name": "",
                "plugin_type": self.plugin_ui["plugin_type"],
                "value": defaults.get("value"),
                "config": defaults.get("config", {}),
                "state": {},
                "metadata": defaults.get("metadata", {}),
            }
        return {
            "name": self.record.get("name", ""),
            "plugin_type": self.record.get("plugin_type", self.plugin_ui["plugin_type"]),
            "value": self.record.get("value"),
            "config": deep_copy_payload(self.record.get("config", {})),
            "state": deep_copy_payload(self.record.get("state", {})),
            "metadata": deep_copy_payload(self.record.get("metadata", {})),
        }

    def _build_form(self) -> None:
        data = self._base_data()
        if self.mode == "create":
            header = ttk.LabelFrame(self.scroll_frame, text="Identity", padding=8)
            header.pack(fill=tk.X, pady=6)
            ttk.Label(header, text="Name").grid(row=0, column=0, sticky="w", padx=4, pady=4)
            var = tk.StringVar(value=data.get("name", ""))
            entry = ttk.Entry(header, textvariable=var)
            entry.grid(row=0, column=1, sticky="ew", padx=4, pady=4)
            header.columnconfigure(1, weight=1)
            self.field_vars["name"] = (var, {"type": "string", "required": True})

        sections = self.plugin_ui.get("edit", {}).get("sections", [])
        if not sections and self.mode == "create":
            sections = [{"title": "Values", "fields": []}]
        for section in sections:
            lf = ttk.LabelFrame(self.scroll_frame, text=section.get("title", "Section"), padding=8)
            lf.pack(fill=tk.X, pady=6)
            lf.columnconfigure(1, weight=1)
            row = 0
            for field in section.get("fields", []):
                key = field["key"]
                if self.mode == "create" and key.startswith("state."):
                    continue
                ttk.Label(lf, text=field.get("label", key)).grid(row=row, column=0, sticky="nw", padx=4, pady=4)
                widget, var = self._make_input(lf, field, get_by_path(data, key))
                widget.grid(row=row, column=1, sticky="ew", padx=4, pady=4)
                self.field_vars[key] = (var, field)
                row += 1

        desc = self.plugin_ui.get("description", "")
        if desc:
            ttk.Label(self.scroll_frame, text=desc, wraplength=620).pack(fill=tk.X, pady=6)

    def _make_input(self, parent: tk.Misc, field: dict[str, Any], value: Any):
        field_type = field.get("type", "string")
        readonly = bool(field.get("readonly"))

        if field_type in {"text", "code", "json"}:
            text = tk.Text(parent, height=6 if field_type in {"text", "code"} else 4, wrap="word")
            if value is not None:
                if field_type == "json" and not isinstance(value, str):
                    text.insert("1.0", json.dumps(value, indent=2, sort_keys=True))
                else:
                    text.insert("1.0", str(value))
            if readonly:
                text.configure(state="disabled")
            return text, text

        if field_type == "bool":
            var = tk.BooleanVar(value=bool(value))
            widget = ttk.Checkbutton(parent, variable=var)
            if readonly:
                widget.state(["disabled"])
            return widget, var

        if field_type in {"parameter_ref", "enum"}:
            options = field.get("options") or self.parameter_names
            var = tk.StringVar(value="" if value is None else str(value))
            widget = ttk.Combobox(parent, textvariable=var, values=list(options), state="readonly" if not readonly else "disabled")
            return widget, var

        if field_type == "parameter_ref_list":
            var = tk.StringVar(value=", ".join(value or []))
            widget = ttk.Entry(parent, textvariable=var)
            if readonly:
                widget.state(["disabled"])
            return widget, var

        shown = "" if value is None else (json.dumps(value) if isinstance(value, (dict, list)) else str(value))
        var = tk.StringVar(value=shown)
        widget = ttk.Entry(parent, textvariable=var)
        if readonly or field_type == "readonly":
            widget.state(["readonly"])
        return widget, var

    def _read_field_value(self, key: str, spec: dict[str, Any], holder: tk.Variable | tk.Text) -> Any:
        field_type = spec.get("type", "string")
        if isinstance(holder, tk.Text):
            raw = holder.get("1.0", "end").strip()
        else:
            raw = holder.get()
        if field_type in {"readonly"}:
            return raw
        if field_type in {"text", "code", "string", "parameter_ref", "enum"}:
            return raw
        if field_type == "json":
            if raw == "":
                return None
            return json.loads(raw)
        if field_type == "bool":
            return bool(raw)
        if field_type == "int":
            return int(raw) if raw != "" else None
        if field_type == "float":
            return float(raw) if raw != "" else None
        if field_type == "parameter_ref_list":
            return [item.strip() for item in raw.split(",") if item.strip()]
        return raw

    def _collect_data(self) -> dict[str, Any]:
        data = self._base_data()
        for key, (holder, spec) in self.field_vars.items():
            set_by_path(data, key, self._read_field_value(key, spec, holder))
        return data

    def _validate(self, data: dict[str, Any]) -> None:
        required = set(self.plugin_ui.get("create", {}).get("required", []))
        for key, (holder, spec) in self.field_vars.items():
            if spec.get("required"):
                required.add(key)
        missing = []
        for path in sorted(required):
            value = get_by_path(data, path)
            if value in (None, "", []):
                missing.append(path)
        if missing:
            raise ValueError("Missing required fields: " + ", ".join(missing))

    def on_save(self) -> None:
        try:
            data = self._collect_data()
            self._validate(data)
            if self.mode == "create":
                self.client.create_parameter(
                    data["name"],
                    self.plugin_ui["plugin_type"],
                    value=data.get("value"),
                    config=data.get("config", {}),
                    metadata=data.get("metadata", {}),
                )
            else:
                name = data["name"]
                if "value" in data:
                    self.client.set_value(name, data.get("value"))
                self.client.update_config(name, **data.get("config", {}))
                self.client.update_metadata(name, **data.get("metadata", {}))
            self.result = True
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Save failed", str(exc), parent=self)


class MonitorApp:
    def __init__(self, root: tk.Tk, client: SignalClient) -> None:
        self.root = root
        self.client = client
        self.events: queue.Queue = queue.Queue()
        self.rows: dict[str, dict[str, Any]] = {}
        self.stop_flag = threading.Event()
        self.plugin_ui_cache: dict[str, dict[str, Any]] = {}
        self.graph = {}

        root.title("RealtimeDB Monitor")
        root.geometry("1650x850")

        toolbar = ttk.Frame(root, padding=8)
        toolbar.pack(fill=tk.X)
        ttk.Button(toolbar, text="Create", command=self.create_parameter).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Edit", command=self.edit_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Delete", command=self.delete_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Refresh Graph", command=self.refresh_graph).pack(side=tk.LEFT, padx=10)
        ttk.Button(toolbar, text="Snapshot", command=self.show_snapshot).pack(side=tk.LEFT, padx=2)
        ttk.Label(toolbar, text="Filter").pack(side=tk.LEFT, padx=(20, 4))
        self.filter_var = tk.StringVar()
        filter_entry = ttk.Entry(toolbar, textvariable=self.filter_var, width=30)
        filter_entry.pack(side=tk.LEFT)
        filter_entry.bind("<KeyRelease>", lambda e: self.refresh_tree())

        self.status_var = tk.StringVar(value="Connecting...")
        ttk.Label(toolbar, textvariable=self.status_var).pack(side=tk.RIGHT)

        cols = ("name", "plugin_type", "value", "deps", "dependents", "config", "state", "metadata")
        self.tree = ttk.Treeview(root, columns=cols, show="headings", height=20)
        widths = {
            "name": 180,
            "plugin_type": 100,
            "value": 140,
            "deps": 170,
            "dependents": 170,
            "config": 280,
            "state": 260,
            "metadata": 180,
        }
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=widths[col], anchor="w")
        self.tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.update_details())
        self.tree.bind("<Double-1>", lambda e: self.edit_selected())

        detail = ttk.LabelFrame(root, text="Selected", padding=8)
        detail.pack(fill=tk.BOTH, padx=8, pady=(0, 8))
        self.detail_text = tk.Text(detail, height=14, wrap="word")
        self.detail_text.pack(fill=tk.BOTH, expand=True)

        self.load_initial()
        self.start_subscription_thread()
        self.root.after(150, self.process_events)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def load_initial(self) -> None:
        self.plugin_ui_cache = self.client.list_plugin_ui()
        self.rows = {}
        for name, desc in self.client.describe().items():
            record = dict(desc)
            record["name"] = name
            self.rows[name] = record
        self.refresh_graph()
        self.refresh_tree()

    def refresh_graph(self) -> None:
        try:
            self.graph = self.client.graph_info()
        except Exception as exc:
            messagebox.showerror("Graph error", str(exc), parent=self.root)
            self.graph = {"dependencies": {}, "warnings": [], "scan_order": []}
        self.refresh_tree()
        self.update_status()
        self.update_details()

    def deps_for(self, name: str) -> list[str]:
        return list((self.graph.get("dependencies") or {}).get(name, []))

    def dependents_for(self, name: str) -> list[str]:
        deps = self.graph.get("dependencies") or {}
        return sorted([param for param, values in deps.items() if name in values])

    def row_values(self, name: str, desc: dict[str, Any]) -> tuple[Any, ...]:
        return (
            name,
            desc.get("plugin_type", ""),
            repr(desc.get("value")),
            ", ".join(self.deps_for(name)),
            ", ".join(self.dependents_for(name)),
            json.dumps(desc.get("config", {}), sort_keys=True),
            json.dumps(desc.get("state", {}), sort_keys=True),
            json.dumps(desc.get("metadata", {}), sort_keys=True),
        )

    def refresh_tree(self) -> None:
        needle = self.filter_var.get().strip().lower()
        existing = set(self.tree.get_children())
        wanted = set()
        for name, desc in sorted(self.rows.items()):
            hay = " ".join([
                name,
                str(desc.get("plugin_type", "")),
                json.dumps(desc.get("config", {}), sort_keys=True),
                json.dumps(desc.get("metadata", {}), sort_keys=True),
            ]).lower()
            if needle and needle not in hay:
                continue
            wanted.add(name)
            values = self.row_values(name, desc)
            if self.tree.exists(name):
                self.tree.item(name, values=values)
            else:
                self.tree.insert("", "end", iid=name, values=values)
        for iid in existing - wanted:
            self.tree.delete(iid)
        self.update_status()

    def selected_name(self) -> str | None:
        selected = self.tree.selection()
        return selected[0] if selected else None

    def selected_record(self) -> dict[str, Any] | None:
        name = self.selected_name()
        if not name:
            return None
        return self.rows.get(name)

    def get_plugin_ui(self, plugin_type: str) -> dict[str, Any]:
        if plugin_type not in self.plugin_ui_cache:
            self.plugin_ui_cache[plugin_type] = self.client.get_plugin_ui(plugin_type)
        return self.plugin_ui_cache[plugin_type]

    def create_parameter(self) -> None:
        plugin_map = self.client.list_plugin_ui()
        choices = sorted(plugin_map)
        if not choices:
            messagebox.showwarning("No plugins", "No plugin UIs are available.", parent=self.root)
            return
        plugin_type = simpledialog.askstring("Create parameter", "Plugin type:\n" + "\n".join(choices), parent=self.root)
        if not plugin_type:
            return
        plugin_type = plugin_type.strip()
        if plugin_type not in plugin_map:
            messagebox.showerror("Unknown type", f"Unknown plugin type: {plugin_type}", parent=self.root)
            return
        dlg = ParameterEditor(self.root, self.client, self.get_plugin_ui(plugin_type), "create")
        self.root.wait_window(dlg)

    def edit_selected(self) -> None:
        record = self.selected_record()
        if not record:
            return
        ui = self.get_plugin_ui(record["plugin_type"])
        dlg = ParameterEditor(self.root, self.client, ui, "edit", record=record)
        self.root.wait_window(dlg)

    def delete_selected(self) -> None:
        name = self.selected_name()
        if not name:
            return
        if messagebox.askyesno("Delete parameter", f"Delete '{name}'?", parent=self.root):
            try:
                self.client.delete_parameter(name)
            except Exception as exc:
                messagebox.showerror("Delete failed", str(exc), parent=self.root)

    def show_snapshot(self) -> None:
        try:
            data = self.client.snapshot()
        except Exception as exc:
            messagebox.showerror("Snapshot failed", str(exc), parent=self.root)
            return
        win = tk.Toplevel(self.root)
        win.title("Snapshot")
        txt = tk.Text(win, wrap="word")
        txt.pack(fill=tk.BOTH, expand=True)
        txt.insert("1.0", json.dumps(data, indent=2, sort_keys=True))

    def update_details(self) -> None:
        self.detail_text.delete("1.0", "end")
        record = self.selected_record()
        if not record:
            return
        name = record["name"]
        payload = {
            "name": name,
            "plugin_type": record.get("plugin_type"),
            "value": record.get("value"),
            "config": record.get("config", {}),
            "state": record.get("state", {}),
            "metadata": record.get("metadata", {}),
            "dependencies": self.deps_for(name),
            "dependents": self.dependents_for(name),
        }
        self.detail_text.insert("1.0", json.dumps(payload, indent=2, sort_keys=True))

    def update_status(self) -> None:
        try:
            stats = self.client.stats()
            self.status_var.set(
                f"Connected | params={len(self.rows)} | cycles={stats.get('cycle_count')} | last_scan={stats.get('last_scan_duration_s'):.6f}s | warnings={len(self.graph.get('warnings', []))}"
            )
        except Exception as exc:
            self.status_var.set(f"Disconnected: {exc}")

    def start_subscription_thread(self) -> None:
        def worker() -> None:
            try:
                with self.client.subscribe(send_initial=False) as sub:
                    for event in sub:
                        if self.stop_flag.is_set():
                            break
                        self.events.put(event)
            except Exception as exc:
                self.events.put({"event": "monitor_error", "error": str(exc)})

        threading.Thread(target=worker, daemon=True).start()

    def process_events(self) -> None:
        graph_dirty = False
        try:
            while True:
                event = self.events.get_nowait()
                et = event.get("event")
                name = event.get("name")
                if et in {"parameter_added", "parameter_snapshot"} and name:
                    record = {
                        "name": name,
                        "plugin_type": event.get("plugin_type"),
                        "value": event.get("value"),
                        "config": event.get("config", {}),
                        "state": event.get("state", {}),
                        "metadata": event.get("metadata", {}),
                    }
                    self.rows[name] = record
                    graph_dirty = True
                elif et == "parameter_removed" and name:
                    self.rows.pop(name, None)
                    graph_dirty = True
                elif et == "value_changed" and name in self.rows:
                    self.rows[name]["value"] = event.get("value")
                elif et == "config_changed" and name in self.rows:
                    self.rows[name]["config"] = event.get("config", {})
                    graph_dirty = True
                elif et == "metadata_changed" and name in self.rows:
                    self.rows[name]["metadata"] = event.get("metadata", {})
                elif et == "state_changed" and name in self.rows:
                    self.rows[name]["state"] = event.get("state", {})
                elif et == "monitor_error":
                    self.status_var.set(f"Disconnected: {event.get('error')}")
                else:
                    continue
        except queue.Empty:
            pass

        if graph_dirty:
            try:
                self.graph = self.client.graph_info()
            except Exception:
                pass
        self.refresh_tree()
        self.update_details()
        self.root.after(150, self.process_events)

    def on_close(self) -> None:
        self.stop_flag.set()
        self.root.destroy()


def main() -> None:
    parser = argparse.ArgumentParser(description="RealtimeDB monitor")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    root = tk.Tk()
    client = SignalClient(args.host, args.port, timeout=5.0)
    MonitorApp(root, client)
    root.mainloop()


if __name__ == "__main__":
    main()
