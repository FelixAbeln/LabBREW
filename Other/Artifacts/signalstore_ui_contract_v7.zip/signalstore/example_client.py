from realtimedb_service.client import SignalClient

c = SignalClient()
print('ping:', c.ping())
print('plugins:', c.list_plugin_types())
print('plugin ui summary:', c.list_plugin_ui())
print('pid ui spec:', c.get_plugin_ui('pid'))

for name, plugin_type, value, config in [
    ('tank.level', 'hold', 10.0, {}),
    ('tank.sp', 'hold', 20.0, {}),
    ('tank.pid', 'pid', 0.0, {
        'pv': 'tank.level',
        'sp': 'tank.sp',
        'kp': 2.0,
        'ki': 0.1,
        'kd': 0.0,
        'out_min': 0.0,
        'out_max': 100.0,
    }),
]:
    try:
        c.create_parameter(name, plugin_type, value=value, config=config)
    except Exception:
        pass

with c.subscribe() as events:
    for event in events:
        print(event)
