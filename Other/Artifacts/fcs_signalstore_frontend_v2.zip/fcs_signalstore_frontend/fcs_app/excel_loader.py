from __future__ import annotations

from dataclasses import dataclass

from openpyxl import load_workbook

from .models import ControllerAction, ScheduleStep


OPERATOR_KEYS = {">=", "<=", ">", "<", "==", "!=", "in_range", "out_of_range", "valid_for"}
LEGACY_ALIAS_KEYS = {"temperature", "pressure", "agitator"}


@dataclass(slots=True)
class ScheduleLoadResult:
    ok: bool
    message: str
    sheet_names: list[str]
    startup_sheet: str
    plan_sheet: str
    startup_steps: list[ScheduleStep]
    plan_steps: list[ScheduleStep]


class ExcelScheduleLoader:
    def __init__(self) -> None:
        self.workbook_path = ""
        self.sheet_names: list[str] = []
        self.startup_sheet = ""
        self.plan_sheet = ""

    def load_workbook(self, path: str, sheet_name: str = "") -> ScheduleLoadResult:
        path = str(path or "").strip()
        if not path:
            return ScheduleLoadResult(False, "No schedule file selected", [], "", "", [], [])
        wb = load_workbook(path, data_only=True)
        self.sheet_names = list(wb.sheetnames)
        if not self.sheet_names:
            return ScheduleLoadResult(False, "Workbook has no sheets", [], "", "", [], [])

        startup_sheet = "StartupRoutine" if "StartupRoutine" in wb.sheetnames else ""
        plan_sheet = "Plan" if "Plan" in wb.sheetnames else ""
        if sheet_name and sheet_name in wb.sheetnames:
            plan_sheet = sheet_name
        if not startup_sheet and not plan_sheet:
            plan_sheet = wb.sheetnames[0]

        startup_steps = self._parse_sheet(wb[startup_sheet]) if startup_sheet else []
        plan_steps = self._parse_sheet(wb[plan_sheet]) if plan_sheet else []
        if not plan_steps and not startup_steps:
            return ScheduleLoadResult(False, "No executable rows found in workbook", self.sheet_names, startup_sheet, plan_sheet, [], [])

        self.workbook_path = path
        self.startup_sheet = startup_sheet
        self.plan_sheet = plan_sheet
        msg = f"Loaded workbook: startup={len(startup_steps)} step(s), plan={len(plan_steps)} step(s)"
        return ScheduleLoadResult(True, msg, self.sheet_names, startup_sheet, plan_sheet, startup_steps, plan_steps)

    def _parse_sheet(self, ws) -> list[ScheduleStep]:
        header_cells = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), None)
        if not header_cells:
            return []
        headers = [str(v).strip() if v is not None else "" for v in header_cells]
        header_map = {h.lower(): i for i, h in enumerate(headers) if h}

        def cell(row, name, default=None):
            idx = header_map.get(name.lower())
            if idx is None or idx >= len(row):
                return default
            value = row[idx]
            return default if value is None else value

        def as_bool(value, default=False):
            if value is None:
                return default
            if isinstance(value, bool):
                return value
            txt = str(value).strip().lower()
            if txt in {"1", "true", "yes", "y", "on"}:
                return True
            if txt in {"0", "false", "no", "n", "off"}:
                return False
            return default

        def as_float(value):
            if value in (None, ""):
                return None
            try:
                return float(value)
            except Exception:
                return None

        steps: list[ScheduleStep] = []
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=0):
            if not any(v not in (None, "") for v in row):
                continue
            valid_sources_raw = cell(row, "valid_sources", "")
            valid_sources = [part.strip() for part in str(valid_sources_raw or "").split(",") if part.strip()]
            explicit_actions = _parse_controller_actions_cell(cell(row, "controller_actions", ""))
            wait_type = _normalize_wait_type(cell(row, "wait_type", "elapsed_time"))
            threshold = _parse_threshold_value(cell(row, "threshold"))
            step = ScheduleStep(
                index=int(cell(row, "order", cell(row, "index", row_idx)) or row_idx),
                enabled=as_bool(cell(row, "enabled", True), True),
                name=str(cell(row, "step_name", cell(row, "name", f"Step {row_idx + 1}")) or f"Step {row_idx + 1}"),
                wait_type=wait_type,
                wait_source=str(cell(row, "wait_source", "") or "").strip(),
                operator=str(cell(row, "operator", ">=") or ">=").strip().lower(),
                threshold=threshold,
                threshold_low=as_float(cell(row, "threshold_low")),
                threshold_high=as_float(cell(row, "threshold_high")),
                duration_s=as_float(cell(row, "duration_s")) if as_float(cell(row, "duration_s")) is not None else as_float(cell(row, "time_s")),
                hold_for_s=max(0.0, (as_float(cell(row, "hold_for_s")) if as_float(cell(row, "hold_for_s")) is not None else (as_float(cell(row, "time_s")) or 0.0))),
                valid_sources=valid_sources,
                require_confirmation=as_bool(cell(row, "require_confirmation", False), False),
                confirmation_message=str(cell(row, "confirmation_message", "") or "").strip(),
                controller_actions=list(explicit_actions),
                notes=str(cell(row, "notes", "") or "").strip(),
            )
            if step.operator not in OPERATOR_KEYS:
                step.operator = ">=" if step.wait_type == "signal" else ("valid_for" if step.wait_type == "all_valid" else step.operator)
            if step.wait_type == "elapsed_time" and step.duration_s is None:
                step.duration_s = max(0.0, float(step.hold_for_s or 0.0))
            elif step.wait_type in {"signal", "all_valid"} and not float(step.hold_for_s or 0.0):
                step.hold_for_s = max(0.0, float(step.duration_s or 0.0))
            if step.confirmation_message or step.wait_type == "confirmation":
                step.require_confirmation = True
                if step.wait_type == "confirmation":
                    step.wait_type = "elapsed_time"
                    step.duration_s = max(0.0, float(step.duration_s or 0.0))
            steps.append(step)
        return steps


def _parse_optional_bool(value):
    if value in (None, ""):
        return None
    txt = str(value).strip().lower()
    if txt in {"", "none", "keep", "default", "inherit"}:
        return None
    if txt in {"1", "true", "yes", "y", "on"}:
        return True
    if txt in {"0", "false", "no", "n", "off"}:
        return False
    return None


def _normalize_wait_type(value: str) -> str:
    txt = str(value or "elapsed_time").strip().lower()
    if txt in {"signal_threshold", "threshold", "twin_threshold"}:
        return "signal"
    if txt in {"valid_all", "valid"}:
        return "all_valid"
    if txt in {"time", "duration"}:
        return "elapsed_time"
    return txt or "elapsed_time"


def _parse_scalar_or_text(value_text: str):
    b = _parse_optional_bool(value_text)
    if b is not None:
        return b
    try:
        return float(value_text.replace(",", "."))
    except Exception:
        return value_text


def _parse_threshold_value(value):
    if value in (None, ""):
        return None
    if isinstance(value, (int, float, bool)):
        return value
    return _parse_scalar_or_text(str(value).strip())


def _parse_controller_action_entry(text: str) -> ControllerAction | None:
    raw = str(text or "").strip()
    if not raw:
        return None
    parts = [part.strip() for part in raw.split(":")]
    if len(parts) < 2:
        return None
    target = parts[0]
    value_text = parts[1]
    ramp = None
    if len(parts) >= 3 and parts[2] not in {"", "-"}:
        try:
            ramp = abs(float(parts[2].replace(",", ".")))
        except Exception:
            ramp = None
    if "." in target:
        # Full ParameterDB path, not a logical controller alias.
        return ControllerAction(
            controller_key=target,
            field="__direct__",
            value=_parse_scalar_or_text(value_text),
            ramp_per_s=ramp,
            raw_value=value_text,
        )
    if target in LEGACY_ALIAS_KEYS:
        field = "command" if target == "agitator" else "setpoint"
        return ControllerAction(
            controller_key=target,
            field=field,
            value=_parse_scalar_or_text(value_text),
            ramp_per_s=ramp,
            raw_value=value_text,
        )
    return ControllerAction(
        controller_key=target,
        field="__direct__",
        value=_parse_scalar_or_text(value_text),
        ramp_per_s=ramp,
        raw_value=value_text,
    )


def _parse_controller_actions_cell(value) -> list[ControllerAction]:
    if value in (None, ""):
        return []
    text = str(value).replace("\n", ";")
    actions: list[ControllerAction] = []
    for chunk in text.split(";"):
        action = _parse_controller_action_entry(chunk)
        if action is not None:
            actions.append(action)
    return actions
