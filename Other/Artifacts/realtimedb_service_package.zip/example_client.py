from realtimedb_service.client import SignalClient


client = SignalClient(host="127.0.0.1", port=8765)

print(client.ping())
client.ensure("tank.level", 20.0, {"unit": "%"})
client.ensure("tank.level_sp", 50.0)
client.ensure("pump.cmd", 0.0)
print(client.snapshot())
