# realtimedb-service

A small Python package that provides:

- a mutable signal store
- a periodic scan engine
- pluggable scan-cycle objects loaded from `.py` files
- a standalone TCP service so other applications/modules can connect and read/write signals

## Why this structure

The service owns the runtime loop and signal memory. Other processes connect through a tiny JSON-over-TCP protocol.

That gives you:

- one independent service process
- many clients
- runtime signal creation
- runtime plugin loading
- pluggable node behavior per scan cycle

## Install

```bash
cd signalstore_pkg
python -m pip install -e .
```

## Run the service

```bash
realtimedb-service --host 127.0.0.1 --port 8765 --period 0.1 --plugin-dir ./plugins
```

## Client example

```python
from realtimedb_service.client import SignalClient

client = SignalClient("127.0.0.1", 8765)
client.ensure("motor.speed", 0.0, {"unit": "rpm"})
client.set("motor.speed", 1200)
print(client.get("motor.speed"))
print(client.snapshot())
```

## Load a plugin at runtime

```python
from realtimedb_service.client import SignalClient

client = SignalClient()
client.ensure("tank.level", 25.0)
client.ensure("tank.level_sp", 50.0)
client.ensure("pump.cmd", 0.0)

client.load_plugin(
    "./plugins/pid_controller.py",
    "PIDController",
    name="level_pid",
    pv="tank.level",
    sp="tank.level_sp",
    out="pump.cmd",
    kp=2.0,
    ki=0.5,
    kd=0.1,
    out_min=0.0,
    out_max=100.0,
)
```

## Boot plugins automatically on service startup

Create `plugins/boot.txt`.

Each line:

```text
pid_controller.py:PIDController:{"name":"level_pid","pv":"tank.level","sp":"tank.level_sp","out":"pump.cmd","kp":2.0,"ki":0.5,"kd":0.1}
```

Then start:

```bash
realtimedb-service --plugin-dir ./plugins
```

## JSON protocol

One JSON object per line.

### Request examples

```json
{"cmd":"ping"}
{"cmd":"get","name":"tank.level"}
{"cmd":"set","name":"tank.level","value":12.3}
{"cmd":"ensure","name":"tank.level_sp","initial":50.0,"metadata":{"unit":"%"}}
{"cmd":"snapshot"}
{"cmd":"load_plugin","pyfile":"./plugins/pid_controller.py","class_name":"PIDController","kwargs":{"name":"level_pid","pv":"tank.level","sp":"tank.level_sp","out":"pump.cmd"}}
```

### Response shape

```json
{"ok":true,"result":...}
```

or

```json
{"ok":false,"error":"..."}
```

## Package layout

```text
realtimedb_service/
  __init__.py
  client.py
  engine.py
  loader.py
  node.py
  protocol.py
  server.py
  service.py
  store.py
  plugins/
    pid_controller.py
```

## Notes

- This is soft real-time, not hard real-time.
- The transport is plain TCP on localhost by default.
- For remote deployment, add authentication/TLS before exposing it on a network.
- Right now writes are immediate and shared globally.

## Good next steps

- subscriptions / change events
- historian / persistence
- typed signals and validation
- permissions / auth
- HTTP or WebSocket gateway
- plugin hot reload
