from __future__ import annotations

import argparse
import signal
from pathlib import Path

from .engine import ScanEngine
from .loader import create_node_from_plugin
from .server import SignalTCPServer


def _load_boot_plugins(engine: ScanEngine, plugin_dir: Path) -> None:
    plugin_dir.mkdir(parents=True, exist_ok=True)
    boot_file = plugin_dir / "boot.txt"
    if not boot_file.exists():
        return

    for raw in boot_file.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # format: path.py:ClassName:{"name":"pid1",...}
        pyfile, class_name, json_kwargs = line.split(":", 2)
        import json
        kwargs = json.loads(json_kwargs)
        node = create_node_from_plugin(str(plugin_dir / pyfile), class_name, **kwargs)
        engine.add_node(node)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the realtime signal store service")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--period", type=float, default=0.1, help="Scan period in seconds")
    parser.add_argument("--plugin-dir", default="./plugins")
    return parser


def main() -> None:
    args = build_arg_parser().parse_args()

    engine = ScanEngine(period_s=args.period)
    plugin_dir = Path(args.plugin_dir)
    _load_boot_plugins(engine, plugin_dir)
    engine.start()

    server = SignalTCPServer(args.host, args.port, engine)

    stop_requested = False

    def _stop(_sig, _frame) -> None:
        nonlocal stop_requested
        stop_requested = True
        server.shutdown()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    try:
        print(f"realtimedb-service listening on {args.host}:{args.port} scan={args.period}s")
        server.serve_forever(poll_interval=0.5)
    finally:
        if stop_requested:
            print("Stopping service...")
        server.server_close()
        engine.stop()


if __name__ == "__main__":
    main()
