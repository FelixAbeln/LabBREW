from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import Optional

from .store import SignalStore


class ScanNode(ABC):
    """Base type for all objects executed each scan cycle."""

    def __init__(self, name: Optional[str] = None, priority: int = 100) -> None:
        self.name = name or f"{self.__class__.__name__}_{uuid.uuid4().hex[:8]}"
        self.priority = priority

    def on_added(self, store: SignalStore) -> None:
        pass

    def on_removed(self, store: SignalStore) -> None:
        pass

    @abstractmethod
    def scan(self, ctx: "ScanContext") -> None:
        raise NotImplementedError
