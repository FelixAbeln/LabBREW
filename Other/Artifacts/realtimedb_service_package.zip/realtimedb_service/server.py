from __future__ import annotations

import socketserver
from typing import Any

from .engine import ScanEngine
from .loader import create_node_from_plugin
from .protocol import ProtocolError, decode_message, encode_message


class RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        while True:
            line = self.rfile.readline()
            if not line:
                break
            try:
                req = decode_message(line)
                resp = self.server.dispatch(req)  # type: ignore[attr-defined]
            except Exception as exc:
                resp = {"ok": False, "error": str(exc)}
            self.wfile.write(encode_message(resp))
            self.wfile.flush()


class SignalTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, host: str, port: int, engine: ScanEngine):
        super().__init__((host, port), RequestHandler)
        self.engine = engine

    def dispatch(self, req: dict[str, Any]) -> dict[str, Any]:
        cmd = req.get("cmd")
        if not cmd:
            raise ProtocolError("Missing 'cmd'")

        store = self.engine.store

        if cmd == "ping":
            return {"ok": True, "result": "pong"}

        if cmd == "stats":
            return {"ok": True, "result": self.engine.stats()}

        if cmd == "list_signals":
            return {"ok": True, "result": store.list_signals()}

        if cmd == "snapshot":
            return {"ok": True, "result": store.snapshot()}

        if cmd == "describe":
            return {"ok": True, "result": store.describe()}

        if cmd == "get":
            name = req["name"]
            default = req.get("default")
            return {"ok": True, "result": store.get(name, default)}

        if cmd == "set":
            store.set(req["name"], req.get("value"))
            return {"ok": True, "result": True}

        if cmd == "ensure":
            name = req["name"]
            initial = req.get("initial")
            metadata = req.get("metadata", {})
            store.ensure(name, initial, **metadata)
            return {"ok": True, "result": True}

        if cmd == "delete":
            store.delete(req["name"])
            return {"ok": True, "result": True}

        if cmd == "list_nodes":
            return {"ok": True, "result": self.engine.list_nodes()}

        if cmd == "load_plugin":
            pyfile = req["pyfile"]
            class_name = req["class_name"]
            kwargs = req.get("kwargs", {})
            node = create_node_from_plugin(pyfile, class_name, **kwargs)
            self.engine.add_node(node)
            return {"ok": True, "result": node.name}

        if cmd == "remove_node":
            self.engine.remove_node(req["name"])
            return {"ok": True, "result": True}

        raise ProtocolError(f"Unknown cmd: {cmd}")
