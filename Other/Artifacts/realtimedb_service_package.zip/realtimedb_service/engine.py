from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Optional

from .node import ScanNode
from .store import SignalStore


@dataclass(slots=True)
class ScanContext:
    now: float
    dt: float
    cycle_count: int
    store: SignalStore


class ScanEngine:
    def __init__(self, period_s: float, store: Optional[SignalStore] = None) -> None:
        self.period_s = period_s
        self.store = store or SignalStore()
        self._nodes: dict[str, ScanNode] = {}
        self._lock = threading.RLock()
        self._running = False
        self._thread: threading.Thread | None = None
        self._cycle_count = 0
        self._last_scan_started_at: float | None = None
        self._last_scan_duration_s = 0.0

    def add_node(self, node: ScanNode) -> str:
        with self._lock:
            if node.name in self._nodes:
                raise ValueError(f"Node '{node.name}' already exists")
            self._nodes[node.name] = node
            node.on_added(self.store)
            return node.name

    def remove_node(self, name: str) -> None:
        with self._lock:
            node = self._nodes.pop(name, None)
        if node is not None:
            node.on_removed(self.store)

    def get_node(self, name: str) -> ScanNode | None:
        with self._lock:
            return self._nodes.get(name)

    def list_nodes(self) -> list[str]:
        with self._lock:
            return sorted(self._nodes.keys())

    def scan_once(self, dt: float) -> None:
        start = time.perf_counter()
        now = time.time()
        self._last_scan_started_at = now

        with self._lock:
            nodes = sorted(self._nodes.values(), key=lambda n: (n.priority, n.name))

        ctx = ScanContext(now=now, dt=dt, cycle_count=self._cycle_count, store=self.store)

        for node in nodes:
            try:
                node.scan(ctx)
            except Exception as exc:
                print(f"[ScanEngine] node '{node.name}' failed: {exc}")

        self._cycle_count += 1
        self._last_scan_duration_s = time.perf_counter() - start

    def _run_loop(self) -> None:
        last = time.perf_counter()
        while self._running:
            start = time.perf_counter()
            dt = start - last
            last = start
            self.scan_once(dt=dt)
            elapsed = time.perf_counter() - start
            time.sleep(max(0.0, self.period_s - elapsed))

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name="ScanEngine", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    @property
    def is_running(self) -> bool:
        return self._running

    def stats(self) -> dict[str, float | int | bool | None]:
        return {
            "running": self._running,
            "period_s": self.period_s,
            "cycle_count": self._cycle_count,
            "last_scan_started_at": self._last_scan_started_at,
            "last_scan_duration_s": self._last_scan_duration_s,
            "node_count": len(self.list_nodes()),
            "signal_count": len(self.store.list_signals()),
        }
