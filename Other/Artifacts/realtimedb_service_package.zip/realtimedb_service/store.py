from __future__ import annotations

from dataclasses import dataclass, field
from threading import RLock
from typing import Any


@dataclass
class Signal:
    name: str
    value: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)


class SignalStore:
    """Thread-safe mutable signal database."""

    def __init__(self) -> None:
        self._signals: dict[str, Signal] = {}
        self._lock = RLock()

    def exists(self, name: str) -> bool:
        with self._lock:
            return name in self._signals

    def create(self, name: str, initial: Any = None, **metadata: Any) -> Signal:
        with self._lock:
            if name in self._signals:
                raise ValueError(f"Signal '{name}' already exists")
            sig = Signal(name=name, value=initial, metadata=dict(metadata))
            self._signals[name] = sig
            return sig

    def ensure(self, name: str, initial: Any = None, **metadata: Any) -> Signal:
        with self._lock:
            if name not in self._signals:
                self._signals[name] = Signal(name=name, value=initial, metadata=dict(metadata))
            else:
                self._signals[name].metadata.update(metadata)
            return self._signals[name]

    def get(self, name: str, default: Any = None) -> Any:
        with self._lock:
            sig = self._signals.get(name)
            return default if sig is None else sig.value

    def get_signal(self, name: str) -> Signal:
        with self._lock:
            if name not in self._signals:
                raise KeyError(name)
            sig = self._signals[name]
            return Signal(name=sig.name, value=sig.value, metadata=dict(sig.metadata))

    def set(self, name: str, value: Any) -> None:
        with self._lock:
            if name not in self._signals:
                self._signals[name] = Signal(name=name, value=value)
            else:
                self._signals[name].value = value

    def update_metadata(self, name: str, **metadata: Any) -> None:
        with self._lock:
            if name not in self._signals:
                raise KeyError(name)
            self._signals[name].metadata.update(metadata)

    def delete(self, name: str) -> None:
        with self._lock:
            self._signals.pop(name, None)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {name: signal.value for name, signal in self._signals.items()}

    def describe(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {
                name: {"value": signal.value, "metadata": dict(signal.metadata)}
                for name, signal in self._signals.items()
            }

    def list_signals(self) -> list[str]:
        with self._lock:
            return sorted(self._signals.keys())
