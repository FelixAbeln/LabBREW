from __future__ import annotations

import socket
from typing import Any

from .protocol import decode_message, encode_message


class SignalClient:
    def __init__(self, host: str = "127.0.0.1", port: int = 8765, timeout: float = 2.0) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout

    def _request(self, payload: dict[str, Any]) -> Any:
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
            sock.sendall(encode_message(payload))
            file = sock.makefile("rb")
            line = file.readline()
            if not line:
                raise RuntimeError("No response from server")
            resp = decode_message(line)
        if not resp.get("ok"):
            raise RuntimeError(resp.get("error", "Unknown server error"))
        return resp.get("result")

    def ping(self) -> str:
        return self._request({"cmd": "ping"})

    def stats(self) -> dict[str, Any]:
        return self._request({"cmd": "stats"})

    def list_signals(self) -> list[str]:
        return self._request({"cmd": "list_signals"})

    def snapshot(self) -> dict[str, Any]:
        return self._request({"cmd": "snapshot"})

    def describe(self) -> dict[str, Any]:
        return self._request({"cmd": "describe"})

    def get(self, name: str, default: Any = None) -> Any:
        return self._request({"cmd": "get", "name": name, "default": default})

    def set(self, name: str, value: Any) -> bool:
        return self._request({"cmd": "set", "name": name, "value": value})

    def ensure(self, name: str, initial: Any = None, metadata: dict[str, Any] | None = None) -> bool:
        return self._request({"cmd": "ensure", "name": name, "initial": initial, "metadata": metadata or {}})

    def delete(self, name: str) -> bool:
        return self._request({"cmd": "delete", "name": name})

    def list_nodes(self) -> list[str]:
        return self._request({"cmd": "list_nodes"})

    def load_plugin(self, pyfile: str, class_name: str, **kwargs: Any) -> str:
        return self._request({"cmd": "load_plugin", "pyfile": pyfile, "class_name": class_name, "kwargs": kwargs})

    def remove_node(self, name: str) -> bool:
        return self._request({"cmd": "remove_node", "name": name})
