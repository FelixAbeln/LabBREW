from __future__ import annotations

import importlib.util
import uuid
from pathlib import Path
from typing import Any

from .node import ScanNode


def load_module_from_pyfile(pyfile: str):
    path = Path(pyfile).resolve()
    module_name = f"plugin_{path.stem}_{uuid.uuid4().hex[:8]}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module from '{pyfile}'")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def create_node_from_plugin(pyfile: str, class_name: str, **kwargs: Any) -> ScanNode:
    module = load_module_from_pyfile(pyfile)
    cls = getattr(module, class_name)
    if not issubclass(cls, ScanNode):
        raise TypeError(f"{class_name} must inherit from ScanNode")
    return cls(**kwargs)
