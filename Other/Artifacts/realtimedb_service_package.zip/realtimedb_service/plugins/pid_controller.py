from __future__ import annotations

from realtimedb_service.engine import ScanContext
from realtimedb_service.node import ScanNode


class PIDController(ScanNode):
    def __init__(
        self,
        name: str,
        pv: str,
        sp: str,
        out: str,
        kp: float = 1.0,
        ki: float = 0.0,
        kd: float = 0.0,
        out_min: float = 0.0,
        out_max: float = 100.0,
        priority: int = 100,
    ) -> None:
        super().__init__(name=name, priority=priority)
        self.pv = pv
        self.sp = sp
        self.out = out
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.out_min = out_min
        self.out_max = out_max
        self._integral = 0.0
        self._prev_error = 0.0

    def on_added(self, store) -> None:
        store.ensure(self.pv, 0.0)
        store.ensure(self.sp, 0.0)
        store.ensure(self.out, 0.0)

    def scan(self, ctx: ScanContext) -> None:
        pv = float(ctx.store.get(self.pv, 0.0))
        sp = float(ctx.store.get(self.sp, 0.0))
        error = sp - pv
        self._integral += error * ctx.dt
        derivative = 0.0 if ctx.dt <= 0 else (error - self._prev_error) / ctx.dt
        value = self.kp * error + self.ki * self._integral + self.kd * derivative
        value = max(self.out_min, min(self.out_max, value))
        ctx.store.set(self.out, value)
        self._prev_error = error
