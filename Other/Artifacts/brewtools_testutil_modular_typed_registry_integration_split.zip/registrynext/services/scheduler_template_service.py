from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from application.queries import ApplicationQueries


class SchedulerTemplateService:
    """Builds and exports scheduler workbook templates.

    This lives outside the GUI so CLI/web/headless clients can generate the
    same workbook without depending on MainWindow or Qt widgets.
    """

    def __init__(self, *, queries: ApplicationQueries) -> None:
        self.queries = queries

    def export_template(self, path: str | Path) -> Path:
        target = Path(path)
        if target.suffix.lower() != '.xlsx':
            target = target.with_suffix('.xlsx')
        wb = Workbook()
        self.populate_workbook(wb)
        wb.save(target)
        return target

    def _style_template_sheet(self, ws, widths: dict[str, float] | None = None, freeze_cell: str = 'A1') -> None:
        header_fill = PatternFill('solid', fgColor='1F4E78')
        header_font = Font(color='FFFFFF', bold=True)
        alt_fill = PatternFill('solid', fgColor='EAF2F8')
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        for row_idx in range(2, ws.max_row + 1):
            if row_idx % 2 == 0:
                for cell in ws[row_idx]:
                    cell.fill = alt_fill
        if widths:
            for col, width in widths.items():
                ws.column_dimensions[col].width = width
        ws.freeze_panes = freeze_cell
        ws.sheet_view.showGridLines = True

    def populate_workbook(self, wb: Workbook) -> None:
        wait_type_rows = [(row.key, row.meaning) for row in self.queries.wait_type_options()]
        schedule_headers = [
            'enabled', 'step_name', 'temp_sp', 'pressure_sp', 'allow_add_gas', 'agitator', 'wait_type',
            'wait_source', 'operator', 'threshold', 'threshold_low', 'threshold_high', 'time_s',
            'valid_sources', 'confirmation_message'
        ]
        ws = wb.active
        ws.title = 'Schedule'
        ws.append(schedule_headers)

        signal_records = sorted(self.queries.signal_records(), key=lambda rec: (rec.key or '', rec.label or ''))
        pressure_key = next((rec.key for rec in signal_records if rec.key.startswith('sensor:pressure:')), 'sensor:pressure:1:1')
        temp_key = next((rec.key for rec in signal_records if rec.key.startswith('sensor:temperature:')), 'sensor:temperature:1:1')
        twin_key = next((rec.key for rec in signal_records if rec.key.startswith('twin:')), 'twin:model_pressure')
        valid_combo = ','.join([k for k in [temp_key, pressure_key, twin_key] if k])
        ws.append([1, 'Pitch yeast', '20:0.05', 0.30, '', '40', 'elapsed_time', '', '>=', '', '', '', 3600, '', 'Pitch Yeast'])
        ws.append([1, 'Ramp pressure naturally', 20.0, '0.80:0.01', 0, '60', 'signal', pressure_key, '>=', 0.75, '', '', 30, pressure_key, ''])
        ws.append([1, 'Wait for fermentation slowdown', '18:0.02', 1.00, '', 'false', 'signal', twin_key, '<=', 1.0, '', '', 300, valid_combo, ''])
        ws.append([1, 'Hold until all signals are valid', 18.0, 1.00, 1, '', 'all_valid', '', 'valid_for', '', '', '', 10, valid_combo, 'Dump trub'])

        self._style_template_sheet(ws, {
            'A': 10, 'B': 28, 'C': 14, 'D': 14, 'E': 14, 'F': 12, 'G': 18, 'H': 34, 'I': 14,
            'J': 12, 'K': 14, 'L': 14, 'M': 12, 'N': 42, 'O': 34,
        }, freeze_cell='A2')

        operator_options = self.queries.operator_options()
        operator_col = get_column_letter(schedule_headers.index('operator') + 1)
        operator_validation = DataValidation(type='list', formula1='=Operators!$A$2:$A$%d' % (len(operator_options) + 1), allow_blank=True)
        operator_validation.promptTitle = 'Valid operators'
        operator_validation.prompt = 'Pick one of the documented operators from the Operators sheet.'
        operator_validation.errorTitle = 'Invalid operator'
        operator_validation.error = 'Choose an operator from the dropdown list.'
        ws.add_data_validation(operator_validation)
        operator_validation.add(f'{operator_col}2:{operator_col}200')

        wait_type_col = get_column_letter(schedule_headers.index('wait_type') + 1)
        wait_type_validation = DataValidation(type='list', formula1="='Wait Types'!$A$2:$A$%d" % (len(wait_type_rows) + 1), allow_blank=True)
        wait_type_validation.promptTitle = 'Valid wait types'
        wait_type_validation.prompt = 'Pick one of the documented wait types from the Wait Types sheet.'
        wait_type_validation.errorTitle = 'Invalid wait type'
        wait_type_validation.error = 'Choose a wait type from the dropdown list.'
        ws.add_data_validation(wait_type_validation)
        wait_type_validation.add(f'{wait_type_col}2:{wait_type_col}200')

        guide = wb.create_sheet('Signal Key Guide')
        guide_headers = ['Signal key', 'Friendly name', 'Unit', 'Quality', 'Current value', 'Source family', 'Notes']
        guide.append(guide_headers)
        for rec in signal_records:
            source_family = str(rec.key).split(':', 1)[0] if rec.key else ''
            notes = ''
            if rec.key.startswith('sensor:temperature:'):
                notes = 'Use for temperature thresholds or valid-source checks'
            elif rec.key.startswith('sensor:pressure:'):
                notes = 'Use for pressure thresholds or valid-source checks'
            elif rec.key.startswith('twin:'):
                notes = 'Twin output variable'
            elif rec.key.startswith('relay:'):
                notes = 'Boolean relay state'
            elif rec.key.startswith('virtual:'):
                notes = 'Controller virtual output'
            elif rec.key.startswith('system:'):
                notes = 'Connected / running state published by services'
            elif rec.key.startswith('agitator:'):
                notes = 'Agitator command, target, duty, or RPM feedback'
            guide.append([rec.key, rec.label, rec.unit, rec.quality, rec.value, source_family, notes])
        self._style_template_sheet(guide, {
            'A': 28, 'B': 42, 'C': 10, 'D': 10, 'E': 16, 'F': 14, 'G': 42,
        }, freeze_cell='A2')

        operators = wb.create_sheet('Operators')
        operators.append(['Operator', 'Meaning', 'Uses threshold/range', 'Uses time_s', 'Example'])
        for row in operator_options:
            operators.append([row.key, row.meaning, 'yes' if row.uses_threshold_or_range else 'no', 'yes' if row.uses_time else 'no', row.example])
        self._style_template_sheet(operators, {'A': 16, 'B': 48, 'C': 20, 'D': 14, 'E': 36}, freeze_cell='A2')

        wait_types = wb.create_sheet('Wait Types')
        wait_types.append(['Wait type', 'Meaning'])
        for row in wait_type_rows:
            wait_types.append(list(row))
        self._style_template_sheet(wait_types, {'A': 18, 'B': 88}, freeze_cell='A2')

        howto = wb.create_sheet('How To Use')
        howto.append(['What to edit', 'Details'])
        rows = [
            ('Schedule sheet', 'Keep row 1 as the header row. Add one recipe step per row starting on row 2.'),
            ('enabled', '1/yes/true enables a step. 0/no/false skips it.'),
            ('temp_sp / pressure_sp', 'Optional setpoints applied while that step is active. Use plain numbers for immediate jumps, or target:rate like 20:0.05 to ramp smoothly at rate-per-second.'),
            ('allow_add_gas', 'Leave blank to keep the current regulator setting. Use 1/yes/on to allow gas addition, or 0/no/off for natural pressure only.'),
            ('agitator', 'Leave blank to keep current agitator command. Use true/false for simple on/off, or a number like 40 for CAN agitator duty cycle percent.'),
            ('wait_type', 'Choose from the dropdown list. Use elapsed_time, signal, or all_valid.'),
            ('wait_source', 'For signal, copy a signal key from the Signal Key Guide sheet.'),
            ('operator', 'Choose from the dropdown list. Safety and Scheduler use the same operator set.'),
            ('threshold / low / high', 'For in_range and out_of_range, fill threshold_low and threshold_high. Otherwise use threshold.'),
            ('time_s', 'Shared time column. For elapsed_time it is the step duration. For threshold waits it is the hold time. For valid_for/all_valid it is the required valid time.'),
            ('valid_sources', 'Comma-separated signal keys that must be GOOD before the step can advance or for all_valid / valid_for checks.'),
            ('confirmation_message', 'If filled, the scheduler pauses at the end of the step and waits for the operator to confirm this message. Leave blank to continue automatically.'),
            ('Operators sheet', 'Explains each supported operator and when to use threshold, range, or time_s.'),
            ('Wait Types sheet', 'Explains each supported wait_type and backs the dropdown list in the Schedule sheet.'),
            ('Discovered signals', 'The Signal Key Guide is generated from the live signals currently discovered by the app.'),
            ('Compatibility', 'Older workbooks using duration_s / hold_for_s, require_confirmation, agitator_on, or agitator_duty_cycle still load.'),
        ]
        for row in rows:
            howto.append(list(row))
        self._style_template_sheet(howto, {'A': 24, 'B': 96}, freeze_cell='A2')
