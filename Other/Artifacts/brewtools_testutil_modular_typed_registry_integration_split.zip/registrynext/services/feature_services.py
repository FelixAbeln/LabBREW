from __future__ import annotations

from dataclasses import dataclass

from services.control_service import DeadbandControlService
from services.digital_twin_service import DigitalTwinService
from services.relay_service import RelayService
from services.safety_service import SafetyService
from services.scheduler_service import SchedulerService
from services.scheduler_template_service import SchedulerTemplateService


@dataclass
class FeatureServices:
    control_service: DeadbandControlService
    safety_service: SafetyService
    digital_twin_service: DigitalTwinService
    relay_service: RelayService
    scheduler_service: SchedulerService
    scheduler_template_service: SchedulerTemplateService
