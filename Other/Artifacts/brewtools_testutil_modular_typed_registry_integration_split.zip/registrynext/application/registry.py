from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from state import AppState
from services.signal_registry import SignalRecord


@dataclass(frozen=True)
class OperatorDefinition:
    key: str
    meaning: str
    uses_threshold_or_range: bool = False
    uses_time: bool = False
    example: str = ''


@dataclass(frozen=True)
class WaitTypeDefinition:
    key: str
    meaning: str


@dataclass(frozen=True)
class SafetyActionDefinition:
    key: str
    label: str


SignalProviderFn = Callable[[AppState], list[SignalRecord]]


@dataclass(frozen=True)
class SignalProviderDefinition:
    key: str
    label: str
    families: tuple[str, ...]
    provider: SignalProviderFn


@dataclass
class AppRegistry:
    operators: dict[str, OperatorDefinition] = field(default_factory=dict)
    wait_types: dict[str, WaitTypeDefinition] = field(default_factory=dict)
    safety_actions: dict[str, SafetyActionDefinition] = field(default_factory=dict)
    signal_providers: dict[str, SignalProviderDefinition] = field(default_factory=dict)
    signal_families: set[str] = field(default_factory=set)

    def register_operator(self, definition: OperatorDefinition) -> None:
        if definition.key in self.operators:
            raise ValueError(f'Duplicate operator registration: {definition.key}')
        self.operators[definition.key] = definition

    def register_wait_type(self, definition: WaitTypeDefinition) -> None:
        if definition.key in self.wait_types:
            raise ValueError(f'Duplicate wait type registration: {definition.key}')
        self.wait_types[definition.key] = definition

    def register_safety_action(self, definition: SafetyActionDefinition) -> None:
        if definition.key in self.safety_actions:
            raise ValueError(f'Duplicate safety action registration: {definition.key}')
        self.safety_actions[definition.key] = definition

    def register_signal_provider(self, definition: SignalProviderDefinition) -> None:
        if definition.key in self.signal_providers:
            raise ValueError(f'Duplicate signal provider registration: {definition.key}')
        duplicate_families = {family for family in definition.families if not family or ':' in family}
        if duplicate_families:
            raise ValueError(f'Invalid signal family names for provider {definition.key}: {sorted(duplicate_families)!r}')
        self.signal_providers[definition.key] = definition
        self.signal_families.update(definition.families)

    def has_operator(self, key: str) -> bool:
        return key in self.operators

    def has_wait_type(self, key: str) -> bool:
        return key in self.wait_types

    def has_safety_action(self, key: str) -> bool:
        return key in self.safety_actions

    def recognizes_signal_key(self, key: str) -> bool:
        if not key:
            return False
        family, _, _ = str(key).partition(':')
        return family in self.signal_families
