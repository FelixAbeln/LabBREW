
from __future__ import annotations

from realtimedb_service.plugin_api import ParameterBase, PluginSpec


class HoldParameter(ParameterBase):
    plugin_type = 'hold'
    display_name = 'Hold Value'
    description = 'Passive retained value written by clients or other parameters.'

    def scan(self, ctx) -> None:
        return


class HoldPlugin(PluginSpec):
    plugin_type = 'hold'
    display_name = 'Hold Value'
    description = 'Passive retained value.'

    def create(self, name, *, config=None, value=None, metadata=None):
        return HoldParameter(name, config=config, value=value, metadata=metadata)


PLUGIN = HoldPlugin()
