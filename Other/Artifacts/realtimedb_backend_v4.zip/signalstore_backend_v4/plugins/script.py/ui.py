# ui.py

def edit_ui(param):
    return None  # fallback to generic editor