from realtimedb_service.plugins.base import ParameterPlugin


class ScriptParameter(ParameterPlugin):
    TYPE = "script"

    def scan(self, param, ctx):
        code = param.config.get("code", "")

        local_ctx = {
            "store": ctx.store,
            "dt": ctx.dt,
            "value": param.value,
        }

        try:
            result = eval(code, {}, local_ctx)
            param.value = result
        except Exception as e:
            param.state["error"] = str(e)