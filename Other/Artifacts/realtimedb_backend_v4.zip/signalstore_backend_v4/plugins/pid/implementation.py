
from __future__ import annotations

from realtimedb_service.plugin_api import ParameterBase, PluginSpec


class PIDParameter(ParameterBase):
    plugin_type = 'pid'
    display_name = 'PID Controller'
    description = 'Self-contained PID using other parameters as references.'

    def on_added(self, store) -> None:
        self.state.setdefault('integral', 0.0)
        self.state.setdefault('prev_error', 0.0)

    def dependencies(self) -> list[str]:
        deps = []
        pv = self.config.get('pv')
        sp = self.config.get('sp')
        mode = self.config.get('mode_param')
        enable = self.config.get('enable_param')
        for name in [pv, sp, mode, enable]:
            if name:
                deps.append(name)
        return deps

    def scan(self, ctx) -> None:
        cfg = self.config
        store = ctx.store
        enable_param = cfg.get('enable_param')
        if enable_param and not bool(store.get_value(enable_param, False)):
            return
        mode_param = cfg.get('mode_param')
        mode = str(store.get_value(mode_param, 'AUTO')) if mode_param else str(cfg.get('mode', 'AUTO'))
        if mode.upper() != 'AUTO':
            return
        pv = float(store.get_value(cfg['pv'], 0.0))
        sp = float(store.get_value(cfg['sp'], 0.0))
        kp = float(cfg.get('kp', 1.0))
        ki = float(cfg.get('ki', 0.0))
        kd = float(cfg.get('kd', 0.0))
        out_min = float(cfg.get('out_min', 0.0))
        out_max = float(cfg.get('out_max', 100.0))
        error = sp - pv
        self.state['integral'] = self.state.get('integral', 0.0) + error * ctx.dt
        derivative = 0.0 if ctx.dt <= 0 else (error - self.state.get('prev_error', 0.0)) / ctx.dt
        out = kp * error + ki * self.state['integral'] + kd * derivative
        out = max(out_min, min(out_max, out))
        self.value = out
        out_param = cfg.get('out_param')
        if out_param:
            store.set_value(out_param, out, source=self.name)
        self.state['pv'] = pv
        self.state['sp'] = sp
        self.state['error'] = error
        self.state['prev_error'] = error


class PIDPlugin(PluginSpec):
    plugin_type = 'pid'
    display_name = 'PID Controller'
    description = 'Closed-loop control against other parameters in the database.'

    def create(self, name, *, config=None, value=None, metadata=None):
        return PIDParameter(name, config=config, value=value, metadata=metadata)

    def default_config(self):
        return {
            'pv': '',
            'sp': '',
            'out_param': '',
            'enable_param': '',
            'mode_param': '',
            'mode': 'AUTO',
            'kp': 1.0,
            'ki': 0.0,
            'kd': 0.0,
            'out_min': 0.0,
            'out_max': 100.0,
        }


PLUGIN = PIDPlugin()
