
from __future__ import annotations

from realtimedb_service.plugin_api import ParameterBase, PluginSpec


class ScriptParameter(ParameterBase):
    plugin_type = 'script'
    display_name = 'Script'
    description = 'Evaluates a Python expression each scan.'

    def dependencies(self) -> list[str]:
        return list(self.config.get('inputs', []))

    def scan(self, ctx) -> None:
        code = self.config.get('code', 'value')
        local_ctx = {
            'store': ctx.store,
            'dt': ctx.dt,
            'value': self.value,
            'inputs': {name: ctx.store.get_value(name) for name in self.config.get('inputs', [])},
        }
        self.value = eval(code, {}, local_ctx)


class ScriptPlugin(PluginSpec):
    plugin_type = 'script'
    display_name = 'Script'
    description = 'Expression-driven calculated value.'

    def create(self, name, *, config=None, value=None, metadata=None):
        return ScriptParameter(name, config=config, value=value, metadata=metadata)

    def default_config(self):
        return {'inputs': [], 'code': 'value'}


PLUGIN = ScriptPlugin()
