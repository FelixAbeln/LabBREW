
from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any

from .store import ParameterStore


@dataclass(slots=True)
class ScanContext:
    now: float
    dt: float
    cycle_count: int
    store: ParameterStore


class ScanEngine:
    def __init__(self, period_s: float, store: ParameterStore | None = None) -> None:
        self.period_s = period_s
        self.store = store or ParameterStore()
        self._running = False
        self._thread: threading.Thread | None = None
        self._cycle_count = 0
        self._last_scan_started_at: float | None = None
        self._last_scan_duration_s = 0.0
        self._full_scan_each_cycle = False

    def _build_graph(self) -> tuple[dict[str, list[str]], dict[str, int]]:
        params = self.store.params_map()
        forward: dict[str, list[str]] = defaultdict(list)
        indegree: dict[str, int] = {name: 0 for name in params}
        for name, param in params.items():
            deps = [d for d in param.dependencies() if d in params and d != name]
            indegree[name] = len(deps)
            for dep in deps:
                forward[dep].append(name)
        return forward, indegree

    def _toposort(self, names: set[str]) -> list[str]:
        params = self.store.params_map()
        forward, indegree_all = self._build_graph()
        indegree = {n: 0 for n in names}
        for n in names:
            indegree[n] = sum(1 for d in params[n].dependencies() if d in names and d != n)
        q = deque(sorted([n for n, deg in indegree.items() if deg == 0]))
        out: list[str] = []
        while q:
            n = q.popleft()
            out.append(n)
            for child in forward.get(n, []):
                if child not in indegree:
                    continue
                indegree[child] -= 1
                if indegree[child] == 0:
                    q.append(child)
        # cycles fall back to stable name order for remaining nodes
        remaining = sorted([n for n in names if n not in out])
        return out + remaining

    def _affected_by_dirty(self, dirty: set[str]) -> set[str]:
        params = self.store.params_map()
        if not dirty or self._full_scan_each_cycle:
            return set(params)
        forward, _ = self._build_graph()
        seen = set(dirty)
        q = deque(dirty)
        while q:
            n = q.popleft()
            for child in forward.get(n, []):
                if child not in seen:
                    seen.add(child)
                    q.append(child)
        return {n for n in seen if n in params}

    def scan_once(self, dt: float) -> None:
        started = time.perf_counter()
        now = time.time()
        self._last_scan_started_at = now
        ctx = ScanContext(now=now, dt=dt, cycle_count=self._cycle_count, store=self.store)
        dirty = self.store.consume_dirty()
        to_scan = self._toposort(self._affected_by_dirty(dirty))
        params = self.store.params_map()
        for name in to_scan:
            param = params.get(name)
            if param is None:
                continue
            old_value = param.get_value()
            old_state = dict(param.state)
            try:
                param.scan(ctx)
            except Exception as exc:
                param.state['last_error'] = str(exc)
            self.store.mark_scanned(name, old_value, param.get_value(), old_state, dict(param.state))
        self._cycle_count += 1
        self._last_scan_duration_s = time.perf_counter() - started

    def _run_loop(self) -> None:
        last = time.perf_counter()
        while self._running:
            start = time.perf_counter()
            dt = start - last
            last = start
            self.scan_once(dt)
            elapsed = time.perf_counter() - start
            time.sleep(max(0.0, self.period_s - elapsed))

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name='ParameterScanEngine', daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    def stats(self) -> dict[str, Any]:
        return {
            'running': self._running,
            'period_s': self.period_s,
            'cycle_count': self._cycle_count,
            'last_scan_started_at': self._last_scan_started_at,
            'last_scan_duration_s': self._last_scan_duration_s,
            'parameter_count': len(self.store.list_names()),
            'full_scan_each_cycle': self._full_scan_each_cycle,
        }
