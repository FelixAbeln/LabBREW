
from __future__ import annotations

import time
from threading import RLock
from typing import Any

from .event_broker import EventBroker
from .plugin_api import ParameterBase


class ParameterStore:
    def __init__(self) -> None:
        self._params: dict[str, ParameterBase] = {}
        self._lock = RLock()
        self._dirty: set[str] = set()
        self._broker = EventBroker()

    @property
    def broker(self) -> EventBroker:
        return self._broker

    def exists(self, name: str) -> bool:
        with self._lock:
            return name in self._params

    def add(self, param: ParameterBase) -> None:
        with self._lock:
            if param.name in self._params:
                raise ValueError(f"Parameter '{param.name}' already exists")
            self._params[param.name] = param
            self._dirty.add(param.name)
        self._publish('parameter_added', param.name, param.get_value(), plugin_type=param.plugin_type)

    def get_param(self, name: str) -> ParameterBase:
        with self._lock:
            try:
                return self._params[name]
            except KeyError as exc:
                raise KeyError(f"Unknown parameter '{name}'") from exc

    def remove(self, name: str) -> ParameterBase | None:
        with self._lock:
            param = self._params.pop(name, None)
            self._dirty.add(name)
        if param is not None:
            self._publish('parameter_removed', name, None, plugin_type=param.plugin_type)
        return param

    def set_value(self, name: str, value: Any, source: str = 'external') -> None:
        with self._lock:
            param = self._params[name]
            old = param.get_value()
            param.set_value(value)
            self._dirty.add(name)
        if old != value:
            self._publish('value_changed', name, value, source=source)

    def get_value(self, name: str, default: Any = None) -> Any:
        with self._lock:
            param = self._params.get(name)
            return default if param is None else param.get_value()

    def update_config(self, name: str, **changes: Any) -> None:
        with self._lock:
            self._params[name].update_config(**changes)
            self._dirty.add(name)
        self._publish('config_changed', name, self._params[name].get_value(), changes=changes)

    def update_metadata(self, name: str, **metadata: Any) -> None:
        with self._lock:
            self._params[name].metadata.update(metadata)
        self._publish('metadata_changed', name, self._params[name].get_value(), changes=metadata)

    def list_names(self) -> list[str]:
        with self._lock:
            return sorted(self._params)

    def records(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {
                name: {
                    'plugin_type': p.plugin_type,
                    'value': p.get_value(),
                    'config': dict(p.config),
                    'state': dict(p.state),
                    'metadata': dict(p.metadata),
                    'dependencies': list(p.dependencies()),
                }
                for name, p in self._params.items()
            }

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {name: p.get_value() for name, p in self._params.items()}

    def items_for_scan(self) -> list[ParameterBase]:
        with self._lock:
            return list(self._params.values())

    def params_map(self) -> dict[str, ParameterBase]:
        with self._lock:
            return dict(self._params)

    def consume_dirty(self) -> set[str]:
        with self._lock:
            dirty = set(self._dirty)
            self._dirty.clear()
            return dirty

    def mark_scanned(self, name: str, old_value: Any, new_value: Any, old_state: dict[str, Any], new_state: dict[str, Any]) -> None:
        changed = old_value != new_value or old_state != new_state
        if changed:
            with self._lock:
                self._dirty.add(name)
            self._publish('scan_update', name, new_value)

    def _publish(self, event_type: str, name: str, value: Any, **extra: Any) -> None:
        self._broker.publish({
            'event': event_type,
            'name': name,
            'value': value,
            'ts': time.time(),
            **extra,
        })
