from __future__ import annotations

import argparse
import importlib.util
import json
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

from .client import SignalClient


class MonitorApp:
    def __init__(self, root: tk.Tk, client: SignalClient, plugin_root: str, refresh_ms: int = 250) -> None:
        self.root = root
        self.client = client
        self.plugin_root = Path(plugin_root)
        self.refresh_ms = refresh_ms
        self.plugin_types: dict[str, dict] = {}

        root.title("RealtimeDB Parameter Monitor")
        root.geometry("1100x560")

        top = ttk.Frame(root, padding=8)
        top.pack(fill=tk.X)
        self.status_var = tk.StringVar(value="Connecting...")
        ttk.Label(top, textvariable=self.status_var).pack(side=tk.LEFT)
        ttk.Button(top, text="New parameter", command=self.create_dialog).pack(side=tk.RIGHT)
        ttk.Button(top, text="Edit selected", command=self.edit_selected).pack(side=tk.RIGHT, padx=(0, 8))

        cols = ("name", "plugin_type", "value", "config", "state")
        self.tree = ttk.Treeview(root, columns=cols, show="headings")
        for col, width in [("name", 220), ("plugin_type", 130), ("value", 160), ("config", 280), ("state", 280)]:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width)
        self.tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self.tree.bind("<Double-1>", lambda _e: self.edit_selected())

        self.root.after(10, self.refresh)

    def refresh(self) -> None:
        try:
            self.plugin_types = self.client.list_plugin_types()
            data = self.client.describe()
            self.status_var.set(f"Connected | parameters={len(data)} | plugin types={len(self.plugin_types)}")
            existing = set(self.tree.get_children())
            seen = set()
            for name in sorted(data):
                desc = data[name]
                row = (
                    name,
                    desc.get("plugin_type", "?"),
                    repr(desc.get("value")),
                    json.dumps(desc.get("config", {}), sort_keys=True),
                    json.dumps(desc.get("state", {}), sort_keys=True),
                )
                if name in existing:
                    self.tree.item(name, values=row)
                else:
                    self.tree.insert("", tk.END, iid=name, values=row)
                seen.add(name)
            for iid in existing - seen:
                self.tree.delete(iid)
        except Exception as exc:
            self.status_var.set(f"Disconnected: {exc}")
        finally:
            self.root.after(self.refresh_ms, self.refresh)

    def selected_name(self) -> str | None:
        selection = self.tree.selection()
        if not selection:
            return None
        return selection[0]

    def create_dialog(self) -> None:
        win = tk.Toplevel(self.root)
        win.title("Create parameter")
        win.geometry("500x220")

        ttk.Label(win, text="Name").pack(anchor="w", padx=10, pady=(10, 0))
        name_var = tk.StringVar()
        ttk.Entry(win, textvariable=name_var).pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Plugin type").pack(anchor="w", padx=10, pady=(10, 0))
        plugin_var = tk.StringVar(value=next(iter(self.plugin_types), "hold"))
        ttk.Combobox(win, textvariable=plugin_var, values=list(self.plugin_types), state="readonly").pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Initial value (JSON)").pack(anchor="w", padx=10, pady=(10, 0))
        value_var = tk.StringVar(value="null")
        ttk.Entry(win, textvariable=value_var).pack(fill=tk.X, padx=10)

        def create() -> None:
            try:
                value = json.loads(value_var.get())
                self.client.create_parameter(name_var.get().strip(), plugin_var.get(), value=value)
                win.destroy()
            except Exception as exc:
                messagebox.showerror("Create failed", str(exc), parent=win)

        ttk.Button(win, text="Create", command=create).pack(anchor="e", padx=10, pady=12)

    def edit_selected(self) -> None:
        name = self.selected_name()
        if not name:
            return
        desc = self.client.describe().get(name)
        if not desc:
            return
        plugin_type = desc.get("plugin_type")
        plugin_info = self.plugin_types.get(plugin_type, {})
        plugin_path = plugin_info.get("plugin_path")
        if plugin_path:
            ui_py = Path(plugin_path) / "ui.py"
            if ui_py.exists():
                spec = importlib.util.spec_from_file_location(f"ui_{plugin_type}", ui_py)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    if hasattr(module, "open_editor"):
                        module.open_editor(self.root, self.client, name, desc)
                        return
        self.default_editor(name, desc)

    def default_editor(self, name: str, desc: dict) -> None:
        win = tk.Toplevel(self.root)
        win.title(f"Edit {name}")
        win.geometry("700x420")

        ttk.Label(win, text=f"Plugin type: {desc.get('plugin_type')}").pack(anchor="w", padx=10, pady=(10, 4))
        ttk.Label(win, text="Value (JSON)").pack(anchor="w", padx=10)
        value_text = tk.Text(win, height=4)
        value_text.pack(fill=tk.X, padx=10)
        value_text.insert("1.0", json.dumps(desc.get("value"), indent=2))

        ttk.Label(win, text="Config (JSON)").pack(anchor="w", padx=10, pady=(10, 0))
        config_text = tk.Text(win, height=10)
        config_text.pack(fill=tk.BOTH, expand=True, padx=10)
        config_text.insert("1.0", json.dumps(desc.get("config", {}), indent=2, sort_keys=True))

        def save() -> None:
            try:
                self.client.set_value(name, json.loads(value_text.get("1.0", "end").strip() or "null"))
                config = json.loads(config_text.get("1.0", "end").strip() or "{}")
                self.client.update_config(name, **config)
                win.destroy()
            except Exception as exc:
                messagebox.showerror("Save failed", str(exc), parent=win)

        ttk.Button(win, text="Save", command=save).pack(anchor="e", padx=10, pady=10)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Open a simple monitor for the realtime database")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--plugin-root", default="./plugins")
    parser.add_argument("--refresh-ms", type=int, default=250)
    return parser


def main() -> None:
    args = build_arg_parser().parse_args()
    root = tk.Tk()
    client = SignalClient(args.host, args.port, timeout=1.0)
    MonitorApp(root, client, plugin_root=args.plugin_root, refresh_ms=args.refresh_ms)
    root.mainloop()


if __name__ == "__main__":
    main()
