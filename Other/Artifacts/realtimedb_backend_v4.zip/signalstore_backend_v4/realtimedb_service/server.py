
from __future__ import annotations

import queue
import socketserver
from pathlib import Path
from typing import Any

from .engine import ScanEngine
from .loader import PluginRegistry, autodiscover_plugins, load_plugin_folder
from .protocol import ProtocolError, encode_message, read_message


class RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        while True:
            try:
                req = read_message(self.rfile)
                if req is None:
                    break
                if req.get('cmd') == 'subscribe':
                    self.server.handle_subscription(self.wfile, req)  # type: ignore[attr-defined]
                    break
                resp = self.server.dispatch(req)  # type: ignore[attr-defined]
            except Exception as exc:
                resp = {'ok': False, 'error': str(exc)}
            self.wfile.write(encode_message(resp))
            self.wfile.flush()


class SignalTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, host: str, port: int, engine: ScanEngine, registry: PluginRegistry):
        super().__init__((host, port), RequestHandler)
        self.engine = engine
        self.registry = registry

    def handle_subscription(self, wfile, req: dict[str, Any]) -> None:
        names = req.get('names')
        send_initial = bool(req.get('send_initial', True))
        token, q = self.engine.store.broker.subscribe(names)
        try:
            wfile.write(encode_message({'ok': True, 'result': {'subscribed': True, 'names': names}}))
            wfile.flush()
            if send_initial:
                records = self.engine.store.records()
                for name, rec in records.items():
                    if names and name not in names:
                        continue
                    wfile.write(encode_message({'ok': True, 'result': {'event': 'snapshot', 'name': name, 'value': rec['value'], 'record': rec}}))
                wfile.flush()
            while True:
                event = q.get(timeout=60.0)
                wfile.write(encode_message({'ok': True, 'result': event}))
                wfile.flush()
        except (BrokenPipeError, ConnectionResetError, queue.Empty):
            return
        finally:
            self.engine.store.broker.unsubscribe(token)

    def dispatch(self, req: dict[str, Any]) -> dict[str, Any]:
        cmd = req.get('cmd')
        if not cmd:
            raise ProtocolError("Missing 'cmd'")
        store = self.engine.store

        if cmd == 'ping':
            return {'ok': True, 'result': 'pong'}
        if cmd == 'stats':
            return {'ok': True, 'result': self.engine.stats()}
        if cmd == 'snapshot':
            return {'ok': True, 'result': store.snapshot()}
        if cmd == 'describe':
            return {'ok': True, 'result': store.records()}
        if cmd == 'list_parameters':
            return {'ok': True, 'result': store.list_names()}
        if cmd == 'list_plugin_types':
            return {'ok': True, 'result': self.registry.list_types()}
        if cmd == 'autodiscover_plugins':
            loaded = autodiscover_plugins(req['root'], self.registry)
            return {'ok': True, 'result': loaded}
        if cmd == 'create_parameter':
            spec = self.registry.get(req['plugin_type'])
            param = spec.create(req['name'], config=req.get('config') or {}, value=req.get('value'), metadata=req.get('metadata') or {})
            store.add(param)
            param.on_added(store)
            return {'ok': True, 'result': True}
        if cmd == 'delete_parameter':
            param = store.remove(req['name'])
            if param is not None:
                param.on_removed(store)
            return {'ok': True, 'result': True}
        if cmd == 'get_value':
            return {'ok': True, 'result': store.get_value(req['name'], req.get('default'))}
        if cmd == 'set_value':
            store.set_value(req['name'], req.get('value'))
            return {'ok': True, 'result': True}
        if cmd == 'update_config':
            store.update_config(req['name'], **(req.get('changes') or {}))
            return {'ok': True, 'result': True}
        if cmd == 'update_metadata':
            store.update_metadata(req['name'], **(req.get('changes') or {}))
            return {'ok': True, 'result': True}
        if cmd == 'load_plugin_folder':
            plugin_type = load_plugin_folder(Path(req['folder']), self.registry)
            return {'ok': True, 'result': plugin_type}
        raise ProtocolError(f'Unknown cmd: {cmd}')
