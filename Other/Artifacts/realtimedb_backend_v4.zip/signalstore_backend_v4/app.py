
import argparse
import signal
import sys
from pathlib import Path

from realtimedb_service.service import build_service


def main():
    parser = argparse.ArgumentParser(description='RealtimeDB Service')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--period', type=float, default=0.05)
    parser.add_argument('--plugin-root', default='./plugins')
    args = parser.parse_args()

    plugin_root = Path(args.plugin_root).resolve()
    plugin_root.mkdir(parents=True, exist_ok=True)
    engine, server, registry, loaded = build_service(args.host, args.port, args.period, str(plugin_root))
    print(f'[INFO] Plugin root: {plugin_root}')
    print(f'[INFO] Loaded plugins: {loaded}')
    engine.start()
    import threading
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    print(f'[INFO] Service running on {args.host}:{args.port}')

    def shutdown(*_):
        print('
[INFO] Shutting down...')
        server.shutdown()
        server.server_close()
        engine.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    signal.pause()


if __name__ == '__main__':
    main()
