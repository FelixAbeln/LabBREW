from __future__ import annotations

from dataclasses import dataclass

from gui.panel_field_models import (
    BrewPanelFields,
    ControlPanelFields,
    RelayPanelFields,
    SafetyPanelFields,
    SchedulerPanelFields,
    TwinPanelFields,
)


@dataclass
class BrewPanelEditor:
    panel: object

    def fields(self) -> BrewPanelFields:
        return BrewPanelFields(self.panel)

    def read_form_state(self):
        return self.fields().read()

    def apply_settings(self, settings) -> None:
        self.fields().apply(settings)


@dataclass
class ControlPanelEditor:
    panel: object
    ui_state: object
    settings: object
    source_controller: object

    def fields(self) -> ControlPanelFields:
        return ControlPanelFields(self.panel)

    def read_form_state(self):
        return self.fields().read(
            settings=self.settings,
            selected_or_pending_source_key=self.source_controller.selected_or_pending_source_key,
            pending_temp_source_key=self.ui_state.pending_temp_source_key,
            pending_pressure_source_key=self.ui_state.pending_pressure_source_key,
        )

    def apply_settings(self, settings) -> None:
        self.fields().apply(settings, self.ui_state)


@dataclass
class RelayPanelEditor:
    panel: object
    relay_channel_rows: dict[int, dict[str, object]]

    def fields(self) -> RelayPanelFields:
        return RelayPanelFields(self.panel, self.relay_channel_rows)

    def read_form_state(self):
        return self.fields().read()

    def apply_settings(self, settings) -> None:
        self.fields().apply(settings)


@dataclass
class SafetyPanelEditor:
    panel: object
    rules_controller: object

    def fields(self) -> SafetyPanelFields:
        return SafetyPanelFields(self.panel, self.rules_controller)

    def read_form_state(self):
        return self.fields().read()

    def apply_settings(self, settings) -> None:
        self.fields().apply(settings)


@dataclass
class SchedulerPanelEditor:
    panel: object

    def fields(self) -> SchedulerPanelFields:
        return SchedulerPanelFields(self.panel)

    def read_form_state(self):
        return self.fields().read()

    def apply_settings(self, settings) -> None:
        self.fields().apply(settings)


@dataclass
class TwinPanelEditor:
    panel: object
    settings: object
    queries: object

    def fields(self) -> TwinPanelFields:
        return TwinPanelFields(self.panel)

    def read_form_state(self):
        return self.fields().read(settings=self.settings, queries=self.queries)

    def apply_settings(self, settings) -> None:
        self.fields().apply(settings)


@dataclass
class MainWindowEditors:
    brew: BrewPanelEditor
    control: ControlPanelEditor
    relay: RelayPanelEditor
    safety: SafetyPanelEditor
    scheduler: SchedulerPanelEditor
    twin: TwinPanelEditor


def build_main_window_editors(window) -> MainWindowEditors:
    return MainWindowEditors(
        brew=BrewPanelEditor(window.brew_panel),
        control=ControlPanelEditor(window.control_panel, window.ui_state, window.settings, window.source_controller),
        relay=RelayPanelEditor(window.relay_panel, window.relay_channel_rows),
        safety=SafetyPanelEditor(window.safety_panel, window.safety_rules_controller),
        scheduler=SchedulerPanelEditor(window.scheduler_panel),
        twin=TwinPanelEditor(window.twin_panel, window.settings, window.queries),
    )
