from __future__ import annotations

from fcs_app.ui import run_ui


if __name__ == "__main__":
    raise SystemExit(run_ui())
