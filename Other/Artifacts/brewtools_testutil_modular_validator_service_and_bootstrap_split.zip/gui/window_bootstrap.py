from __future__ import annotations

from gui.config_adapters import ApplicationConfigBuilder
from gui.config_controller import WindowConfigController
from gui.discovery_controller import WindowDiscoveryController
from gui.device_session_controller import WindowDeviceSessionController
from gui.panel_editors import build_main_window_editors
from gui.panel_facades import build_panel_facades
from gui.runtime_bridge import WindowRuntimeBridge
from gui.safety_rules_controller import SafetyRulesController
from gui.settings_loader import WindowSettingsLoader
from gui.source_controller import WindowSourceController
from gui.ui_state import WindowUIState
from gui.validation_controller import WindowValidationController
from gui.window_session import MainWindowSession
from gui.window_shell import MainWindowShell
from application.normalization import normalize_control_source_key
from gui.constants import OUTPUT_LABELS


class MainWindowBootstrap:
    """Builds and starts the window so MainWindow stays a thin composition root."""

    def __init__(self, window):
        self.window = window

    def initialize(self) -> None:
        w = self.window
        w.ui_state = WindowUIState(
            pending_temp_source_key=normalize_control_source_key(w.settings.temp_controller.source_key),
            pending_pressure_source_key=normalize_control_source_key(w.settings.pressure_controller.source_key),
        )
        w.safety_rules_controller = SafetyRulesController()
        w.OUTPUT_LABELS = OUTPUT_LABELS
        w.relay_channel_rows = {}
        w._config_builder = ApplicationConfigBuilder(w)
        w.config_controller = WindowConfigController(w, w._config_builder)
        w.discovery_controller = WindowDiscoveryController(w)
        w.device_controller = WindowDeviceSessionController(w)
        w.runtime_bridge = WindowRuntimeBridge(w)
        w.source_controller = WindowSourceController(w)
        w.settings_loader = WindowSettingsLoader(w)

        w._panel_facades = build_panel_facades(w)
        w.shell = MainWindowShell(w)
        w.shell.build()
        w.editors = build_main_window_editors(w)
        w.validation_controller = WindowValidationController(w)
        w.session = MainWindowSession(w)
        w.shell.wire_signals()
        w.session.bind_runtime_events()

        self._load_startup_state()
        w.session.start()
        w.session.initial_refresh()

    def _load_startup_state(self) -> None:
        w = self.window
        w.ui_state.loading_settings = True
        try:
            w.discovery_controller.populate_psu_ports()
            w.discovery_controller.populate_channels()
            w.discovery_controller.populate_relay_targets()
            w.settings_loader.apply()
        finally:
            w.ui_state.loading_settings = False
        w.source_controller.refresh_control_sources()
        w.source_controller.refresh_twin_sources()
        w.runtime_bridge.refresh_footer()
        w.commands.set_status_message('Ready. Select PSU port, choose CAN voltage, power the rail, then connect CAN.')
        w.validation_controller.validate_current(decorate=True, show_status=False)
