from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QMessageBox

from helpers import list_kvaser_channels, list_serial_ports
from gui.ui_helpers import find_data_index


class WindowDiscoveryController:
    """Owns GUI-side discovery, picker dialogs, and other UI workflows."""

    def __init__(self, window):
        self.window = window

    def set_status(self, message: str) -> None:
        self.window.commands.set_status_message(str(message))

    def populate_channels(self) -> None:
        combo = self.window.brew_panel.channel_combo
        current = combo.currentData()
        combo.clear()
        bitrate = int(self.window.brew_panel.bitrate.value())
        channels = list_kvaser_channels(bitrate)
        for ch, label in channels:
            combo.addItem(label, ch)
        if current is not None:
            idx = combo.findData(current)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        self.window.config_controller.save_settings()
        self.set_status(f'Channels refreshed: {len(channels)} found (bitrate hint {bitrate}).')

    def populate_psu_ports(self) -> None:
        combo = self.window.brew_panel.psu_port_combo
        current = combo.currentData()
        combo.clear()
        for device, label in list_serial_ports():
            combo.addItem(label, device)
        if current is not None:
            idx = combo.findData(current)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        self.window.config_controller.save_settings()
        self.set_status('PSU ports refreshed.')

    def populate_relay_targets(self) -> None:
        relay_host = self.window.relay_panel.relay_host
        current = relay_host.currentText().strip()
        relay_host.blockSignals(True)
        relay_host.clear()
        targets = self.window.commands.discover_relay_targets()
        for info in targets:
            relay_host.addItem(getattr(info, 'label', str(info)), getattr(info, 'host', str(info)))
        if current:
            idx = relay_host.findData(current)
            if idx >= 0:
                relay_host.setCurrentIndex(idx)
            else:
                relay_host.setEditText(current)
        elif self.window.settings.relay.host:
            relay_host.setEditText(self.window.settings.relay.host)
        relay_host.blockSignals(False)
        self.window.config_controller.save_settings()
        self.set_status(f'Relay targets refreshed: {len(targets)} available.')

    def refresh_scheduler_sheet_combo(self, sheet_names: list[str], target: str = '') -> None:
        self.window.ui_state.loading_scheduler_ui = True
        try:
            combo = self.window.scheduler_panel.scheduler_sheet
            combo.blockSignals(True)
            combo.clear()
            if target and target not in sheet_names:
                combo.addItem(target)
            for name in sheet_names:
                combo.addItem(name)
            if combo.count() == 0:
                combo.addItem('')
            idx = find_data_index(combo, None)
            if target:
                idx = combo.findText(target)
            combo.setCurrentIndex(idx if idx >= 0 else 0)
            combo.blockSignals(False)
        finally:
            self.window.ui_state.loading_scheduler_ui = False

    def create_schedule_template(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self.window,
            'Create schedule template',
            'fermentation_schedule_template.xlsx',
            'Excel Workbook (*.xlsx)',
        )
        if not path:
            return
        result = self.window.commands.export_scheduler_template(path)
        if result.ok:
            final_path = str(result.payload or path)
            self.window.scheduler_panel.scheduler_path.setText(final_path)
            self.window.scheduler_panel.scheduler_file_status.setText(f'Template created: {Path(final_path).name}')
            self.window.config_controller.save_settings()
            return
        QMessageBox.critical(self.window, 'Template error', result.message)
