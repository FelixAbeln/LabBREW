from __future__ import annotations

import socketserver
from pathlib import Path
from typing import Any

from signalstore_core.protocol import (
    encode_message,
    make_error_response,
    make_response,
    read_message,
    validate_request_envelope,
)

from .api import CommandDispatcher, register_all_handlers
from .api.validation import (
    validate_create_parameter,
    validate_delete_parameter,
    validate_empty_ok,
    validate_get_plugin_ui,
    validate_get_value,
    validate_load_plugin_folder,
    validate_set_value,
    validate_subscribe,
    validate_update_changes,
)
from .engine import ScanEngine
from .loader import PluginRegistry, load_plugin_folder


class RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        while True:
            req_id: str | None = None
            try:
                req = read_message(self.rfile)
                if req is None:
                    break

                cmd, req_id, payload = validate_request_envelope(req)

                streaming_handler = self.server.dispatcher.get_streaming_handler(cmd)  # type: ignore[attr-defined]
                if streaming_handler is not None:
                    streaming_handler(self, req_id=req_id, payload=payload)
                    break

                result = self.server.dispatch(cmd, payload)  # type: ignore[attr-defined]
                resp = make_response(req_id=req_id, result=result)
            except Exception as exc:
                resp = make_error_response(
                    req_id=req_id,
                    error_type=exc.__class__.__name__,
                    message=str(exc),
                )

            self.wfile.write(encode_message(resp))
            self.wfile.flush()


class SignalTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, host: str, port: int, engine: ScanEngine, registry: PluginRegistry):
        super().__init__((host, port), RequestHandler)
        self.engine = engine
        self.registry = registry
        self.dispatcher = CommandDispatcher()
        register_all_handlers(self)

    def dispatch(self, cmd: str, payload: dict[str, Any]) -> Any:
        return self.dispatcher.dispatch(cmd, payload)

    # general
    def api_stats(self, payload: dict[str, Any]) -> dict[str, Any]:
        validate_empty_ok(payload)
        return self.engine.stats()

    def api_snapshot(self, payload: dict[str, Any]) -> dict[str, Any]:
        validate_empty_ok(payload)
        return self.engine.store.snapshot()

    def api_describe(self, payload: dict[str, Any]) -> dict[str, Any]:
        validate_empty_ok(payload)
        return self.engine.store.records()

    def api_list_parameters(self, payload: dict[str, Any]) -> list[str]:
        validate_empty_ok(payload)
        return self.engine.store.list_names()

    # graph
    def api_graph_info(self, payload: dict[str, Any]) -> dict[str, Any]:
        validate_empty_ok(payload)
        return self.engine.graph_info()

    # plugins
    def api_list_plugin_types(self, payload: dict[str, Any]) -> dict[str, Any]:
        validate_empty_ok(payload)
        return self.registry.list_types()

    def api_list_plugin_ui(self, payload: dict[str, Any]) -> dict[str, Any]:
        validate_empty_ok(payload)
        return self.registry.list_ui()

    def api_get_plugin_ui(self, payload: dict[str, Any]) -> dict[str, Any]:
        clean = validate_get_plugin_ui(payload)
        return self.registry.get_ui_spec(clean["plugin_type"])

    def api_load_plugin_folder(self, payload: dict[str, Any]) -> str:
        clean = validate_load_plugin_folder(payload)
        return load_plugin_folder(Path(clean["folder"]), self.registry)

    # parameters
    def api_create_parameter(self, payload: dict[str, Any]) -> bool:
        clean = validate_create_parameter(payload)
        store = self.engine.store
        spec = self.registry.get(clean["plugin_type"])
        param = spec.create(
            clean["name"],
            config=clean["config"],
            value=clean["value"],
            metadata=clean["metadata"],
        )
        store.add(param)
        param.on_added(store)
        return True

    def api_delete_parameter(self, payload: dict[str, Any]) -> bool:
        clean = validate_delete_parameter(payload)
        store = self.engine.store
        param = store.remove(clean["name"])
        if param is not None:
            param.on_removed(store)
        return True

    def api_get_value(self, payload: dict[str, Any]) -> Any:
        clean = validate_get_value(payload)
        return self.engine.store.get_value(clean["name"], clean.get("default"))

    def api_set_value(self, payload: dict[str, Any]) -> bool:
        clean = validate_set_value(payload)
        self.engine.store.set_value(clean["name"], clean["value"])
        return True

    def api_update_config(self, payload: dict[str, Any]) -> bool:
        clean = validate_update_changes(payload)
        self.engine.store.update_config(clean["name"], **clean["changes"])
        return True

    def api_update_metadata(self, payload: dict[str, Any]) -> bool:
        clean = validate_update_changes(payload)
        self.engine.store.update_metadata(clean["name"], **clean["changes"])
        return True

    # streaming
    def api_subscribe(self, request_handler: RequestHandler, *, req_id: str | None, payload: dict[str, Any]) -> None:
        clean = validate_subscribe(payload)
        store = self.engine.store
        names = set(clean["names"])
        send_initial = clean["send_initial"]

        q = store.subscribe()
        try:
            request_handler.wfile.write(encode_message(make_response(req_id=req_id, result="subscribed")))
            request_handler.wfile.flush()

            if send_initial:
                current = store.records()
                for name, desc in current.items():
                    if names and name not in names:
                        continue
                    request_handler.wfile.write(encode_message({
                        "event": "parameter_snapshot",
                        "name": name,
                        **desc,
                    }))
                request_handler.wfile.flush()

            while True:
                event = q.get()
                event_name = event.get("name")
                if names and event_name and event_name not in names:
                    continue
                request_handler.wfile.write(encode_message(event))
                request_handler.wfile.flush()

        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            store.unsubscribe(q)
