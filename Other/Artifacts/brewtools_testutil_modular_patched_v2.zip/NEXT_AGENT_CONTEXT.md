# Next agent context

## Current objective
Make controller inventory genuinely operator-defined. The UI should display and edit dynamic controller instances that the operator creates, instead of forcing the codebase to guess a fixed set of controllers.

## What was just fixed
- Restored `StateStore.set_scheduler_runtime()` in `state.py`.
- Audited all `state_store.set_*` call sites and verified there are no remaining missing setter methods on `StateStore`.
- Previous fix restoring `set_controller_instances()`, `set_safety_config()`, `set_safety_runtime()`, `set_twin_config()`, `set_twin_runtime()`, and `set_scheduler_config()` still stands.
- Dynamic-controller dialog still excludes legacy dedicated controllers: `temperature`, `pressure`, and `agitator`.

## Important current stance
- Dynamic inventory should be centered on generic controller types such as deadband / PI(PID).
- Agitator is **not** wanted as a dynamic controller type. Leave it on the dedicated legacy path until that whole path is either removed or intentionally reworked. Do not create new dynamic agitator flows.
- The recent startup errors were caused by incomplete `StateStore` surface restoration during refactor, not by the dynamic-controller concept itself.

## Verified baseline
- `state_store.set_*` call audit is clean: every referenced setter currently exists on `StateStore`.
- That means the next failures, if any, are more likely to be ordinary runtime/UI issues than another missing state API of the same pattern.

## Best next steps
1. Boot the app and confirm the controller inventory table is populated from `AppState.controller_instances` only.
2. Trace any UI code that still synthesizes a built-in controller list instead of querying configured controller instances.
3. Remove or isolate legacy built-in assumptions where safe, especially around control-panel composition, query adapters, and refresh flows.
4. Keep updating `REFACTOR_STATUS.md` after each pass so the migration trail stays readable.

## Watch-outs
- Scheduler compatibility still has legacy temperature/pressure/agitator columns. That is okay for now; avoid breaking workbook loading while cleaning up the live dynamic-controller path.
- Registry still contains dedicated controller definitions for legacy flows because some UI/runtime lookups depend on them. Excluding them from the operator-defined dialog is intentional for now.
- Prefer small traceable deletions over another wide refactor that leaves half-moved or duplicate state methods behind.
