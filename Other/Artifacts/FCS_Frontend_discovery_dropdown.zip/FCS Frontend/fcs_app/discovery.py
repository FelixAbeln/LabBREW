from __future__ import annotations

import socket
import threading
from dataclasses import dataclass
from typing import Any

try:
    from zeroconf import ServiceBrowser, ServiceInfo, ServiceStateChange, Zeroconf
except Exception:  # pragma: no cover - optional dependency
    ServiceBrowser = None
    ServiceInfo = None
    ServiceStateChange = None
    Zeroconf = None


SERVICE_TYPE = "_brewsys._tcp.local."


def _local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
    except OSError:
        ip = "127.0.0.1"
    finally:
        sock.close()
    return ip


def _hostname() -> str:
    return socket.gethostname()


@dataclass(slots=True)
class MdnsAdvertiser:
    service_label: str
    port: int
    path: str = "/status"
    service_type: str = SERVICE_TYPE

    def __post_init__(self) -> None:
        self.zeroconf = Zeroconf() if Zeroconf is not None else None
        self.info: ServiceInfo | None = None

    def start(self) -> bool:
        if self.zeroconf is None or ServiceInfo is None:
            return False

        ip = _local_ip()
        host = _hostname()
        instance_name = f"{host} {self.service_label}.{self.service_type}"
        server_name = f"{host}.local."
        props = {
            b"path": self.path.encode(),
            b"proto": b"http",
            b"hostname": host.encode(),
        }
        self.info = ServiceInfo(
            type_=self.service_type,
            name=instance_name,
            addresses=[socket.inet_aton(ip)],
            port=self.port,
            properties=props,
            server=server_name,
        )
        self.zeroconf.register_service(self.info)
        return True

    def close(self) -> None:
        if self.zeroconf is None:
            return
        if self.info is not None:
            try:
                self.zeroconf.unregister_service(self.info)
            except Exception:
                pass
        self.zeroconf.close()


class MdnsDiscoveryBrowser:
    def __init__(self, service_type: str = SERVICE_TYPE) -> None:
        self.service_type = service_type
        self.zeroconf = Zeroconf() if Zeroconf is not None else None
        self.browser: ServiceBrowser | None = None
        self._lock = threading.Lock()
        self._services: dict[str, dict[str, Any]] = {}

    def start(self) -> bool:
        if self.zeroconf is None or ServiceBrowser is None:
            return False
        if self.browser is None:
            self.browser = ServiceBrowser(self.zeroconf, self.service_type, handlers=[self._on_service_state_change])
        return True

    def _on_service_state_change(self, zeroconf: Zeroconf, service_type: str, name: str, state_change: ServiceStateChange) -> None:
        if ServiceStateChange is None:
            return
        if state_change is ServiceStateChange.Removed:
            with self._lock:
                self._services.pop(name, None)
            return
        info = zeroconf.get_service_info(service_type, name, timeout=1000)
        if info is None:
            return
        address = ""
        if info.addresses:
            try:
                address = socket.inet_ntoa(info.addresses[0])
            except OSError:
                address = ""
        properties = info.properties or {}
        hostname_raw = properties.get(b"hostname", b"")
        hostname = hostname_raw.decode(errors="ignore").strip() if isinstance(hostname_raw, (bytes, bytearray)) else str(hostname_raw).strip()
        if not hostname and info.server:
            hostname = info.server.rstrip(".")
        path_raw = properties.get(b"path", b"")
        path = path_raw.decode(errors="ignore") if isinstance(path_raw, (bytes, bytearray)) else str(path_raw)
        proto_raw = properties.get(b"proto", b"http")
        proto = proto_raw.decode(errors="ignore") if isinstance(proto_raw, (bytes, bytearray)) else str(proto_raw)
        entry = {
            "name": name,
            "host": hostname,
            "address": address,
            "port": info.port,
            "proto": proto or "http",
            "path": path or "/status",
        }
        with self._lock:
            self._services[name] = entry

    def snapshot(self) -> list[dict[str, Any]]:
        with self._lock:
            values = list(self._services.values())
        return sorted(values, key=lambda item: (str(item.get("host") or "").lower(), str(item.get("address") or "")))

    def close(self) -> None:
        if self.zeroconf is None:
            return
        try:
            if self.browser is not None:
                self.browser.cancel()
        except Exception:
            pass
        self.zeroconf.close()
