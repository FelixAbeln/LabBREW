from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from state import AppState
from services.signal_registry import SignalRecord


@dataclass(frozen=True)
class OperatorDefinition:
    key: str
    meaning: str
    uses_threshold_or_range: bool = False
    uses_time: bool = False
    example: str = ''


@dataclass(frozen=True)
class WaitTypeDefinition:
    key: str
    meaning: str


@dataclass(frozen=True)
class SafetyActionDefinition:
    key: str
    label: str


SignalProviderFn = Callable[[AppState], list[SignalRecord]]


@dataclass(frozen=True)
class SignalProviderDefinition:
    key: str
    label: str
    families: tuple[str, ...]
    provider: SignalProviderFn


@dataclass(frozen=True)
class ControllerDefinition:
    key: str
    label: str
    kind: str
    description: str = ''
    source_families: tuple[str, ...] = ()
    target_families: tuple[str, ...] = ()
    setpoint_unit: str = ''
    supports_ramp: bool = False
    value_kind: str = 'setpoint'


@dataclass(frozen=True)
class OutputTargetRecord:
    key: str
    label: str
    family: str
    value_kind: str
    controller_keys: tuple[str, ...] = ()
    unit: str = ''


OutputTargetProviderFn = Callable[[AppState], list[OutputTargetRecord]]


@dataclass(frozen=True)
class OutputTargetProviderDefinition:
    key: str
    label: str
    families: tuple[str, ...]
    provider: OutputTargetProviderFn


@dataclass
class AppRegistry:
    operators: dict[str, OperatorDefinition] = field(default_factory=dict)
    wait_types: dict[str, WaitTypeDefinition] = field(default_factory=dict)
    safety_actions: dict[str, SafetyActionDefinition] = field(default_factory=dict)
    signal_providers: dict[str, SignalProviderDefinition] = field(default_factory=dict)
    signal_families: set[str] = field(default_factory=set)
    controllers: dict[str, ControllerDefinition] = field(default_factory=dict)
    output_target_providers: dict[str, OutputTargetProviderDefinition] = field(default_factory=dict)
    output_target_families: set[str] = field(default_factory=set)

    def register_operator(self, definition: OperatorDefinition) -> None:
        if definition.key in self.operators:
            raise ValueError(f'Duplicate operator registration: {definition.key}')
        self.operators[definition.key] = definition

    def register_wait_type(self, definition: WaitTypeDefinition) -> None:
        if definition.key in self.wait_types:
            raise ValueError(f'Duplicate wait type registration: {definition.key}')
        self.wait_types[definition.key] = definition

    def register_safety_action(self, definition: SafetyActionDefinition) -> None:
        if definition.key in self.safety_actions:
            raise ValueError(f'Duplicate safety action registration: {definition.key}')
        self.safety_actions[definition.key] = definition

    def register_signal_provider(self, definition: SignalProviderDefinition) -> None:
        if definition.key in self.signal_providers:
            raise ValueError(f'Duplicate signal provider registration: {definition.key}')
        families = tuple(str(name).strip() for name in definition.families if str(name).strip())
        invalid = [name for name in families if ':' in name]
        if invalid:
            raise ValueError(f'Invalid signal family names for {definition.key}: {invalid}')
        self.signal_families.update(families)
        self.signal_providers[definition.key] = definition

    def register_controller(self, definition: ControllerDefinition) -> None:
        if definition.key in self.controllers:
            raise ValueError(f'Duplicate controller registration: {definition.key}')
        invalid_sources = [name for name in definition.source_families if ':' in str(name)]
        invalid_targets = [name for name in definition.target_families if ':' in str(name)]
        if invalid_sources:
            raise ValueError(f'Invalid controller source families for {definition.key}: {invalid_sources}')
        if invalid_targets:
            raise ValueError(f'Invalid controller target families for {definition.key}: {invalid_targets}')
        self.controllers[definition.key] = definition

    def register_output_target_provider(self, definition: OutputTargetProviderDefinition) -> None:
        if definition.key in self.output_target_providers:
            raise ValueError(f'Duplicate output-target provider registration: {definition.key}')
        families = tuple(str(name).strip() for name in definition.families if str(name).strip())
        invalid = [name for name in families if ':' in name]
        if invalid:
            raise ValueError(f'Invalid output-target family names for {definition.key}: {invalid}')
        self.output_target_families.update(families)
        self.output_target_providers[definition.key] = definition

    def has_operator(self, key: str) -> bool:
        return key in self.operators

    def has_wait_type(self, key: str) -> bool:
        return key in self.wait_types

    def has_safety_action(self, key: str) -> bool:
        return key in self.safety_actions

    def has_controller(self, key: str) -> bool:
        return key in self.controllers

    def recognizes_signal_key(self, key: str) -> bool:
        if not key:
            return False
        family, _, _ = str(key).partition(':')
        return family in self.signal_families

    def recognizes_output_target_key(self, key: str) -> bool:
        if not key:
            return False
        family, _, _ = str(key).partition(':')
        return family in self.output_target_families
