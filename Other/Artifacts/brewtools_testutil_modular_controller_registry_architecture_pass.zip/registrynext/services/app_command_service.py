from __future__ import annotations

from typing import Callable, Optional

from application.commands import CommandResult
from application.config_models import ApplicationConfigModel
from services.digital_twin_service import DigitalTwinService
from services.relay_service import RelayService
from services.runtime_service import AppRuntimeService
from services.scheduler_service import SchedulerService, ScheduleLoadResult
from services.scheduler_template_service import SchedulerTemplateService
from state import StateStore


class AppCommandService:
    """Explicit application command surface for GUI/CLI/web clients.

    This service is the write-side API for the app. Interface layers should call
    these commands instead of reaching into individual services for mutations.
    """

    def __init__(
        self,
        *,
        state_store: StateStore,
        runtime_service: AppRuntimeService,
        scheduler_service: SchedulerService,
        digital_twin_service: DigitalTwinService,
        relay_service: RelayService,
        scheduler_template_service: SchedulerTemplateService,
        status_callback=None,
        start_scheduler_callback: Optional[Callable[..., tuple[bool, str]]] = None,
        pause_scheduler_callback: Optional[Callable[[], tuple[bool, str]]] = None,
        stop_scheduler_callback: Optional[Callable[[], tuple[bool, str]]] = None,
        previous_scheduler_step_callback: Optional[Callable[[], tuple[bool, str]]] = None,
        next_scheduler_step_callback: Optional[Callable[[], tuple[bool, str]]] = None,
        confirm_scheduler_step_callback: Optional[Callable[[], tuple[bool, str]]] = None,
        apply_configuration_callback: Optional[Callable[[ApplicationConfigModel], tuple[bool, str]]] = None,
        set_status_callback: Optional[Callable[[str], tuple[bool, str]]] = None,
    ) -> None:
        self.state_store = state_store
        self.runtime_service = runtime_service
        self.scheduler_service = scheduler_service
        self.digital_twin_service = digital_twin_service
        self.relay_service = relay_service
        self.scheduler_template_service = scheduler_template_service
        self._status_callback = status_callback
        self._start_scheduler_callback = start_scheduler_callback
        self._pause_scheduler_callback = pause_scheduler_callback
        self._stop_scheduler_callback = stop_scheduler_callback
        self._previous_scheduler_step_callback = previous_scheduler_step_callback
        self._next_scheduler_step_callback = next_scheduler_step_callback
        self._confirm_scheduler_step_callback = confirm_scheduler_step_callback
        self._apply_configuration_callback = apply_configuration_callback
        self._set_status_callback = set_status_callback

    def _emit_status(self, message: str) -> None:
        if self._status_callback is not None:
            self._status_callback(str(message))

    def apply_configuration(self, config: ApplicationConfigModel, *, persist: bool = False) -> CommandResult:
        if self._apply_configuration_callback is None:
            return CommandResult(False, 'Configuration apply is not available.')
        ok, message = self._apply_configuration_callback(config, persist=persist)
        return CommandResult(ok, message)

    def set_status_message(self, message: str) -> CommandResult:
        if self._set_status_callback is None:
            self._emit_status(str(message))
            return CommandResult(True, str(message))
        ok, final_message = self._set_status_callback(str(message))
        return CommandResult(ok, final_message)

    def toggle_psu_power(self) -> CommandResult:
        ok, message = self.runtime_service.toggle_psu_power()
        return CommandResult(ok, message)

    def poll_psu_measurements(self) -> CommandResult:
        self.runtime_service.poll_psu_measurements()
        return CommandResult(True, 'PSU measurements updated.')

    def toggle_can_connection(self) -> CommandResult:
        ok, message = self.runtime_service.toggle_can_connection()
        return CommandResult(ok, message)

    def ensure_can_connected(self) -> CommandResult:
        ok, message = self.runtime_service.ensure_can_connected()
        return CommandResult(ok, message)

    def toggle_relay_connection(self) -> CommandResult:
        ok, message = self.runtime_service.toggle_relay_connection()
        return CommandResult(ok, message)

    def ensure_relays_connected(self) -> CommandResult:
        ok, message = self.runtime_service.ensure_relays_connected()
        return CommandResult(ok, message)

    def evaluate_controls(self) -> CommandResult:
        self.runtime_service.evaluate_controls()
        return CommandResult(True, 'Controls evaluated.')

    def evaluate_scheduler(self) -> CommandResult:
        self.runtime_service.evaluate_scheduler()
        return CommandResult(True, 'Scheduler evaluated.')

    def sync_relays(self) -> CommandResult:
        self.runtime_service.sync_relays()
        return CommandResult(True, 'Relay states synchronized.')

    def on_can_frame(self) -> CommandResult:
        self.runtime_service.on_can_frame()
        return CommandResult(True, 'CAN frame processed.')

    def update_agitator_runtime(self) -> CommandResult:
        self.runtime_service.update_agitator_runtime()
        return CommandResult(True, 'Agitator runtime updated.')

    def discover_relay_targets(self):
        return self.relay_service.discover_targets()

    def set_relay_manual_state(self, channel: int, checked: bool) -> CommandResult:
        self.state_store.set_relay_manual_state(int(channel), bool(checked))
        snap = self.state_store.snapshot()
        state_txt = 'closed' if checked else 'open'
        if snap.relay.connected and self.relay_service.is_connected:
            try:
                if not snap.relay.auto_enabled.get(int(channel), True):
                    self.relay_service.set_channel(int(channel), bool(checked))
                    states = self.relay_service.states()
                    self.state_store.set_relay_state(connected=True, channel_states=states)
                self.runtime_service.sync_relays()
                message = f'Relay {int(channel)} manual command set to {state_txt}.'
                self._emit_status(message)
                return CommandResult(True, message)
            except Exception as exc:
                message = f'Relay error: {exc}'
                self._emit_status(message)
                return CommandResult(False, message)
        self.runtime_service.sync_relays()
        message = f'Relay {int(channel)} manual command set to {state_txt}.'
        self._emit_status(message)
        return CommandResult(True, message)

    def load_twin_model(self, path: str) -> CommandResult:
        ok, message = self.digital_twin_service.load_model(str(path or '').strip())
        self._emit_status(message)
        return CommandResult(ok, message)

    def request_twin_cycle(self) -> CommandResult:
        self.digital_twin_service.request_cycle()
        return CommandResult(True, 'Twin cycle requested.')

    def latest_twin_result(self) -> dict:
        return self.digital_twin_service.latest_result()

    def load_scheduler_workbook(self, path: str, sheet_name: str = '', *, auto_start: bool = False) -> ScheduleLoadResult:
        result = self.scheduler_service.load_workbook(str(path or '').strip(), str(sheet_name or '').strip())
        self._emit_status(result.message)
        if result.ok and auto_start:
            self.scheduler_service.start()
            self.runtime_service.evaluate_scheduler()
        return result

    def export_scheduler_template(self, path: str) -> CommandResult:
        try:
            target = self.scheduler_template_service.export_template(str(path or '').strip())
        except Exception as exc:
            message = f'Scheduler template error: {exc}'
            self._emit_status(message)
            return CommandResult(False, message)
        message = f'Scheduler template written to {target}'
        self._emit_status(message)
        return CommandResult(True, message, payload=str(target))

    def start_scheduler(self, *, skip_startup: bool = False) -> CommandResult:
        if self._start_scheduler_callback is None:
            return CommandResult(False, 'Scheduler start is not available.')
        ok, message = self._start_scheduler_callback(skip_startup=skip_startup)
        return CommandResult(ok, message)

    def pause_scheduler(self) -> CommandResult:
        if self._pause_scheduler_callback is None:
            return CommandResult(False, 'Scheduler pause is not available.')
        ok, message = self._pause_scheduler_callback()
        return CommandResult(ok, message)

    def stop_scheduler(self) -> CommandResult:
        if self._stop_scheduler_callback is None:
            return CommandResult(False, 'Scheduler stop is not available.')
        ok, message = self._stop_scheduler_callback()
        return CommandResult(ok, message)

    def scheduler_previous_step(self) -> CommandResult:
        if self._previous_scheduler_step_callback is None:
            return CommandResult(False, 'Scheduler previous-step command is not available.')
        ok, message = self._previous_scheduler_step_callback()
        return CommandResult(ok, message)

    def scheduler_next_step(self) -> CommandResult:
        if self._next_scheduler_step_callback is None:
            return CommandResult(False, 'Scheduler next-step command is not available.')
        ok, message = self._next_scheduler_step_callback()
        return CommandResult(ok, message)

    def confirm_scheduler_step(self) -> CommandResult:
        if self._confirm_scheduler_step_callback is None:
            return CommandResult(False, 'Scheduler confirm command is not available.')
        ok, message = self._confirm_scheduler_step_callback()
        return CommandResult(ok, message)
