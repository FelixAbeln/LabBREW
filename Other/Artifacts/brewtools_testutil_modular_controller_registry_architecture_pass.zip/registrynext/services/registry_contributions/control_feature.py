from __future__ import annotations

from application.registry import (
    AppRegistry,
    ControllerDefinition,
    OutputTargetProviderDefinition,
    OutputTargetRecord,
    SignalProviderDefinition,
)
from services.signal_registry import SignalRecord
from state import AppState


CONTROL_DEFINITIONS = (
    ControllerDefinition(
        key='temperature',
        label='Temperature controller',
        kind='deadband',
        description='Maintains a temperature setpoint using paired heat/cool outputs.',
        source_families=('sensor', 'twin'),
        target_families=('relay_assignment',),
        setpoint_unit='°C',
        supports_ramp=True,
    ),
    ControllerDefinition(
        key='pressure',
        label='Pressure controller',
        kind='deadband',
        description='Maintains a pressure setpoint using add-gas/remove-gas outputs.',
        source_families=('sensor', 'twin'),
        target_families=('relay_assignment',),
        setpoint_unit='bar',
        supports_ramp=True,
    ),
    ControllerDefinition(
        key='agitator',
        label='Agitator controller',
        kind='duty_or_pid',
        description='Drives the agitator through relay or CAN duty-cycle outputs.',
        source_families=('agitator', 'sensor'),
        target_families=('agitator_target',),
        setpoint_unit='%',
        supports_ramp=False,
        value_kind='command',
    ),
)


def register_control_feature(registry: AppRegistry) -> None:
    registry.register_signal_provider(SignalProviderDefinition(
        key='control.virtual_outputs',
        label='Control runtime outputs and agitator state',
        families=('virtual', 'agitator'),
        provider=_control_signal_records,
    ))
    for definition in CONTROL_DEFINITIONS:
        registry.register_controller(definition)
    registry.register_output_target_provider(OutputTargetProviderDefinition(
        key='control.agitator_targets',
        label='Agitator output targets',
        families=('agitator_target',),
        provider=_agitator_target_records,
    ))


def _control_signal_records(snapshot: AppState) -> list[SignalRecord]:
    return [
        SignalRecord('virtual:heat', 'Virtual — HEAT', snapshot.controls.heat_cool.output_a, 'GOOD', ''),
        SignalRecord('virtual:cool', 'Virtual — COOL', snapshot.controls.heat_cool.output_b, 'GOOD', ''),
        SignalRecord('virtual:add_gas', 'Virtual — ADD GAS', snapshot.controls.gas.output_a, 'GOOD', ''),
        SignalRecord('virtual:remove_gas', 'Virtual — REMOVE GAS', snapshot.controls.gas.output_b, 'GOOD', ''),
        SignalRecord('virtual:agitator', 'Virtual — AGITATOR', snapshot.controls.agitator_runtime.effective_on, 'GOOD', ''),
        SignalRecord('agitator:on', 'Agitator — Command on', snapshot.controls.agitator.on, 'GOOD', ''),
        SignalRecord('agitator:enabled', 'Agitator — Controller enabled', snapshot.controls.agitator.enabled, 'GOOD', ''),
        SignalRecord('agitator:target', 'Agitator — Target selection', snapshot.controls.agitator.target, 'GOOD', ''),
        SignalRecord('agitator:mode', 'Agitator — Control mode', snapshot.controls.agitator.mode, 'GOOD', ''),
        SignalRecord('agitator:duty_cycle', 'Agitator — Effective duty cycle', snapshot.controls.agitator_runtime.effective_duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:configured_duty_cycle', 'Agitator — Configured duty cycle', snapshot.controls.agitator.duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:speed_setpoint_rpm', 'Agitator — Speed setpoint', snapshot.controls.agitator.speed_setpoint_rpm, 'GOOD', 'rpm'),
        SignalRecord('agitator:pid_active', 'Agitator — PID active', snapshot.controls.agitator_runtime.pid_active, 'GOOD', ''),
        SignalRecord('agitator:rpm', 'Agitator — RPM feedback', snapshot.controls.agitator_runtime.rpm_feedback, 'GOOD' if snapshot.controls.agitator_runtime.rpm_feedback is not None else 'MISSING', 'rpm'),
    ]


def _agitator_target_records(snapshot: AppState) -> list[OutputTargetRecord]:
    records = [
        OutputTargetRecord(
            key='relay',
            label='Relay virtual output (AGITATOR)',
            family='agitator_target',
            value_kind='duty_cycle',
            controller_keys=('agitator',),
            unit='%',
        )
    ]
    for st in sorted(snapshot.devices.values(), key=lambda item: item.node_id):
        if int(st.sender_node_type) != 6:
            continue
        label = f'CAN agitator node {st.node_id}'
        if st.rpm is not None:
            label += f' — RPM {st.rpm:.1f}'
        records.append(OutputTargetRecord(
            key=f'can:{int(st.node_id)}',
            label=label,
            family='agitator_target',
            value_kind='duty_cycle',
            controller_keys=('agitator',),
            unit='%',
        ))
    return records
