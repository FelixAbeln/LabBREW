from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field, fields, is_dataclass
from typing import Dict, Optional, Tuple, Any, List

DeviceKey = Tuple[int, int]


@dataclass
class DeviceState:
    sender_node_type: int
    node_id: int
    last_seen: float
    last_obj: Optional[object] = None
    temperature: Optional[float] = None
    pressure: Optional[float] = None
    density: Optional[float] = None
    level: Optional[float] = None
    rpm: Optional[float] = None
    min_val: Optional[float] = None
    max_val: Optional[float] = None


@dataclass
class DeadbandControllerConfig:
    enabled: bool = False
    source_key: Optional[Any] = None
    setpoint: float = 0.0
    deadband: float = 1.0
    allow_add_gas: bool = True


@dataclass
class ControllerIOState:
    process_value: Optional[float] = None
    output_a: bool = False
    output_b: bool = False
    state_text: str = 'Idle'


@dataclass
class AgitatorConfig:
    enabled: bool = False
    target: str = 'relay'
    on: bool = False
    duty_cycle: float = 100.0
    mode: str = 'manual'  # manual | pid
    speed_setpoint_rpm: float = 120.0
    pid_kp: float = 0.30
    pid_ki: float = 0.05
    pid_kd: float = 0.00


@dataclass
class AgitatorRuntimeState:
    effective_on: bool = False
    effective_duty_cycle: float = 0.0
    rpm_feedback: Optional[float] = None
    target_rpm: Optional[float] = None
    pid_active: bool = False
    state_text: str = 'Off'


@dataclass
class RelayConfig:
    host: str = '127.0.0.1'
    tcp_port: int = 502
    connected: bool = False
    channel_count: int = 8
    assignments: Dict[int, Optional[str]] = field(default_factory=lambda: {i: None for i in range(1, 9)})
    auto_enabled: Dict[int, bool] = field(default_factory=lambda: {i: True for i in range(1, 9)})
    manual_states: Dict[int, bool] = field(default_factory=lambda: {i: False for i in range(1, 9)})
    channel_states: Dict[int, bool] = field(default_factory=dict)


@dataclass
class ControlState:
    temperature: DeadbandControllerConfig = field(default_factory=lambda: DeadbandControllerConfig(setpoint=65.0, deadband=1.0))
    pressure: DeadbandControllerConfig = field(default_factory=lambda: DeadbandControllerConfig(setpoint=1.2, deadband=0.1))
    agitator: AgitatorConfig = field(default_factory=AgitatorConfig)
    heat_cool: ControllerIOState = field(default_factory=ControllerIOState)
    gas: ControllerIOState = field(default_factory=ControllerIOState)
    agitator_runtime: AgitatorRuntimeState = field(default_factory=AgitatorRuntimeState)




@dataclass
class SafetyRule:
    name: str = ''
    enabled: bool = True
    signal_key: str = ''
    operator: str = '>'
    threshold: Optional[float] = None
    threshold_low: Optional[float] = None
    threshold_high: Optional[float] = None
    stale_for_s: float = 10.0
    actions: List[str] = field(default_factory=list)

@dataclass
class SafetyConfig:
    enabled: bool = True
    stale_timeout_s: float = 10.0
    min_switch_time_s: float = 3.0
    require_can_connected: bool = True
    require_psu_power: bool = False
    require_relays_connected: bool = False
    max_temperature_enabled: bool = False
    max_temperature_c: float = 35.0
    max_pressure_enabled: bool = False
    max_pressure_bar: float = 2.5
    power_off_psu_on_trip: bool = False
    all_relays_off_on_trip: bool = False
    rules: List[SafetyRule] = field(default_factory=list)
    safe_outputs: Dict[str, bool] = field(default_factory=lambda: {
        'heat': False,
        'cool': False,
        'add_gas': False,
        'remove_gas': False,
        'agitator': False,
    })


@dataclass
class SafetyRuntimeState:
    tripped: bool = False
    reason: str = 'OK'
    active_rules: List[str] = field(default_factory=list)
    active_actions: List[str] = field(default_factory=list)
    effective_outputs: Dict[str, bool] = field(default_factory=lambda: {
        'heat': False,
        'cool': False,
        'add_gas': False,
        'remove_gas': False,
        'agitator': False,
    })




@dataclass
class SchedulerStep:
    index: int
    enabled: bool = True
    name: str = ''
    temperature_setpoint: Optional[float] = None
    temperature_ramp_per_s: Optional[float] = None
    pressure_setpoint: Optional[float] = None
    pressure_ramp_per_s: Optional[float] = None
    allow_add_gas: Optional[bool] = None
    wait_type: str = 'elapsed_time'
    wait_source: str = ''
    operator: str = '>='
    threshold: Optional[float] = None
    threshold_low: Optional[float] = None
    threshold_high: Optional[float] = None
    duration_s: Optional[float] = None
    hold_for_s: float = 0.0
    valid_sources: List[str] = field(default_factory=list)
    require_confirmation: bool = False
    confirmation_message: str = ''
    agitator_on: Optional[bool] = None
    agitator_duty_cycle: Optional[float] = None


@dataclass
class SchedulerConfig:
    enabled: bool = False
    workbook_path: str = ''
    sheet_name: str = ''
    auto_start: bool = False
    steps: List[SchedulerStep] = field(default_factory=list)


@dataclass
class SchedulerRuntimeState:
    running: bool = False
    paused: bool = False
    current_step_index: int = -1
    current_step_name: str = ''
    current_step_started_at_monotonic: Optional[float] = None
    current_step_elapsed_s: float = 0.0
    waiting_reason: str = 'Idle'
    last_transition: str = ''
    hold_elapsed_s: float = 0.0
    schedule_loaded: bool = False
    awaiting_confirmation: bool = False
    confirmation_message: str = ''

@dataclass
class DigitalTwinConfig:
    enabled: bool = True
    fmu_path: str = ''
    input_bindings: Dict[str, Optional[str]] = field(default_factory=dict)


@dataclass
class DigitalTwinRuntimeState:
    input_values: Dict[str, Optional[float]] = field(default_factory=dict)
    outputs: Dict[str, Any] = field(default_factory=lambda: {
        'model_temperature': None,
        'model_pressure': None,
        'heat_request': False,
        'cool_request': False,
        'add_gas_request': False,
        'remove_gas_request': False,
        'status_text': 'Idle',
    })


@dataclass
class AppState:
    can_connected: bool = False
    can_channel_label: str = ''
    can_channel: Optional[int] = None
    can_bitrate: int = 1_000_000

    psu_port: str = ''
    psu_power_on: bool = False
    psu_set_voltage: float = 24.0
    psu_measured_voltage: Optional[float] = None
    psu_measured_current: Optional[float] = None

    relay: RelayConfig = field(default_factory=RelayConfig)
    last_status_message: str = 'Ready.'
    event_log: list[str] = field(default_factory=list)
    devices: Dict[DeviceKey, DeviceState] = field(default_factory=dict)
    controls: ControlState = field(default_factory=ControlState)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    safety_runtime: SafetyRuntimeState = field(default_factory=SafetyRuntimeState)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    scheduler_runtime: SchedulerRuntimeState = field(default_factory=SchedulerRuntimeState)
    twin: DigitalTwinConfig = field(default_factory=DigitalTwinConfig)
    twin_runtime: DigitalTwinRuntimeState = field(default_factory=DigitalTwinRuntimeState)


def _clone_state_value(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return type(value)(**{f.name: _clone_state_value(getattr(value, f.name)) for f in fields(value)})
    if isinstance(value, dict):
        return {_clone_state_value(k): _clone_state_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_clone_state_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_clone_state_value(item) for item in value)
    return value


class StateStore:
    def __init__(self) -> None:
        self._state = AppState()
        self._lock = threading.RLock()

    def snapshot(self) -> AppState:
        with self._lock:
            return _clone_state_value(self._state)

    def set_status(self, message: str) -> None:
        with self._lock:
            self._state.last_status_message = message
            stamp = time.strftime('%H:%M:%S')
            self._state.event_log.append(f'[{stamp}] {message}')
            self._state.event_log = self._state.event_log[-200:]

    def set_can_config(self, *, channel: Optional[int], channel_label: str, bitrate: int) -> None:
        with self._lock:
            self._state.can_channel = channel
            self._state.can_channel_label = channel_label
            self._state.can_bitrate = bitrate

    def set_can_connected(self, connected: bool) -> None:
        with self._lock:
            self._state.can_connected = connected

    def set_psu_config(self, *, port: str, set_voltage: float) -> None:
        with self._lock:
            self._state.psu_port = port
            self._state.psu_set_voltage = set_voltage

    def set_psu_state(self, *, power_on: bool, measured_voltage: Optional[float] = None, measured_current: Optional[float] = None) -> None:
        with self._lock:
            self._state.psu_power_on = power_on
            self._state.psu_measured_voltage = measured_voltage
            self._state.psu_measured_current = measured_current

    def set_relay_config(
        self,
        *,
        host: str,
        tcp_port: int,
        channel_count: int,
        assignments: Dict[int, Optional[str]],
        auto_enabled: Dict[int, bool],
        manual_states: Optional[Dict[int, bool]] = None,
    ) -> None:
        with self._lock:
            self._state.relay.host = host
            self._state.relay.tcp_port = int(tcp_port)
            self._state.relay.channel_count = channel_count
            self._state.relay.assignments = dict(assignments)
            self._state.relay.auto_enabled = dict(auto_enabled)
            if manual_states is not None:
                self._state.relay.manual_states = dict(manual_states)

    def set_relay_manual_state(self, channel: int, active: bool) -> None:
        with self._lock:
            self._state.relay.manual_states[int(channel)] = bool(active)

    def set_relay_state(self, *, connected: bool, channel_states: Optional[Dict[int, bool]] = None) -> None:
        with self._lock:
            self._state.relay.connected = connected
            if channel_states is not None:
                self._state.relay.channel_states = dict(channel_states)

    def set_controller_config(self, name: str, *, enabled: bool, source_key: Optional[DeviceKey], setpoint: float, deadband: float, allow_add_gas: Optional[bool] = None) -> None:
        with self._lock:
            cfg = self._state.controls.temperature if name == 'temperature' else self._state.controls.pressure
            cfg.enabled = enabled
            cfg.source_key = source_key
            cfg.setpoint = setpoint
            cfg.deadband = deadband
            if allow_add_gas is not None and name == 'pressure':
                cfg.allow_add_gas = bool(allow_add_gas)

    def set_controller_outputs(self, name: str, *, process_value: Optional[float], output_a: bool, output_b: bool, state_text: str) -> None:
        with self._lock:
            io = self._state.controls.heat_cool if name == 'temperature' else self._state.controls.gas
            io.process_value = process_value
            io.output_a = output_a
            io.output_b = output_b
            io.state_text = state_text

    def set_agitator_config(self, *, enabled: bool, target: str, on: bool = False, duty_cycle: float = 100.0, mode: str = 'manual', speed_setpoint_rpm: float = 120.0, pid_kp: float = 0.30, pid_ki: float = 0.05, pid_kd: float = 0.00) -> None:
        with self._lock:
            cfg = self._state.controls.agitator
            cfg.enabled = bool(enabled)
            cfg.target = str(target or 'relay')
            cfg.on = bool(on)
            cfg.duty_cycle = max(0.0, min(100.0, float(duty_cycle)))
            cfg.mode = 'pid' if str(mode or 'manual').lower() == 'pid' else 'manual'
            cfg.speed_setpoint_rpm = max(0.0, float(speed_setpoint_rpm))
            cfg.pid_kp = max(0.0, float(pid_kp))
            cfg.pid_ki = max(0.0, float(pid_ki))
            cfg.pid_kd = max(0.0, float(pid_kd))

    def set_agitator_runtime(self, *, effective_on: bool, effective_duty_cycle: float, rpm_feedback: Optional[float] = None, state_text: str = '', target_rpm: Optional[float] = None, pid_active: bool = False) -> None:
        with self._lock:
            rt = self._state.controls.agitator_runtime
            rt.effective_on = bool(effective_on)
            rt.effective_duty_cycle = max(0.0, min(100.0, float(effective_duty_cycle)))
            rt.rpm_feedback = rpm_feedback
            rt.target_rpm = (None if target_rpm is None else max(0.0, float(target_rpm)))
            rt.pid_active = bool(pid_active)
            rt.state_text = str(state_text or '')

    def update_device_from_obj(self, sender_node_type: int, node_id: int, obj: object, now: Optional[float] = None) -> None:
        now = now or time.time()
        key = (sender_node_type, node_id)
        with self._lock:
            st = self._state.devices.get(key)
            if st is None:
                st = DeviceState(sender_node_type=sender_node_type, node_id=node_id, last_seen=now)
                self._state.devices[key] = st
            st.last_seen = now
            st.last_obj = obj

            if hasattr(obj, 'value_c'):
                st.temperature = obj.value_c
            elif hasattr(obj, 'value_bar'):
                st.pressure = obj.value_bar
            elif obj.__class__.__name__ == 'DensityMeasurement':
                st.density = obj.value
            elif obj.__class__.__name__ == 'LevelMeasurement':
                st.level = obj.value
            elif hasattr(obj, 'value_rpm'):
                st.rpm = obj.value_rpm
            elif obj.__class__.__name__ == 'MinValue':
                st.min_val = obj.value
            elif obj.__class__.__name__ == 'MaxValue':
                st.max_val = obj.value

    def update_device_seen(self, sender_node_type: int, node_id: int, obj: Optional[object] = None, now: Optional[float] = None) -> None:
        now = now or time.time()
        key = (sender_node_type, node_id)
        with self._lock:
            st = self._state.devices.get(key)
            if st is None:
                st = DeviceState(sender_node_type=sender_node_type, node_id=node_id, last_seen=now)
                self._state.devices[key] = st
            st.last_seen = now
            st.last_obj = obj


    def set_safety_config(
        self,
        *,
        enabled: bool,
        stale_timeout_s: float,
        min_switch_time_s: float,
        require_can_connected: bool,
        require_psu_power: bool,
        require_relays_connected: bool,
        max_temperature_enabled: bool,
        max_temperature_c: float,
        max_pressure_enabled: bool,
        max_pressure_bar: float,
        power_off_psu_on_trip: bool,
        all_relays_off_on_trip: bool,
        rules: List[SafetyRule],
        safe_outputs: Dict[str, bool],
    ) -> None:
        with self._lock:
            self._state.safety.enabled = bool(enabled)
            self._state.safety.stale_timeout_s = max(0.1, float(stale_timeout_s))
            self._state.safety.min_switch_time_s = max(0.0, float(min_switch_time_s))
            self._state.safety.require_can_connected = bool(require_can_connected)
            self._state.safety.require_psu_power = bool(require_psu_power)
            self._state.safety.require_relays_connected = bool(require_relays_connected)
            self._state.safety.max_temperature_enabled = bool(max_temperature_enabled)
            self._state.safety.max_temperature_c = float(max_temperature_c)
            self._state.safety.max_pressure_enabled = bool(max_pressure_enabled)
            self._state.safety.max_pressure_bar = float(max_pressure_bar)
            self._state.safety.power_off_psu_on_trip = bool(power_off_psu_on_trip)
            self._state.safety.all_relays_off_on_trip = bool(all_relays_off_on_trip)
            self._state.safety.rules = [SafetyRule(
                name=r.name, enabled=r.enabled, signal_key=r.signal_key, operator=r.operator,
                threshold=r.threshold, threshold_low=r.threshold_low, threshold_high=r.threshold_high,
                stale_for_s=r.stale_for_s, actions=list(r.actions)
            ) for r in rules]
            self._state.safety.safe_outputs = dict(safe_outputs)

    def set_safety_runtime(self, *, tripped: bool, reason: str, effective_outputs: Dict[str, bool], active_rules: List[str] | None = None, active_actions: List[str] | None = None) -> None:
        with self._lock:
            self._state.safety_runtime.tripped = bool(tripped)
            self._state.safety_runtime.reason = str(reason)
            self._state.safety_runtime.active_rules = list(active_rules or [])
            self._state.safety_runtime.active_actions = list(active_actions or [])
            self._state.safety_runtime.effective_outputs = dict(effective_outputs)


    def set_twin_config(self, *, enabled: bool, fmu_path: str = '', input_bindings: Dict[str, Optional[str]]) -> None:
        with self._lock:
            self._state.twin.enabled = bool(enabled)
            self._state.twin.fmu_path = str(fmu_path or '')
            self._state.twin.input_bindings = dict(input_bindings)

    def set_twin_runtime(self, *, input_values: Dict[str, Optional[float]], outputs: Dict[str, Any]) -> None:
        with self._lock:
            self._state.twin_runtime.input_values = dict(input_values)
            self._state.twin_runtime.outputs = dict(outputs)


    def set_scheduler_config(self, *, enabled: bool, workbook_path: str, sheet_name: str, auto_start: bool, steps: List[SchedulerStep]) -> None:
        with self._lock:
            self._state.scheduler.enabled = bool(enabled)
            self._state.scheduler.workbook_path = str(workbook_path or '')
            self._state.scheduler.sheet_name = str(sheet_name or '')
            self._state.scheduler.auto_start = bool(auto_start)
            self._state.scheduler.steps = [SchedulerStep(
                index=step.index,
                enabled=step.enabled,
                name=step.name,
                temperature_setpoint=step.temperature_setpoint,
                temperature_ramp_per_s=step.temperature_ramp_per_s,
                pressure_setpoint=step.pressure_setpoint,
                pressure_ramp_per_s=step.pressure_ramp_per_s,
                allow_add_gas=step.allow_add_gas,
                wait_type=step.wait_type,
                wait_source=step.wait_source,
                operator=step.operator,
                threshold=step.threshold,
                threshold_low=step.threshold_low,
                threshold_high=step.threshold_high,
                duration_s=step.duration_s,
                hold_for_s=step.hold_for_s,
                valid_sources=list(step.valid_sources),
                require_confirmation=step.require_confirmation,
                confirmation_message=step.confirmation_message,
                agitator_on=step.agitator_on,
                agitator_duty_cycle=step.agitator_duty_cycle,
            ) for step in steps]

    def set_scheduler_runtime(
        self,
        *,
        running: bool,
        paused: bool,
        current_step_index: int,
        current_step_name: str,
        current_step_started_at_monotonic: Optional[float],
        current_step_elapsed_s: float,
        waiting_reason: str,
        last_transition: str,
        hold_elapsed_s: float,
        schedule_loaded: bool,
        awaiting_confirmation: bool = False,
        confirmation_message: str = '',
    ) -> None:
        with self._lock:
            rt = self._state.scheduler_runtime
            rt.running = bool(running)
            rt.paused = bool(paused)
            rt.current_step_index = int(current_step_index)
            rt.current_step_name = str(current_step_name or '')
            rt.current_step_started_at_monotonic = current_step_started_at_monotonic
            rt.current_step_elapsed_s = float(current_step_elapsed_s)
            rt.waiting_reason = str(waiting_reason or '')
            rt.last_transition = str(last_transition or '')
            rt.hold_elapsed_s = float(hold_elapsed_s)
            rt.schedule_loaded = bool(schedule_loaded)
            rt.awaiting_confirmation = bool(awaiting_confirmation)
            rt.confirmation_message = str(confirmation_message or '')
