from __future__ import annotations

import signal
import time
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QCoreApplication, QTimer, Signal

from application.config_models import ApplicationConfigModel
from application.normalization import normalize_control_source_key
from application.events import ApplicationEvents
from application.registry import AppRegistry
from application.view_models import (
    ControlPanelViewModel,
    DeviceRowViewModel,
    FooterStatusViewModel,
    RelayPanelViewModel,
    SafetyPanelViewModel,
    SchedulerPanelViewModel,
    TwinPanelViewModel,
)
from settings import AppSettings, SettingsManager
from state import SafetyRule, SchedulerStep, StateStore
from services.integrations.can import CANService
from services.features.control import DeadbandControlService, register_control_feature
from services.features.twin import DigitalTwinService, register_twin_feature
from services.integrations.psu import PSUService
from services.features.relay import RelayService, register_relay_feature
from services.core.runtime_service import AppRuntimeService
from services.application.app_command_service import AppCommandService
from services.application.app_query_service import AppQueryService
from services.features.safety import SafetyService, register_safety_feature
from services.features.scheduler import SchedulerService, register_scheduler_feature
from services.application.scheduler_template_service import SchedulerTemplateService
from services.application.config_validation_service import ConfigValidationService
from services.application.settings_mapper_service import SettingsMapperService
from services.core_services import CoreServices
from services.integration_services import IntegrationServices
from services.feature_services import FeatureServices
from services.core.signal_registry_service import SignalRegistryService
from services.signal_registry import configure_signal_registry_service
from services.registry_contributions import register_system_signal_family


class AppCore(QObject):
    status = Signal(str)
    cycle_completed = Signal()
    command_failed = Signal(str, str)
    frame_decoded = Signal(object, object)
    can_connection_changed = Signal(bool)

    def __init__(
        self,
        *,
        settings_path: str | Path | None = None,
        parent: Optional[QObject] = None,
    ) -> None:
        super().__init__(parent)
        self.events = ApplicationEvents(self)
        self.base_dir = Path(__file__).resolve().parent
        self.settings_path = Path(settings_path) if settings_path else (self.base_dir / 'brewtools_can_settings.json')
        self.state_store = StateStore()
        self.settings_manager = SettingsManager(self.settings_path)
        self.settings = self.settings_manager.load()

        self.registry = AppRegistry()
        register_system_signal_family(self.registry)
        register_control_feature(self.registry)
        register_relay_feature(self.registry)
        register_twin_feature(self.registry)
        register_safety_feature(self.registry)
        register_scheduler_feature(self.registry)

        self.core_services = CoreServices(
            signal_registry_service=SignalRegistryService(registry=self.registry),
            settings_mapper=SettingsMapperService(),
            config_validation_service=ConfigValidationService(registry=self.registry),
        )
        self.integration_services = IntegrationServices(
            can_service=CANService(self),
            psu_service=PSUService(),
        )
        self.feature_services = FeatureServices(
            control_service=DeadbandControlService(),
            safety_service=SafetyService(),
            digital_twin_service=DigitalTwinService(),
            relay_service=RelayService(),
            scheduler_service=SchedulerService(),
            scheduler_template_service=None,
        )

        configure_signal_registry_service(self.core_services.signal_registry_service)

        # Compatibility aliases while callers migrate to grouped service ownership.
        self.can_service = self.integration_services.can_service
        self.psu_service = self.integration_services.psu_service
        self.signal_registry_service = self.core_services.signal_registry_service
        self.settings_mapper = self.core_services.settings_mapper
        self.config_validation_service = self.core_services.config_validation_service
        self.control_service = self.feature_services.control_service
        self.safety_service = self.feature_services.safety_service
        self.digital_twin_service = self.feature_services.digital_twin_service
        self.relay_service = self.feature_services.relay_service
        self.scheduler_service = self.feature_services.scheduler_service

        self.runtime_service = AppRuntimeService(
            state_store=self.state_store,
            can_service=self.can_service,
            psu_service=self.psu_service,
            control_service=self.control_service,
            safety_service=self.safety_service,
            digital_twin_service=self.digital_twin_service,
            relay_service=self.relay_service,
            scheduler_service=self.scheduler_service,
            scheduler_override=self._scheduler_runtime_override,
            parent=self,
        )
        self.queries = AppQueryService(
            state_store=self.state_store,
            runtime_service=self.runtime_service,
            scheduler_service=self.scheduler_service,
            digital_twin_service=self.digital_twin_service,
            scheduler_startup_state_callback=self.scheduler_startup_state,
            scheduler_startup_active_callback=self.is_scheduler_startup_active,
            signal_registry_service=self.signal_registry_service,
            registry=self.registry,
        )
        self.scheduler_template_service = SchedulerTemplateService(queries=self.queries)
        self.feature_services.scheduler_template_service = self.scheduler_template_service
        self.commands = AppCommandService(
            state_store=self.state_store,
            runtime_service=self.runtime_service,
            scheduler_service=self.scheduler_service,
            digital_twin_service=self.digital_twin_service,
            relay_service=self.relay_service,
            scheduler_template_service=self.scheduler_template_service,
            status_callback=self.status.emit,
            start_scheduler_callback=self.start_scheduler,
            pause_scheduler_callback=self.pause_scheduler,
            stop_scheduler_callback=self.stop_scheduler,
            previous_scheduler_step_callback=self.scheduler_previous_step,
            next_scheduler_step_callback=self.scheduler_next_step,
            confirm_scheduler_step_callback=self.confirm_scheduler_step,
            apply_configuration_callback=self.apply_configuration,
            set_status_callback=self.set_status_message,
        )

        self._scheduler_startup_active = False
        self._scheduler_startup_deadline = 0.0
        self._scheduler_startup_started_at = 0.0
        self._scheduler_startup_message = ''
        self._scheduler_startup_summary = ''
        self._scheduler_startup_timer = QTimer(self)
        self._scheduler_startup_timer.setInterval(250)
        self._scheduler_startup_timer.timeout.connect(self._advance_scheduler_startup)

        self.runtime_service.status.connect(self.status)
        self.runtime_service.cycle_completed.connect(self._on_runtime_cycle_completed)
        self.runtime_service.command_failed.connect(self.command_failed)
        self.can_service.frame_received.connect(self._on_can_frame)
        self.can_service.status.connect(self.status)
        self.can_service.connection_changed.connect(self._on_can_connection_changed)

        self.status.connect(self.events.status)
        self.cycle_completed.connect(self.events.cycle_completed)
        self.command_failed.connect(self.events.command_failed)
        self.frame_decoded.connect(self.events.frame_decoded)
        self.can_connection_changed.connect(self.events.can_connection_changed)

        self._last_footer_vm: FooterStatusViewModel | None = None
        self._last_device_rows: list[DeviceRowViewModel] | None = None
        self._last_control_vm: ControlPanelViewModel | None = None
        self._last_safety_vm: SafetyPanelViewModel | None = None
        self._last_twin_vm: TwinPanelViewModel | None = None
        self._last_scheduler_vm: SchedulerPanelViewModel | None = None
        self._last_relay_vm: RelayPanelViewModel | None = None
        self._last_signal_keys: list[str] | None = None

        self.apply_settings(self.settings)
        self._seed_intent_view_state()

    def _signal_keys_snapshot(self) -> list[str]:
        return [str(rec.key) for rec in self.queries.signal_records()]

    def _seed_intent_view_state(self) -> None:
        self._last_footer_vm = self.queries.footer_status()
        self._last_device_rows = self.queries.device_rows()
        self._last_control_vm = self.queries.control_panel()
        self._last_safety_vm = self.queries.safety_panel()
        self._last_twin_vm = self.queries.twin_panel()
        self._last_scheduler_vm = self.queries.scheduler_panel()
        self._last_relay_vm = self.queries.relay_panel()
        self._last_signal_keys = self._signal_keys_snapshot()

    def _emit_intent_events(self, *, include_devices: bool = False, include_signal_registry: bool = False) -> None:
        footer_vm = self.queries.footer_status()
        if footer_vm != self._last_footer_vm:
            self._last_footer_vm = footer_vm
            self.events.footer_changed.emit()

        if include_devices:
            device_rows = self.queries.device_rows()
            if device_rows != self._last_device_rows:
                self._last_device_rows = device_rows
                self.events.device_rows_changed.emit()

        control_vm = self.queries.control_panel()
        if control_vm != self._last_control_vm:
            self._last_control_vm = control_vm
            self.events.control_changed.emit()

        safety_vm = self.queries.safety_panel()
        if safety_vm != self._last_safety_vm:
            self._last_safety_vm = safety_vm
            self.events.safety_changed.emit()

        twin_vm = self.queries.twin_panel()
        if twin_vm != self._last_twin_vm:
            self._last_twin_vm = twin_vm
            self.events.twin_changed.emit()

        scheduler_vm = self.queries.scheduler_panel()
        if scheduler_vm != self._last_scheduler_vm:
            self._last_scheduler_vm = scheduler_vm
            self.events.scheduler_changed.emit()

        relay_vm = self.queries.relay_panel()
        if relay_vm != self._last_relay_vm:
            self._last_relay_vm = relay_vm
            self.events.relay_changed.emit()

        if include_signal_registry:
            signal_keys = self._signal_keys_snapshot()
            if signal_keys != self._last_signal_keys:
                self._last_signal_keys = signal_keys
                self.events.signal_registry_changed.emit()

    def _on_runtime_cycle_completed(self) -> None:
        self.cycle_completed.emit()
        self._emit_intent_events()

    def _on_can_connection_changed(self, connected: bool) -> None:
        self.state_store.set_can_connected(bool(connected))
        self.can_connection_changed.emit(bool(connected))
        self._emit_intent_events()

    def _on_can_frame(self, frame, obj) -> None:
        sender_node_type = int(frame.can_id.sender_node_type)
        node_id = int(frame.can_id.secondary_node_id)
        now = time.time()
        if obj is not None:
            self.state_store.update_device_from_obj(sender_node_type, node_id, obj, now)
        else:
            self.state_store.update_device_seen(sender_node_type, node_id, obj, now)
        self.can_service.note_decoded_frame(frame, obj)
        self.frame_decoded.emit(frame, obj)
        self.events.device_rows_changed.emit()
        signal_keys = self._signal_keys_snapshot()
        if signal_keys != self._last_signal_keys:
            self._last_signal_keys = signal_keys
            self.events.signal_registry_changed.emit()
        self.runtime_service.on_can_frame()

    def apply_settings(self, settings: Optional[AppSettings] = None) -> None:
        self.settings = settings or self.settings_manager.load()
        channel_label = f'Channel {self.settings.can_channel}' if self.settings.can_channel is not None else ''
        self.settings_mapper.apply_settings_to_state(self.state_store, self.settings, can_channel_label=channel_label)
        self._load_supporting_models()
        self.runtime_service.evaluate_scheduler()
        self.runtime_service.evaluate_controls()
        self.runtime_service.sync_relays()
        self._emit_intent_events(include_devices=True, include_signal_registry=True)

    def apply_configuration(self, config: ApplicationConfigModel, *, persist: bool = False) -> tuple[bool, str]:
        validation = self.config_validation_service.validate(config)
        if not validation.is_valid:
            return False, validation.summary()
        settings = self.settings_mapper.config_to_settings(config)
        relay_manual_states = {int(k): bool(v) for k, v in (config.relay.manual_states or {}).items()}
        self.settings = settings
        self.settings_mapper.apply_settings_to_state(
            self.state_store,
            settings,
            can_channel_label=str(config.can_channel_label or ''),
            relay_manual_states=relay_manual_states,
        )
        if persist:
            self.settings_manager.save(settings)
        self.runtime_service.evaluate_scheduler()
        self.runtime_service.evaluate_controls()
        self.runtime_service.sync_relays()
        self._emit_intent_events(include_devices=True, include_signal_registry=True)
        return True, 'Configuration applied.' if not persist else 'Configuration saved.'

    def set_status_message(self, message: str) -> tuple[bool, str]:
        self.state_store.set_status(str(message))
        self.status.emit(str(message))
        return True, str(message)

    def _load_supporting_models(self) -> None:
        twin_path = str(self.settings.twin.fmu_path or '').strip()
        if twin_path:
            result = self.commands.load_twin_model(twin_path)
            self.status.emit(result.message)
        workbook = str(self.settings.scheduler.workbook_path or '').strip()
        if workbook:
            try:
                result = self.scheduler_service.load_workbook(workbook, str(self.settings.scheduler.sheet_name or ''))
                self.status.emit(result.message)
            except Exception as exc:
                self.status.emit(f'Schedule load failed: {exc}')

    def start(self) -> None:
        self.runtime_service.start()
        self.digital_twin_service.start_background(self.state_store.snapshot, period_s=0.25)

    def stop(self) -> None:
        self._cancel_scheduler_startup()
        self.runtime_service.stop()
        self.digital_twin_service.stop_background()
        try:
            if self.state_store.snapshot().psu_power_on:
                self.psu_service.power_off()
        except Exception:
            pass
        self.psu_service.close()
        self.relay_service.close()
        self.can_service.disconnect_bus()

    def run_headless_bootstrap(self) -> None:
        self.start()
        should_start_scheduler = bool(getattr(self.settings.scheduler, 'enabled', False) and getattr(self.settings.scheduler, 'auto_start', False))
        if should_start_scheduler:
            ok, message = self.start_scheduler()
            self.status.emit(message)
        self.status.emit('Headless core started.')


    def scheduler_startup_state(self) -> dict:
        return {
            'active': bool(self._scheduler_startup_active),
            'started_at': float(self._scheduler_startup_started_at),
            'deadline': float(self._scheduler_startup_deadline),
            'message': str(self._scheduler_startup_message or ''),
            'summary': str(self._scheduler_startup_summary or ''),
        }

    def is_scheduler_startup_active(self) -> bool:
        return bool(self._scheduler_startup_active)

    def _scheduler_has_startup_sequence(self) -> bool:
        sched = self.settings.scheduler
        return bool(
            getattr(sched, 'startup_sequence_enabled', False) and (
                getattr(sched, 'startup_auto_connect_relays', False)
                or getattr(sched, 'startup_auto_connect_can', False)
                or getattr(sched, 'startup_auto_power_psu', False)
                or getattr(sched, 'startup_auto_load_twin', False)
                or float(getattr(sched, 'startup_delay_s', 0.0) or 0.0) > 0.0
            )
        )

    def _cancel_scheduler_startup(self) -> None:
        self._scheduler_startup_active = False
        self._scheduler_startup_deadline = 0.0
        self._scheduler_startup_started_at = 0.0
        self._scheduler_startup_message = ''
        self._scheduler_startup_summary = ''
        self._scheduler_startup_timer.stop()

    def _complete_scheduler_startup(self) -> tuple[bool, str]:
        self._cancel_scheduler_startup()
        ok, message = self.scheduler_service.start()
        self.status.emit(message)
        self.runtime_service.evaluate_scheduler()
        return ok, message

    def _advance_scheduler_startup(self) -> None:
        if not self._scheduler_startup_active:
            self._scheduler_startup_timer.stop()
            return
        self.runtime_service.evaluate_scheduler()

    def _scheduler_runtime_override(self) -> Optional[dict]:
        if not self._scheduler_startup_active:
            return None
        now = time.monotonic()
        remaining = max(0.0, self._scheduler_startup_deadline - now)
        elapsed = max(0.0, now - self._scheduler_startup_started_at)
        total = max(elapsed + remaining, 0.0)
        self._scheduler_startup_message = f'Starting up… settling {elapsed:.1f}/{total:.1f} s'
        if remaining <= 0.0:
            QTimer.singleShot(0, self._complete_scheduler_startup)
            return {
                'running': False,
                'paused': False,
                'current_step_index': -1,
                'current_step_name': '',
                'current_step_started_at_monotonic': None,
                'current_step_elapsed_s': 0.0,
                'waiting_reason': 'Finalizing startup…',
                'last_transition': self._scheduler_startup_summary or 'Startup sequence active',
                'hold_elapsed_s': 0.0,
                'schedule_loaded': bool(self.scheduler_service.steps),
                'awaiting_confirmation': False,
                'confirmation_message': '',
                'active_temperature_setpoint': None,
                'active_pressure_setpoint': None,
                'active_allow_add_gas': None,
                'active_agitator_on': None,
                'active_agitator_duty_cycle': None,
            }
        return {
            'running': False,
            'paused': False,
            'current_step_index': -1,
            'current_step_name': '',
            'current_step_started_at_monotonic': None,
            'current_step_elapsed_s': 0.0,
            'waiting_reason': self._scheduler_startup_message,
            'last_transition': self._scheduler_startup_summary or 'Startup sequence active',
            'hold_elapsed_s': 0.0,
            'schedule_loaded': bool(self.scheduler_service.steps),
            'awaiting_confirmation': False,
            'confirmation_message': '',
            'active_temperature_setpoint': None,
            'active_pressure_setpoint': None,
            'active_allow_add_gas': None,
            'active_agitator_on': None,
            'active_agitator_duty_cycle': None,
        }

    def start_scheduler(self, *, skip_startup: bool = False) -> tuple[bool, str]:
        if self._scheduler_startup_active:
            return True, self._scheduler_startup_message or 'Startup sequence running'
        if not skip_startup and self._scheduler_has_startup_sequence():
            actions: list[str] = []
            sched = self.settings.scheduler
            try:
                if getattr(sched, 'startup_auto_connect_relays', False):
                    result = self.commands.ensure_relays_connected()
                    if not result.ok:
                        return False, result.message
                    actions.append(result.message)
                if getattr(sched, 'startup_auto_connect_can', False):
                    result = self.commands.ensure_can_connected()
                    if not result.ok:
                        return False, result.message
                    actions.append(result.message)
                if getattr(sched, 'startup_auto_power_psu', False):
                    snap = self.state_store.snapshot()
                    if not snap.psu_power_on:
                        result = self.commands.toggle_psu_power()
                        if not result.ok:
                            return False, result.message
                        actions.append(result.message)
                    else:
                        actions.append('PSU already on')
                if getattr(sched, 'startup_auto_load_twin', False):
                    twin_path = str(self.settings.twin.fmu_path or '').strip()
                    if not twin_path:
                        return False, 'No FMU selected'
                    result = self.commands.load_twin_model(twin_path)
                    if not result.ok:
                        return False, result.message
                    actions.append(result.message)
                    self.status.emit(result.message)
            except Exception as exc:
                return False, str(exc)
            delay = max(0.0, float(getattr(sched, 'startup_delay_s', 0.0) or 0.0))
            if delay <= 0.0:
                return self._complete_scheduler_startup()
            self._scheduler_startup_active = True
            self._scheduler_startup_started_at = time.monotonic()
            self._scheduler_startup_deadline = self._scheduler_startup_started_at + delay
            self._scheduler_startup_summary = '; '.join(actions) if actions else 'Startup delay'
            self._scheduler_startup_message = f'Starting up… settling for {delay:.1f} s'
            self._scheduler_startup_timer.start()
            self.runtime_service.evaluate_scheduler()
            return True, self._scheduler_startup_message
        return self._complete_scheduler_startup()

    def pause_scheduler(self) -> tuple[bool, str]:
        snap = self.state_store.snapshot()
        if snap.scheduler_runtime.running and snap.scheduler_runtime.paused:
            self.scheduler_service.resume()
            self.runtime_service.evaluate_scheduler()
            self.status.emit('Scheduler resumed')
            return True, 'Scheduler resumed'
        self.scheduler_service.pause()
        self.runtime_service.evaluate_scheduler()
        self.status.emit('Scheduler paused')
        return True, 'Scheduler paused'

    def stop_scheduler(self) -> tuple[bool, str]:
        self._cancel_scheduler_startup()
        self.scheduler_service.stop()
        self.runtime_service.evaluate_scheduler()
        self.status.emit('Scheduler stopped')
        return True, 'Scheduler stopped'

    def confirm_scheduler_step(self) -> tuple[bool, str]:
        ok, message = self.scheduler_service.confirm_step()
        self.runtime_service.evaluate_scheduler()
        self.status.emit(message)
        return ok, message

    def scheduler_previous_step(self) -> tuple[bool, str]:
        ok, message = self.scheduler_service.previous_step()
        self.runtime_service.evaluate_scheduler()
        self.status.emit(message)
        return ok, message

    def scheduler_next_step(self) -> tuple[bool, str]:
        ok, message = self.scheduler_service.next_step()
        self.runtime_service.evaluate_scheduler()
        self.status.emit(message)
        return ok, message


def install_signal_handlers(core: AppCore, app: QCoreApplication) -> None:
    def _shutdown(*_args):
        core.status.emit('Shutdown requested.')
        core.stop()
        app.quit()
    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)
