from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from gui.ui_helpers import create_collapsible_section, make_output_badge, normalize_signal_key, refresh_binding_combo


@dataclass
class BrewPanelFacade:
    populate_psu_ports: Callable[[], None]
    toggle_psu_power: Callable[..., None]
    populate_channels: Callable[[], None]
    toggle_can_connection: Callable[..., None]
    open_send_dialog: Callable[[], None]
    save_settings: Callable[..., None]
    on_bitrate_changed: Callable[..., None]


@dataclass
class ControlPanelFacade:
    save_settings: Callable[..., None]
    normalize_signal_key: Callable[[object], object]
    make_output_badge: Callable[[str], object]
    bind_twin_editor_inputs: Callable[[], None]
    ui_state: object
    get_agitator_target: Callable[[], str]


@dataclass
class TwinPanelFacade:
    save_settings: Callable[..., None]
    set_status: Callable[[str], None]
    refresh_twin_panel: Callable[[], None]
    refresh_footer: Callable[[], None]
    save_settings_to_state: Callable[[], None]
    ui_state: object
    load_twin_model: Callable[[str], object]
    snapshot: Callable[[], object]
    signal_records: Callable[[], list]
    twin_input_variables: Callable[[], list]
    twin_output_variables: Callable[[], list]
    latest_twin_result: Callable[[], object]
    twin_model_name: Callable[[], str | None]
    twin_status_text: Callable[[], str | None]
    refresh_binding_combo: Callable[[object, object, object], None]
    make_output_badge: Callable[[str], object]
    bind_twin_editor_inputs: Callable[[], None]


@dataclass
class SchedulerPanelFacade:
    save_settings: Callable[..., None]
    save_settings_to_state: Callable[[], None]
    set_status: Callable[[str], None]
    create_collapsible_section: Callable[..., object]
    create_schedule_template: Callable[[], None]
    load_scheduler_workbook: Callable[[str, str | None], object]
    refresh_scheduler_panel: Callable[[], None]
    refresh_scheduler_sheet_combo: Callable[[list, str | None], None]
    scheduler_startup_status: Callable[[], object]
    start_scheduler: Callable[[], object]
    pause_scheduler: Callable[[], object]
    stop_scheduler: Callable[[], object]
    scheduler_previous_step: Callable[[], object]
    scheduler_next_step: Callable[[], object]
    confirm_scheduler_step: Callable[[], object]
    ui_state: object


@dataclass
class SafetyPanelFacade:
    save_settings: Callable[..., None]
    create_collapsible_section: Callable[..., object]
    action_labels: dict[str, str]
    operator_keys: list[str]
    palette_provider: Callable[[], object]
    snapshot_provider: Callable[[], object]
    safety_rules_controller: object


@dataclass
class RelayPanelFacade:
    save_settings: Callable[..., None]
    refresh_relay_panel: Callable[[], None]
    refresh_footer: Callable[[], None]
    set_status: Callable[[str], None]
    make_output_badge: Callable[[str], object]
    bind_twin_editor_inputs: Callable[[], None]
    set_relay_manual_state: Callable[[int, bool], object]
    populate_relay_targets: Callable[[], None]
    toggle_relay_connection: Callable[..., None]
    relay_channel_rows: dict[int, dict[str, object]]


@dataclass
class PanelFacadeBundle:
    brew: BrewPanelFacade
    control: ControlPanelFacade
    twin: TwinPanelFacade
    scheduler: SchedulerPanelFacade
    safety: SafetyPanelFacade
    relay: RelayPanelFacade


def build_panel_facades(window) -> PanelFacadeBundle:
    return PanelFacadeBundle(
        brew=BrewPanelFacade(
            populate_psu_ports=window.brew_controller.populate_psu_ports,
            toggle_psu_power=window.brew_controller.toggle_psu_power,
            populate_channels=window.brew_controller.populate_channels,
            toggle_can_connection=window.brew_controller.toggle_can_connection,
            open_send_dialog=window.brew_controller.open_send_dialog,
            save_settings=window.config_controller.save_settings,
            on_bitrate_changed=window.config_controller.on_bitrate_changed,
        ),
        control=ControlPanelFacade(
            save_settings=window.config_controller.save_settings,
            normalize_signal_key=normalize_signal_key,
            make_output_badge=make_output_badge,
            bind_twin_editor_inputs=lambda: window.editors.twin.bind_dynamic_inputs() if hasattr(window, 'editors') else None,
            ui_state=window.ui_state,
            get_agitator_target=lambda: getattr(window.core.settings.agitator, 'target', 'relay'),
        ),
        twin=TwinPanelFacade(
            save_settings=window.config_controller.save_settings,
            set_status=window.commands.set_status_message,
            refresh_twin_panel=window.intent_dispatcher.refresh_twin_panel,
            refresh_footer=window.intent_dispatcher.refresh_footer,
            save_settings_to_state=window.config_controller.save_settings_to_state,
            ui_state=window.ui_state,
            load_twin_model=window.commands.load_twin_model,
            snapshot=window.queries.snapshot,
            signal_records=window.queries.signal_records,
            twin_input_variables=window.queries.twin_input_variables,
            twin_output_variables=window.queries.twin_output_variables,
            latest_twin_result=window.queries.latest_twin_result,
            twin_model_name=window.queries.twin_model_name,
            twin_status_text=window.queries.twin_status_text,
            refresh_binding_combo=refresh_binding_combo,
            make_output_badge=make_output_badge,
            bind_twin_editor_inputs=lambda: window.editors.twin.bind_dynamic_inputs() if hasattr(window, 'editors') else None,
        ),
        scheduler=SchedulerPanelFacade(
            save_settings=window.config_controller.save_settings,
            save_settings_to_state=window.config_controller.save_settings_to_state,
            set_status=window.commands.set_status_message,
            create_collapsible_section=create_collapsible_section,
            create_schedule_template=window.scheduler_controller.create_schedule_template,
            load_scheduler_workbook=window.commands.load_scheduler_workbook,
            refresh_scheduler_panel=window.intent_dispatcher.refresh_scheduler_panel,
            refresh_scheduler_sheet_combo=window.scheduler_controller.refresh_scheduler_sheet_combo,
            scheduler_startup_status=window.queries.scheduler_startup_status,
            start_scheduler=window.commands.start_scheduler,
            pause_scheduler=window.commands.pause_scheduler,
            stop_scheduler=window.commands.stop_scheduler,
            scheduler_previous_step=window.commands.scheduler_previous_step,
            scheduler_next_step=window.commands.scheduler_next_step,
            confirm_scheduler_step=window.commands.confirm_scheduler_step,
            ui_state=window.ui_state,
        ),
        safety=SafetyPanelFacade(
            save_settings=window.config_controller.save_settings,
            create_collapsible_section=create_collapsible_section,
            action_labels=window._action_labels,
            operator_keys=window._operator_keys,
            palette_provider=window.palette,
            snapshot_provider=window.queries.snapshot,
            safety_rules_controller=window.safety_rules_controller,
        ),
        relay=RelayPanelFacade(
            save_settings=window.config_controller.save_settings,
            refresh_relay_panel=window.intent_dispatcher.refresh_relay_panel,
            refresh_footer=window.intent_dispatcher.refresh_footer,
            set_status=window.relay_controller.set_status,
            make_output_badge=make_output_badge,
            bind_twin_editor_inputs=lambda: window.editors.twin.bind_dynamic_inputs() if hasattr(window, 'editors') else None,
            set_relay_manual_state=window.commands.set_relay_manual_state,
            populate_relay_targets=window.relay_controller.populate_relay_targets,
            toggle_relay_connection=window.relay_controller.toggle_relay_connection,
            relay_channel_rows=window.relay_channel_rows,
        ),
    )
