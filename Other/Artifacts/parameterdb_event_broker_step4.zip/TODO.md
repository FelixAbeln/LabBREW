# ParameterDB TODO

## Phase 1: Core Hardening

- [x] Protocol envelope v1
- [x] Command dispatcher (replace if-chain)
- [x] Request validation layer
- [x] Event broker cleanup (bounded queues)
- [ ] Store API tightening (no live objects)
- [ ] Concurrency and lock policy documentation

## Phase 2: Reliability

- [ ] Snapshot persistence
- [ ] Audit log

## Phase 3: Optional

- [ ] Auth layer (token-based)
- [ ] Event stream envelope
