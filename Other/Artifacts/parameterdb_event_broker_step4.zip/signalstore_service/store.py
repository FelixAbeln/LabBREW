from __future__ import annotations

from threading import RLock
from typing import Any

from .event_broker import EventBroker
from .plugin_api import ParameterBase


class ParameterStore:
    def __init__(self, broker: EventBroker | None = None) -> None:
        self._params: dict[str, ParameterBase] = {}
        self._lock = RLock()
        self._revision = 0
        self._broker = broker or EventBroker()

    @property
    def broker(self) -> EventBroker:
        return self._broker

    def _touch(self) -> int:
        self._revision += 1
        return self._revision

    def revision(self) -> int:
        with self._lock:
            return self._revision

    def _publish(self, event: dict[str, Any]) -> None:
        self._broker.publish(event)

    def exists(self, name: str) -> bool:
        with self._lock:
            return name in self._params

    def add(self, param: ParameterBase) -> None:
        with self._lock:
            if param.name in self._params:
                raise ValueError(f"Parameter '{param.name}' already exists")
            self._params[param.name] = param
            rev = self._touch()
            event = {
                "event": "parameter_added",
                "name": param.name,
                "plugin_type": param.plugin_type,
                "value": param.get_value(),
                "config": dict(param.config),
                "state": dict(param.state),
                "metadata": dict(param.metadata),
                "store_revision": rev,
            }
        self._publish(event)

    def get_param(self, name: str) -> ParameterBase:
        with self._lock:
            try:
                return self._params[name]
            except KeyError as exc:
                raise KeyError(f"Unknown parameter '{name}'") from exc

    def remove(self, name: str) -> ParameterBase | None:
        with self._lock:
            param = self._params.pop(name, None)
            rev = self._touch() if param is not None else self._revision
        if param is not None:
            self._publish({
                "event": "parameter_removed",
                "name": name,
                "store_revision": rev,
            })
        return param

    def set_value(self, name: str, value: Any) -> None:
        with self._lock:
            param = self._params[name]
            old = param.get_value()
            param.set_value(value)
            new = param.get_value()
            rev = self._touch() if old != new else self._revision
        if old != new:
            self._publish({
                "event": "value_changed",
                "name": name,
                "value": new,
                "source": "external",
                "store_revision": rev,
            })

    def get_value(self, name: str, default: Any = None) -> Any:
        with self._lock:
            param = self._params.get(name)
            return default if param is None else param.get_value()

    def update_config(self, name: str, **changes: Any) -> None:
        with self._lock:
            self._params[name].update_config(**changes)
            config = dict(self._params[name].config)
            rev = self._touch()
        self._publish({
            "event": "config_changed",
            "name": name,
            "config": config,
            "store_revision": rev,
        })

    def update_metadata(self, name: str, **metadata: Any) -> None:
        with self._lock:
            self._params[name].metadata.update(metadata)
            data = dict(self._params[name].metadata)
            rev = self._touch()
        self._publish({
            "event": "metadata_changed",
            "name": name,
            "metadata": data,
            "store_revision": rev,
        })

    def list_names(self) -> list[str]:
        with self._lock:
            return sorted(self._params)

    def records(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {
                name: {
                    "plugin_type": p.plugin_type,
                    "value": p.get_value(),
                    "config": dict(p.config),
                    "state": dict(p.state),
                    "metadata": dict(p.metadata),
                }
                for name, p in self._params.items()
            }

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {name: p.get_value() for name, p in self._params.items()}

    def items_for_scan(self) -> list[ParameterBase]:
        with self._lock:
            return list(self._params.values())

    def publish_scan_value_if_changed(self, name: str, old: Any, new: Any) -> None:
        if old != new:
            rev = self.revision()
            self._publish({
                "event": "value_changed",
                "name": name,
                "value": new,
                "source": "scan",
                "store_revision": rev,
            })

    def publish_scan_state(self, name: str, state: dict[str, Any]) -> None:
        self._publish({
            "event": "state_changed",
            "name": name,
            "state": state,
            "store_revision": self.revision(),
        })
