from __future__ import annotations

import queue
import threading
import uuid
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SubscriptionInfo:
    token: str
    names: tuple[str, ...]
    max_queue: int
    dropped_events: int = 0


class EventSubscription:
    def __init__(self, token: str, q: queue.Queue[dict[str, Any]], names: set[str] | None, max_queue: int) -> None:
        self.token = token
        self.queue = q
        self.names = names
        self.max_queue = max_queue
        self.dropped_events = 0

    def matches(self, event: dict[str, Any]) -> bool:
        if self.names is None:
            return True
        event_name = event.get("name")
        return isinstance(event_name, str) and event_name in self.names

    def snapshot(self) -> SubscriptionInfo:
        return SubscriptionInfo(
            token=self.token,
            names=tuple(sorted(self.names or ())),
            max_queue=self.max_queue,
            dropped_events=self.dropped_events,
        )


class EventBroker:
    """Central fanout for subscription events.

    Queue policy is intentionally simple and bounded:
    - each subscriber gets a bounded queue
    - on overflow, drop the oldest queued event and enqueue the newest
    - if even that fails, disconnect the subscriber
    - publish an internal overflow notice when possible
    """

    def __init__(self, *, default_max_queue: int = 1000) -> None:
        self._lock = threading.RLock()
        self._subs: dict[str, EventSubscription] = {}
        self._default_max_queue = default_max_queue

    def subscribe(self, names: list[str] | None = None, max_queue: int | None = None) -> EventSubscription:
        token = uuid.uuid4().hex
        clean_names = {name for name in (names or []) if isinstance(name, str) and name}
        actual_max = max_queue if isinstance(max_queue, int) and max_queue > 0 else self._default_max_queue
        sub = EventSubscription(
            token=token,
            q=queue.Queue(maxsize=actual_max),
            names=clean_names or None,
            max_queue=actual_max,
        )
        with self._lock:
            self._subs[token] = sub
        return sub

    def unsubscribe(self, token: str) -> None:
        with self._lock:
            self._subs.pop(token, None)

    def list_subscriptions(self) -> list[SubscriptionInfo]:
        with self._lock:
            return [sub.snapshot() for sub in self._subs.values()]

    def publish(self, event: dict[str, Any]) -> None:
        with self._lock:
            subscribers = list(self._subs.values())

        stale_tokens: list[str] = []
        for sub in subscribers:
            if not sub.matches(event):
                continue
            if not self._enqueue(sub, event):
                stale_tokens.append(sub.token)

        if stale_tokens:
            with self._lock:
                for token in stale_tokens:
                    self._subs.pop(token, None)

    def _enqueue(self, sub: EventSubscription, event: dict[str, Any]) -> bool:
        try:
            sub.queue.put_nowait(event)
            return True
        except queue.Full:
            sub.dropped_events += 1

        try:
            sub.queue.get_nowait()
        except queue.Empty:
            pass

        overflow_notice = {
            "event": "subscription_overflow",
            "dropped_events": sub.dropped_events,
            "subscription_id": sub.token,
        }

        try:
            sub.queue.put_nowait(overflow_notice)
        except queue.Full:
            # Still full after dropping one item. Try to enqueue the latest event directly.
            try:
                sub.queue.get_nowait()
            except queue.Empty:
                pass
            try:
                sub.queue.put_nowait(event)
                return True
            except queue.Full:
                return False

        try:
            sub.queue.put_nowait(event)
            return True
        except queue.Full:
            return False
