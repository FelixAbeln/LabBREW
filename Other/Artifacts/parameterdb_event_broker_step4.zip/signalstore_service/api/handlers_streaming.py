from __future__ import annotations

from typing import Any

from signalstore_core.protocol import encode_message, make_response

from .validation import validate_subscribe


def register_streaming_handlers(server: Any) -> None:
    server.dispatcher.register_streaming("subscribe", server.api_subscribe)


def stream_subscribe(server: Any, request_handler: Any, *, req_id: str | None, payload: dict[str, Any]) -> None:
    clean = validate_subscribe(payload)
    names = list(clean["names"])
    send_initial = clean["send_initial"]
    max_queue = clean.get("max_queue")

    sub = server.engine.broker.subscribe(names=names, max_queue=max_queue)
    try:
        request_handler.wfile.write(encode_message(make_response(
            req_id=req_id,
            result={
                "status": "subscribed",
                "subscription_id": sub.token,
                "max_queue": sub.max_queue,
            },
        )))
        request_handler.wfile.flush()

        if send_initial:
            current = server.engine.store.records()
            for name, desc in current.items():
                if names and name not in names:
                    continue
                request_handler.wfile.write(encode_message({
                    "event": "parameter_snapshot",
                    "name": name,
                    **desc,
                }))
            request_handler.wfile.flush()

        while True:
            event = sub.queue.get()
            request_handler.wfile.write(encode_message(event))
            request_handler.wfile.flush()

    except (BrokenPipeError, ConnectionResetError, OSError):
        pass
    finally:
        server.engine.broker.unsubscribe(sub.token)
