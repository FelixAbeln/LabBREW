from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from state import AppState
from services.signal_registry import SignalRecord


@dataclass(frozen=True)
class OperatorDefinitionModel:
    key: str
    meaning: str
    uses_threshold_or_range: bool = False
    uses_time: bool = False
    example: str = ''


@dataclass(frozen=True)
class WaitTypeDefinitionModel:
    key: str
    meaning: str


@dataclass(frozen=True)
class SafetyActionDefinitionModel:
    key: str
    label: str


SignalProvider = Callable[[AppState], list[SignalRecord]]


@dataclass
class AppRegistry:
    operators: dict[str, OperatorDefinitionModel] = field(default_factory=dict)
    wait_types: dict[str, WaitTypeDefinitionModel] = field(default_factory=dict)
    safety_actions: dict[str, SafetyActionDefinitionModel] = field(default_factory=dict)
    signal_providers: list[SignalProvider] = field(default_factory=list)

    def register_operator(self, definition: OperatorDefinitionModel) -> None:
        if definition.key in self.operators:
            raise ValueError(f'Duplicate operator registration: {definition.key}')
        self.operators[definition.key] = definition

    def register_wait_type(self, definition: WaitTypeDefinitionModel) -> None:
        if definition.key in self.wait_types:
            raise ValueError(f'Duplicate wait type registration: {definition.key}')
        self.wait_types[definition.key] = definition

    def register_safety_action(self, definition: SafetyActionDefinitionModel) -> None:
        if definition.key in self.safety_actions:
            raise ValueError(f'Duplicate safety action registration: {definition.key}')
        self.safety_actions[definition.key] = definition

    def register_signal_provider(self, provider: SignalProvider) -> None:
        self.signal_providers.append(provider)
