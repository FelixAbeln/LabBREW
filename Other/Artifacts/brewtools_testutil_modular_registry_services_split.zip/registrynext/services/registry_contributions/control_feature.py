from __future__ import annotations

from application.registry import AppRegistry
from services.signal_registry import SignalRecord
from state import AppState


def register_control_feature(registry: AppRegistry) -> None:
    registry.register_signal_provider(_control_signal_records)


def _control_signal_records(snapshot: AppState) -> list[SignalRecord]:
    return [
        SignalRecord('virtual:heat', 'Virtual — HEAT', snapshot.controls.heat_cool.output_a, 'GOOD', ''),
        SignalRecord('virtual:cool', 'Virtual — COOL', snapshot.controls.heat_cool.output_b, 'GOOD', ''),
        SignalRecord('virtual:add_gas', 'Virtual — ADD GAS', snapshot.controls.gas.output_a, 'GOOD', ''),
        SignalRecord('virtual:remove_gas', 'Virtual — REMOVE GAS', snapshot.controls.gas.output_b, 'GOOD', ''),
        SignalRecord('virtual:agitator', 'Virtual — AGITATOR', snapshot.controls.agitator_runtime.effective_on, 'GOOD', ''),
        SignalRecord('agitator:on', 'Agitator — Command on', snapshot.controls.agitator.on, 'GOOD', ''),
        SignalRecord('agitator:enabled', 'Agitator — Controller enabled', snapshot.controls.agitator.enabled, 'GOOD', ''),
        SignalRecord('agitator:target', 'Agitator — Target selection', snapshot.controls.agitator.target, 'GOOD', ''),
        SignalRecord('agitator:mode', 'Agitator — Control mode', snapshot.controls.agitator.mode, 'GOOD', ''),
        SignalRecord('agitator:duty_cycle', 'Agitator — Effective duty cycle', snapshot.controls.agitator_runtime.effective_duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:configured_duty_cycle', 'Agitator — Configured duty cycle', snapshot.controls.agitator.duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:speed_setpoint_rpm', 'Agitator — Speed setpoint', snapshot.controls.agitator.speed_setpoint_rpm, 'GOOD', 'rpm'),
        SignalRecord('agitator:pid_active', 'Agitator — PID active', snapshot.controls.agitator_runtime.pid_active, 'GOOD', ''),
        SignalRecord('agitator:rpm', 'Agitator — RPM feedback', snapshot.controls.agitator_runtime.rpm_feedback, 'GOOD' if snapshot.controls.agitator_runtime.rpm_feedback is not None else 'MISSING', 'rpm'),
    ]
