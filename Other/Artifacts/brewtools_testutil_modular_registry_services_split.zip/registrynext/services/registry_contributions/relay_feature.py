from __future__ import annotations

from application.registry import AppRegistry
from services.signal_registry import SignalRecord, make_signal_key
from state import AppState


def register_relay_feature(registry: AppRegistry) -> None:
    registry.register_signal_provider(_relay_signal_records)


def _relay_signal_records(snapshot: AppState) -> list[SignalRecord]:
    records: list[SignalRecord] = []
    for ch in range(1, max(1, snapshot.relay.channel_count) + 1):
        records.append(SignalRecord(make_signal_key('relay', ch), f'Relay {ch} state', snapshot.relay.channel_states.get(ch, False), 'GOOD' if snapshot.relay.connected else 'MISSING', ''))
    return records
