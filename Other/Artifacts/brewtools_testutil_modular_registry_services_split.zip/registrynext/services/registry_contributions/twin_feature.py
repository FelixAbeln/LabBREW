from __future__ import annotations

from application.registry import AppRegistry
from services.signal_registry import SignalRecord, make_signal_key
from state import AppState


def register_twin_feature(registry: AppRegistry) -> None:
    registry.register_signal_provider(_twin_signal_records)


def _twin_signal_records(snapshot: AppState) -> list[SignalRecord]:
    records: list[SignalRecord] = []
    for name, value in sorted(snapshot.twin_runtime.outputs.items()):
        if name in {'status_text', 'fmu_name'}:
            continue
        records.append(SignalRecord(make_signal_key('twin', name), f'Twin — {name}', value, 'GOOD' if value is not None else 'MISSING', ''))
    return records
