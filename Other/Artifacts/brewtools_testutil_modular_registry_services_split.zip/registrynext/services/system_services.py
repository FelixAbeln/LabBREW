from __future__ import annotations

from dataclasses import dataclass

from services.can_service import CANService
from services.config_validation_service import ConfigValidationService
from services.psu_service import PSUService
from services.settings_mapper_service import SettingsMapperService
from services.signal_registry_service import SignalRegistryService


@dataclass
class SystemServices:
    can_service: CANService
    psu_service: PSUService
    signal_registry_service: SignalRegistryService
    settings_mapper: SettingsMapperService
    config_validation_service: ConfigValidationService
