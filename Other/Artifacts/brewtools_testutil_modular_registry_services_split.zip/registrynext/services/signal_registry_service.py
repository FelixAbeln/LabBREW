from __future__ import annotations

from application.registry import AppRegistry
from services.signal_registry import SignalRecord
from state import AppState


class SignalRegistryService:
    """Core app service that aggregates registered signal providers."""

    def __init__(self, *, registry: AppRegistry) -> None:
        self.registry = registry

    def build_signal_registry(self, snapshot: AppState) -> list[SignalRecord]:
        records: list[SignalRecord] = []
        for provider in self.registry.signal_providers:
            records.extend(list(provider(snapshot)))
        return records

    def signal_lookup(self, snapshot: AppState) -> dict[str, SignalRecord]:
        return {rec.key: rec for rec in self.build_signal_registry(snapshot)}
