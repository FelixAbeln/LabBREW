from __future__ import annotations

from application.config_models import ApplicationConfigModel
from gui.panel_field_models import (
    BrewPanelFields,
    ControlPanelFields,
    RelayPanelFields,
    SafetyPanelFields,
    SchedulerPanelFields,
    TwinPanelFields,
)
from gui.panel_config_adapters import (
    ControlPanelConfigAdapter,
    RelayPanelConfigAdapter,
    SafetyPanelConfigAdapter,
    SchedulerPanelConfigAdapter,
    TwinPanelConfigAdapter,
)


class ApplicationConfigBuilder:
    """Collects panel editor/form state and translates it into application-facing config DTOs."""

    def __init__(self, window):
        self.window = window

    def build(self) -> ApplicationConfigModel:
        w = self.window
        brew_form = BrewPanelFields(w.brew_panel).read()
        control_form = ControlPanelFields(w.control_panel).read(
            settings=w.settings,
            selected_or_pending_source_key=w.source_controller.selected_or_pending_source_key,
            pending_temp_source_key=w.ui_state.pending_temp_source_key,
            pending_pressure_source_key=w.ui_state.pending_pressure_source_key,
        )
        relay_form = RelayPanelFields(w.relay_panel, w.relay_channel_rows).read()
        safety_form = SafetyPanelFields(w.safety_panel, w.safety_rules_controller).read()
        scheduler_form = SchedulerPanelFields(w.scheduler_panel).read()
        twin_form = TwinPanelFields(w.twin_panel).read(settings=w.settings, queries=w.queries)

        control = ControlPanelConfigAdapter(control_form)
        relay = RelayPanelConfigAdapter(relay_form)
        safety = SafetyPanelConfigAdapter(safety_form, list(w.safety_rules_controller.get_rules()))
        scheduler = SchedulerPanelConfigAdapter(scheduler_form, list(w.queries.scheduler_steps()))
        twin = TwinPanelConfigAdapter(twin_form)

        return ApplicationConfigModel(
            bitrate=brew_form.bitrate,
            can_channel=brew_form.can_channel,
            can_channel_label=brew_form.can_channel_label,
            psu_com_port=brew_form.psu_com_port,
            voltage=brew_form.voltage,
            temp_controller=control.temp_controller(),
            pressure_controller=control.pressure_controller(),
            agitator=control.agitator(),
            relay=relay.relay(),
            safety=safety.safety(),
            scheduler=scheduler.scheduler(),
            twin=twin.twin(),
        )
