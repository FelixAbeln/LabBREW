
## Latest pass: richer panel editor models for config harvesting

Fixed in this pass:
- Expanded `gui/panel_field_models.py` from simple apply helpers into richer panel editor/form models with explicit `*FormState` dataclasses for Brew, Control, Relay, Safety, Scheduler, and Twin panels.
- Refactored `gui/config_adapters.py` so config harvesting now reads panel form state first and only then translates that state into application config DTOs.
- Reworked `gui/panel_config_adapters.py` into pure translators from panel form-state models to `application.config_models`, removing direct widget reads from those config adapters.
- Twin input binding collection and control/relay/safety/scheduler field reads are now encapsulated behind panel field adapters instead of being scattered across raw widget-centric config adapter code.

Why this helps:
- Config editing is less widget-centric and more form/editor-model centric.
- It becomes easier to validate, test, or reuse panel config logic without needing live Qt widgets everywhere in the translation layer.
- The boundary between “read UI state” and “build application config” is clearer and more consistent across panels.

Still not fully fixed:
- Some panel field models still read directly from Qt widgets, so there is still room to introduce richer validation objects or editor controllers later.
- `MainWindow` still owns some top-level shell composition and startup wiring, even though much less than before.
- `StateStore.snapshot()` is still manual and brittle.
- Some refresh flows are still broader than ideal and could eventually become more event-targeted.

# Refactor status

## Latest pass: UI state + safety-rule controller extraction

Fixed in this pass:
- Added `gui/ui_state.py` and moved the remaining window-scoped UI flags/state bags out of `MainWindow`, including pending control source keys, combo sync flags, loading flags, and source cache lists.
- Added `gui/safety_rules_controller.py` and moved editable safety-rule state out of `MainWindow`; panels/config adapters now use the controller instead of `window._safety_rules`.
- Centralized `normalize_control_source_key()` in `application/normalization.py` and updated `app_core.py`, `services/settings_mapper_service.py`, and `gui/main_window.py` to import the shared helper instead of copying it.
- Removed dead transitional `gui/window_actions.py`.

Why this helps:
- `MainWindow` lost more compatibility state and no longer acts as the owner of transient GUI rule/edit state.
- Facades now depend less on raw window attributes and more on focused controller/state objects.
- The normalization helper now has one source of truth instead of three copy-pasted implementations.

Still not fully fixed:
- `MainWindow` still owns top-level timer/event orchestration and refresh coordinator composition.
- Config editing is panel-adapter based now, but still fundamentally widget-centric rather than field/controller-object based.
- `StateStore.snapshot()` is still manual and brittle.
- Some refresh paths are still broad and should eventually become more targeted/event-driven.

## Latest pass: control/twin widget builders moved into panel-owned widgets


### Fixed in this pass

1. **Moved the control subgroup builders into `ControlPanel`.**
   - Temperature, pressure, and agitator widget construction now lives in `gui/panels/control_panel.py`.
   - `MainWindow` no longer needs to build those control subgroups itself.

2. **Moved twin input/output group construction and variable-widget rebuild logic into `TwinPanel`.**
   - FMU-driven input/output widget creation now lives in `gui/panels/twin_panel.py`.
   - `MainWindow.refresh_twin_sources()` now delegates to the panel instead of owning the twin widget rebuild path.

3. **Reduced facade leakage from `MainWindow` into the panels.**
   - The control facade no longer passes raw builder callbacks or a widget owner.
   - The twin facade now exposes query/service callbacks the panel needs instead of asking `MainWindow` to build widgets for it.

4. **Moved more control/twin widget access onto real panel objects.**
   - `MainWindow` and presenters now reference `control_panel`/`twin_panel` widgets directly for the migrated areas instead of assuming the window owns those widgets.

## Previously fixed

1. **Removed panel `refs()` compatibility plumbing.**
   - Deleted the `*PanelRefs` dataclasses and `refs()` methods from the GUI panels.
   - `MainWindow` no longer binds panel widget references onto itself via `_bind_panel_refs(...)`.

2. **Introduced explicit panel-facing facades.**
   - Added `gui/panel_facades.py`.
   - Panels now receive a narrower facade instead of depending directly on `MainWindow` as their action host.
   - This is a real step toward controller-style boundaries and away from “the window knows everything.”

3. **Kept panel-local behavior in the panel classes while reducing direct window coupling.**
   - `BrewPanel`, `ControlPanel`, `TwinPanel`, `SchedulerPanel`, `SafetyPanel`, and `RelayPanel` now talk to facade callbacks/services instead of calling `self.window` directly.
   - `SafetyPanel` now owns its own safety action checkbox collection instead of stashing it on the window.

4. **Preserved compileability during the migration.**
   - The updated code compiles after the facade split and `refs()` removal.
   - This pass was structural cleanup, not a behavior redesign.

1. **Moved panel-local handlers into the panel classes.**
   - `ControlPanel` owns source-selection and agitator-mode UI behavior.
   - `TwinPanel` owns FMU browse/load actions.
   - `SchedulerPanel` owns scheduler command handlers and startup-summary UI behavior.
   - `SafetyPanel` owns rule-editor add/update/delete/load/visibility logic.
   - `RelayPanel` owns relay auto/manual toggle handlers.

2. **Moved panel-local signal wiring out of `MainWindow`.**
   - Panel classes now own their local widget wiring.
   - `MainWindow._wire_signals()` is no longer the giant tab-local signal matrix.

3. **Converted tab builders into real panel widget classes.**
   - Replaced builder-style tab functions with dedicated widgets in `gui/panels/`.

4. **Split the main tabs into GUI panel modules.**
   - Added `gui/panels/` and moved top-level tab construction out of the giant `_build_ui()` body.

5. **Extracted GUI refresh/presenter responsibilities out of `MainWindow`.**
   - Added `gui/presenters.py`.
   - Footer, devices, control, safety, scheduler, twin, and relay refresh logic now live in dedicated presenter classes.

6. **Removed the most obvious GUI → state-store boundary violations.**
   - Config/state writes were pushed through config DTOs and command paths instead of direct `StateStore` mutation from the window.

7. **Moved runtime ownership toward core/services.**
   - The app has `AppCore`, commands, queries, events, a headless mode, and view-model-driven reads.
   - The GUI is much less privileged than it was originally.

## Still not fully fixed

1. **`MainWindow` is still too large.**
   - It still owns a lot of shell orchestration, compatibility glue, refresh routing, and file workflow behavior.

2. **Some panel widget access still goes through `MainWindow`-level code paths.**
   - Control/twin builders moved, but the window still contains a lot of panel orchestration and direct widget reads during save/apply flows.
   - The remaining path should keep moving toward panel-facing form adapters/controllers.

3. **Settings/form assembly is still too GUI-heavy.**
   - The write boundary is better.
   - But the GUI still gathers a lot of config/edit state manually instead of using dedicated form adapters or editors.

5. **`StateStore.snapshot()` is still manual and brittle.**
   - The state cloning plumbing has not been modernized yet.

6. **Some command/query methods are still thinner than they should be.**
   - The architecture is increasingly justified now.
   - But some service boundaries could still be sharpened or consolidated.

7. **Higher-level application events are still incomplete.**
   - The UI still refreshes broader sections opportunistically in several places.
   - A cleaner end state is more event-driven and panel-targeted.

## Recommended next steps

1. Move the remaining widget/subgroup builders out of `MainWindow` and into panel-owned builders or controller classes.

2. Remove the temporary `MainWindow.__getattr__` compatibility bridge by migrating remaining window methods to panel/view-model access.

3. Introduce dedicated form adapters or panel controllers for config editing.

4. Replace manual `StateStore.snapshot()` cloning with a safer centralized clone strategy.

5. Tighten the application event surface so panels refresh from higher-level app events instead of broad refresh calls.


## Latest pass: panel widget ownership cleanup

Fixed in this pass:
- Rewired `MainWindow` and `gui/presenters.py` to use panel-owned widgets directly for Brew, Safety, Scheduler, Twin, and Relay controls instead of stale window-level widget names.
- Corrected log panel ownership after the widget mapping pass, so the system log remains a top-level panel and presenters write to `window.log_panel.event_log`.
- This removes another chunk of fake `MainWindow` widget ownership and flushes out migration-time AttributeError paths such as `psu_port_combo` and `lbl_heat`.

Still not fully fixed:
- `MainWindow` still owns too much apply/save workflow and too many UI orchestration methods.
- Some refresh helpers are still window methods rather than panel-local presenters/controllers.
- Settings harvesting is still too GUI-heavy and should keep moving toward panel form adapters / config DTOs.


## Latest patch: Twin source refresh ownership fix

Fixed in this patch:
- `MainWindow.refresh_twin_sources()` now delegates fully to `TwinPanel.refresh_sources()` instead of trying to rebuild twin binding items itself.
- This removes another stale window-owned twin helper path that was left behind after moving twin widget ownership into `TwinPanel`.

Still not fully fixed:
- `MainWindow` still contains several legacy helper methods for control/twin construction that are now effectively dead code and should be removed in a later cleanup pass after verifying no callers remain.
- Save/apply/form harvesting logic is still too concentrated in `MainWindow`.

## Latest pass
- Moved scheduler template workbook generation out of `gui/main_window.py` into `services/scheduler_template_service.py`.
- Added `commands.export_scheduler_template(...)` so the GUI only asks for a path and invokes the command surface.
- Remaining cleanup: move more import/export/config translation helpers out of `MainWindow` the same way.


## Latest pass: window orchestration extraction

Fixed in this pass:
- Added `gui/window_actions.py` and moved panel-facing orchestration callbacks there, including save/apply settings, status updates, port/channel discovery, relay target discovery, scheduler sheet refresh, and template export.
- Added `gui/config_adapters.py` and moved application config harvesting out of `MainWindow` into an explicit `ApplicationConfigBuilder`.
- Updated `gui/panel_facades.py` so panels now depend on `window.actions` for most orchestration callbacks instead of pointing directly at `MainWindow` methods.
- Removed obvious migration residue from `MainWindow`, including the old device-status/measurement formatting helpers and the inline config-harvesting block.

Still not fully fixed:
- `MainWindow` still coordinates several cross-panel refresh and runtime response flows.
- Some facade callbacks still route through `window.actions`, which is cleaner than direct `MainWindow` coupling but still transitional glue until more panel/application controllers exist.
- Settings apply/load is cleaner, but UI-to-config mapping is still widget-centric rather than field-adapter-centric.
- `StateStore.snapshot()` is still manual and brittle.

## Latest pass: coordinator/controller split and panel config adapters

Fixed in this pass:
- Split the old `window.actions` glue into focused GUI-side collaborators:
  - `gui/config_controller.py` for apply/persist flows
  - `gui/discovery_controller.py` for discovery dialogs and pickers
  - `gui/runtime_bridge.py` for cross-panel refresh/runtime coordination
- Updated `gui/panel_facades.py` so panels now depend on these narrower controllers instead of the monolithic `window.actions` object.
- Refactored `gui/config_adapters.py` to compose dedicated panel config adapters from `gui/panel_config_adapters.py` rather than harvesting every field in one giant widget-centric block.
- Moved more cross-panel refresh/runtime response logic out of `MainWindow` into `WindowRuntimeBridge`, including frame handling and runtime-cycle refresh orchestration.

Still not fully fixed:
- `MainWindow` still exposes several compatibility wrapper methods that now only delegate to panels/controllers and can be removed in later cleanup passes.
- The GUI config side is more structured now, but panel edit flows are still widget-driven rather than true field/controller objects with validation boundaries.
- `StateStore.snapshot()` is still manual and brittle.
- Some presenter refresh paths are still broad and could be narrowed further with more targeted events.

- Fixed `runtime_bridge` init order in `MainWindow`.

## Latest pass: source/settings controller split and UI helper extraction

Fixed in this pass:
- Added `gui/source_controller.py` and moved cross-panel source reconciliation there, including control source combo refresh, safety signal source refresh, twin source refresh delegation, and agitator target discovery/rebuild.
- Added `gui/settings_loader.py` and moved the large persisted-settings -> widget application flow out of `MainWindow`.
- Added `gui/ui_helpers.py` and moved reusable UI primitives there, including collapsible section creation, output badge styling, signal-key normalization, combo data lookup, and twin binding combo refresh.
- Updated `gui/panel_facades.py`, presenters, and controllers to depend on those focused helpers/controllers instead of more raw `MainWindow` methods.

Why this helps:
- `MainWindow` owns less cross-panel coordination.
- The old facade callbacks now point less often at window methods and more often at narrower collaborators or reusable GUI helpers.
- Settings load/apply is less widget-centric inside the window itself, which is a step toward cleaner panel-specific edit controllers.

Still not fully fixed:
- `MainWindow` still contains compatibility wrapper methods for panel/controller calls and should keep shrinking.
- The config side still harvests raw widget values, even though it is now panel-adapter-shaped; deeper field/controller validation boundaries are still future work.
- `StateStore.snapshot()` is still manual and brittle.
- Some refresh paths are still broad rather than driven by narrower application events.

## Patch notes

- Fixed a `NameError` in `gui/presenters.py` by importing `set_output_badge` from `gui.ui_helpers`.


## Latest pass: MainWindow compatibility wrapper reduction

Fixed in this pass:
- Removed a large set of thin compatibility wrappers from `gui/main_window.py` and switched callers to use controllers, panels, or helpers directly.
- Added `gui/device_session_controller.py` so Brew/Relay panel actions no longer depend on window-owned toggle/send-dialog wrappers.
- Moved scheduler target application into `ControlPanel.apply_scheduler_targets(...)` and updated `WindowRuntimeBridge` to use the panel directly.
- Updated presenters to call panel methods and controllers directly instead of bouncing through `MainWindow` compatibility methods.
- Removed dead legacy control-group builder methods that were no longer part of the active UI path.

Still not fully fixed:
- `MainWindow` still owns some top-level Qt event wiring and cross-panel refresh objects.
- Settings/config harvesting is panel-adapter based now, but still fundamentally widget-centric rather than field-object/controller based.
- `StateStore.snapshot()` is still manual and brittle.
- Some facade callbacks still depend on window-scoped flags/state bags (`_pending_*`, `_loading_*`, `_safety_rules`).

## Patch notes

- Fixed startup break after wrapper reduction: initial agitator runtime sync now lives in `WindowRuntimeBridge.update_agitator_runtime()` instead of calling a removed `MainWindow._update_agitator_runtime()` wrapper.


## Latest pass: session orchestration split and panel field adapters

Fixed in this pass:
- Added `gui/window_session.py` and moved top-level timer/event orchestration plus refresh coordinator composition out of `MainWindow`.
- `WindowRuntimeBridge` now depends on an injected refresh coordinator instead of `MainWindow._refresh`, so `MainWindow` no longer owns refresh composition directly.
- Replaced the remaining big widget-by-widget settings apply flow with panel-level field adapters in `gui/panel_field_models.py`.
- Updated config harvesting to reuse those panel field models for Brew/Relay reads, reducing more raw widget-centric code.

Why this helps:
- `MainWindow` is now closer to a shell that assembles collaborators and panels, rather than the place that owns timers and runtime-event plumbing.
- Settings/edit flows are still widget-backed, but the access pattern is now panel-form shaped instead of controller code reaching into dozens of individual widgets directly.

Still not fully fixed:
- Some config adapters still read directly from panel widgets and could move further toward richer field objects or validated editor models.
- `WindowRuntimeBridge` still performs some broad refresh fan-out after runtime cycles; a more event-targeted surface would reduce that further.
- `StateStore.snapshot()` is still manual and brittle.
