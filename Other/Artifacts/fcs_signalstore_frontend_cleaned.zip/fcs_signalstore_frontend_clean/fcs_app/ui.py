from __future__ import annotations

import json
from dataclasses import dataclass
from urllib import request

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QComboBox,
)

from .template_exporter import ScheduleTemplateExporter, TemplateExportOptions


@dataclass(slots=True)
class ApiClient:
    base_url: str

    def get(self, path: str) -> dict:
        with request.urlopen(f"{self.base_url}{path}", timeout=3.0) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def post(self, path: str, payload: dict | None = None) -> dict:
        data = json.dumps(payload or {}).encode("utf-8")
        req = request.Request(f"{self.base_url}{path}", data=data, headers={"Content-Type": "application/json"}, method="POST")
        with request.urlopen(req, timeout=5.0) as resp:
            return json.loads(resp.read().decode("utf-8"))


class MainWindow(QMainWindow):
    def __init__(self, api: ApiClient) -> None:
        super().__init__()
        self.api = api
        self.template_exporter = ScheduleTemplateExporter()
        self.setWindowTitle("FCS Scheduler Client")
        root = QWidget()
        layout = QVBoxLayout(root)

        top_group = QGroupBox("Workbook")
        top = QGridLayout(top_group)
        self.workbook_path = QLineEdit()
        self.sheet_name = QLineEdit()
        self.btn_browse = QPushButton("Browse…")
        self.btn_load = QPushButton("Load workbook")
        self.template_mode = QComboBox()
        self.template_mode.addItems(["Blank template", "Test routine template"])
        self.btn_export_template = QPushButton("Export template")
        top.addWidget(QLabel("Workbook"), 0, 0)
        top.addWidget(self.workbook_path, 0, 1)
        top.addWidget(self.btn_browse, 0, 2)
        top.addWidget(self.btn_load, 0, 3)
        top.addWidget(QLabel("Optional plan sheet override"), 1, 0)
        top.addWidget(self.sheet_name, 1, 1)
        top.addWidget(QLabel("Template mode"), 1, 2)
        top.addWidget(self.template_mode, 1, 3)
        top.addWidget(self.btn_export_template, 0, 4, 2, 1)
        top.setColumnStretch(1, 1)
        layout.addWidget(top_group)

        ctrl = QHBoxLayout()
        self.btn_start = QPushButton("Start")
        self.btn_pause = QPushButton("Pause")
        self.btn_resume = QPushButton("Resume")
        self.btn_stop = QPushButton("Stop")
        self.btn_prev = QPushButton("Previous")
        self.btn_next = QPushButton("Next")
        self.btn_confirm = QPushButton("Confirm / Continue")
        for btn in [self.btn_start, self.btn_pause, self.btn_resume, self.btn_stop, self.btn_prev, self.btn_next, self.btn_confirm]:
            ctrl.addWidget(btn)
        layout.addLayout(ctrl)

        status_group = QGroupBox("Runtime status")
        status_form = QFormLayout(status_group)
        self.state_lbl = QLabel("—")
        self.phase_lbl = QLabel("—")
        self.step_lbl = QLabel("—")
        self.elapsed_lbl = QLabel("—")
        self.hold_lbl = QLabel("—")
        self.wait_lbl = QLabel("—")
        self.confirm_lbl = QLabel("—")
        self.transition_lbl = QLabel("—")
        status_form.addRow("State", self.state_lbl)
        status_form.addRow("Phase", self.phase_lbl)
        status_form.addRow("Current step", self.step_lbl)
        status_form.addRow("Step elapsed", self.elapsed_lbl)
        status_form.addRow("Hold elapsed", self.hold_lbl)
        status_form.addRow("Waiting", self.wait_lbl)
        status_form.addRow("Confirmation", self.confirm_lbl)
        status_form.addRow("Last transition", self.transition_lbl)
        layout.addWidget(status_group)

        self.tabs = QTabWidget()
        self.startup_table = QTableWidget(0, 8)
        self.startup_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.plan_table = QTableWidget(0, 8)
        self.plan_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.tabs.addTab(self.startup_table, "StartupRoutine")
        self.tabs.addTab(self.plan_table, "Plan")
        layout.addWidget(self.tabs)

        self.events = QTextEdit()
        self.events.setReadOnly(True)
        layout.addWidget(self.events)

        self.setCentralWidget(root)
        self._wire()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_status)
        self.timer.start(1000)
        self.refresh_status()

    def _wire(self) -> None:
        self.btn_browse.clicked.connect(self.browse_workbook)
        self.btn_load.clicked.connect(self.load_schedule)
        self.btn_export_template.clicked.connect(self.export_template)
        self.btn_start.clicked.connect(lambda: self._post("/run/start"))
        self.btn_pause.clicked.connect(lambda: self._post("/run/pause"))
        self.btn_resume.clicked.connect(lambda: self._post("/run/resume"))
        self.btn_stop.clicked.connect(lambda: self._post("/run/stop"))
        self.btn_prev.clicked.connect(lambda: self._post("/run/previous"))
        self.btn_next.clicked.connect(lambda: self._post("/run/next"))
        self.btn_confirm.clicked.connect(lambda: self._post("/run/confirm"))

    def browse_workbook(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select schedule workbook", self.workbook_path.text().strip(), "Excel Workbook (*.xlsx *.xlsm)")
        if path:
            self.workbook_path.setText(path)

    def export_template(self) -> None:
        suggested_name = "fcs_test_routine_template.xlsx" if self.template_mode.currentIndex() == 1 else "fcs_schedule_template.xlsx"
        path, _ = QFileDialog.getSaveFileName(self, "Export schedule template", suggested_name, "Excel Workbook (*.xlsx)")
        if not path:
            return
        try:
            options = TemplateExportOptions(include_examples=True, include_test_routine=self.template_mode.currentIndex() == 1)
            exported = self.template_exporter.export(path, options)
            self.workbook_path.setText(str(exported))
            self.sheet_name.setText("Plan")
            QMessageBox.information(self, "Template exported", f"Template written to:\n{exported}")
        except Exception as exc:
            QMessageBox.critical(self, "Template export failed", str(exc))

    def load_schedule(self) -> None:
        self._post("/schedule/load", {"workbook_path": self.workbook_path.text().strip(), "sheet_name": self.sheet_name.text().strip()}, refresh=True)

    def refresh_status(self) -> None:
        try:
            status = self.api.get("/status")
        except Exception as exc:
            self.state_lbl.setText(f"Disconnected ({exc})")
            return
        self.state_lbl.setText(str(status.get("state", "—")))
        self.phase_lbl.setText(str(status.get("phase", "—")))
        idx = status.get("current_step_index", -1)
        name = status.get("current_step_name", "")
        self.step_lbl.setText(f"{idx} | {name}")
        self.elapsed_lbl.setText(f"{float(status.get('step_elapsed_s', 0.0)):.1f} s")
        self.hold_lbl.setText(f"{float(status.get('hold_elapsed_s', 0.0)):.1f} s")
        self.wait_lbl.setText(str(status.get("wait_reason", "—")))
        self.confirm_lbl.setText(str(status.get("confirmation_message", "—")))
        self.transition_lbl.setText(str(status.get("last_transition", "—")))
        self._fill_table(self.startup_table, status.get("startup_steps", []))
        self._fill_table(self.plan_table, status.get("plan_steps", []))
        self.events.setPlainText("\n".join(status.get("event_log", [])))

    def _fill_table(self, table: QTableWidget, steps: list[dict]) -> None:
        table.setRowCount(len(steps))
        for row, step in enumerate(steps):
            actions = "; ".join(action.get("display_text", "") for action in step.get("controller_actions", []))
            criteria = self._criteria_text(step)
            values = [
                step.get("index", row),
                step.get("enabled", True),
                step.get("name", ""),
                actions,
                step.get("wait_type", ""),
                step.get("wait_source", ""),
                criteria,
                step.get("confirmation_message", "") or step.get("require_confirmation", False),
            ]
            for col, value in enumerate(values):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        table.resizeColumnsToContents()

    def _criteria_text(self, step: dict) -> str:
        wait_type = step.get("wait_type", "")
        if wait_type == "signal":
            operator = step.get("operator", "")
            if operator in {"in_range", "out_of_range"}:
                return f"{operator} [{step.get('threshold_low', '')}, {step.get('threshold_high', '')}] hold={step.get('hold_for_s', 0)}s"
            return f"{operator} {step.get('threshold', '')} hold={step.get('hold_for_s', 0)}s"
        if wait_type == "all_valid":
            return f"{', '.join(step.get('valid_sources', []))} hold={step.get('hold_for_s', 0)}s"
        return f"{step.get('duration_s', 0)}s"

    def _post(self, path: str, payload: dict | None = None, *, refresh: bool = True) -> None:
        try:
            result = self.api.post(path, payload)
            if refresh:
                self.refresh_status()
            if not result.get("ok", True):
                QMessageBox.warning(self, "FCS service", str(result.get("message", "Unknown error")))
        except Exception as exc:
            QMessageBox.critical(self, "FCS service", str(exc))


def run_ui(base_url: str = "http://127.0.0.1:8769") -> int:
    app = QApplication([])
    window = MainWindow(ApiClient(base_url=base_url.rstrip("/")))
    window.resize(1280, 860)
    window.show()
    return app.exec()
