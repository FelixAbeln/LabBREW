from __future__ import annotations

import socket
from typing import Any

from .protocol import encode_message, read_message


class SignalClient:
    def __init__(self, host: str = "127.0.0.1", port: int = 8765, timeout: float = 2.0) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout

    def _request(self, payload: dict[str, Any]) -> Any:
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
            sock.sendall(encode_message(payload))
            resp = read_message(sock.makefile("rb"))
            if resp is None:
                raise RuntimeError("No response from server")
        if not resp.get("ok"):
            raise RuntimeError(resp.get("error", "Unknown server error"))
        return resp.get("result")

    def ping(self) -> str:
        return self._request({"cmd": "ping"})

    def stats(self) -> dict[str, Any]:
        return self._request({"cmd": "stats"})

    def snapshot(self) -> dict[str, Any]:
        return self._request({"cmd": "snapshot"})

    def describe(self) -> dict[str, Any]:
        return self._request({"cmd": "describe"})

    def list_parameters(self) -> list[str]:
        return self._request({"cmd": "list_parameters"})

    def list_plugin_types(self) -> dict[str, Any]:
        return self._request({"cmd": "list_plugin_types"})

    def create_parameter(self, name: str, plugin_type: str, *, value: Any = None, config: dict[str, Any] | None = None, metadata: dict[str, Any] | None = None) -> bool:
        return self._request({
            "cmd": "create_parameter",
            "name": name,
            "plugin_type": plugin_type,
            "value": value,
            "config": config or {},
            "metadata": metadata or {},
        })

    def delete_parameter(self, name: str) -> bool:
        return self._request({"cmd": "delete_parameter", "name": name})

    def get_value(self, name: str, default: Any = None) -> Any:
        return self._request({"cmd": "get_value", "name": name, "default": default})

    def set_value(self, name: str, value: Any) -> bool:
        return self._request({"cmd": "set_value", "name": name, "value": value})

    def update_config(self, name: str, **changes: Any) -> bool:
        return self._request({"cmd": "update_config", "name": name, "changes": changes})

    def update_metadata(self, name: str, **changes: Any) -> bool:
        return self._request({"cmd": "update_metadata", "name": name, "changes": changes})

    def load_plugin_folder(self, folder: str) -> str:
        return self._request({"cmd": "load_plugin_folder", "folder": folder})
