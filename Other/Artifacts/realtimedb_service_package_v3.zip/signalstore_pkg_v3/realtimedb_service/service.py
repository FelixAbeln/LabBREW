from __future__ import annotations

import argparse
import signal
from pathlib import Path

from .engine import ScanEngine
from .loader import PluginRegistry, load_plugin_folder
from .server import SignalTCPServer


def _autoload_plugins(registry: PluginRegistry, plugin_root: Path) -> None:
    plugin_root.mkdir(parents=True, exist_ok=True)
    for folder in sorted(plugin_root.iterdir()):
        if folder.is_dir() and (folder / "implementation.py").exists():
            load_plugin_folder(folder, registry)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the realtime parameter service")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--period", type=float, default=0.1)
    parser.add_argument("--plugin-root", default="./plugins")
    return parser


def main() -> None:
    args = build_arg_parser().parse_args()
    registry = PluginRegistry()
    plugin_root = Path(args.plugin_root)
    _autoload_plugins(registry, plugin_root)

    engine = ScanEngine(period_s=args.period)
    engine.start()
    server = SignalTCPServer(args.host, args.port, engine, registry)

    def _stop(_sig, _frame) -> None:
        server.shutdown()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    try:
        print(f"realtimedb-service listening on {args.host}:{args.port} scan={args.period}s plugin_root={plugin_root}")
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
        engine.stop()


if __name__ == "__main__":
    main()
