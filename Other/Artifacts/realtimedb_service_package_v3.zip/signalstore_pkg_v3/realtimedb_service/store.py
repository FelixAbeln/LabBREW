from __future__ import annotations

from threading import RLock
from typing import Any

from .plugin_api import ParameterBase, ParameterRecord


class ParameterStore:
    def __init__(self) -> None:
        self._params: dict[str, ParameterBase] = {}
        self._lock = RLock()

    def exists(self, name: str) -> bool:
        with self._lock:
            return name in self._params

    def add(self, param: ParameterBase) -> None:
        with self._lock:
            if param.name in self._params:
                raise ValueError(f"Parameter '{param.name}' already exists")
            self._params[param.name] = param

    def get_param(self, name: str) -> ParameterBase:
        with self._lock:
            try:
                return self._params[name]
            except KeyError as exc:
                raise KeyError(f"Unknown parameter '{name}'") from exc

    def remove(self, name: str) -> ParameterBase | None:
        with self._lock:
            return self._params.pop(name, None)

    def set_value(self, name: str, value: Any) -> None:
        with self._lock:
            self._params[name].set_value(value)

    def get_value(self, name: str, default: Any = None) -> Any:
        with self._lock:
            param = self._params.get(name)
            return default if param is None else param.get_value()

    def update_config(self, name: str, **changes: Any) -> None:
        with self._lock:
            self._params[name].update_config(**changes)

    def update_metadata(self, name: str, **metadata: Any) -> None:
        with self._lock:
            self._params[name].metadata.update(metadata)

    def list_names(self) -> list[str]:
        with self._lock:
            return sorted(self._params)

    def records(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {
                name: {
                    "plugin_type": p.plugin_type,
                    "value": p.get_value(),
                    "config": dict(p.config),
                    "state": dict(p.state),
                    "metadata": dict(p.metadata),
                }
                for name, p in self._params.items()
            }

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {name: p.get_value() for name, p in self._params.items()}

    def items_for_scan(self) -> list[ParameterBase]:
        with self._lock:
            return list(self._params.values())
