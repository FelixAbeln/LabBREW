from __future__ import annotations

import importlib.util
import uuid
from pathlib import Path
from typing import Any

from .plugin_api import PluginSpec


class PluginRegistry:
    def __init__(self) -> None:
        self._specs: dict[str, PluginSpec] = {}
        self._ui_modules: dict[str, Any] = {}
        self._plugin_paths: dict[str, str] = {}

    def register(self, spec: PluginSpec, *, ui_module: Any | None = None, path: str | None = None) -> None:
        self._specs[spec.plugin_type] = spec
        if ui_module is not None:
            self._ui_modules[spec.plugin_type] = ui_module
        if path is not None:
            self._plugin_paths[spec.plugin_type] = path

    def get(self, plugin_type: str) -> PluginSpec:
        try:
            return self._specs[plugin_type]
        except KeyError as exc:
            raise ValueError(f"Unknown plugin type '{plugin_type}'") from exc

    def list_types(self) -> dict[str, dict[str, Any]]:
        return {
            name: {
                "display_name": spec.display_name,
                "description": spec.description,
                "default_config": spec.default_config(),
                "schema": spec.schema(),
                "has_ui": name in self._ui_modules,
                "plugin_path": self._plugin_paths.get(name),
            }
            for name, spec in sorted(self._specs.items())
        }

    def get_ui_module(self, plugin_type: str) -> Any | None:
        return self._ui_modules.get(plugin_type)


def _load_py_module(pyfile: Path):
    module_name = f"plugin_{pyfile.stem}_{uuid.uuid4().hex[:8]}"
    spec = importlib.util.spec_from_file_location(module_name, pyfile)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module from '{pyfile}'")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_plugin_folder(folder: str | Path, registry: PluginRegistry) -> str:
    plugin_dir = Path(folder).resolve()
    impl_file = plugin_dir / "implementation.py"
    if not impl_file.exists():
        raise FileNotFoundError(f"Missing implementation.py in {plugin_dir}")

    impl = _load_py_module(impl_file)
    spec = getattr(impl, "PLUGIN")
    if not isinstance(spec, PluginSpec):
        raise TypeError(f"{impl_file} must expose PLUGIN = PluginSpec instance")

    ui_module = None
    ui_file = plugin_dir / "ui.py"
    if ui_file.exists():
        ui_module = _load_py_module(ui_file)

    registry.register(spec, ui_module=ui_module, path=str(plugin_dir))
    return spec.plugin_type
