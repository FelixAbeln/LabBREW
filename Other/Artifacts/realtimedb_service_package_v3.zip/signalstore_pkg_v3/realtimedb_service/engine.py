from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any

from .store import ParameterStore


@dataclass(slots=True)
class ScanContext:
    now: float
    dt: float
    cycle_count: int
    store: ParameterStore


class ScanEngine:
    def __init__(self, period_s: float, store: ParameterStore | None = None) -> None:
        self.period_s = period_s
        self.store = store or ParameterStore()
        self._running = False
        self._thread: threading.Thread | None = None
        self._cycle_count = 0
        self._last_scan_started_at: float | None = None
        self._last_scan_duration_s = 0.0

    def scan_once(self, dt: float) -> None:
        started = time.perf_counter()
        now = time.time()
        self._last_scan_started_at = now
        ctx = ScanContext(now=now, dt=dt, cycle_count=self._cycle_count, store=self.store)
        for param in self.store.items_for_scan():
            try:
                param.scan(ctx)
            except Exception as exc:
                param.state["last_error"] = str(exc)
        self._cycle_count += 1
        self._last_scan_duration_s = time.perf_counter() - started

    def _run_loop(self) -> None:
        last = time.perf_counter()
        while self._running:
            start = time.perf_counter()
            dt = start - last
            last = start
            self.scan_once(dt)
            elapsed = time.perf_counter() - start
            time.sleep(max(0.0, self.period_s - elapsed))

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name="ParameterScanEngine", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    def stats(self) -> dict[str, Any]:
        return {
            "running": self._running,
            "period_s": self.period_s,
            "cycle_count": self._cycle_count,
            "last_scan_started_at": self._last_scan_started_at,
            "last_scan_duration_s": self._last_scan_duration_s,
            "parameter_count": len(self.store.list_names()),
        }
