from realtimedb_service.client import SignalClient

c = SignalClient()
print(c.ping())
print(c.list_plugin_types())
c.create_parameter("tank.level", "hold", value=12.5)
c.create_parameter("tank.sp", "hold", value=20.0)
c.create_parameter(
    "tank.pid",
    "pid",
    config={"pv": "tank.level", "sp": "tank.sp", "kp": 2.0, "ki": 0.5, "kd": 0.1, "out_min": 0.0, "out_max": 100.0},
)
print(c.describe())
