from __future__ import annotations


class WindowRuntimeBridge:
    """Coordinates cross-panel refresh and runtime-driven GUI updates."""

    def __init__(self, window):
        self.window = window

    def refresh_footer(self) -> None:
        self.window._refresh.footer.refresh()

    def refresh_table(self) -> None:
        self.window._refresh.devices.refresh_table()

    def on_frame(self, frame, obj) -> None:
        self.window._refresh.devices.on_frame(frame, obj)

    def refresh_control_panel(self) -> None:
        self.window._refresh.control.refresh()

    def refresh_safety_panel(self) -> None:
        self.window._refresh.safety.refresh()

    def refresh_twin_panel(self) -> None:
        self.window._refresh.twin.refresh()

    def refresh_scheduler_panel(self) -> None:
        self.window._refresh.scheduler.refresh()

    def refresh_relay_panel(self) -> None:
        self.window._refresh.relays.refresh()

    def refresh_sources(self) -> None:
        self.window.source_controller.refresh_all_sources()

    def refresh_all(self) -> None:
        self.refresh_footer()
        self.refresh_table()
        self.refresh_control_panel()
        self.refresh_safety_panel()
        self.refresh_twin_panel()
        self.refresh_scheduler_panel()
        self.refresh_relay_panel()

    def on_runtime_cycle_completed(self) -> None:
        snap = self.window.queries.snapshot()
        self.window._loading_scheduler_ui = True
        try:
            changed = self.window.control_panel.apply_scheduler_targets(
                snap.controls.temperature.setpoint,
                snap.controls.pressure.setpoint,
                snap.controls.pressure.allow_add_gas,
                snap.controls.agitator.on,
                snap.controls.agitator.duty_cycle,
            )
        finally:
            self.window._loading_scheduler_ui = False
        if changed:
            self.window.config_controller.save_settings_to_state()
        self.refresh_control_panel()
        self.refresh_safety_panel()
        self.refresh_scheduler_panel()
        self.refresh_relay_panel()
        self.refresh_footer()
