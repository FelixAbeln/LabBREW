from __future__ import annotations

import os

from fcs_app.discovery import MdnsAdvertiser
from fcs_app.http_api import run_http_server
from fcs_app.runtime import FcsRuntimeService
from fcs_app.signalstore_backend import SignalStoreBackend


def main() -> None:
    backend_host = os.getenv("FCS_BACKEND_HOST", "127.0.0.1")
    backend_port = int(os.getenv("FCS_BACKEND_PORT", "8765"))
    service_host = os.getenv("FCS_SERVICE_HOST", "0.0.0.0")
    service_port = int(os.getenv("FCS_SERVICE_PORT", "8769"))

    backend = SignalStoreBackend(host=backend_host, port=backend_port)
    runtime = FcsRuntimeService(backend)
    runtime.start_background()
    server = run_http_server(runtime, host=service_host, port=service_port)

    advertiser = MdnsAdvertiser(service_label="FCS Scheduler", port=service_port, path="/status")
    discovery_enabled = advertiser.start()
    print(f"FCS runtime service listening on http://{service_host}:{service_port}")
    if discovery_enabled:
        print("mDNS discovery enabled for _fcs._tcp.local.")
    else:
        print("mDNS discovery unavailable (install zeroconf to enable it).")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        advertiser.close()
        server.server_close()
        runtime.shutdown()


if __name__ == "__main__":
    main()
