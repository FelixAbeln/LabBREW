# realtime parameter service

This package is a small scan-cycle data system.

The key idea is:
- every named item in the database is a **parameter object**
- each parameter object has a plugin type
- some plugin types are passive values
- some plugin types do work every scan cycle
- each plugin can ship its own editor UI in `ui.py`

## plugin folder structure

Each plugin lives in its own folder:

```text
plugins/
  hold/
    implementation.py
    ui.py
  pid/
    implementation.py
    ui.py
```

`implementation.py` must expose:

```python
PLUGIN = SomePluginSpec()
```

`ui.py` may expose:

```python
def open_editor(root, client, name, desc):
    ...
```

## built-in plugins

- `hold` - passive retained value
- `pid` - active scan-cycle PID controller
- `script` - active Python expression

## run

```bash
python -m pip install -e .
mkdir -p ./plugins
cp -r parameterdb_service/plugins/* ./plugins/
parameterdb-service --host 127.0.0.1 --port 8765 --period 0.05 --plugin-root ./plugins
```

## monitor

```bash
parameterdb-monitor --host 127.0.0.1 --port 8765 --plugin-root ./plugins
```

## client example

```python
from parameterdb_service.client import SignalClient

c = SignalClient()
c.create_parameter("tank.level", "hold", value=12.5)
c.create_parameter("tank.sp", "hold", value=20.0)
c.create_parameter(
    "tank.pid",
    "pid",
    config={"pv": "tank.level", "sp": "tank.sp", "kp": 2.0, "ki": 0.5, "kd": 0.0, "out_min": 0.0, "out_max": 100.0},
)
print(c.describe())
```

## notes

The protocol is MessagePack over TCP with a length prefix.

For plugin-specific editor UIs, the monitor app needs access to the same plugin folders so it can import each plugin's `ui.py`.


## Package layout

- `parameterdb_core`: shared protocol, client, and plugin-UI helpers
- `parameterdb_service`: backend runtime, loader, engine, and server
- `parameterdb_monitor`: monitor/editor UI
- `parameterdb_service`: compatibility imports for older code and plugins


## Snapshot persistence

The service can periodically write the current parameter database to a JSON snapshot file and restore it on startup.
Use `--snapshot-path` to choose the file, `--snapshot-interval` to control save frequency, and `--no-restore-snapshot` if you want a clean start.


## Audit log

The service can also write an append-only JSONL audit log for operational traceability.
By default it logs connections, subscriptions, command errors, parameter creation/deletion, config changes, metadata changes, and plugin folder loads.
It does not log every scan-driven value update. External writes can be included with `--audit-external-writes`.

Use `--audit-log-path` to choose the file and `--no-audit-log` to disable it.


## Persistent client sessions

For long-running tools like the monitor and data sources, use a persistent session to avoid reconnecting for every command:

```python
from parameterdb_core.client import SignalClient

client = SignalClient()
with client.session() as s:
    print(s.ping())
    print(s.describe())
```


## Connection model

- Simple one-shot scripts can keep using `SignalClient()` directly.
- The monitor uses its own persistent command session plus a separate subscription socket.
- Each data source instance opens and owns its own persistent command session.

This avoids connection churn and keeps one actor from stalling another actor's request path.
