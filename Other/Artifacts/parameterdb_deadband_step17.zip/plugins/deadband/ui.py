def get_ui_spec() -> dict:
    return {
        "parameter_type": "deadband",
        "display_name": "Deadband Controller",
        "description": "Boolean hysteresis controller. Turns on below the band or above the band and holds state inside it.",
        "create": {
            "required": ["name", "config.pv", "config.sp", "config.deadband"],
            "defaults": {
                "value": False,
                "config": {
                    "pv": "",
                    "sp": "",
                    "deadband": 1.0,
                    "direction": "below",
                    "enable_param": "",
                },
                "metadata": {},
            },
            "sections": [
                {
                    "title": "Identity",
                    "fields": [
                        {
                            "key": "name",
                            "label": "Name",
                            "type": "string",
                            "required": True,
                            "help": "Unique parameter name for the boolean controller output.",
                        },
                        {
                            "key": "value",
                            "label": "Initial Output",
                            "type": "bool",
                            "help": "Starting boolean output used until the first decisive scan.",
                        },
                    ],
                },
                {
                    "title": "Inputs",
                    "fields": [
                        {
                            "key": "config.pv",
                            "label": "Process Value",
                            "type": "parameter_ref",
                            "required": True,
                            "help": "Parameter providing the measured value.",
                        },
                        {
                            "key": "config.sp",
                            "label": "Setpoint",
                            "type": "parameter_ref",
                            "required": True,
                            "help": "Parameter providing the setpoint or switching center.",
                        },
                        {
                            "key": "config.enable_param",
                            "label": "Enable Parameter",
                            "type": "parameter_ref",
                            "help": "Optional boolean-like parameter used to enable or disable updates.",
                        },
                    ],
                },
                {
                    "title": "Behavior",
                    "fields": [
                        {
                            "key": "config.deadband",
                            "label": "Deadband",
                            "type": "float",
                            "required": True,
                            "help": "Half-width around the setpoint used for hysteresis.",
                        },
                        {
                            "key": "config.direction",
                            "label": "Active When",
                            "type": "enum",
                            "options": ["below", "above"],
                            "help": "Choose 'below' for heating-style action or 'above' for cooling-style action.",
                        },
                    ],
                },
            ],
        },
        "edit": {
            "allow_rename": False,
            "sections": [
                {
                    "title": "Identity",
                    "fields": [
                        {"key": "name", "label": "Name", "type": "string", "readonly": True},
                        {
                            "key": "value",
                            "label": "Current Output",
                            "type": "readonly",
                            "help": "Live boolean output after hysteresis logic.",
                        },
                    ],
                },
                {
                    "title": "Inputs",
                    "fields": [
                        {"key": "config.pv", "label": "Process Value", "type": "parameter_ref", "required": True},
                        {"key": "config.sp", "label": "Setpoint", "type": "parameter_ref", "required": True},
                        {"key": "config.enable_param", "label": "Enable Parameter", "type": "parameter_ref"},
                    ],
                },
                {
                    "title": "Behavior",
                    "fields": [
                        {"key": "config.deadband", "label": "Deadband", "type": "float", "required": True},
                        {"key": "config.direction", "label": "Active When", "type": "enum", "options": ["below", "above"]},
                    ],
                },
                {
                    "title": "State",
                    "fields": [
                        {"key": "state.pv", "label": "PV", "type": "readonly"},
                        {"key": "state.sp", "label": "SP", "type": "readonly"},
                        {"key": "state.lower", "label": "Lower Threshold", "type": "readonly"},
                        {"key": "state.upper", "label": "Upper Threshold", "type": "readonly"},
                        {"key": "state.direction", "label": "Direction", "type": "readonly"},
                        {"key": "state.last_error", "label": "Last Error", "type": "readonly"},
                    ],
                },
            ],
        },
    }
