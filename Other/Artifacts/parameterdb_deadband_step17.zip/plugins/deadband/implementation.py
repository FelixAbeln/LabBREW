from __future__ import annotations

from typing import Any

from parameterdb_service.plugin_api import ParameterBase, PluginSpec


class DeadbandParameter(ParameterBase):
    parameter_type = "deadband"
    display_name = "Deadband Controller"
    description = "Boolean hysteresis controller driven by PV and SP parameters."

    def __init__(
        self,
        name: str,
        *,
        config: dict[str, Any] | None = None,
        value: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(name, config=config, value=bool(value) if value is not None else False, metadata=metadata)

    def dependencies(self) -> list[str]:
        deps = [
            self.config.get("pv"),
            self.config.get("sp"),
            self.config.get("enable_param"),
        ]
        return [str(d) for d in deps if d]

    def scan(self, ctx) -> None:
        cfg = self.config
        store = ctx.store

        pv_name = cfg.get("pv")
        sp_name = cfg.get("sp")
        enable_param = cfg.get("enable_param")

        if not pv_name or not sp_name:
            self.state["last_error"] = "deadband requires 'pv' and 'sp'"
            return

        enabled = True
        if enable_param:
            enabled = bool(store.get_value(enable_param, True))
        self.state["enabled"] = enabled
        if not enabled:
            self.state.pop("last_error", None)
            return

        pv = float(store.get_value(pv_name, 0.0))
        sp = float(store.get_value(sp_name, 0.0))
        deadband = abs(float(cfg.get("deadband", 0.0)))
        direction = str(cfg.get("direction", "below")).strip().lower()
        if direction not in {"below", "above"}:
            direction = "below"

        lower = sp - deadband
        upper = sp + deadband
        current = bool(self.value)

        if direction == "below":
            if pv <= lower:
                output = True
            elif pv >= upper:
                output = False
            else:
                output = current
        else:
            if pv >= upper:
                output = True
            elif pv <= lower:
                output = False
            else:
                output = current

        self.value = output
        self.state["pv"] = pv
        self.state["sp"] = sp
        self.state["lower"] = lower
        self.state["upper"] = upper
        self.state["direction"] = direction
        self.state.pop("last_error", None)


class DeadbandPlugin(PluginSpec):
    parameter_type = "deadband"
    display_name = "Deadband"
    description = "Boolean hysteresis controller"

    def create(self, name: str, *, config=None, value=None, metadata=None) -> ParameterBase:
        return DeadbandParameter(name, config=config, value=value, metadata=metadata)

    def default_config(self) -> dict[str, Any]:
        return {
            "pv": "",
            "sp": "",
            "deadband": 1.0,
            "direction": "below",
            "enable_param": "",
        }

    def schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pv": {"type": "string"},
                "sp": {"type": "string"},
                "deadband": {"type": "number"},
                "direction": {"type": "string", "enum": ["below", "above"]},
                "enable_param": {"type": "string"},
            },
            "required": ["pv", "sp"],
        }


PLUGIN = DeadbandPlugin()
