from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable


@dataclass(frozen=True)
class ValidationIssue:
    panel: str
    field: str
    message: str
    severity: str = "error"


@dataclass(frozen=True)
class ValidationResult:
    issues: tuple[ValidationIssue, ...] = ()

    @property
    def errors(self) -> tuple[ValidationIssue, ...]:
        return tuple(i for i in self.issues if i.severity == "error")

    @property
    def warnings(self) -> tuple[ValidationIssue, ...]:
        return tuple(i for i in self.issues if i.severity == "warning")

    @property
    def is_valid(self) -> bool:
        return not self.errors

    def summary(self) -> str:
        if self.is_valid and not self.warnings:
            return "Configuration looks valid."
        if self.errors:
            first = self.errors[0]
            suffix = "" if len(self.errors) == 1 else f" (+{len(self.errors)-1} more)"
            return f"Fix configuration errors before saving: {first.message}{suffix}"
        first = self.warnings[0]
        suffix = "" if len(self.warnings) == 1 else f" (+{len(self.warnings)-1} more)"
        return f"Configuration warnings: {first.message}{suffix}"


class WindowValidationController:
    """Explicit validation rules for panel editor state, independent of widget configuration."""

    ERROR_STYLE = "border: 1px solid #d32f2f;"
    WARNING_STYLE = "border: 1px solid #ed6c02;"

    def __init__(self, window):
        self.window = window
        self.last_result = ValidationResult()

    def validate_current(self, *, decorate: bool = True, show_status: bool = False) -> ValidationResult:
        issues = [
            *self._validate_brew(),
            *self._validate_control(),
            *self._validate_relay(),
            *self._validate_safety(),
            *self._validate_scheduler(),
            *self._validate_twin(),
        ]
        result = ValidationResult(tuple(issues))
        self.last_result = result
        if decorate:
            self._decorate(result)
        if show_status:
            self.window.statusBar().showMessage(result.summary())
        return result

    def can_apply(self, *, show_status: bool = True) -> bool:
        return self.validate_current(decorate=True, show_status=show_status).is_valid

    def _validate_brew(self) -> list[ValidationIssue]:
        state = self.window.editors.brew.read_form_state()
        issues: list[ValidationIssue] = []
        if int(state.bitrate) <= 0:
            issues.append(ValidationIssue("brew", "bitrate", "CAN bitrate must be greater than 0."))
        if float(state.voltage) <= 0.0:
            issues.append(ValidationIssue("brew", "voltage", "PSU voltage must be greater than 0 V."))
        return issues

    def _validate_control(self) -> list[ValidationIssue]:
        state = self.window.editors.control.read_form_state()
        issues: list[ValidationIssue] = []
        if state.temp_enabled and not state.temp_source_key:
            issues.append(ValidationIssue("control", "temp_source_key", "Temperature control needs a source signal."))
        if float(state.temp_deadband) < 0.0:
            issues.append(ValidationIssue("control", "temp_deadband", "Temperature deadband cannot be negative."))
        if state.pressure_enabled and not state.pressure_source_key:
            issues.append(ValidationIssue("control", "pressure_source_key", "Pressure control needs a source signal."))
        if float(state.pressure_deadband) < 0.0:
            issues.append(ValidationIssue("control", "pressure_deadband", "Pressure deadband cannot be negative."))
        if state.agitator_enabled and not state.agitator_target:
            issues.append(ValidationIssue("control", "agitator_target", "Agitator control needs a target."))
        if float(state.agitator_duty_cycle) < 0.0 or float(state.agitator_duty_cycle) > 100.0:
            issues.append(ValidationIssue("control", "agitator_duty_cycle", "Agitator duty cycle must be between 0 and 100%."))
        if state.agitator_mode == "pid":
            if float(state.agitator_speed_setpoint_rpm) <= 0.0:
                issues.append(ValidationIssue("control", "agitator_speed_setpoint_rpm", "PID agitator mode needs a positive speed setpoint."))
            for field in ("agitator_pid_kp", "agitator_pid_ki", "agitator_pid_kd"):
                if float(getattr(state, field)) < 0.0:
                    issues.append(ValidationIssue("control", field, "Agitator PID gains cannot be negative."))
        return issues

    def _validate_relay(self) -> list[ValidationIssue]:
        state = self.window.editors.relay.read_form_state()
        issues: list[ValidationIssue] = []
        if not str(state.host).strip():
            issues.append(ValidationIssue("relay", "host", "Relay host cannot be empty."))
        if int(state.tcp_port) <= 0 or int(state.tcp_port) > 65535:
            issues.append(ValidationIssue("relay", "tcp_port", "Relay TCP port must be between 1 and 65535."))
        assigned = [str(v).strip() for v in state.assignments.values() if v]
        duplicates = {v for v in assigned if assigned.count(v) > 1}
        if duplicates:
            issues.append(ValidationIssue("relay", "assignments", f"Relay targets must be unique. Duplicate: {sorted(duplicates)[0]}"))
        return issues

    def _validate_safety(self) -> list[ValidationIssue]:
        state = self.window.editors.safety.read_form_state()
        issues: list[ValidationIssue] = []
        if float(state.stale_timeout_s) <= 0.0:
            issues.append(ValidationIssue("safety", "stale_timeout_s", "Safety stale timeout must be greater than 0 s."))
        if float(state.min_switch_time_s) < 0.0:
            issues.append(ValidationIssue("safety", "min_switch_time_s", "Minimum switch time cannot be negative."))
        if state.max_temperature_enabled and float(state.max_temperature_c) <= 0.0:
            issues.append(ValidationIssue("safety", "max_temperature_c", "Max temperature must be greater than 0 when enabled."))
        if state.max_pressure_enabled and float(state.max_pressure_bar) <= 0.0:
            issues.append(ValidationIssue("safety", "max_pressure_bar", "Max pressure must be greater than 0 when enabled."))
        rules = list(self.window.safety_rules_controller.get_rules())
        names = [str(r.name).strip() for r in rules if getattr(r, "name", "").strip()]
        duplicates = {n for n in names if names.count(n) > 1}
        if duplicates:
            issues.append(ValidationIssue("safety", "rules", f"Safety rule names must be unique. Duplicate: {sorted(duplicates)[0]}"))
        for rule in rules:
            if not str(getattr(rule, "name", "")).strip():
                issues.append(ValidationIssue("safety", "rules", "Safety rules must have a name."))
                break
            if not str(getattr(rule, "signal_key", "")).strip():
                issues.append(ValidationIssue("safety", "rules", f"Safety rule '{rule.name}' needs a signal source."))
                break
        return issues

    def _validate_scheduler(self) -> list[ValidationIssue]:
        state = self.window.editors.scheduler.read_form_state()
        issues: list[ValidationIssue] = []
        if state.enabled and not str(state.workbook_path).strip():
            issues.append(ValidationIssue("scheduler", "workbook_path", "Scheduler is enabled but no workbook path is set."))
        if state.enabled and not str(state.sheet_name).strip():
            issues.append(ValidationIssue("scheduler", "sheet_name", "Scheduler is enabled but no sheet is selected."))
        if float(state.startup_delay_s) < 0.0:
            issues.append(ValidationIssue("scheduler", "startup_delay_s", "Scheduler startup delay cannot be negative."))
        return issues

    def _validate_twin(self) -> list[ValidationIssue]:
        state = self.window.editors.twin.read_form_state()
        issues: list[ValidationIssue] = []
        if state.enabled and not str(state.fmu_path).strip():
            issues.append(ValidationIssue("twin", "fmu_path", "Twin is enabled but no FMU path is set."))
        return issues

    def _decorate(self, result: ValidationResult) -> None:
        severity_map: dict[tuple[str, str], str] = {(issue.panel, issue.field): issue.severity for issue in result.issues}
        message_map: dict[tuple[str, str], list[str]] = {}
        for issue in result.issues:
            message_map.setdefault((issue.panel, issue.field), []).append(issue.message)
        for panel, field_widgets in self._field_widgets().items():
            for field, widgets in field_widgets.items():
                widgets = widgets if isinstance(widgets, (list, tuple)) else [widgets]
                severity = severity_map.get((panel, field))
                message = "\n".join(message_map.get((panel, field), []))
                for widget in widgets:
                    self._style_widget(widget, severity, message)

    def _style_widget(self, widget, severity: str | None, message: str) -> None:
        if widget is None:
            return
        if severity == "error":
            widget.setStyleSheet(self.ERROR_STYLE)
            widget.setToolTip(message)
        elif severity == "warning":
            widget.setStyleSheet(self.WARNING_STYLE)
            widget.setToolTip(message)
        else:
            widget.setStyleSheet("")
            widget.setToolTip("")

    def _field_widgets(self) -> dict[str, dict[str, object]]:
        w = self.window
        return {
            "brew": {
                "bitrate": w.brew_panel.bitrate,
                "voltage": w.brew_panel.psu_voltage,
            },
            "control": {
                "temp_source_key": w.control_panel.temp_source_combo,
                "temp_deadband": w.control_panel.temp_deadband,
                "pressure_source_key": w.control_panel.pressure_source_combo,
                "pressure_deadband": w.control_panel.pressure_deadband,
                "agitator_target": w.control_panel.agitator_target_combo,
                "agitator_duty_cycle": w.control_panel.agitator_duty,
                "agitator_speed_setpoint_rpm": w.control_panel.agitator_speed_setpoint,
                "agitator_pid_kp": w.control_panel.agitator_pid_kp,
                "agitator_pid_ki": w.control_panel.agitator_pid_ki,
                "agitator_pid_kd": w.control_panel.agitator_pid_kd,
            },
            "relay": {
                "host": w.relay_panel.relay_host,
                "tcp_port": w.relay_panel.relay_tcp_port,
                "assignments": [row["combo"] for row in w.relay_channel_rows.values()],
            },
            "safety": {
                "stale_timeout_s": w.safety_panel.safety_stale_timeout,
                "min_switch_time_s": w.safety_panel.safety_min_switch,
                "max_temperature_c": w.safety_panel.safety_max_temp,
                "max_pressure_bar": w.safety_panel.safety_max_pressure,
                "rules": w.safety_panel.rules_table,
            },
            "scheduler": {
                "workbook_path": w.scheduler_panel.scheduler_path,
                "sheet_name": w.scheduler_panel.scheduler_sheet,
                "startup_delay_s": w.scheduler_panel.scheduler_startup_delay,
            },
            "twin": {
                "fmu_path": w.twin_panel.twin_fmu_path,
            },
        }
