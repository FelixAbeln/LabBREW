from parameterdb_core.client import SignalClient

c = SignalClient()
print('ping:', c.ping())
print('plugin ui:', c.list_plugin_ui())
