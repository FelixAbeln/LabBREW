# ParameterDB

ParameterDB is a scan-cycle parameter database.

It separates four concerns:
- `plugins/` — parameter behaviors that run inside the database runtime
- `sources/` — external data-source types that connect to the database as separate services
- `parameterdb_service/` — the runtime, store, server, and plugin loading
- `parameterdb_monitor/` — the monitor/editor UI

## Project layout

```text
parameterdb/
  app.py
  monitor_app.py
  source_runner.py
  plugins/
  sources/
  source_configs/
  parameterdb_core/
  parameterdb_service/
  parameterdb_monitor/
  parameterdb_sources/
```

## Plugins

Each plugin lives in its own folder under `plugins/`:

```text
plugins/
  hold/
    implementation.py
    ui.py
  pid/
    implementation.py
    ui.py
```

`implementation.py` provides runtime behavior. `ui.py` provides the declarative editor spec that clients use to build editors.

## Data sources

Each source type lives in its own folder under `sources/`:

```text
sources/
  system_time/
    service.py
    ui.py
```

A data source is a separate process that connects through the client API, ensures the parameters it needs, and updates them over time.

## Run

Start the database service:

```bash
python app.py --plugin-root ./plugins
```

Start the monitor/editor:

```bash
python monitor_app.py --host 127.0.0.1 --port 8765
```

Start the source runner with the sample config:

```bash
python source_runner.py --config ./source_configs/system_time_demo.json
```

## Client example

```python
from parameterdb_core.client import SignalClient

client = SignalClient()
client.create_parameter("tank.level", "hold", value=12.5)
client.create_parameter("tank.sp", "hold", value=20.0)
client.create_parameter(
    "tank.pid",
    "pid",
    config={"pv": "tank.level", "sp": "tank.sp", "kp": 2.0, "ki": 0.5, "kd": 0.0, "out_min": 0.0, "out_max": 100.0},
)
```
