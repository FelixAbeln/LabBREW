from __future__ import annotations

import queue
from threading import RLock
from typing import Any

from .plugin_api import ParameterBase


class ParameterStore:
    def __init__(self) -> None:
        self._params: dict[str, ParameterBase] = {}
        self._lock = RLock()
        self._subscribers: list[queue.Queue] = []
        self._revision = 0

    def _touch(self) -> int:
        self._revision += 1
        return self._revision

    def revision(self) -> int:
        with self._lock:
            return self._revision

    def _publish(self, event: dict[str, Any]) -> None:
        dead: list[queue.Queue] = []
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except Exception:
                dead.append(q)
        if dead:
            with self._lock:
                self._subscribers = [q for q in self._subscribers if q not in dead]

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue()
        with self._lock:
            self._subscribers.append(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._lock:
            self._subscribers = [x for x in self._subscribers if x is not q]

    def exists(self, name: str) -> bool:
        with self._lock:
            return name in self._params

    def add(self, param: ParameterBase) -> None:
        with self._lock:
            if param.name in self._params:
                raise ValueError(f"Parameter '{param.name}' already exists")
            self._params[param.name] = param
            rev = self._touch()
        self._publish({
            "event": "parameter_added",
            "name": param.name,
            "plugin_type": param.plugin_type,
            "value": param.get_value(),
            "config": dict(param.config),
            "state": dict(param.state),
            "metadata": dict(param.metadata),
            "store_revision": rev,
        })

    def get_param(self, name: str) -> ParameterBase:
        with self._lock:
            try:
                return self._params[name]
            except KeyError as exc:
                raise KeyError(f"Unknown parameter '{name}'") from exc

    def remove(self, name: str) -> ParameterBase | None:
        with self._lock:
            param = self._params.pop(name, None)
            rev = self._touch() if param is not None else self._revision
        if param is not None:
            self._publish({
                "event": "parameter_removed",
                "name": name,
                "store_revision": rev,
            })
        return param

    def set_value(self, name: str, value: Any) -> None:
        with self._lock:
            param = self._params[name]
            old = param.get_value()
            param.set_value(value)
            new = param.get_value()
        if old != new:
            self._publish({
                "event": "value_changed",
                "name": name,
                "value": new,
                "source": "external",
            })

    def get_value(self, name: str, default: Any = None) -> Any:
        with self._lock:
            param = self._params.get(name)
            return default if param is None else param.get_value()

    def update_config(self, name: str, **changes: Any) -> None:
        with self._lock:
            self._params[name].update_config(**changes)
            config = dict(self._params[name].config)
            rev = self._touch()
        self._publish({
            "event": "config_changed",
            "name": name,
            "config": config,
            "store_revision": rev,
        })

    def update_metadata(self, name: str, **metadata: Any) -> None:
        with self._lock:
            self._params[name].metadata.update(metadata)
            data = dict(self._params[name].metadata)
        self._publish({
            "event": "metadata_changed",
            "name": name,
            "metadata": data,
        })

    def list_names(self) -> list[str]:
        with self._lock:
            return sorted(self._params)

    def records(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {
                name: {
                    "plugin_type": p.plugin_type,
                    "value": p.get_value(),
                    "config": dict(p.config),
                    "state": dict(p.state),
                    "metadata": dict(p.metadata),
                }
                for name, p in self._params.items()
            }

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {name: p.get_value() for name, p in self._params.items()}

    def items_for_scan(self) -> list[ParameterBase]:
        with self._lock:
            return list(self._params.values())

    def publish_scan_value_if_changed(self, name: str, old: Any, new: Any) -> None:
        if old != new:
            self._publish({
                "event": "value_changed",
                "name": name,
                "value": new,
                "source": "scan",
            })

    def publish_scan_state(self, name: str, state: dict[str, Any]) -> None:
        self._publish({
            "event": "state_changed",
            "name": name,
            "state": state,
        })
