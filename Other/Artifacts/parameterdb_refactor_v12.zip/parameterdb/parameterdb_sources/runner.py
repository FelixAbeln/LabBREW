from __future__ import annotations

import argparse
import json
import signal
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from parameterdb_core.client import SignalClient

from .base import DataSourceBase
from .loader import DataSourceRegistry, autodiscover_sources


@dataclass(slots=True)
class SourceInstance:
    name: str
    source_type: str
    source: DataSourceBase
    thread: threading.Thread


class SourceRunner:
    def __init__(self, client: SignalClient, registry: DataSourceRegistry) -> None:
        self.client = client
        self.registry = registry
        self.instances: list[SourceInstance] = []

    def load_configs(self, config_files: list[str]) -> list[SourceInstance]:
        created: list[SourceInstance] = []
        for cfg_path in config_files:
            payload = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
            name = payload["name"]
            source_type = payload["source_type"]
            config = payload.get("config") or {}
            spec = self.registry.get(source_type)
            source = spec.create(name, self.client, config=config)
            thread = threading.Thread(target=source.run, name=f"source:{name}", daemon=True)
            created.append(SourceInstance(name=name, source_type=source_type, source=source, thread=thread))
        self.instances.extend(created)
        return created

    def start_all(self) -> None:
        for inst in self.instances:
            inst.source.start()
            inst.thread.start()

    def stop_all(self) -> None:
        for inst in self.instances:
            inst.source.stop()
        for inst in self.instances:
            inst.thread.join(timeout=2.0)


def _builtin_source_root() -> str:
    return str(Path(__file__).resolve().parents[1] / "sources")


def _default_config_dir() -> str:
    return "./source_configs"


def main() -> None:
    parser = argparse.ArgumentParser(description="ParameterDB data source runner")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--source-root", default=None, help="Optional extra folder containing custom source type folders.")
    parser.add_argument("--config", action="append", default=[], help="Path to a source config JSON file. May be passed multiple times.")
    parser.add_argument("--config-dir", default=_default_config_dir(), help="Load all *.json source configs from this folder if --config is not used.")
    args = parser.parse_args()

    client = SignalClient(args.host, args.port, timeout=5.0)
    registry = DataSourceRegistry()

    builtin_root = _builtin_source_root()
    loaded_builtin = autodiscover_sources(builtin_root, registry)
    loaded_custom: list[str] = []
    if args.source_root:
        loaded_custom = autodiscover_sources(args.source_root, registry)

    config_files = list(args.config)
    if not config_files:
        cfg_dir = Path(args.config_dir)
        if cfg_dir.exists():
            config_files = [str(p) for p in sorted(cfg_dir.glob("*.json"))]

    if not config_files:
        raise SystemExit("No source config files found. Use --config or place *.json files in ./sources")

    runner = SourceRunner(client, registry)
    instances = runner.load_configs(config_files)

    print(f"[INFO] Built-in source root: {builtin_root}")
    print(f"[INFO] Loaded built-in source types: {loaded_builtin}")
    if args.source_root:
        print(f"[INFO] Extra source root: {args.source_root}")
        print(f"[INFO] Loaded extra source types: {loaded_custom}")
    print(f"[INFO] Loaded source instances: {[i.name for i in instances]}")

    runner.start_all()

    def shutdown(*_args: Any) -> None:
        print("[INFO] Stopping data sources...")
        runner.stop_all()
        raise SystemExit(0)

    signal.signal(signal.SIGINT, shutdown)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, shutdown)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        shutdown()
