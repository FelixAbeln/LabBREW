from __future__ import annotations

import socket
from typing import Any, Iterator

from .protocol import (
    encode_message,
    make_request,
    read_message,
    validate_response_envelope,
)


class Subscription:
    def __init__(self, host: str, port: int, timeout: float, names: list[str] | None = None, send_initial: bool = True, max_queue: int = 1000) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self.names = names or []
        self.send_initial = send_initial
        self.max_queue = max(1, int(max_queue))
        self.sock: socket.socket | None = None
        self.file = None
        self.subscription_info: dict[str, Any] | None = None

    def __enter__(self) -> "Subscription":
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.file = self.sock.makefile("rb")
        self.sock.sendall(encode_message(make_request(
            "subscribe",
            {
                "names": self.names,
                "send_initial": self.send_initial,
                "max_queue": self.max_queue,
            },
        )))
        ack = read_message(self.file)
        if ack is None:
            raise RuntimeError("No subscribe response from server")
        ok, _req_id, result, error = validate_response_envelope(ack)
        if not ok:
            raise RuntimeError((error or {}).get("message", "Subscribe failed"))
        self.subscription_info = result if isinstance(result, dict) else {"status": result}
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            if self.file:
                self.file.close()
        finally:
            if self.sock:
                self.sock.close()

    def __iter__(self) -> Iterator[dict[str, Any]]:
        while True:
            if self.file is None:
                break
            msg = read_message(self.file)
            if msg is None:
                break
            yield msg


class SignalClient:
    def __init__(self, host: str = "127.0.0.1", port: int = 8765, timeout: float = 2.0) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout

    def _request(self, cmd: str, payload: dict[str, Any] | None = None) -> Any:
        req = make_request(cmd, payload or {})
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
            sock.sendall(encode_message(req))
            resp = read_message(sock.makefile("rb"))
            if resp is None:
                raise RuntimeError("No response from server")
        ok, _req_id, result, error = validate_response_envelope(resp)
        if not ok:
            if error is None:
                raise RuntimeError("Unknown server error")
            raise RuntimeError(f"{error.get('type', 'Error')}: {error.get('message', 'Unknown error')}")
        return result

    def subscribe(self, names: list[str] | None = None, send_initial: bool = True, max_queue: int = 1000) -> Subscription:
        return Subscription(self.host, self.port, self.timeout, names=names, send_initial=send_initial, max_queue=max_queue)

    def ping(self) -> str:
        return self._request("ping")

    def stats(self) -> dict[str, Any]:
        return self._request("stats")

    def graph_info(self) -> dict[str, Any]:
        return self._request("graph_info")

    def snapshot(self) -> dict[str, Any]:
        return self._request("snapshot")

    def describe(self) -> dict[str, Any]:
        return self._request("describe")

    def list_parameters(self) -> list[str]:
        return self._request("list_parameters")

    def list_plugin_types(self) -> dict[str, Any]:
        return self._request("list_plugin_types")

    def list_plugin_ui(self) -> dict[str, Any]:
        return self._request("list_plugin_ui")

    def get_plugin_ui(self, plugin_type: str) -> dict[str, Any]:
        return self._request("get_plugin_ui", {"plugin_type": plugin_type})

    def create_parameter(self, name: str, plugin_type: str, *, value: Any = None, config: dict[str, Any] | None = None, metadata: dict[str, Any] | None = None) -> bool:
        return self._request("create_parameter", {
            "name": name,
            "plugin_type": plugin_type,
            "value": value,
            "config": config or {},
            "metadata": metadata or {},
        })

    def delete_parameter(self, name: str) -> bool:
        return self._request("delete_parameter", {"name": name})

    def get_value(self, name: str, default: Any = None) -> Any:
        return self._request("get_value", {"name": name, "default": default})

    def set_value(self, name: str, value: Any) -> bool:
        return self._request("set_value", {"name": name, "value": value})

    def update_config(self, name: str, **changes: Any) -> bool:
        return self._request("update_config", {"name": name, "changes": changes})

    def update_metadata(self, name: str, **changes: Any) -> bool:
        return self._request("update_metadata", {"name": name, "changes": changes})

    def load_plugin_folder(self, folder: str) -> str:
        return self._request("load_plugin_folder", {"folder": folder})
