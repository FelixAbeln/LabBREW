from __future__ import annotations

from dataclasses import dataclass

from application.config_models import ApplicationConfigModel


@dataclass(frozen=True)
class ValidationIssue:
    panel: str
    field: str
    message: str
    severity: str = "error"


@dataclass(frozen=True)
class ValidationResult:
    issues: tuple[ValidationIssue, ...] = ()

    @property
    def errors(self) -> tuple[ValidationIssue, ...]:
        return tuple(i for i in self.issues if i.severity == "error")

    @property
    def warnings(self) -> tuple[ValidationIssue, ...]:
        return tuple(i for i in self.issues if i.severity == "warning")

    @property
    def is_valid(self) -> bool:
        return not self.errors

    def summary(self) -> str:
        if self.is_valid and not self.warnings:
            return "Configuration looks valid."
        if self.errors:
            first = self.errors[0]
            suffix = "" if len(self.errors) == 1 else f" (+{len(self.errors)-1} more)"
            return f"Fix configuration errors before saving: {first.message}{suffix}"
        first = self.warnings[0]
        suffix = "" if len(self.warnings) == 1 else f" (+{len(self.warnings)-1} more)"
        return f"Configuration warnings: {first.message}{suffix}"


def validate_application_config(config: ApplicationConfigModel) -> ValidationResult:
    from services.config_validation_service import ConfigValidationService
    return ConfigValidationService().validate(config)
