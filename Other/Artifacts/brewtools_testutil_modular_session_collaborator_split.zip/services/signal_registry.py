from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from state import AppState


@dataclass
class SignalRecord:
    key: str
    label: str
    value: Any
    quality: str = "GOOD"
    unit: str = ""


def make_signal_key(kind: str, *parts: object) -> str:
    return ':'.join([kind, *[str(p) for p in parts]])


def build_signal_registry(snapshot: AppState) -> List[SignalRecord]:
    now = time.time()
    stale_after = max(0.1, float(snapshot.safety.stale_timeout_s))
    records: List[SignalRecord] = []

    def quality(last_seen: Optional[float]) -> str:
        if last_seen is None:
            return 'MISSING'
        return 'GOOD' if (now - float(last_seen)) <= stale_after else 'STALE'

    for key, st in sorted(snapshot.devices.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        q = quality(st.last_seen)
        try:
            from helpers import format_node_type
            base = f'{format_node_type(st.sender_node_type)} #{st.node_id}'
        except Exception:
            base = f'{st.sender_node_type}:{st.node_id}'
        if st.temperature is not None:
            records.append(SignalRecord(make_signal_key('sensor','temperature',*key), f'{base} — Temperature', st.temperature, q, '°C'))
        if st.pressure is not None:
            records.append(SignalRecord(make_signal_key('sensor','pressure',*key), f'{base} — Pressure', st.pressure, q, 'bar'))
        if st.density is not None:
            records.append(SignalRecord(make_signal_key('sensor','density',*key), f'{base} — Density', st.density, q, ''))
        if st.level is not None:
            records.append(SignalRecord(make_signal_key('sensor','level',*key), f'{base} — Level', st.level, q, ''))
        if st.rpm is not None:
            records.append(SignalRecord(make_signal_key('sensor','rpm',*key), f'{base} — RPM', st.rpm, q, 'rpm'))
    records.extend([
        SignalRecord('system:can_connected', 'System — CAN connected', snapshot.can_connected, 'GOOD', ''),
        SignalRecord('system:psu_power_on', 'System — PSU power on', snapshot.psu_power_on, 'GOOD', ''),
        SignalRecord('system:relay_connected', 'System — Relays connected', snapshot.relay.connected, 'GOOD', ''),
        SignalRecord('system:scheduler_running', 'System — Scheduler running', snapshot.scheduler_runtime.running, 'GOOD', ''),
        SignalRecord('system:scheduler_paused', 'System — Scheduler paused', snapshot.scheduler_runtime.paused, 'GOOD', ''),
        SignalRecord('system:twin_enabled', 'System — Twin enabled', snapshot.twin.enabled, 'GOOD', ''),
        SignalRecord('system:twin_loaded', 'System — Twin loaded', bool(snapshot.twin_runtime.outputs.get('runtime_mode', 'none') != 'none' or snapshot.twin_runtime.outputs.get('fmu_name')), 'GOOD', ''),
        SignalRecord('virtual:heat', 'Virtual — HEAT', snapshot.controls.heat_cool.output_a, 'GOOD', ''),
        SignalRecord('virtual:cool', 'Virtual — COOL', snapshot.controls.heat_cool.output_b, 'GOOD', ''),
        SignalRecord('virtual:add_gas', 'Virtual — ADD GAS', snapshot.controls.gas.output_a, 'GOOD', ''),
        SignalRecord('virtual:remove_gas', 'Virtual — REMOVE GAS', snapshot.controls.gas.output_b, 'GOOD', ''),
        SignalRecord('virtual:agitator', 'Virtual — AGITATOR', snapshot.controls.agitator_runtime.effective_on, 'GOOD', ''),
        SignalRecord('agitator:on', 'Agitator — Command on', snapshot.controls.agitator.on, 'GOOD', ''),
        SignalRecord('agitator:enabled', 'Agitator — Controller enabled', snapshot.controls.agitator.enabled, 'GOOD', ''),
        SignalRecord('agitator:target', 'Agitator — Target selection', snapshot.controls.agitator.target, 'GOOD', ''),
        SignalRecord('agitator:mode', 'Agitator — Control mode', snapshot.controls.agitator.mode, 'GOOD', ''),
        SignalRecord('agitator:duty_cycle', 'Agitator — Effective duty cycle', snapshot.controls.agitator_runtime.effective_duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:configured_duty_cycle', 'Agitator — Configured duty cycle', snapshot.controls.agitator.duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:speed_setpoint_rpm', 'Agitator — Speed setpoint', snapshot.controls.agitator.speed_setpoint_rpm, 'GOOD', 'rpm'),
        SignalRecord('agitator:pid_active', 'Agitator — PID active', snapshot.controls.agitator_runtime.pid_active, 'GOOD', ''),
        SignalRecord('agitator:rpm', 'Agitator — RPM feedback', snapshot.controls.agitator_runtime.rpm_feedback, 'GOOD' if snapshot.controls.agitator_runtime.rpm_feedback is not None else 'MISSING', 'rpm'),
    ])
    for ch in range(1, max(1, snapshot.relay.channel_count)+1):
        records.append(SignalRecord(make_signal_key('relay', ch), f'Relay {ch} state', snapshot.relay.channel_states.get(ch, False), 'GOOD' if snapshot.relay.connected else 'MISSING', ''))
    records.append(SignalRecord('psu:measured_voltage', 'PSU — Measured voltage', snapshot.psu_measured_voltage, 'GOOD' if snapshot.psu_measured_voltage is not None else 'MISSING', 'V'))
    records.append(SignalRecord('psu:measured_current', 'PSU — Measured current', snapshot.psu_measured_current, 'GOOD' if snapshot.psu_measured_current is not None else 'MISSING', 'A'))
    for name, value in sorted(snapshot.twin_runtime.outputs.items()):
        if name in {'status_text', 'fmu_name'}:
            continue
        records.append(SignalRecord(make_signal_key('twin', name), f'Twin — {name}', value, 'GOOD' if value is not None else 'MISSING', ''))
    return records


def signal_lookup(snapshot: AppState) -> Dict[str, SignalRecord]:
    return {rec.key: rec for rec in build_signal_registry(snapshot)}
