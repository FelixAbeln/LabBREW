from __future__ import annotations

from gui.window_composer import MainWindowComposer
from gui.window_startup import MainWindowStartup


class MainWindowBootstrap:
    """Coordinates composition and startup so MainWindow stays tiny."""

    def __init__(self, window):
        self.window = window
        self.composer = MainWindowComposer(window)
        self.startup = MainWindowStartup(window)

    def initialize(self) -> None:
        self.composer.compose()
        self.startup.apply()
        self.window.session.start()
        self.window.session.initial_refresh()
