from __future__ import annotations


class MainWindowStartup:
    """Owns startup discovery, settings application, and initial validation."""

    def __init__(self, window):
        self.window = window

    def apply(self) -> None:
        w = self.window
        w.ui_state.loading_settings = True
        try:
            w.brew_controller.populate_psu_ports()
            w.brew_controller.populate_channels()
            w.relay_controller.populate_relay_targets()
            w.settings_loader.apply()
        finally:
            w.ui_state.loading_settings = False
        w.source_controller.refresh_control_sources()
        w.source_controller.refresh_twin_sources()
        w.intent_dispatcher.refresh_footer()
        w.brew_controller.set_status('Ready. Select PSU port, choose CAN voltage, power the rail, then connect CAN.')
        w.validation_controller.validate_current(decorate=True, show_status=False)
