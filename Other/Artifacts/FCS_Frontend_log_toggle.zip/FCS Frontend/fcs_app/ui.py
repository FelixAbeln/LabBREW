from __future__ import annotations

import json
from dataclasses import dataclass
from urllib import request

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
    QComboBox,
)

from .template_exporter import ScheduleTemplateExporter, TemplateExportOptions


@dataclass(slots=True)
class ApiClient:
    base_url: str

    def get(self, path: str) -> dict:
        with request.urlopen(f"{self.base_url}{path}", timeout=3.0) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def post(self, path: str, payload: dict | None = None) -> dict:
        data = json.dumps(payload or {}).encode("utf-8")
        req = request.Request(f"{self.base_url}{path}", data=data, headers={"Content-Type": "application/json"}, method="POST")
        with request.urlopen(req, timeout=5.0) as resp:
            return json.loads(resp.read().decode("utf-8"))


class MainWindow(QMainWindow):
    def __init__(self, api: ApiClient) -> None:
        super().__init__()
        self.api = api
        self.template_exporter = ScheduleTemplateExporter()
        self.setWindowTitle("FCS Scheduler Client")
        self._log_expanded = False

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        top_group = QGroupBox("Workbook")
        top = QGridLayout(top_group)
        self.workbook_path = QLineEdit()
        self.btn_browse = QPushButton("Browse…")
        self.btn_load = QPushButton("Load workbook")
        self.template_mode = QComboBox()
        self.template_mode.addItems(["Blank template", "Test routine template"])
        self.btn_export_template = QPushButton("Export template")
        top.addWidget(QLabel("Workbook"), 0, 0)
        top.addWidget(self.workbook_path, 0, 1)
        top.addWidget(self.btn_browse, 0, 2)
        top.addWidget(self.btn_load, 0, 3)
        top.addWidget(QLabel("Template mode"), 1, 0)
        top.addWidget(self.template_mode, 1, 1, 1, 2)
        top.addWidget(self.btn_export_template, 1, 3)
        top.setColumnStretch(1, 1)
        layout.addWidget(top_group)

        ctrl = QHBoxLayout()
        ctrl.setSpacing(8)
        self.btn_start = QPushButton("Start")
        self.btn_pause = QPushButton("Pause")
        self.btn_resume = QPushButton("Resume")
        self.btn_stop = QPushButton("Stop")
        self.btn_prev = QPushButton("Previous")
        self.btn_next = QPushButton("Next")
        self.btn_confirm = QPushButton("Confirm / Continue")
        for btn in [self.btn_start, self.btn_pause, self.btn_resume, self.btn_stop, self.btn_prev, self.btn_next, self.btn_confirm]:
            btn.setMinimumHeight(44)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            ctrl.addWidget(btn)
        layout.addLayout(ctrl)

        status_group = QGroupBox("Runtime status")
        status_form = QFormLayout(status_group)
        status_form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        self.state_lbl = QLabel("—")
        self.phase_lbl = QLabel("—")
        self.step_lbl = QLabel("—")
        self.elapsed_lbl = QLabel("—")
        self.hold_lbl = QLabel("—")
        self.wait_lbl = QLabel("—")
        self.confirm_lbl = QLabel("—")
        self.transition_lbl = QLabel("—")
        for lbl in [self.state_lbl, self.phase_lbl, self.step_lbl, self.elapsed_lbl, self.hold_lbl, self.wait_lbl, self.confirm_lbl, self.transition_lbl]:
            lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        status_form.addRow("State", self.state_lbl)
        status_form.addRow("Phase", self.phase_lbl)
        status_form.addRow("Current step", self.step_lbl)
        status_form.addRow("Step elapsed", self.elapsed_lbl)
        status_form.addRow("Hold elapsed", self.hold_lbl)
        status_form.addRow("Waiting", self.wait_lbl)
        status_form.addRow("Confirmation", self.confirm_lbl)
        status_form.addRow("Last transition", self.transition_lbl)
        layout.addWidget(status_group)

        self.tabs = QTabWidget()
        self.startup_table = QTableWidget(0, 8)
        self.startup_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.plan_table = QTableWidget(0, 8)
        self.plan_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.tabs.addTab(self.startup_table, "StartupRoutine")
        self.tabs.addTab(self.plan_table, "Plan")
        self.startup_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.plan_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        log_group = QGroupBox("Log")
        log_layout = QVBoxLayout(log_group)
        log_layout.setContentsMargins(8, 8, 8, 8)
        self.btn_toggle_log = QPushButton("Show log")
        self.btn_toggle_log.setCheckable(True)
        self.btn_toggle_log.setChecked(False)
        self.events = QTextEdit()
        self.events.setReadOnly(True)
        self.events.setVisible(False)
        self.events.setMinimumHeight(120)
        log_layout.addWidget(self.btn_toggle_log, 0)
        log_layout.addWidget(self.events, 1)

        self.content_splitter = QSplitter(Qt.Vertical)
        self.content_splitter.addWidget(self.tabs)
        self.content_splitter.addWidget(log_group)
        self.content_splitter.setStretchFactor(0, 1)
        self.content_splitter.setStretchFactor(1, 0)
        self.content_splitter.setCollapsible(0, False)
        self.content_splitter.setCollapsible(1, True)
        layout.addWidget(self.content_splitter, 1)

        self.setCentralWidget(root)
        self._wire()
        self._apply_styles()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_status)
        self.timer.start(1000)
        self._sync_log_visibility()
        self.refresh_status()

    def _apply_styles(self) -> None:
        self.setStyleSheet(
            """
            QTableWidget { gridline-color: #d5dbe3; background: white; }
            QHeaderView::section { background: #174a7e; color: white; padding: 6px; border: none; }
            QTabWidget::pane { border: 1px solid #c7d0db; top: -1px; background: white; }
            QTabBar::tab { background: #e7edf4; border: 1px solid #c7d0db; padding: 8px 18px; min-width: 120px; }
            QTabBar::tab:selected { background: white; }
            QGroupBox { font-weight: 600; }
            QTextEdit { background: white; }
            """
        )

    def _wire(self) -> None:
        self.btn_browse.clicked.connect(self.browse_workbook)
        self.btn_load.clicked.connect(self.load_schedule)
        self.btn_export_template.clicked.connect(self.export_template)
        self.btn_start.clicked.connect(lambda: self._post("/run/start"))
        self.btn_pause.clicked.connect(lambda: self._post("/run/pause"))
        self.btn_resume.clicked.connect(lambda: self._post("/run/resume"))
        self.btn_stop.clicked.connect(lambda: self._post("/run/stop"))
        self.btn_prev.clicked.connect(lambda: self._post("/run/previous"))
        self.btn_next.clicked.connect(lambda: self._post("/run/next"))
        self.btn_confirm.clicked.connect(lambda: self._post("/run/confirm"))
        self.btn_toggle_log.toggled.connect(self._on_toggle_log)

    def _on_toggle_log(self, checked: bool) -> None:
        self._log_expanded = checked
        self._sync_log_visibility()

    def _sync_log_visibility(self) -> None:
        self.events.setVisible(self._log_expanded)
        self.btn_toggle_log.setText("Hide log" if self._log_expanded else "Show log")
        if self._log_expanded:
            self.content_splitter.setSizes([620, 220])
            self._scroll_log_to_bottom()
        else:
            self.content_splitter.setSizes([840, 0])

    def browse_workbook(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select schedule workbook", self.workbook_path.text().strip(), "Excel Workbook (*.xlsx *.xlsm)")
        if path:
            self.workbook_path.setText(path)

    def export_template(self) -> None:
        suggested_name = "fcs_test_routine_template.xlsx" if self.template_mode.currentIndex() == 1 else "fcs_schedule_template.xlsx"
        path, _ = QFileDialog.getSaveFileName(self, "Export schedule template", suggested_name, "Excel Workbook (*.xlsx)")
        if not path:
            return
        try:
            options = TemplateExportOptions(include_examples=True, include_test_routine=self.template_mode.currentIndex() == 1)
            exported = self.template_exporter.export(path, options)
            self.workbook_path.setText(str(exported))
            QMessageBox.information(self, "Template exported", f"Template written to:
{exported}")
        except Exception as exc:
            QMessageBox.critical(self, "Template export failed", str(exc))

    def load_schedule(self) -> None:
        self._post("/schedule/load", {"workbook_path": self.workbook_path.text().strip()}, refresh=True)

    def refresh_status(self) -> None:
        try:
            status = self.api.get("/status")
        except Exception as exc:
            self.state_lbl.setText(f"Disconnected ({exc})")
            return
        self.state_lbl.setText(str(status.get("state", "—")))
        self.phase_lbl.setText(str(status.get("phase", "—")))
        idx = int(status.get("current_step_index", -1))
        name = status.get("current_step_name", "")
        display_idx = idx + 1 if idx >= 0 else idx
        self.step_lbl.setText(f"{display_idx} | {name}" if name else str(display_idx))
        self.elapsed_lbl.setText(f"{float(status.get('step_elapsed_s', 0.0)):.1f} s")
        self.hold_lbl.setText(f"{float(status.get('hold_elapsed_s', 0.0)):.1f} s")
        self.wait_lbl.setText(str(status.get("wait_reason", "—")))
        self.confirm_lbl.setText(str(status.get("confirmation_message", "—")))
        self.transition_lbl.setText(str(status.get("last_transition", "—")))
        self._fill_table(self.startup_table, status.get("startup_steps", []))
        self._fill_table(self.plan_table, status.get("plan_steps", []))
        self.events.setPlainText("
".join(status.get("event_log", [])))
        self._scroll_log_to_bottom()

    def _scroll_log_to_bottom(self) -> None:
        sb = self.events.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _fill_table(self, table: QTableWidget, steps: list[dict]) -> None:
        table.setRowCount(len(steps))
        for row, step in enumerate(steps):
            actions = "; ".join(action.get("display_text", "") for action in step.get("controller_actions", []))
            criteria = self._criteria_text(step)
            index_value = int(step.get("index", row)) + 1
            values = [
                index_value,
                step.get("enabled", True),
                step.get("name", ""),
                actions,
                step.get("wait_type", ""),
                step.get("wait_source", ""),
                criteria,
                step.get("confirmation_message", "") or step.get("require_confirmation", False),
            ]
            for col, value in enumerate(values):
                table.setItem(row, col, QTableWidgetItem(str(value)))
        header = table.horizontalHeader()
        header.setStretchLastSection(False)
        for col in [2, 3, 5, 6, 7]:
            header.setSectionResizeMode(col, header.Stretch)
        table.resizeRowsToContents()

    def _criteria_text(self, step: dict) -> str:
        wait_type = step.get("wait_type", "")
        if wait_type == "signal":
            operator = step.get("operator", "")
            if operator in {"in_range", "out_of_range"}:
                return f"{operator} [{step.get('threshold_low', '')}, {step.get('threshold_high', '')}] hold={step.get('hold_for_s', 0)}s"
            return f"{operator} {step.get('threshold', '')} hold={step.get('hold_for_s', 0)}s"
        if wait_type == "all_valid":
            return f"{', '.join(step.get('valid_sources', []))} hold={step.get('hold_for_s', 0)}s"
        return f"{step.get('duration_s', 0)}s"

    def _post(self, path: str, payload: dict | None = None, *, refresh: bool = True) -> None:
        try:
            result = self.api.post(path, payload)
            if refresh:
                self.refresh_status()
            if not result.get("ok", True):
                QMessageBox.warning(self, "FCS service", str(result.get("message", "Unknown error")))
        except Exception as exc:
            QMessageBox.critical(self, "FCS service", str(exc))


def run_ui(base_url: str = "http://127.0.0.1:8769") -> int:
    app = QApplication([])
    window = MainWindow(ApiClient(base_url=base_url.rstrip("/")))
    window.resize(1280, 860)
    window.show()
    return app.exec()
