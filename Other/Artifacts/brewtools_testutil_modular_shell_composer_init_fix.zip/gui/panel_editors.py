from __future__ import annotations

from dataclasses import dataclass
from gui.panel_field_models import (
    BrewPanelFormState,
    ControlPanelFormState,
    RelayPanelFormState,
    SafetyPanelFormState,
    SchedulerPanelFormState,
    TwinPanelFormState,
)
from gui.ui_helpers import find_data_index, normalize_signal_key


class _SignalBinder:
    @staticmethod
    def combo_value(combo):
        return combo.currentData() if combo.count() else None


@dataclass
class BrewPanelEditor:
    panel: object
    settings: object
    state: BrewPanelFormState | None = None

    def __post_init__(self) -> None:
        self.state = BrewPanelFormState(
            bitrate=int(self.settings.bitrate),
            can_channel=self.settings.can_channel,
            can_channel_label='',
            psu_com_port=str(self.settings.psu_com_port or ''),
            voltage=float(self.settings.voltage),
        )

    def bind(self) -> None:
        self.panel.bitrate.valueChanged.connect(lambda value: self._update(bitrate=int(value)))
        self.panel.channel_combo.currentIndexChanged.connect(self._on_channel_changed)
        self.panel.psu_port_combo.currentIndexChanged.connect(self._on_psu_port_changed)
        self.panel.psu_voltage.valueChanged.connect(lambda value: self._update(voltage=float(value)))

    def _update(self, **changes) -> None:
        self.state = BrewPanelFormState(**{**self.state.__dict__, **changes})

    def _on_channel_changed(self, _index: int) -> None:
        self._update(
            can_channel=self.panel.channel_combo.currentData(),
            can_channel_label=self.panel.channel_combo.currentText().strip() if self.panel.channel_combo.count() else '',
        )

    def _on_psu_port_changed(self, _index: int) -> None:
        self._update(psu_com_port=str(self.panel.psu_port_combo.currentData() or ''))

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        self.state = BrewPanelFormState(
            bitrate=int(settings.bitrate),
            can_channel=settings.can_channel,
            can_channel_label=self.state.can_channel_label,
            psu_com_port=str(settings.psu_com_port or ''),
            voltage=float(settings.voltage),
        )
        self.panel.bitrate.setValue(settings.bitrate)
        self.panel.psu_voltage.setValue(settings.voltage)
        idx = self.panel.channel_combo.findData(settings.can_channel)
        if idx >= 0:
            self.panel.channel_combo.setCurrentIndex(idx)
        idx = self.panel.psu_port_combo.findData(settings.psu_com_port)
        if idx >= 0:
            self.panel.psu_port_combo.setCurrentIndex(idx)


@dataclass
class ControlPanelEditor:
    panel: object
    ui_state: object
    settings: object
    state: ControlPanelFormState | None = None

    def __post_init__(self) -> None:
        a = self.settings.agitator
        self.state = ControlPanelFormState(
            temp_enabled=bool(self.settings.temp_controller.enabled),
            temp_source_key=normalize_signal_key(self.settings.temp_controller.source_key),
            temp_setpoint=float(self.settings.temp_controller.setpoint),
            temp_deadband=float(self.settings.temp_controller.deadband),
            pressure_enabled=bool(self.settings.pressure_controller.enabled),
            pressure_source_key=normalize_signal_key(self.settings.pressure_controller.source_key),
            pressure_setpoint=float(self.settings.pressure_controller.setpoint),
            pressure_deadband=float(self.settings.pressure_controller.deadband),
            pressure_allow_add_gas=bool(getattr(self.settings.pressure_controller, 'allow_add_gas', True)),
            agitator_enabled=bool(getattr(a, 'enabled', False)),
            agitator_target=str(getattr(a, 'target', 'relay') or 'relay'),
            agitator_on=bool(getattr(a, 'on', False)),
            agitator_duty_cycle=float(getattr(a, 'duty_cycle', 100.0)),
            agitator_mode=str(getattr(a, 'mode', 'manual') or 'manual'),
            agitator_speed_setpoint_rpm=float(getattr(a, 'speed_setpoint_rpm', 120.0)),
            agitator_pid_kp=float(getattr(a, 'pid_kp', 0.30)),
            agitator_pid_ki=float(getattr(a, 'pid_ki', 0.05)),
            agitator_pid_kd=float(getattr(a, 'pid_kd', 0.00)),
        )

    def bind(self) -> None:
        p = self.panel
        p.temp_ctrl_enabled.toggled.connect(lambda value: self._update(temp_enabled=bool(value)))
        p.temp_source_combo.currentIndexChanged.connect(lambda _i: self._update(temp_source_key=normalize_signal_key(p.temp_source_combo.currentData()) or self.state.temp_source_key))
        p.temp_setpoint.valueChanged.connect(lambda value: self._update(temp_setpoint=float(value)))
        p.temp_deadband.valueChanged.connect(lambda value: self._update(temp_deadband=float(value)))
        p.pressure_ctrl_enabled.toggled.connect(lambda value: self._update(pressure_enabled=bool(value)))
        p.pressure_source_combo.currentIndexChanged.connect(lambda _i: self._update(pressure_source_key=normalize_signal_key(p.pressure_source_combo.currentData()) or self.state.pressure_source_key))
        p.pressure_setpoint.valueChanged.connect(lambda value: self._update(pressure_setpoint=float(value)))
        p.pressure_deadband.valueChanged.connect(lambda value: self._update(pressure_deadband=float(value)))
        p.pressure_allow_add_gas.toggled.connect(lambda value: self._update(pressure_allow_add_gas=bool(value)))
        p.agitator_enabled.toggled.connect(lambda value: self._update(agitator_enabled=bool(value)))
        p.agitator_target_combo.currentIndexChanged.connect(self._on_agitator_target_changed)
        p.agitator_on.toggled.connect(lambda value: self._update(agitator_on=bool(value)))
        p.agitator_duty.valueChanged.connect(lambda value: self._update(agitator_duty_cycle=float(value)))
        p.agitator_control_mode.currentIndexChanged.connect(self._on_agitator_mode_changed)
        p.agitator_speed_setpoint.valueChanged.connect(lambda value: self._update(agitator_speed_setpoint_rpm=float(value)))
        p.agitator_pid_kp.valueChanged.connect(lambda value: self._update(agitator_pid_kp=float(value)))
        p.agitator_pid_ki.valueChanged.connect(lambda value: self._update(agitator_pid_ki=float(value)))
        p.agitator_pid_kd.valueChanged.connect(lambda value: self._update(agitator_pid_kd=float(value)))

    def _update(self, **changes) -> None:
        self.state = ControlPanelFormState(**{**self.state.__dict__, **changes})

    def _on_agitator_target_changed(self, _index: int) -> None:
        self._update(agitator_target=str(self.panel.agitator_target_combo.currentData() or self.state.agitator_target))

    def _on_agitator_mode_changed(self, _index: int) -> None:
        self._update(agitator_mode=str(self.panel.agitator_control_mode.currentData() or self.state.agitator_mode))

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        self.ui_state.pending_temp_source_key = normalize_signal_key(settings.temp_controller.source_key)
        self.ui_state.pending_pressure_source_key = normalize_signal_key(settings.pressure_controller.source_key)
        a = settings.agitator
        self.state = ControlPanelFormState(
            temp_enabled=bool(settings.temp_controller.enabled),
            temp_source_key=normalize_signal_key(settings.temp_controller.source_key),
            temp_setpoint=float(settings.temp_controller.setpoint),
            temp_deadband=float(settings.temp_controller.deadband),
            pressure_enabled=bool(settings.pressure_controller.enabled),
            pressure_source_key=normalize_signal_key(settings.pressure_controller.source_key),
            pressure_setpoint=float(settings.pressure_controller.setpoint),
            pressure_deadband=float(settings.pressure_controller.deadband),
            pressure_allow_add_gas=bool(getattr(settings.pressure_controller, 'allow_add_gas', True)),
            agitator_enabled=bool(getattr(a, 'enabled', False)),
            agitator_target=str(getattr(a, 'target', 'relay') or 'relay'),
            agitator_on=bool(getattr(a, 'on', False)),
            agitator_duty_cycle=float(getattr(a, 'duty_cycle', 100.0)),
            agitator_mode=str(getattr(a, 'mode', 'manual') or 'manual'),
            agitator_speed_setpoint_rpm=float(getattr(a, 'speed_setpoint_rpm', 120.0)),
            agitator_pid_kp=float(getattr(a, 'pid_kp', 0.30)),
            agitator_pid_ki=float(getattr(a, 'pid_ki', 0.05)),
            agitator_pid_kd=float(getattr(a, 'pid_kd', 0.00)),
        )
        p = self.panel
        p.temp_ctrl_enabled.setChecked(settings.temp_controller.enabled)
        p.temp_setpoint.setValue(settings.temp_controller.setpoint)
        p.temp_deadband.setValue(settings.temp_controller.deadband)
        p.pressure_ctrl_enabled.setChecked(settings.pressure_controller.enabled)
        p.pressure_setpoint.setValue(settings.pressure_controller.setpoint)
        p.pressure_deadband.setValue(settings.pressure_controller.deadband)
        p.pressure_allow_add_gas.setChecked(bool(getattr(settings.pressure_controller, 'allow_add_gas', True)))
        p.agitator_enabled.setChecked(bool(getattr(a, 'enabled', False)))
        p.agitator_on.setChecked(bool(getattr(a, 'on', False)))
        p.agitator_duty.setValue(float(getattr(a, 'duty_cycle', 100.0)))
        p.agitator_speed_setpoint.setValue(float(getattr(a, 'speed_setpoint_rpm', 120.0)))
        p.agitator_pid_kp.setValue(float(getattr(a, 'pid_kp', 0.30)))
        p.agitator_pid_ki.setValue(float(getattr(a, 'pid_ki', 0.05)))
        p.agitator_pid_kd.setValue(float(getattr(a, 'pid_kd', 0.00)))
        idx = p.agitator_control_mode.findData(getattr(a, 'mode', 'manual'))
        p.agitator_control_mode.setCurrentIndex(idx if idx >= 0 else 0)
        p.refresh_agitator_control_ui()


@dataclass
class RelayPanelEditor:
    panel: object
    relay_channel_rows: dict[int, dict[str, object]]
    settings: object
    state: RelayPanelFormState | None = None

    def __post_init__(self) -> None:
        self.state = RelayPanelFormState(
            host=str(self.settings.relay.host),
            tcp_port=int(self.settings.relay.tcp_port),
            assignments={str(k): v for k, v in self.settings.relay.assignments.items()},
            auto_enabled={str(k): bool(v) for k, v in self.settings.relay.auto_enabled.items()},
            manual_states={str(k): False for k in self.settings.relay.assignments.keys()},
        )

    def bind(self) -> None:
        self.panel.relay_host.editTextChanged.connect(lambda text: self._update(host=text.strip()))
        self.panel.relay_tcp_port.valueChanged.connect(lambda value: self._update(tcp_port=int(value)))
        for ch, row in self.relay_channel_rows.items():
            key = str(ch)
            row['combo'].currentIndexChanged.connect(lambda _i, k=key, combo=row['combo']: self._set_assignment(k, combo.currentData()))
            row['auto'].toggled.connect(lambda value, k=key: self._set_auto(k, bool(value)))
            row['test'].toggled.connect(lambda value, k=key: self._set_manual(k, bool(value)))

    def _update(self, **changes) -> None:
        self.state = RelayPanelFormState(**{**self.state.__dict__, **changes})

    def _set_assignment(self, key: str, value) -> None:
        assignments = dict(self.state.assignments)
        assignments[key] = value
        self._update(assignments=assignments)

    def _set_auto(self, key: str, value: bool) -> None:
        auto = dict(self.state.auto_enabled)
        auto[key] = value
        self._update(auto_enabled=auto)

    def _set_manual(self, key: str, value: bool) -> None:
        manual = dict(self.state.manual_states)
        manual[key] = value
        self._update(manual_states=manual)

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        self.state = RelayPanelFormState(
            host=str(settings.relay.host),
            tcp_port=int(settings.relay.tcp_port),
            assignments={str(k): v for k, v in settings.relay.assignments.items()},
            auto_enabled={str(k): bool(v) for k, v in settings.relay.auto_enabled.items()},
            manual_states={str(k): False for k in settings.relay.assignments.keys()},
        )
        self.panel.relay_host.setEditText(settings.relay.host)
        self.panel.relay_tcp_port.setValue(int(settings.relay.tcp_port))
        for ch, row in self.relay_channel_rows.items():
            key = str(ch)
            target = settings.relay.assignments.get(key)
            idx = find_data_index(row['combo'], target)
            row['combo'].setCurrentIndex(idx if idx >= 0 else 0)
            row['auto'].setChecked(bool(settings.relay.auto_enabled.get(key, True)))
            row['test'].setChecked(False)


@dataclass
class SafetyPanelEditor:
    panel: object
    rules_controller: object
    settings: object
    state: SafetyPanelFormState | None = None

    def __post_init__(self) -> None:
        s = self.settings.safety
        self.state = SafetyPanelFormState(
            enabled=bool(s.enabled), stale_timeout_s=float(s.stale_timeout_s), min_switch_time_s=float(s.min_switch_time_s),
            require_can_connected=bool(s.require_can_connected), require_psu_power=bool(s.require_psu_power), require_relays_connected=bool(s.require_relays_connected),
            max_temperature_enabled=bool(s.max_temperature_enabled), max_temperature_c=float(s.max_temperature_c),
            max_pressure_enabled=bool(s.max_pressure_enabled), max_pressure_bar=float(s.max_pressure_bar),
            power_off_psu_on_trip=bool(s.power_off_psu_on_trip), all_relays_off_on_trip=bool(s.all_relays_off_on_trip),
            safe_outputs={k: bool(v) for k, v in s.safe_outputs.items()},
        )

    def bind(self) -> None:
        p=self.panel
        p.safety_enabled.toggled.connect(lambda value: self._update(enabled=bool(value)))
        p.safety_stale_timeout.valueChanged.connect(lambda value: self._update(stale_timeout_s=float(value)))
        p.safety_min_switch.valueChanged.connect(lambda value: self._update(min_switch_time_s=float(value)))
        p.safety_require_can.toggled.connect(lambda value: self._update(require_can_connected=bool(value)))
        p.safety_require_psu.toggled.connect(lambda value: self._update(require_psu_power=bool(value)))
        p.safety_require_relays.toggled.connect(lambda value: self._update(require_relays_connected=bool(value)))
        p.safety_max_temp_enabled.toggled.connect(lambda value: self._update(max_temperature_enabled=bool(value)))
        p.safety_max_temp.valueChanged.connect(lambda value: self._update(max_temperature_c=float(value)))
        p.safety_max_pressure_enabled.toggled.connect(lambda value: self._update(max_pressure_enabled=bool(value)))
        p.safety_max_pressure.valueChanged.connect(lambda value: self._update(max_pressure_bar=float(value)))
        p.safe_psu_off.toggled.connect(lambda value: self._update(power_off_psu_on_trip=bool(value)))
        p.safe_all_relays_off.toggled.connect(lambda value: self._update(all_relays_off_on_trip=bool(value)))
        for key, cb in [('heat',p.safe_heat),('cool',p.safe_cool),('add_gas',p.safe_add_gas),('remove_gas',p.safe_remove_gas),('agitator',p.safe_agitator)]:
            cb.toggled.connect(lambda value, k=key: self._set_safe_output(k, bool(value)))

    def _update(self, **changes) -> None:
        self.state = SafetyPanelFormState(**{**self.state.__dict__, **changes})

    def _set_safe_output(self, key: str, value: bool) -> None:
        outputs = dict(self.state.safe_outputs)
        outputs[key] = value
        self._update(safe_outputs=outputs)

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        s = settings.safety
        self.state = SafetyPanelFormState(
            enabled=bool(s.enabled), stale_timeout_s=float(s.stale_timeout_s), min_switch_time_s=float(s.min_switch_time_s),
            require_can_connected=bool(s.require_can_connected), require_psu_power=bool(s.require_psu_power), require_relays_connected=bool(s.require_relays_connected),
            max_temperature_enabled=bool(s.max_temperature_enabled), max_temperature_c=float(s.max_temperature_c),
            max_pressure_enabled=bool(s.max_pressure_enabled), max_pressure_bar=float(s.max_pressure_bar),
            power_off_psu_on_trip=bool(s.power_off_psu_on_trip), all_relays_off_on_trip=bool(s.all_relays_off_on_trip),
            safe_outputs={k: bool(v) for k, v in s.safe_outputs.items()},
        )
        p=self.panel
        p.safety_enabled.setChecked(s.enabled)
        p.safety_require_can.setChecked(s.require_can_connected)
        p.safety_require_psu.setChecked(s.require_psu_power)
        p.safety_require_relays.setChecked(s.require_relays_connected)
        p.safety_stale_timeout.setValue(float(s.stale_timeout_s))
        p.safety_min_switch.setValue(float(s.min_switch_time_s))
        p.safety_max_temp_enabled.setChecked(bool(s.max_temperature_enabled))
        p.safety_max_temp.setValue(float(s.max_temperature_c))
        p.safety_max_pressure_enabled.setChecked(bool(s.max_pressure_enabled))
        p.safety_max_pressure.setValue(float(s.max_pressure_bar))
        p.safe_heat.setChecked(bool(s.safe_outputs.get('heat', False)))
        p.safe_cool.setChecked(bool(s.safe_outputs.get('cool', False)))
        p.safe_add_gas.setChecked(bool(s.safe_outputs.get('add_gas', False)))
        p.safe_remove_gas.setChecked(bool(s.safe_outputs.get('remove_gas', False)))
        p.safe_psu_off.setChecked(bool(s.power_off_psu_on_trip))
        p.safe_all_relays_off.setChecked(bool(s.all_relays_off_on_trip))
        p.safe_agitator.setChecked(bool(s.safe_outputs.get('agitator', False)))
        self.rules_controller.load_from_settings(getattr(s, 'rules', []))
        p.refresh_rules_table()
        p.clear_rule_editor()


@dataclass
class SchedulerPanelEditor:
    panel: object
    settings: object
    state: SchedulerPanelFormState | None = None

    def __post_init__(self) -> None:
        s = self.settings.scheduler
        self.state = SchedulerPanelFormState(
            enabled=bool(s.enabled), workbook_path=str(s.workbook_path), sheet_name=str(s.sheet_name), auto_start=bool(s.auto_start),
            startup_sequence_enabled=bool(s.startup_sequence_enabled), startup_auto_connect_relays=bool(s.startup_auto_connect_relays),
            startup_auto_connect_can=bool(s.startup_auto_connect_can), startup_auto_power_psu=bool(s.startup_auto_power_psu),
            startup_auto_load_twin=bool(s.startup_auto_load_twin), startup_delay_s=float(s.startup_delay_s), startup_show_advanced=bool(s.startup_show_advanced),
        )

    def bind(self) -> None:
        p=self.panel
        p.scheduler_enabled.toggled.connect(lambda value: self._update(enabled=bool(value)))
        p.scheduler_path.textChanged.connect(lambda text: self._update(workbook_path=text.strip()))
        p.scheduler_sheet.currentTextChanged.connect(lambda text: self._update(sheet_name=text.strip()))
        p.scheduler_auto_start.toggled.connect(lambda value: self._update(auto_start=bool(value)))
        p.scheduler_startup_enabled.toggled.connect(lambda value: self._update(startup_sequence_enabled=bool(value)))
        p.scheduler_startup_connect_relays.toggled.connect(lambda value: self._update(startup_auto_connect_relays=bool(value)))
        p.scheduler_startup_connect_can.toggled.connect(lambda value: self._update(startup_auto_connect_can=bool(value)))
        p.scheduler_startup_power_psu.toggled.connect(lambda value: self._update(startup_auto_power_psu=bool(value)))
        p.scheduler_startup_load_twin.toggled.connect(lambda value: self._update(startup_auto_load_twin=bool(value)))
        p.scheduler_startup_delay.valueChanged.connect(lambda value: self._update(startup_delay_s=float(value)))
        p.scheduler_startup_section.toggle_button.toggled.connect(lambda value: self._update(startup_show_advanced=bool(value)))

    def _update(self, **changes) -> None:
        self.state = SchedulerPanelFormState(**{**self.state.__dict__, **changes})

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        s = settings.scheduler
        self.state = SchedulerPanelFormState(
            enabled=bool(s.enabled), workbook_path=str(s.workbook_path), sheet_name=str(s.sheet_name), auto_start=bool(s.auto_start),
            startup_sequence_enabled=bool(s.startup_sequence_enabled), startup_auto_connect_relays=bool(s.startup_auto_connect_relays),
            startup_auto_connect_can=bool(s.startup_auto_connect_can), startup_auto_power_psu=bool(s.startup_auto_power_psu),
            startup_auto_load_twin=bool(s.startup_auto_load_twin), startup_delay_s=float(s.startup_delay_s), startup_show_advanced=bool(s.startup_show_advanced),
        )
        p=self.panel
        p.scheduler_enabled.setChecked(s.enabled)
        p.scheduler_auto_start.setChecked(s.auto_start)
        p.scheduler_path.setText(s.workbook_path)
        p.scheduler_startup_enabled.setChecked(bool(s.startup_sequence_enabled))
        p.scheduler_startup_connect_relays.setChecked(bool(s.startup_auto_connect_relays))
        p.scheduler_startup_connect_can.setChecked(bool(s.startup_auto_connect_can))
        p.scheduler_startup_power_psu.setChecked(bool(s.startup_auto_power_psu))
        p.scheduler_startup_load_twin.setChecked(bool(s.startup_auto_load_twin))
        p.scheduler_startup_delay.setValue(float(s.startup_delay_s or 0.0))
        p.scheduler_startup_section.toggle_button.setChecked(bool(s.startup_show_advanced))


@dataclass
class TwinPanelEditor:
    panel: object
    settings: object
    queries: object
    state: TwinPanelFormState | None = None

    def __post_init__(self) -> None:
        t = self.settings.twin
        self.state = TwinPanelFormState(enabled=bool(t.enabled), fmu_path=str(t.fmu_path), input_bindings=dict(getattr(t, 'input_bindings', {}) or {}))

    def bind(self) -> None:
        self.panel.twin_enabled.toggled.connect(lambda value: self._update(enabled=bool(value)))
        self.panel.twin_fmu_path.textChanged.connect(lambda text: self._update(fmu_path=text.strip()))
        self.bind_dynamic_inputs()

    def bind_dynamic_inputs(self) -> None:
        for name, combo in self.panel.twin_input_combos.items():
            try:
                combo.currentIndexChanged.disconnect()
            except Exception:
                pass
            combo.currentIndexChanged.connect(lambda idx, n=name, c=combo: self._set_input_binding(n, c.itemData(idx) if idx >= 0 else None))
            if combo.count() and combo.currentIndex() >= 0:
                self._set_input_binding(name, combo.currentData())

    def _update(self, **changes) -> None:
        self.state = TwinPanelFormState(**{**self.state.__dict__, **changes})

    def _set_input_binding(self, name: str, value) -> None:
        bindings = dict(self.state.input_bindings)
        bindings[name] = value
        self._update(input_bindings=bindings)

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        t = settings.twin
        self.state = TwinPanelFormState(enabled=bool(t.enabled), fmu_path=str(t.fmu_path), input_bindings=dict(getattr(t, 'input_bindings', {}) or {}))
        self.panel.twin_enabled.setChecked(t.enabled)
        self.panel.twin_fmu_path.setText(t.fmu_path)


@dataclass
class MainWindowEditors:
    brew: BrewPanelEditor
    control: ControlPanelEditor
    relay: RelayPanelEditor
    safety: SafetyPanelEditor
    scheduler: SchedulerPanelEditor
    twin: TwinPanelEditor


def build_main_window_editors(window) -> MainWindowEditors:
    editors = MainWindowEditors(
        brew=BrewPanelEditor(window.brew_panel, window.settings),
        control=ControlPanelEditor(window.control_panel, window.ui_state, window.settings),
        relay=RelayPanelEditor(window.relay_panel, window.relay_channel_rows, window.settings),
        safety=SafetyPanelEditor(window.safety_panel, window.safety_rules_controller, window.settings),
        scheduler=SchedulerPanelEditor(window.scheduler_panel, window.settings),
        twin=TwinPanelEditor(window.twin_panel, window.settings, window.queries),
    )
    editors.brew.bind()
    editors.control.bind()
    editors.relay.bind()
    editors.safety.bind()
    editors.scheduler.bind()
    editors.twin.bind()
    return editors
