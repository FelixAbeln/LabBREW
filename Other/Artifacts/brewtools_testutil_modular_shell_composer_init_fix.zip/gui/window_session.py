from __future__ import annotations

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QMessageBox



class MainWindowSession:
    """Owns top-level UI event wiring, timers, and refresh orchestration."""

    def __init__(self, window):
        self.window = window
        self._confirm_blink_timer = QTimer(window)
        self._confirm_blink_timer.setInterval(700)
        self._confirm_blink_timer.timeout.connect(self._toggle_confirm_blink)
        self._confirm_blink_state = False

        self._twin_refresh_timer = QTimer(window)
        self._twin_refresh_timer.setInterval(250)
        self._twin_refresh_timer.timeout.connect(self._poll_twin_runtime)

    def bind_runtime_events(self) -> None:
        events = self.window.events
        events.status.connect(self._on_status_event)
        events.cycle_completed.connect(self._on_runtime_cycle_completed)
        events.command_failed.connect(self._show_runtime_error)
        events.frame_decoded.connect(self.window.runtime_bridge.append_frame_log)
        events.footer_changed.connect(self.window.intent_dispatcher.refresh_footer)
        events.device_rows_changed.connect(self.window.intent_dispatcher.refresh_table)
        events.control_changed.connect(self.window.intent_dispatcher.refresh_control_panel)
        events.safety_changed.connect(self.window.intent_dispatcher.refresh_safety_panel)
        events.twin_changed.connect(self.window.intent_dispatcher.refresh_twin_panel)
        events.scheduler_changed.connect(self.window.intent_dispatcher.refresh_scheduler_panel)
        events.relay_changed.connect(self.window.intent_dispatcher.refresh_relay_panel)
        events.signal_registry_changed.connect(self._on_signal_registry_changed)

    def start(self) -> None:
        self._twin_refresh_timer.start()

    def stop(self) -> None:
        if self._confirm_blink_timer.isActive():
            self._confirm_blink_timer.stop()
        if self._twin_refresh_timer.isActive():
            self._twin_refresh_timer.stop()

    def initial_refresh(self) -> None:
        self.window.source_controller.refresh_control_sources()
        self.window.runtime_bridge.update_agitator_runtime()
        self.window.source_controller.refresh_twin_sources()
        self.window.intent_dispatcher.refresh_all(force=True)

    def update_confirm_button_state(self, awaiting_confirmation: bool) -> None:
        button = self.window.scheduler_panel.btn_scheduler_confirm
        if awaiting_confirmation:
            button.setText('Confirm Step')
            if not self._confirm_blink_timer.isActive():
                self._confirm_blink_state = False
                self._confirm_blink_timer.start()
                self._toggle_confirm_blink()
        else:
            if self._confirm_blink_timer.isActive():
                self._confirm_blink_timer.stop()
            self._confirm_blink_state = False
            button.setText('Confirm / Continue')
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _toggle_confirm_blink(self) -> None:
        panel = self.window.queries.scheduler_panel()
        button = self.window.scheduler_panel.btn_scheduler_confirm
        if not panel.awaiting_confirmation:
            if self._confirm_blink_timer.isActive():
                self._confirm_blink_timer.stop()
            self._confirm_blink_state = False
            button.setText('Confirm / Continue')
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')
            return
        self._confirm_blink_state = not self._confirm_blink_state
        button.setText('Confirm Step')
        if self._confirm_blink_state:
            button.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _on_status_event(self, message: str) -> None:
        self.window.statusBar().showMessage(str(message))
        self.window.intent_dispatcher.refresh_footer()

    def _on_signal_registry_changed(self) -> None:
        self.window.source_controller.refresh_control_sources()
        self.window.source_controller.refresh_twin_sources()

    def _on_runtime_cycle_completed(self) -> None:
        self.window.runtime_bridge.sync_runtime_targets()

    def _show_runtime_error(self, title: str, message: str) -> None:
        QMessageBox.critical(self.window, title, message)

    def _poll_twin_runtime(self) -> None:
        self.window.intent_dispatcher.refresh_twin_panel()
        self.window.intent_dispatcher.refresh_footer()
