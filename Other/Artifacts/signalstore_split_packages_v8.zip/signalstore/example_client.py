from signalstore_core.client import SignalClient

c = SignalClient()
print('ping:', c.ping())
print('plugins:', c.list_plugin_types())

for name, plugin_type, kwargs in [
    ('tank.level', 'hold', {'value': 10.0}),
    ('tank.sp', 'hold', {'value': 20.0}),
    ('tank.pid', 'pid', {'config': {
        'pv': 'tank.level',
        'sp': 'tank.sp',
        'kp': 2.0,
        'ki': 0.1,
        'kd': 0.0,
        'out_min': 0.0,
        'out_max': 100.0,
    }}),
]:
    try:
        c.create_parameter(name, plugin_type, **kwargs)
    except Exception:
        pass

with c.subscribe() as events:
    for event in events:
        print(event)
