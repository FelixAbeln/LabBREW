# realtime parameter service

This project is split into three packages so the runtime and the client UI stay cleanly separated.

## package layout

```text
signalstore_core/
  protocol.py
  client.py

signalstore_service/
  plugin_api.py
  store.py
  engine.py
  loader.py
  server.py
  service.py

signalstore_monitor/
  app.py

plugins/
  hold/
    implementation.py
    ui.py
  pid/
    implementation.py
    ui.py
  script/
    implementation.py
    ui.py
```

- `signalstore_core` contains the network protocol and reusable client.
- `signalstore_service` contains the database runtime and server.
- `signalstore_monitor` contains the standalone monitor/editor app.
- `plugins/*/implementation.py` contains runtime behavior.
- `plugins/*/ui.py` is the client-facing editor contract.

A small `realtimedb_service` compatibility package is still included so older imports keep working while the codebase transitions.

## run the service

```bash
python app.py --plugin-root ./plugins
```

## run the monitor

```bash
python monitor_app.py --host 127.0.0.1 --port 8765
```

## client example

```python
from signalstore_core.client import SignalClient

c = SignalClient()
print(c.ping())
print(c.describe())
```
