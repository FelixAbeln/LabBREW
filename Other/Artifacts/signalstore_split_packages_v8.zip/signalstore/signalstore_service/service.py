
from __future__ import annotations

from pathlib import Path

from signalstore_service.engine import ScanEngine
from signalstore_service.loader import PluginRegistry, autodiscover_plugins
from signalstore_service.server import SignalTCPServer


def build_service(host: str = '127.0.0.1', port: int = 8765, period_s: float = 0.05, plugin_root: str = './plugins'):
    registry = PluginRegistry()
    loaded = autodiscover_plugins(plugin_root, registry)
    engine = ScanEngine(period_s=period_s)
    server = SignalTCPServer(host, port, engine, registry)
    return engine, server, registry, loaded



def main() -> None:
    from app import main as app_main
    app_main()
