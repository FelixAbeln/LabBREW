from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from state import AppState
from services.signal_registry import SignalRecord


@dataclass(frozen=True)
class OperatorDefinition:
    key: str
    meaning: str
    uses_threshold_or_range: bool = False
    uses_time: bool = False
    example: str = ''


@dataclass(frozen=True)
class WaitTypeDefinition:
    key: str
    meaning: str


@dataclass(frozen=True)
class SafetyActionDefinition:
    key: str
    label: str


SignalProviderFn = Callable[[AppState], list[SignalRecord]]


@dataclass(frozen=True)
class SignalProviderDefinition:
    key: str
    label: str
    families: tuple[str, ...]
    provider: SignalProviderFn


@dataclass(frozen=True)
class ControllerDefinition:
    key: str
    label: str
    kind: str
    description: str = ''
    source_families: tuple[str, ...] = ()
    target_families: tuple[str, ...] = ()
    setpoint_unit: str = ''
    supports_ramp: bool = False
    value_kind: str = 'setpoint'
    action_fields: tuple[str, ...] = ('setpoint',)
    aliases: tuple[str, ...] = ()


ControllerApplyFn = Callable[[Any, AppState, Any], None]


@dataclass(frozen=True)
class ControllerHandlerDefinition:
    key: str
    apply_scheduler_action: ControllerApplyFn


@dataclass(frozen=True)
class OutputTargetRecord:
    key: str
    label: str
    family: str
    value_kind: str
    controller_keys: tuple[str, ...] = ()
    unit: str = ''


OutputTargetProviderFn = Callable[[AppState], list[OutputTargetRecord]]


@dataclass(frozen=True)
class OutputTargetProviderDefinition:
    key: str
    label: str
    families: tuple[str, ...]
    provider: OutputTargetProviderFn


@dataclass
class AppRegistry:
    operators: dict[str, OperatorDefinition] = field(default_factory=dict)
    wait_types: dict[str, WaitTypeDefinition] = field(default_factory=dict)
    safety_actions: dict[str, SafetyActionDefinition] = field(default_factory=dict)
    signal_providers: dict[str, SignalProviderDefinition] = field(default_factory=dict)
    signal_families: set[str] = field(default_factory=set)
    controllers: dict[str, ControllerDefinition] = field(default_factory=dict)
    controller_handlers: dict[str, ControllerHandlerDefinition] = field(default_factory=dict)
    controller_aliases: dict[str, str] = field(default_factory=dict)
    output_target_providers: dict[str, OutputTargetProviderDefinition] = field(default_factory=dict)
    output_target_families: set[str] = field(default_factory=set)

    def register_operator(self, definition: OperatorDefinition) -> None:
        if definition.key in self.operators:
            raise ValueError(f'Duplicate operator registration: {definition.key}')
        self.operators[definition.key] = definition

    def register_wait_type(self, definition: WaitTypeDefinition) -> None:
        if definition.key in self.wait_types:
            raise ValueError(f'Duplicate wait type registration: {definition.key}')
        self.wait_types[definition.key] = definition

    def register_safety_action(self, definition: SafetyActionDefinition) -> None:
        if definition.key in self.safety_actions:
            raise ValueError(f'Duplicate safety action registration: {definition.key}')
        self.safety_actions[definition.key] = definition

    def register_signal_provider(self, definition: SignalProviderDefinition) -> None:
        if definition.key in self.signal_providers:
            raise ValueError(f'Duplicate signal provider registration: {definition.key}')
        families = tuple(str(name).strip() for name in definition.families if str(name).strip())
        invalid = [name for name in families if ':' in name]
        if invalid:
            raise ValueError(f'Invalid signal family names for {definition.key}: {invalid}')
        self.signal_families.update(families)
        self.signal_providers[definition.key] = definition

    def register_controller(self, definition: ControllerDefinition) -> None:
        if definition.key in self.controllers:
            raise ValueError(f'Duplicate controller registration: {definition.key}')
        invalid_sources = [name for name in definition.source_families if ':' in str(name)]
        invalid_targets = [name for name in definition.target_families if ':' in str(name)]
        if invalid_sources:
            raise ValueError(f'Invalid controller source families for {definition.key}: {invalid_sources}')
        if invalid_targets:
            raise ValueError(f'Invalid controller target families for {definition.key}: {invalid_targets}')
        self.controllers[definition.key] = definition
        for alias in (definition.aliases or ()): 
            alias_key = str(alias).strip()
            if not alias_key:
                continue
            existing = self.controller_aliases.get(alias_key)
            if existing and existing != definition.key:
                raise ValueError(f'Duplicate controller alias registration: {alias_key}')
            self.controller_aliases[alias_key] = definition.key

    def register_controller_handler(self, definition: ControllerHandlerDefinition) -> None:
        key = self.resolve_controller_key(definition.key)
        if not key:
            raise ValueError(f'Controller handler references unknown controller: {definition.key}')
        if key in self.controller_handlers:
            raise ValueError(f'Duplicate controller handler registration: {key}')
        self.controller_handlers[key] = ControllerHandlerDefinition(key=key, apply_scheduler_action=definition.apply_scheduler_action)

    def register_output_target_provider(self, definition: OutputTargetProviderDefinition) -> None:
        if definition.key in self.output_target_providers:
            raise ValueError(f'Duplicate output-target provider registration: {definition.key}')
        families = tuple(str(name).strip() for name in definition.families if str(name).strip())
        invalid = [name for name in families if ':' in name]
        if invalid:
            raise ValueError(f'Invalid output-target family names for {definition.key}: {invalid}')
        self.output_target_families.update(families)
        self.output_target_providers[definition.key] = definition

    def has_operator(self, key: str) -> bool:
        return key in self.operators

    def has_wait_type(self, key: str) -> bool:
        return key in self.wait_types

    def has_safety_action(self, key: str) -> bool:
        return key in self.safety_actions

    def has_controller(self, key: str) -> bool:
        return self.resolve_controller_key(key) is not None

    def resolve_controller_key(self, key: str | None) -> str | None:
        if not key:
            return None
        txt = str(key).strip()
        if txt in self.controllers:
            return txt
        return self.controller_aliases.get(txt)

    def get_controller_definition(self, key: str | None) -> ControllerDefinition | None:
        resolved = self.resolve_controller_key(key)
        if not resolved:
            return None
        return self.controllers.get(resolved)

    def get_controller_handler(self, key: str | None) -> ControllerHandlerDefinition | None:
        resolved = self.resolve_controller_key(key)
        if not resolved:
            return None
        return self.controller_handlers.get(resolved)

    def recognizes_signal_key(self, key: str) -> bool:
        if not key:
            return False
        family, _, _ = str(key).partition(':')
        return family in self.signal_families

    def recognizes_output_target_key(self, key: str) -> bool:
        if not key:
            return False
        family, _, _ = str(key).partition(':')
        return family in self.output_target_families
