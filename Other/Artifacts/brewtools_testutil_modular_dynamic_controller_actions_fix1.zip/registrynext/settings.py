from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

DEFAULT_CAN_BITRATE = 1_000_000
DEFAULT_PSU_VOLTAGE = 24.0


@dataclass
class ControllerSettings:
    enabled: bool = False
    source_key: Optional[object] = None
    setpoint: float = 0.0
    deadband: float = 1.0
    allow_add_gas: bool = True


@dataclass
class AgitatorSettings:
    enabled: bool = False
    target: str = 'relay'
    on: bool = False
    duty_cycle: float = 100.0
    mode: str = 'manual'
    speed_setpoint_rpm: float = 120.0
    pid_kp: float = 0.30
    pid_ki: float = 0.05
    pid_kd: float = 0.00


@dataclass
class RelaySettings:
    host: str = '127.0.0.1'
    tcp_port: int = 502
    assignments: dict[str, Optional[str]] = field(default_factory=dict)
    auto_enabled: dict[str, bool] = field(default_factory=dict)

    @staticmethod
    def default_assignments(channel_count: int = 8) -> dict[str, Optional[str]]:
        return {str(i): None for i in range(1, channel_count + 1)}

    @staticmethod
    def default_auto_enabled(channel_count: int = 8) -> dict[str, bool]:
        return {str(i): True for i in range(1, channel_count + 1)}





@dataclass
class SafetyRuleSettings:
    name: str = ''
    enabled: bool = True
    signal_key: str = ''
    operator: str = '>'
    threshold: float | None = None
    threshold_low: float | None = None
    threshold_high: float | None = None
    stale_for_s: float = 10.0
    actions: list[str] = field(default_factory=list)

@dataclass
class SafetySettings:
    enabled: bool = True
    stale_timeout_s: float = 10.0
    min_switch_time_s: float = 3.0
    require_can_connected: bool = True
    require_psu_power: bool = False
    require_relays_connected: bool = False
    max_temperature_enabled: bool = False
    max_temperature_c: float = 35.0
    max_pressure_enabled: bool = False
    max_pressure_bar: float = 2.500
    power_off_psu_on_trip: bool = False
    all_relays_off_on_trip: bool = False
    rules: list[SafetyRuleSettings] = field(default_factory=list)
    safe_outputs: dict[str, bool] = field(default_factory=lambda: {
        'heat': False,
        'cool': False,
        'add_gas': False,
        'remove_gas': False,
        'agitator': False,
    })




@dataclass
class SchedulerStepSettings:
    index: int = 0
    enabled: bool = True
    name: str = ''
    temperature_setpoint: float | None = None
    temperature_ramp_per_s: float | None = None
    pressure_setpoint: float | None = None
    pressure_ramp_per_s: float | None = None
    allow_add_gas: bool | None = None
    wait_type: str = 'elapsed_time'
    wait_source: str = ''
    operator: str = '>='
    threshold: float | None = None
    threshold_low: float | None = None
    threshold_high: float | None = None
    duration_s: float | None = None
    hold_for_s: float = 0.0
    valid_sources: list[str] = field(default_factory=list)
    require_confirmation: bool = False
    confirmation_message: str = ''
    agitator_on: bool | None = None
    agitator_duty_cycle: float | None = None
    controller_actions: list[dict[str, object]] = field(default_factory=list)


@dataclass
class SchedulerSettings:
    enabled: bool = False
    workbook_path: str = ''
    sheet_name: str = ''
    auto_start: bool = False
    startup_sequence_enabled: bool = False
    startup_auto_connect_relays: bool = False
    startup_auto_connect_can: bool = False
    startup_auto_power_psu: bool = False
    startup_auto_load_twin: bool = False
    startup_delay_s: float = 3.0
    startup_show_advanced: bool = False
    steps: list[SchedulerStepSettings] = field(default_factory=list)

@dataclass
class DigitalTwinSettings:
    enabled: bool = True
    fmu_path: str = ''
    input_bindings: dict[str, Optional[str]] = field(default_factory=dict)


@dataclass
class AppSettings:
    bitrate: int = DEFAULT_CAN_BITRATE
    can_channel: int | None = None
    psu_com_port: str = ''
    voltage: float = DEFAULT_PSU_VOLTAGE
    temp_controller: ControllerSettings = field(default_factory=lambda: ControllerSettings(setpoint=65.0, deadband=1.0))
    pressure_controller: ControllerSettings = field(default_factory=lambda: ControllerSettings(setpoint=1.2, deadband=0.1))
    agitator: AgitatorSettings = field(default_factory=AgitatorSettings)
    relay: RelaySettings = field(default_factory=lambda: RelaySettings(
        assignments=RelaySettings.default_assignments(),
        auto_enabled=RelaySettings.default_auto_enabled(),
    ))
    safety: SafetySettings = field(default_factory=SafetySettings)
    scheduler: SchedulerSettings = field(default_factory=SchedulerSettings)
    twin: DigitalTwinSettings = field(default_factory=DigitalTwinSettings)


class SettingsManager:
    def __init__(self, path: Path):
        self.path = path

    def load(self) -> AppSettings:
        try:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding='utf-8'))
                if isinstance(data, dict):
                    temp = data.get('temp_controller', {}) or {}
                    press = data.get('pressure_controller', {}) or {}
                    agitator = data.get('agitator', {}) or {}
                    relay = data.get('relay', {}) or {}
                    safety = data.get('safety', {}) or {}
                    scheduler = data.get('scheduler', {}) or {}
                    twin = data.get('twin', {}) or {}
                    assignments = RelaySettings.default_assignments()
                    assignments.update({str(k): v for k, v in (relay.get('assignments', {}) or {}).items()})
                    auto_enabled = RelaySettings.default_auto_enabled()
                    auto_enabled.update({str(k): bool(v) for k, v in (relay.get('auto_enabled', {}) or {}).items()})
                    return AppSettings(
                        bitrate=int(data.get('bitrate', DEFAULT_CAN_BITRATE)),
                        can_channel=data.get('can_channel'),
                        psu_com_port=str(data.get('psu_com_port', '') or ''),
                        voltage=float(data.get('voltage', DEFAULT_PSU_VOLTAGE)),
                        temp_controller=ControllerSettings(
                            enabled=bool(temp.get('enabled', False)),
                            source_key=temp.get('source_key'),
                            setpoint=float(temp.get('setpoint', 65.0)),
                            deadband=max(0.01, float(temp.get('deadband', 1.0))),
                            allow_add_gas=True,
                        ),
                        pressure_controller=ControllerSettings(
                            enabled=bool(press.get('enabled', False)),
                            source_key=press.get('source_key'),
                            setpoint=float(press.get('setpoint', 1.2)),
                            deadband=max(0.001, float(press.get('deadband', 0.1))),
                            allow_add_gas=bool(press.get('allow_add_gas', True)),
                        ),
                        agitator=AgitatorSettings(
                            enabled=bool(agitator.get('enabled', False)),
                            target=str(agitator.get('target', agitator.get('target_type', 'relay')) or 'relay'),
                            on=bool(agitator.get('on', False)),
                            duty_cycle=max(0.0, min(100.0, float(agitator.get('duty_cycle', 100.0)))),
                            mode=('pid' if str(agitator.get('mode', 'manual')).lower() == 'pid' else 'manual'),
                            speed_setpoint_rpm=max(0.0, float(agitator.get('speed_setpoint_rpm', 120.0))),
                            pid_kp=max(0.0, float(agitator.get('pid_kp', 0.30))),
                            pid_ki=max(0.0, float(agitator.get('pid_ki', 0.05))),
                            pid_kd=max(0.0, float(agitator.get('pid_kd', 0.00))),
                        ),
                        relay=RelaySettings(
                            host=str(relay.get('host', '127.0.0.1') or '127.0.0.1'),
                            tcp_port=int(relay.get('tcp_port', 502) or 502),
                            assignments=assignments,
                            auto_enabled=auto_enabled,
                        ),
                        safety=SafetySettings(
                            enabled=bool(safety.get('enabled', True)),
                            stale_timeout_s=max(0.1, float(safety.get('stale_timeout_s', 10.0))),
                            min_switch_time_s=max(0.0, float(safety.get('min_switch_time_s', 3.0))),
                            require_can_connected=bool(safety.get('require_can_connected', True)),
                            require_psu_power=bool(safety.get('require_psu_power', False)),
                            require_relays_connected=bool(safety.get('require_relays_connected', False)),
                            max_temperature_enabled=bool(safety.get('max_temperature_enabled', False)),
                            max_temperature_c=float(safety.get('max_temperature_c', 35.0)),
                            max_pressure_enabled=bool(safety.get('max_pressure_enabled', False)),
                            max_pressure_bar=float(safety.get('max_pressure_bar', 2.5)),
                            power_off_psu_on_trip=bool(safety.get('power_off_psu_on_trip', False)),
                            all_relays_off_on_trip=bool(safety.get('all_relays_off_on_trip', False)),
                            rules=[SafetyRuleSettings(
                                name=str((row or {}).get('name', '') or ''),
                                enabled=bool((row or {}).get('enabled', True)),
                                signal_key=str((row or {}).get('signal_key', '') or ''),
                                operator=str((row or {}).get('operator', '>') or '>'),
                                threshold=(None if (row or {}).get('threshold') in (None, '') else float((row or {}).get('threshold'))),
                                threshold_low=(None if (row or {}).get('threshold_low') in (None, '') else float((row or {}).get('threshold_low'))),
                                threshold_high=(None if (row or {}).get('threshold_high') in (None, '') else float((row or {}).get('threshold_high'))),
                                stale_for_s=max(0.1, float((row or {}).get('stale_for_s', 10.0) or 10.0)),
                                actions=[str(v) for v in ((row or {}).get('actions', []) or [])],
                            ) for row in (safety.get('rules', []) or [])],
                            safe_outputs={
                                'heat': bool((safety.get('safe_outputs', {}) or {}).get('heat', False)),
                                'cool': bool((safety.get('safe_outputs', {}) or {}).get('cool', False)),
                                'add_gas': bool((safety.get('safe_outputs', {}) or {}).get('add_gas', False)),
                                'remove_gas': bool((safety.get('safe_outputs', {}) or {}).get('remove_gas', False)),
                                'agitator': bool((safety.get('safe_outputs', {}) or {}).get('agitator', False)),
                            },
                        ),
                        scheduler=SchedulerSettings(
                            enabled=bool(scheduler.get('enabled', False)),
                            workbook_path=str(scheduler.get('workbook_path', '') or ''),
                            sheet_name=str(scheduler.get('sheet_name', '') or ''),
                            auto_start=bool(scheduler.get('auto_start', False)),
                            startup_sequence_enabled=bool(scheduler.get('startup_sequence_enabled', False)),
                            startup_auto_connect_relays=bool(scheduler.get('startup_auto_connect_relays', False)),
                            startup_auto_connect_can=bool(scheduler.get('startup_auto_connect_can', False)),
                            startup_auto_power_psu=bool(scheduler.get('startup_auto_power_psu', False)),
                            startup_auto_load_twin=bool(scheduler.get('startup_auto_load_twin', False)),
                            startup_delay_s=max(0.0, float(scheduler.get('startup_delay_s', 3.0) or 0.0)),
                            startup_show_advanced=bool(scheduler.get('startup_show_advanced', False)),
                            steps=[SchedulerStepSettings(
                                index=int((row or {}).get('index', idx)),
                                enabled=bool((row or {}).get('enabled', True)),
                                name=str((row or {}).get('name', '') or ''),
                                temperature_setpoint=((None if (row or {}).get('temperature_setpoint') in (None, '') else float((row or {}).get('temperature_setpoint')))),
                                temperature_ramp_per_s=((None if (row or {}).get('temperature_ramp_per_s') in (None, '') else float((row or {}).get('temperature_ramp_per_s')))),
                                pressure_setpoint=((None if (row or {}).get('pressure_setpoint') in (None, '') else float((row or {}).get('pressure_setpoint')))),
                                pressure_ramp_per_s=((None if (row or {}).get('pressure_ramp_per_s') in (None, '') else float((row or {}).get('pressure_ramp_per_s')))),
                                allow_add_gas=((None if (row or {}).get('allow_add_gas') in (None, '') else bool((row or {}).get('allow_add_gas')))),
                                wait_type=str((row or {}).get('wait_type', 'elapsed_time') or 'elapsed_time'),
                                wait_source=str((row or {}).get('wait_source', '') or ''),
                                operator=str((row or {}).get('operator', '>=') or '>='),
                                threshold=((None if (row or {}).get('threshold') in (None, '') else float((row or {}).get('threshold')))),
                                threshold_low=((None if (row or {}).get('threshold_low') in (None, '') else float((row or {}).get('threshold_low')))),
                                threshold_high=((None if (row or {}).get('threshold_high') in (None, '') else float((row or {}).get('threshold_high')))),
                                duration_s=((None if (row or {}).get('duration_s') in (None, '') else float((row or {}).get('duration_s')))),
                                hold_for_s=float((row or {}).get('hold_for_s', 0.0) or 0.0),
                                valid_sources=[str(v) for v in ((row or {}).get('valid_sources', []) or [])],
                                require_confirmation=bool((row or {}).get('require_confirmation', False)),
                                confirmation_message=str((row or {}).get('confirmation_message', '') or ''),
                                agitator_on=((None if (row or {}).get('agitator_on') in (None, '') else bool((row or {}).get('agitator_on')))),
                                agitator_duty_cycle=((None if (row or {}).get('agitator_duty_cycle') in (None, '') else float((row or {}).get('agitator_duty_cycle')))),
                                controller_actions=[dict(v) for v in ((row or {}).get('controller_actions', []) or [])],
                            ) for idx, row in enumerate((scheduler.get('steps', []) or []))],
                        ),
                        twin=DigitalTwinSettings(
                            enabled=bool(twin.get('enabled', True)),
                            fmu_path=str(twin.get('fmu_path', '') or ''),
                            input_bindings={str(k): v for k, v in ((twin.get('input_bindings', {}) or {}).items())},
                        ),
                    )
        except Exception:
            pass
        return AppSettings()

    def save(self, settings: AppSettings) -> None:
        self.path.write_text(json.dumps(asdict(settings), indent=2), encoding='utf-8')
