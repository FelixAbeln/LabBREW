def get_ui_spec() -> dict:
    return {
        "source_type": "system_time",
        "display_name": "System Time",
        "description": "Publishes the runner machine time into one hold parameter.",
        "create": {
            "required": ["name", "config.parameter_name"],
            "defaults": {
                "config": {
                    "parameter_name": "system.time.iso",
                    "update_interval_s": 1.0,
                    "mode": "iso",
                }
            },
        },
        "edit": {
            "sections": [
                {
                    "title": "Identity",
                    "fields": [
                        {"key": "name", "label": "Source Name", "type": "string", "required": True},
                        {"key": "config.parameter_name", "label": "Parameter Name", "type": "string", "required": True},
                    ],
                },
                {
                    "title": "Publishing",
                    "fields": [
                        {"key": "config.update_interval_s", "label": "Update Interval (s)", "type": "float", "required": True, "default": 1.0},
                        {"key": "config.mode", "label": "Format", "type": "enum", "required": True, "choices": ["iso", "unix", "unix_ms"]},
                    ],
                },
            ]
        },
    }
