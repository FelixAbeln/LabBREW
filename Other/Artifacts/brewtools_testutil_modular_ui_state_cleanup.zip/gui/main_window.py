from __future__ import annotations

import sys
import time
from pathlib import Path

from typing import Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
    QScrollArea, QSpinBox, QStatusBar, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout,
    QFrame,
    QWidget,
    QSizePolicy
)
from PySide6.QtWidgets import QHeaderView

from brewtools_can import CanFrame

from helpers import format_node_type, list_kvaser_channels, list_serial_ports
from settings import AppSettings, SettingsManager, DEFAULT_CAN_BITRATE, DEFAULT_PSU_VOLTAGE, ControllerSettings, AgitatorSettings, RelaySettings, DigitalTwinSettings, SafetySettings, SafetyRuleSettings, SchedulerSettings, SchedulerStepSettings
from state import AppState, DeviceKey, DeviceState, StateStore, SchedulerStep, SafetyRule
from app_core import AppCore
from gui.constants import OUTPUT_LABELS
from gui.config_adapters import ApplicationConfigBuilder
from gui.panel_facades import build_panel_facades
from gui.config_controller import WindowConfigController
from gui.discovery_controller import WindowDiscoveryController
from gui.device_session_controller import WindowDeviceSessionController
from gui.runtime_bridge import WindowRuntimeBridge
from gui.safety_rules_controller import SafetyRulesController
from gui.settings_loader import WindowSettingsLoader
from gui.source_controller import WindowSourceController
from gui.ui_state import WindowUIState
from gui.ui_helpers import find_data_index, normalize_signal_key, make_output_badge, set_output_badge
from application.normalization import normalize_control_source_key
from gui.panels import (
    BrewPanel,
    ControlPanel,
    LogPanel,
    RelayPanel,
    SafetyPanel,
    SchedulerPanel,
    TwinPanel,
)
from gui.presenters import MainWindowRefreshCoordinator
from gui.send_dialog import SendDialog
from gui.widgets.band_indicator import BandIndicator



class MainWindow(QMainWindow):
    def __init__(self, *, core: AppCore):
        super().__init__()
        self.setWindowTitle('Brewtools CAN Test Utility')
        self.resize(1220, 820)

        self.core = core
        self.settings_manager = self.core.settings_manager
        self.settings = self.core.settings

        self.commands = self.core.commands
        self.queries = self.core.queries
        self.events = self.core.events
        self._action_labels = self.queries.safety_action_labels()
        self._operator_options = self.queries.operator_options()
        self._operator_keys = [opt.key for opt in self._operator_options]

        self.ui_state = WindowUIState(
            pending_temp_source_key=normalize_control_source_key(self.settings.temp_controller.source_key),
            pending_pressure_source_key=normalize_control_source_key(self.settings.pressure_controller.source_key),
        )
        self.safety_rules_controller = SafetyRulesController()
        self.OUTPUT_LABELS = OUTPUT_LABELS
        self.relay_channel_rows: dict[int, dict[str, object]] = {}
        self._config_builder = ApplicationConfigBuilder(self)
        self.config_controller = WindowConfigController(self, self._config_builder)
        self.discovery_controller = WindowDiscoveryController(self)
        self.device_controller = WindowDeviceSessionController(self)
        self.runtime_bridge = WindowRuntimeBridge(self)
        self.source_controller = WindowSourceController(self)
        self.settings_loader = WindowSettingsLoader(self)

        self._panel_facades = build_panel_facades(self)
        self._build_ui()
        self._wire_signals()
        self._refresh = MainWindowRefreshCoordinator(self, self.queries)

        self.ui_state.loading_settings = True
        try:
            self.discovery_controller.populate_psu_ports()
            self.discovery_controller.populate_channels()
            self.discovery_controller.populate_relay_targets()
            self.settings_loader.apply()
        finally:
            self.ui_state.loading_settings = False
        self.source_controller.refresh_control_sources()
        self.source_controller.refresh_twin_sources()
        self.runtime_bridge.refresh_footer()
        self.commands.set_status_message('Ready. Select PSU port, choose CAN voltage, power the rail, then connect CAN.')

        self.events.status.connect(self._on_status_event)
        self.events.cycle_completed.connect(self._on_runtime_cycle_completed)
        self.events.command_failed.connect(self._show_runtime_error)

        self._confirm_blink_timer = QTimer(self)
        self._confirm_blink_timer.setInterval(700)
        self._confirm_blink_timer.timeout.connect(self._toggle_confirm_blink)
        self._confirm_blink_state = False

        self.twin_refresh_timer = QTimer(self)
        self.twin_refresh_timer.setInterval(250)
        self.twin_refresh_timer.timeout.connect(self._poll_twin_runtime)
        self.twin_refresh_timer.start()

        self.runtime_bridge.refresh_footer()
        self.runtime_bridge.refresh_table()
        self.source_controller.refresh_control_sources()
        self.runtime_bridge.update_agitator_runtime()
        self.runtime_bridge.refresh_control_panel()
        self.runtime_bridge.refresh_safety_panel()
        self.source_controller.refresh_twin_sources()
        self.runtime_bridge.refresh_twin_panel()
        self.runtime_bridge.refresh_scheduler_panel()
        self.runtime_bridge.refresh_relay_panel()

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)

        self.tabs = QTabWidget()
        outer.addWidget(self.tabs)

        self.brew_panel = BrewPanel(self._panel_facades.brew)
        self.control_panel = ControlPanel(self._panel_facades.control)
        self.safety_panel = SafetyPanel(self._panel_facades.safety)
        self.log_panel = LogPanel()
        self.twin_panel = TwinPanel(self._panel_facades.twin)
        self.scheduler_panel = SchedulerPanel(self._panel_facades.scheduler)
        self.relay_panel = RelayPanel(self._panel_facades.relay)

        self.tabs.addTab(self.brew_panel, 'Brewtools')
        self.tabs.addTab(self.control_panel, 'Control')
        self.tabs.addTab(self.safety_panel, 'Safety')
        self.tabs.addTab(self.log_panel, 'System Log')
        self.tabs.addTab(self.twin_panel, 'Twin')
        self.tabs.addTab(self.scheduler_panel, 'Scheduler')
        self.tabs.addTab(self.relay_panel, 'Relays')
        self.footer_event_lbl = None
        self.footer_state_lbl = None


    def _wire_signals(self) -> None:
        self.brew_panel.wire_signals()
        self.control_panel.wire_signals()
        self.safety_panel.wire_signals()
        self.twin_panel.wire_signals()
        self.scheduler_panel.wire_signals()
        self.relay_panel.wire_signals()

        self.events.frame_decoded.connect(self.runtime_bridge.on_frame)
        self.events.can_connection_changed.connect(lambda *_: self.runtime_bridge.refresh_footer())

    def _set_toggle_style(self, button: QPushButton, active: bool) -> None:
        button.setChecked(active)
        if active:
            button.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _toggle_confirm_blink(self) -> None:
        panel = self.queries.scheduler_panel()
        if not panel.awaiting_confirmation:
            if self._confirm_blink_timer.isActive():
                self._confirm_blink_timer.stop()
            self._confirm_blink_state = False
            self.scheduler_panel.btn_scheduler_confirm.setText('Confirm / Continue')
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')
            return
        self._confirm_blink_state = not self._confirm_blink_state
        self.scheduler_panel.btn_scheduler_confirm.setText('Confirm Step')
        if self._confirm_blink_state:
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _update_confirm_button_state(self, awaiting_confirmation: bool) -> None:
        if awaiting_confirmation:
            self.scheduler_panel.btn_scheduler_confirm.setText('Confirm Step')
            if not self._confirm_blink_timer.isActive():
                self._confirm_blink_state = False
                self._confirm_blink_timer.start()
                self._toggle_confirm_blink()
        else:
            if self._confirm_blink_timer.isActive():
                self._confirm_blink_timer.stop()
            self._confirm_blink_state = False
            self.scheduler_panel.btn_scheduler_confirm.setText('Confirm / Continue')
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _on_status_event(self, message: str) -> None:
        self.statusBar().showMessage(str(message))
        self.runtime_bridge.refresh_footer()

    def _on_runtime_cycle_completed(self) -> None:
        self.runtime_bridge.on_runtime_cycle_completed()

    def _show_runtime_error(self, title: str, message: str) -> None:
        QMessageBox.critical(self, title, message)

    def _poll_twin_runtime(self) -> None:
        self.runtime_bridge.refresh_twin_panel()
        self.runtime_bridge.refresh_footer()

    def closeEvent(self, event) -> None:
        self.config_controller.save_settings()
        super().closeEvent(event)


def run() -> int:
    from app import run_gui
    return run_gui()
