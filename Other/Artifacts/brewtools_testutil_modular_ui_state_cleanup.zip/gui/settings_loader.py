from __future__ import annotations

from gui.ui_helpers import find_data_index, normalize_signal_key


class WindowSettingsLoader:
    """Applies persisted settings into panel widgets without making MainWindow the field-by-field owner."""

    def __init__(self, window):
        self.window = window

    def apply(self) -> None:
        w = self.window
        s = w.settings
        w.ui_state.loading_settings = True
        w.brew_panel.bitrate.setValue(s.bitrate)
        w.brew_panel.psu_voltage.setValue(s.voltage)
        w.ui_state.pending_temp_source_key = normalize_signal_key(s.temp_controller.source_key)
        w.ui_state.pending_pressure_source_key = normalize_signal_key(s.pressure_controller.source_key)
        w.control_panel.temp_ctrl_enabled.setChecked(s.temp_controller.enabled)
        w.control_panel.temp_setpoint.setValue(s.temp_controller.setpoint)
        w.control_panel.temp_deadband.setValue(s.temp_controller.deadband)
        w.control_panel.pressure_ctrl_enabled.setChecked(s.pressure_controller.enabled)
        w.control_panel.pressure_setpoint.setValue(s.pressure_controller.setpoint)
        w.control_panel.pressure_deadband.setValue(s.pressure_controller.deadband)
        w.control_panel.pressure_allow_add_gas.setChecked(bool(getattr(s.pressure_controller, 'allow_add_gas', True)))
        w.control_panel.agitator_enabled.setChecked(bool(getattr(s.agitator, 'enabled', False)))
        w.control_panel.agitator_on.setChecked(bool(getattr(s.agitator, 'on', False)))
        w.control_panel.agitator_duty.setValue(float(getattr(s.agitator, 'duty_cycle', 100.0)))
        w.control_panel.agitator_speed_setpoint.setValue(float(getattr(s.agitator, 'speed_setpoint_rpm', 120.0)))
        w.control_panel.agitator_pid_kp.setValue(float(getattr(s.agitator, 'pid_kp', 0.30)))
        w.control_panel.agitator_pid_ki.setValue(float(getattr(s.agitator, 'pid_ki', 0.05)))
        w.control_panel.agitator_pid_kd.setValue(float(getattr(s.agitator, 'pid_kd', 0.00)))
        idx = w.control_panel.agitator_control_mode.findData(getattr(s.agitator, 'mode', 'manual'))
        w.control_panel.agitator_control_mode.setCurrentIndex(idx if idx >= 0 else 0)
        w.control_panel.refresh_agitator_control_ui()

        idx = w.brew_panel.channel_combo.findData(s.can_channel)
        if idx >= 0:
            w.brew_panel.channel_combo.setCurrentIndex(idx)
        idx = w.brew_panel.psu_port_combo.findData(s.psu_com_port)
        if idx >= 0:
            w.brew_panel.psu_port_combo.setCurrentIndex(idx)
        w.relay_panel.relay_host.setEditText(s.relay.host)
        w.relay_panel.relay_tcp_port.setValue(int(s.relay.tcp_port))
        w.safety_panel.safety_enabled.setChecked(s.safety.enabled)
        w.safety_panel.safety_require_can.setChecked(s.safety.require_can_connected)
        w.safety_panel.safety_require_psu.setChecked(s.safety.require_psu_power)
        w.safety_panel.safety_require_relays.setChecked(s.safety.require_relays_connected)
        w.safety_panel.safety_stale_timeout.setValue(float(s.safety.stale_timeout_s))
        w.safety_panel.safety_min_switch.setValue(float(s.safety.min_switch_time_s))
        w.safety_panel.safety_max_temp_enabled.setChecked(bool(s.safety.max_temperature_enabled))
        w.safety_panel.safety_max_temp.setValue(float(s.safety.max_temperature_c))
        w.safety_panel.safety_max_pressure_enabled.setChecked(bool(s.safety.max_pressure_enabled))
        w.safety_panel.safety_max_pressure.setValue(float(s.safety.max_pressure_bar))
        w.safety_panel.safe_heat.setChecked(bool(s.safety.safe_outputs.get('heat', False)))
        w.safety_panel.safe_cool.setChecked(bool(s.safety.safe_outputs.get('cool', False)))
        w.safety_panel.safe_add_gas.setChecked(bool(s.safety.safe_outputs.get('add_gas', False)))
        w.safety_panel.safe_remove_gas.setChecked(bool(s.safety.safe_outputs.get('remove_gas', False)))
        w.safety_panel.safe_psu_off.setChecked(bool(s.safety.power_off_psu_on_trip))
        w.safety_panel.safe_all_relays_off.setChecked(bool(s.safety.all_relays_off_on_trip))
        w.safety_panel.safe_agitator.setChecked(bool(s.safety.safe_outputs.get('agitator', False)))
        w.safety_rules_controller.load_from_settings(getattr(s.safety, 'rules', []))
        w.safety_panel.refresh_rules_table()
        w.safety_panel.clear_rule_editor()
        w.twin_panel.twin_enabled.setChecked(s.twin.enabled)
        w.twin_panel.twin_fmu_path.setText(s.twin.fmu_path)
        w.scheduler_panel.scheduler_enabled.setChecked(s.scheduler.enabled)
        w.scheduler_panel.scheduler_auto_start.setChecked(s.scheduler.auto_start)
        w.scheduler_panel.scheduler_path.setText(s.scheduler.workbook_path)
        w.scheduler_panel.scheduler_startup_enabled.setChecked(bool(getattr(s.scheduler, 'startup_sequence_enabled', False)))
        w.scheduler_panel.scheduler_startup_connect_relays.setChecked(bool(getattr(s.scheduler, 'startup_auto_connect_relays', False)))
        w.scheduler_panel.scheduler_startup_connect_can.setChecked(bool(getattr(s.scheduler, 'startup_auto_connect_can', False)))
        w.scheduler_panel.scheduler_startup_power_psu.setChecked(bool(getattr(s.scheduler, 'startup_auto_power_psu', False)))
        w.scheduler_panel.scheduler_startup_load_twin.setChecked(bool(getattr(s.scheduler, 'startup_auto_load_twin', False)))
        w.scheduler_panel.scheduler_startup_delay.setValue(float(getattr(s.scheduler, 'startup_delay_s', 3.0) or 0.0))
        w.scheduler_panel.scheduler_startup_section.toggle_button.setChecked(bool(getattr(s.scheduler, 'startup_show_advanced', False)))

        for ch, row in w.relay_channel_rows.items():
            key = str(ch)
            target = s.relay.assignments.get(key)
            idx = find_data_index(row['combo'], target)
            row['combo'].setCurrentIndex(idx if idx >= 0 else 0)
            row['auto'].setChecked(bool(s.relay.auto_enabled.get(key, True)))
            row['test'].setChecked(False)

        w.config_controller.save_settings_to_state()
        w.ui_state.loading_twin_widgets = True
        try:
            if s.twin.fmu_path:
                w.commands.load_twin_model(s.twin.fmu_path)
            w.twin_panel.rebuild_variable_widgets()
            w.source_controller.refresh_all_sources()
            w.config_controller.save_settings_to_state()
        finally:
            w.ui_state.loading_twin_widgets = False
        w.ui_state.loading_scheduler_ui = False
        w.runtime_bridge.refresh_footer()
