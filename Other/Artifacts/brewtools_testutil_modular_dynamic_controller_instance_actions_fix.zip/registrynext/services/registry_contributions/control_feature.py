from __future__ import annotations

from application.registry import (
    AppRegistry,
    ControllerDefinition,
    ControllerHandlerDefinition,
    OutputTargetProviderDefinition,
    OutputTargetRecord,
    SignalProviderDefinition,
)
from services.signal_registry import SignalRecord
from state import AppState


CONTROL_DEFINITIONS = (
    ControllerDefinition(
        key='temperature',
        label='Temperature controller',
        kind='deadband',
        description='Maintains a temperature setpoint using paired heat/cool outputs.',
        source_families=('sensor', 'twin'),
        target_families=('relay_assignment',),
        setpoint_unit='°C',
        supports_ramp=True,
        measurement_kind='temperature',
        action_fields=('setpoint',),
        aliases=('temp',),
    ),
    ControllerDefinition(
        key='pressure',
        label='Pressure controller',
        kind='deadband',
        description='Maintains a pressure setpoint using add-gas/remove-gas outputs.',
        source_families=('sensor', 'twin'),
        target_families=('relay_assignment',),
        setpoint_unit='bar',
        supports_ramp=True,
        measurement_kind='pressure',
        action_fields=('setpoint', 'allow_add_gas'),
        aliases=('press',),
    ),
    ControllerDefinition(
        key='deadband',
        label='Generic deadband controller',
        kind='deadband',
        description='Generic on/off controller with upper and lower switching bands.',
        source_families=('sensor', 'twin'),
        target_families=('relay_assignment',),
        supports_ramp=True,
        measurement_kind='temperature',
        action_fields=('setpoint',),
        aliases=('generic_deadband',),
    ),
    ControllerDefinition(
        key='pid',
        label='Generic PID controller',
        kind='pid',
        description='Generic PID controller that produces a duty-cycle style output for supported targets.',
        source_families=('sensor', 'twin', 'agitator'),
        target_families=('agitator_target', 'relay_assignment'),
        supports_ramp=True,
        value_kind='duty_cycle',
        measurement_kind='rpm',
        action_fields=('setpoint',),
        aliases=('generic_pid',),
    ),
    ControllerDefinition(
        key='agitator',
        label='Agitator controller',
        kind='duty_or_pid',
        description='Drives the agitator through relay or CAN duty-cycle outputs.',
        source_families=('agitator', 'sensor'),
        target_families=('agitator_target',),
        setpoint_unit='%',
        supports_ramp=False,
        value_kind='command',
        measurement_kind='rpm',
        action_fields=('command',),
        aliases=('agitate',),
    ),
)


def register_control_feature(registry: AppRegistry) -> None:
    registry.register_signal_provider(SignalProviderDefinition(
        key='control.virtual_outputs',
        label='Control runtime outputs and agitator state',
        families=('virtual', 'agitator'),
        provider=_control_signal_records,
    ))
    for definition in CONTROL_DEFINITIONS:
        registry.register_controller(definition)
    registry.register_controller_handler(ControllerHandlerDefinition('temperature', _apply_temperature_action))
    registry.register_controller_handler(ControllerHandlerDefinition('deadband', _apply_generic_deadband_action))
    registry.register_controller_handler(ControllerHandlerDefinition('pid', _apply_generic_pid_action))
    registry.register_controller_handler(ControllerHandlerDefinition('pressure', _apply_pressure_action))
    registry.register_controller_handler(ControllerHandlerDefinition('agitator', _apply_agitator_action))
    registry.register_output_target_provider(OutputTargetProviderDefinition(
        key='control.agitator_targets',
        label='Agitator output targets',
        families=('agitator_target',),
        provider=_agitator_target_records,
    ))


def _control_signal_records(snapshot: AppState) -> list[SignalRecord]:
    return [
        SignalRecord('virtual:heat', 'Virtual — HEAT', snapshot.controls.heat_cool.output_a, 'GOOD', ''),
        SignalRecord('virtual:cool', 'Virtual — COOL', snapshot.controls.heat_cool.output_b, 'GOOD', ''),
        SignalRecord('virtual:add_gas', 'Virtual — ADD GAS', snapshot.controls.gas.output_a, 'GOOD', ''),
        SignalRecord('virtual:remove_gas', 'Virtual — REMOVE GAS', snapshot.controls.gas.output_b, 'GOOD', ''),
        SignalRecord('virtual:agitator', 'Virtual — AGITATOR', snapshot.controls.agitator_runtime.effective_on, 'GOOD', ''),
        SignalRecord('agitator:on', 'Agitator — Command on', snapshot.controls.agitator.on, 'GOOD', ''),
        SignalRecord('agitator:enabled', 'Agitator — Controller enabled', snapshot.controls.agitator.enabled, 'GOOD', ''),
        SignalRecord('agitator:target', 'Agitator — Target selection', snapshot.controls.agitator.target, 'GOOD', ''),
        SignalRecord('agitator:mode', 'Agitator — Control mode', snapshot.controls.agitator.mode, 'GOOD', ''),
        SignalRecord('agitator:duty_cycle', 'Agitator — Effective duty cycle', snapshot.controls.agitator_runtime.effective_duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:configured_duty_cycle', 'Agitator — Configured duty cycle', snapshot.controls.agitator.duty_cycle, 'GOOD', '%'),
        SignalRecord('agitator:speed_setpoint_rpm', 'Agitator — Speed setpoint', snapshot.controls.agitator.speed_setpoint_rpm, 'GOOD', 'rpm'),
        SignalRecord('agitator:pid_active', 'Agitator — PID active', snapshot.controls.agitator_runtime.pid_active, 'GOOD', ''),
        SignalRecord('agitator:rpm', 'Agitator — RPM feedback', snapshot.controls.agitator_runtime.rpm_feedback, 'GOOD' if snapshot.controls.agitator_runtime.rpm_feedback is not None else 'MISSING', 'rpm'),
    ]


def _agitator_target_records(snapshot: AppState) -> list[OutputTargetRecord]:
    records = [
        OutputTargetRecord(
            key='agitator_target:relay',
            label='Relay virtual output (AGITATOR)',
            family='agitator_target',
            value_kind='duty_cycle',
            controller_keys=('agitator','pid'),
            unit='%',
        )
    ]
    for st in sorted(snapshot.devices.values(), key=lambda item: item.node_id):
        if int(st.sender_node_type) != 6:
            continue
        label = f'CAN agitator node {st.node_id}'
        if st.rpm is not None:
            label += f' — RPM {st.rpm:.1f}'
        records.append(OutputTargetRecord(
            key=f'agitator_target:can:{int(st.node_id)}',
            label=label,
            family='agitator_target',
            value_kind='duty_cycle',
            controller_keys=('agitator','pid'),
            unit='%',
        ))
    return records


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    txt = str(value).strip().lower()
    return txt in {'1', 'true', 'yes', 'y', 'on'}


def _as_float(value, fallback: float) -> float:
    try:
        return float(value)
    except Exception:
        return float(fallback)


def _apply_temperature_action(state_store, snapshot: AppState, action) -> None:
    current = snapshot.controls.temperature
    if action.field != 'setpoint':
        return
    state_store.set_controller_config(
        'temperature',
        enabled=current.enabled,
        source_key=current.source_key,
        setpoint=_as_float(action.value, current.setpoint),
        deadband=current.deadband,
    )


def _apply_pressure_action(state_store, snapshot: AppState, action) -> None:
    current = snapshot.controls.pressure
    if action.field == 'allow_add_gas':
        state_store.set_controller_config(
            'pressure',
            enabled=current.enabled,
            source_key=current.source_key,
            setpoint=current.setpoint,
            deadband=current.deadband,
            allow_add_gas=_as_bool(action.value),
        )
        return
    if action.field != 'setpoint':
        return
    state_store.set_controller_config(
        'pressure',
        enabled=current.enabled,
        source_key=current.source_key,
        setpoint=_as_float(action.value, current.setpoint),
        deadband=current.deadband,
        allow_add_gas=current.allow_add_gas,
    )


def _apply_agitator_action(state_store, snapshot: AppState, action) -> None:
    current = snapshot.controls.agitator
    if action.field != 'command':
        return
    value = action.value
    if isinstance(value, bool):
        on = bool(value)
        duty_cycle = 0.0 if not on else current.duty_cycle
    else:
        duty_cycle = max(0.0, min(100.0, _as_float(value, current.duty_cycle)))
        on = duty_cycle > 0.0
    state_store.set_agitator_config(
        enabled=current.enabled,
        target=current.target,
        on=on,
        duty_cycle=duty_cycle,
        mode=current.mode,
        speed_setpoint_rpm=current.speed_setpoint_rpm,
        pid_kp=current.pid_kp,
        pid_ki=current.pid_ki,
        pid_kd=current.pid_kd,
    )
