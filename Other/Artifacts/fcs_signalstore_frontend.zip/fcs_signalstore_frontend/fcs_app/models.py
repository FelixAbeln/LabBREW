from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class RunState(str, Enum):
    IDLE = "idle"
    STARTUP = "startup"
    RUNNING = "running"
    PAUSED = "paused"
    WAITING_CONFIRMATION = "waiting_confirmation"
    COMPLETED = "completed"
    FAULTED = "faulted"
    STOPPED = "stopped"


@dataclass(slots=True)
class ControllerAction:
    controller_key: str
    field: str
    value: Any
    ramp_per_s: float | None = None
    raw_value: str = ""


@dataclass(slots=True)
class ScheduleStep:
    index: int
    enabled: bool = True
    name: str = ""
    temperature_setpoint: float | None = None
    temperature_ramp_per_s: float | None = None
    pressure_setpoint: float | None = None
    pressure_ramp_per_s: float | None = None
    allow_add_gas: bool | None = None
    wait_type: str = "elapsed_time"
    wait_source: str = ""
    operator: str = ">="
    threshold: float | None = None
    threshold_low: float | None = None
    threshold_high: float | None = None
    duration_s: float | None = None
    hold_for_s: float = 0.0
    valid_sources: list[str] = field(default_factory=list)
    require_confirmation: bool = False
    confirmation_message: str = ""
    agitator_on: bool | None = None
    agitator_duty_cycle: float | None = None
    controller_actions: list[ControllerAction] = field(default_factory=list)


@dataclass(slots=True)
class StartupConfig:
    enabled: bool = True
    connect_relays: bool = True
    connect_can: bool = True
    power_psu: bool = True
    reset_twin: bool = True
    delay_s: float = 3.0


@dataclass(slots=True)
class StartupStatus:
    active: bool = False
    stage: str = "idle"
    message: str = ""


@dataclass(slots=True)
class RunStatus:
    state: str = RunState.IDLE.value
    workbook_path: str = ""
    sheet_name: str = ""
    current_step_index: int = -1
    current_step_name: str = ""
    step_elapsed_s: float = 0.0
    hold_elapsed_s: float = 0.0
    wait_reason: str = "Idle"
    awaiting_confirmation: bool = False
    confirmation_message: str = ""
    last_transition: str = ""
    startup: StartupStatus = field(default_factory=StartupStatus)
    active_actions: list[dict[str, Any]] = field(default_factory=list)
    steps: list[dict[str, Any]] = field(default_factory=list)
    event_log: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class SignalStoreMapping:
    temp_setpoint: str = "controllers.temperature.setpoint"
    pressure_setpoint: str = "controllers.pressure.setpoint"
    pressure_allow_add_gas: str = "controllers.pressure.allow_add_gas"
    agitator_command: str = "controllers.agitator.command"
    relay_connect: str = "system.relays.connect"
    can_connect: str = "system.can.connect"
    psu_power: str = "system.psu.power"
    twin_reset: str = "digital_twin.reset"

    def resolve(self, controller_key: str, field: str) -> str | None:
        lookup = {
            ("temperature", "setpoint"): self.temp_setpoint,
            ("pressure", "setpoint"): self.pressure_setpoint,
            ("pressure", "allow_add_gas"): self.pressure_allow_add_gas,
            ("agitator", "command"): self.agitator_command,
        }
        return lookup.get((controller_key, field))
