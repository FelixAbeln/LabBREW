from __future__ import annotations

import threading
import time
from typing import Any

from .excel_loader import ExcelScheduleLoader
from .models import ControllerAction, RunState, RunStatus, ScheduleStep, StartupConfig, StartupStatus
from .signalstore_backend import SignalStoreBackend


class FcsRuntimeService:
    def __init__(self, backend: SignalStoreBackend, poll_interval_s: float = 0.25) -> None:
        self.backend = backend
        self.loader = ExcelScheduleLoader()
        self.poll_interval_s = max(0.05, float(poll_interval_s))
        self._steps: list[ScheduleStep] = []
        self._startup_config = StartupConfig()
        self._status = RunStatus()
        self._step_started_monotonic: float | None = None
        self._hold_started_monotonic: float | None = None
        self._action_ramp_start_values: dict[tuple[str, str], tuple[float, float]] = {}
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()

    def start_background(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop_event.clear()
            self._thread = threading.Thread(target=self._loop, name="fcs-runtime", daemon=True)
            self._thread.start()

    def shutdown(self) -> None:
        self._stop_event.set()
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=2.0)

    def configure_startup(self, config: StartupConfig) -> None:
        with self._lock:
            self._startup_config = config

    def load_schedule(self, workbook_path: str, sheet_name: str = "") -> dict[str, Any]:
        result = self.loader.load_workbook(workbook_path, sheet_name)
        with self._lock:
            if result.ok:
                self._steps = result.steps
                self._status.workbook_path = workbook_path
                self._status.sheet_name = result.active_sheet
                self._status.steps = [self._step_to_view(step) for step in self._steps]
                self._append_event(result.message)
            return {
                "ok": result.ok,
                "message": result.message,
                "sheet_names": result.sheet_names,
                "active_sheet": result.active_sheet,
                "steps": [self._step_to_view(step) for step in result.steps],
            }

    def start_run(self) -> dict[str, Any]:
        with self._lock:
            if not self._steps:
                return {"ok": False, "message": "No schedule loaded"}
            first = self._first_enabled_step_index()
            if first < 0:
                return {"ok": False, "message": "No enabled steps in schedule"}
            self._status.state = RunState.STARTUP.value if self._startup_config.enabled else RunState.RUNNING.value
            self._status.current_step_index = first
            self._status.current_step_name = self._steps[first].name
            self._status.awaiting_confirmation = False
            self._status.confirmation_message = ""
            self._status.wait_reason = "Preparing run"
            self._status.startup = StartupStatus(active=self._startup_config.enabled, stage="queued", message="Queued")
            self._step_started_monotonic = None
            self._hold_started_monotonic = None
            self._action_ramp_start_values.clear()
            self._append_event(f"Start requested at step {self._steps[first].name}")
            return {"ok": True, "message": "Run started"}

    def pause_run(self) -> dict[str, Any]:
        with self._lock:
            if self._status.state != RunState.RUNNING.value:
                return {"ok": False, "message": "Run is not active"}
            self._status.state = RunState.PAUSED.value
            self._append_event("Run paused")
            return {"ok": True, "message": "Paused"}

    def resume_run(self) -> dict[str, Any]:
        with self._lock:
            if self._status.state != RunState.PAUSED.value:
                return {"ok": False, "message": "Run is not paused"}
            self._status.state = RunState.RUNNING.value
            self._append_event("Run resumed")
            return {"ok": True, "message": "Resumed"}

    def stop_run(self) -> dict[str, Any]:
        with self._lock:
            self._status.state = RunState.STOPPED.value
            self._status.wait_reason = "Stopped"
            self._status.awaiting_confirmation = False
            self._status.confirmation_message = ""
            self._status.startup = StartupStatus()
            self._append_event("Run stopped")
            return {"ok": True, "message": "Stopped"}

    def confirm_step(self) -> dict[str, Any]:
        with self._lock:
            if self._status.state != RunState.WAITING_CONFIRMATION.value:
                return {"ok": False, "message": "Not waiting for confirmation"}
            self._status.awaiting_confirmation = False
            self._status.confirmation_message = ""
            self._status.state = RunState.RUNNING.value
            self._append_event("Operator confirmation received")
            self._advance_to_next_step_locked()
            return {"ok": True, "message": "Confirmed"}

    def next_step(self) -> dict[str, Any]:
        with self._lock:
            return self._manual_jump_locked(+1)

    def previous_step(self) -> dict[str, Any]:
        with self._lock:
            return self._manual_jump_locked(-1)

    def status(self) -> dict[str, Any]:
        with self._lock:
            return self._status.to_dict()

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception as exc:  # pragma: no cover
                with self._lock:
                    self._status.state = RunState.FAULTED.value
                    self._status.wait_reason = f"Fault: {exc}"
                    self._append_event(f"Fault: {exc}")
            time.sleep(self.poll_interval_s)

    def _tick(self) -> None:
        with self._lock:
            now = time.monotonic()
            if self._status.state == RunState.STARTUP.value:
                self._run_startup_locked(now)
                return
            if self._status.state != RunState.RUNNING.value:
                return
            idx = self._status.current_step_index
            if idx < 0 or idx >= len(self._steps):
                self._status.state = RunState.COMPLETED.value
                self._status.wait_reason = "No active step"
                return
            step = self._steps[idx]
            if self._step_started_monotonic is None:
                self._activate_step_locked(idx)
            self._status.step_elapsed_s = max(0.0, now - float(self._step_started_monotonic or now))
            self._apply_actions_locked(step, now)
            ready, reason = self._step_ready_to_advance_locked(step, now)
            self._status.wait_reason = reason
            if ready:
                if step.require_confirmation:
                    self._status.state = RunState.WAITING_CONFIRMATION.value
                    self._status.awaiting_confirmation = True
                    self._status.confirmation_message = step.confirmation_message or f"Confirm completion of {step.name}"
                    self._append_event(f"Waiting for confirmation: {self._status.confirmation_message}")
                else:
                    self._advance_to_next_step_locked()

    def _run_startup_locked(self, now: float) -> None:
        status = self._status.startup
        if not status.active:
            self._status.state = RunState.RUNNING.value
            return
        if status.stage in {"queued", "idle"}:
            status.stage = "running"
            status.message = "Running startup sequence"
            self._append_event("Startup sequence started")
            for event in self.backend.run_startup(
                connect_relays=self._startup_config.connect_relays,
                connect_can=self._startup_config.connect_can,
                power_psu=self._startup_config.power_psu,
                reset_twin=self._startup_config.reset_twin,
            ):
                self._append_event(event)
            self._hold_started_monotonic = now
            return
        delay = max(0.0, self._startup_config.delay_s)
        elapsed = now - float(self._hold_started_monotonic or now)
        if elapsed < delay:
            status.message = f"Settling startup sequence ({elapsed:.1f}/{delay:.1f}s)"
            self._status.wait_reason = status.message
            return
        status.stage = "completed"
        status.message = "Startup complete"
        status.active = False
        self._status.state = RunState.RUNNING.value
        self._hold_started_monotonic = None
        self._append_event("Startup sequence completed")

    def _activate_step_locked(self, index: int) -> None:
        step = self._steps[index]
        self._status.current_step_index = index
        self._status.current_step_name = step.name
        self._step_started_monotonic = time.monotonic()
        self._hold_started_monotonic = None
        self._action_ramp_start_values.clear()
        self._status.last_transition = f"Activated step {index + 1}: {step.name}"
        self._append_event(self._status.last_transition)
        self._status.active_actions = [self._action_to_view(action) for action in step.controller_actions]

    def _apply_actions_locked(self, step: ScheduleStep, now: float) -> None:
        active_views: list[dict[str, Any]] = []
        for action in step.controller_actions:
            applied_value = action.value
            if action.ramp_per_s and isinstance(action.value, (int, float)):
                key = (action.controller_key, action.field)
                if key not in self._action_ramp_start_values:
                    name = self.backend.mapping.resolve(action.controller_key, action.field)
                    current = self.backend.get_value(name, action.value) if name else action.value
                    start_value = float(current if isinstance(current, (int, float)) else action.value)
                    self._action_ramp_start_values[key] = (start_value, now)
                start_value, started = self._action_ramp_start_values[key]
                elapsed = max(0.0, now - started)
                delta = float(action.value) - float(start_value)
                step_size = abs(float(action.ramp_per_s)) * elapsed
                if delta >= 0:
                    applied_value = min(float(action.value), float(start_value) + step_size)
                else:
                    applied_value = max(float(action.value), float(start_value) - step_size)
            self.backend.apply_action(action, stepped_value=applied_value)
            view = self._action_to_view(action)
            view["applied_value"] = applied_value
            active_views.append(view)
        self._status.active_actions = active_views

    def _step_ready_to_advance_locked(self, step: ScheduleStep, now: float) -> tuple[bool, str]:
        if step.wait_type == "elapsed_time":
            duration = max(0.0, float(step.duration_s or 0.0))
            elapsed = now - float(self._step_started_monotonic or now)
            return elapsed >= duration, f"Elapsed time {elapsed:.1f}/{duration:.1f}s"
        if step.wait_type == "signal":
            value = self.backend.get_value(step.wait_source)
            ok = self._evaluate_signal_condition(step, value)
            if not ok:
                self._hold_started_monotonic = None
                return False, f"Waiting for {step.wait_source}"
            if self._hold_started_monotonic is None:
                self._hold_started_monotonic = now
            hold = max(0.0, float(step.hold_for_s or 0.0))
            held = now - float(self._hold_started_monotonic or now)
            self._status.hold_elapsed_s = held
            return held >= hold, f"Condition met on {step.wait_source}; hold {held:.1f}/{hold:.1f}s"
        if step.wait_type == "all_valid":
            all_valid = all(bool(self.backend.get_value(name)) for name in step.valid_sources)
            if not all_valid:
                self._hold_started_monotonic = None
                return False, "Waiting for valid sources"
            if self._hold_started_monotonic is None:
                self._hold_started_monotonic = now
            hold = max(0.0, float(step.hold_for_s or 0.0))
            held = now - float(self._hold_started_monotonic or now)
            self._status.hold_elapsed_s = held
            return held >= hold, f"All valid; hold {held:.1f}/{hold:.1f}s"
        return False, f"Unknown wait type: {step.wait_type}"

    def _evaluate_signal_condition(self, step: ScheduleStep, value: Any) -> bool:
        if value is None:
            return False
        op = step.operator
        if op == "in_range":
            if step.threshold_low is None or step.threshold_high is None:
                return False
            try:
                return float(step.threshold_low) <= float(value) <= float(step.threshold_high)
            except Exception:
                return False
        if op == "out_of_range":
            if step.threshold_low is None or step.threshold_high is None:
                return False
            try:
                return not (float(step.threshold_low) <= float(value) <= float(step.threshold_high))
            except Exception:
                return False
        threshold = step.threshold
        if threshold is None:
            return False
        try:
            current = float(value)
            target = float(threshold)
        except Exception:
            return False
        return {
            ">=": current >= target,
            "<=": current <= target,
            ">": current > target,
            "<": current < target,
            "==": current == target,
            "!=": current != target,
        }.get(op, False)

    def _advance_to_next_step_locked(self) -> None:
        nxt = self._next_enabled_step_index(self._status.current_step_index)
        if nxt < 0:
            self._status.state = RunState.COMPLETED.value
            self._status.wait_reason = "Schedule complete"
            self._status.last_transition = f"Completed schedule at {self._status.current_step_name}"
            self._append_event(self._status.last_transition)
            return
        self._activate_step_locked(nxt)

    def _manual_jump_locked(self, direction: int) -> dict[str, Any]:
        current = self._status.current_step_index
        candidate = self._previous_enabled_step_index(current) if direction < 0 else self._next_enabled_step_index(current)
        if candidate < 0:
            return {"ok": False, "message": "No matching step"}
        self._status.state = RunState.RUNNING.value
        self._status.awaiting_confirmation = False
        self._status.confirmation_message = ""
        self._activate_step_locked(candidate)
        return {"ok": True, "message": self._status.last_transition}

    def _first_enabled_step_index(self) -> int:
        for i, step in enumerate(self._steps):
            if step.enabled:
                return i
        return -1

    def _next_enabled_step_index(self, current: int) -> int:
        for i in range(current + 1, len(self._steps)):
            if self._steps[i].enabled:
                return i
        return -1

    def _previous_enabled_step_index(self, current: int) -> int:
        for i in range(current - 1, -1, -1):
            if self._steps[i].enabled:
                return i
        return -1

    def _append_event(self, text: str) -> None:
        if not text:
            return
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        self._status.event_log.append(f"{stamp} | {text}")
        self._status.event_log = self._status.event_log[-200:]

    @staticmethod
    def _action_to_view(action: ControllerAction) -> dict[str, Any]:
        return {
            "controller_key": action.controller_key,
            "field": action.field,
            "value": action.value,
            "ramp_per_s": action.ramp_per_s,
        }

    @staticmethod
    def _step_to_view(step: ScheduleStep) -> dict[str, Any]:
        return {
            "index": step.index,
            "enabled": step.enabled,
            "name": step.name,
            "temp_sp": step.temperature_setpoint,
            "pressure_sp": step.pressure_setpoint,
            "wait_type": step.wait_type,
            "wait_source": step.wait_source,
            "operator": step.operator,
            "threshold": step.threshold,
            "threshold_low": step.threshold_low,
            "threshold_high": step.threshold_high,
            "duration_s": step.duration_s,
            "hold_for_s": step.hold_for_s,
            "require_confirmation": step.require_confirmation,
            "confirmation_message": step.confirmation_message,
            "valid_sources": list(step.valid_sources),
            "controller_actions": [FcsRuntimeService._action_to_view(a) for a in step.controller_actions],
        }
