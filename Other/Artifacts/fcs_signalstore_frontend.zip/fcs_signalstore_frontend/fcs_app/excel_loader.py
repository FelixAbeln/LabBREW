from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from openpyxl import load_workbook

from .models import ControllerAction, ScheduleStep


OPERATOR_KEYS = {">=", "<=", ">", "<", "==", "!=", "in_range", "out_of_range", "valid_for"}


@dataclass(slots=True)
class ScheduleLoadResult:
    ok: bool
    message: str
    sheet_names: list[str]
    active_sheet: str
    steps: list[ScheduleStep]


class ExcelScheduleLoader:
    def __init__(self) -> None:
        self.workbook_path = ""
        self.sheet_name = ""
        self.sheet_names: list[str] = []

    def load_workbook(self, path: str, sheet_name: str = "") -> ScheduleLoadResult:
        path = str(path or "").strip()
        if not path:
            return ScheduleLoadResult(False, "No schedule file selected", [], "", [])
        wb = load_workbook(path, data_only=True)
        self.sheet_names = list(wb.sheetnames)
        if not self.sheet_names:
            return ScheduleLoadResult(False, "Workbook has no sheets", [], "", [])
        target_sheet = sheet_name if sheet_name in wb.sheetnames else wb.sheetnames[0]
        ws = wb[target_sheet]
        header_cells = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), None)
        if not header_cells:
            return ScheduleLoadResult(False, "Schedule sheet is empty", self.sheet_names, target_sheet, [])
        headers = [str(v).strip() if v is not None else "" for v in header_cells]
        header_map = {h.lower(): i for i, h in enumerate(headers) if h}

        def cell(row, name, default=None):
            idx = header_map.get(name.lower())
            if idx is None or idx >= len(row):
                return default
            value = row[idx]
            return default if value is None else value

        def as_bool(value, default=False):
            if value is None:
                return default
            if isinstance(value, bool):
                return value
            txt = str(value).strip().lower()
            if txt in {"1", "true", "yes", "y", "on"}:
                return True
            if txt in {"0", "false", "no", "n", "off"}:
                return False
            return default

        def as_float(value):
            if value in (None, ""):
                return None
            try:
                return float(value)
            except Exception:
                return None

        steps: list[ScheduleStep] = []
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=0):
            if not any(v not in (None, "") for v in row):
                continue
            valid_sources_raw = cell(row, "valid_sources", "")
            valid_sources = [part.strip() for part in str(valid_sources_raw or "").split(",") if part.strip()]
            temp_target, temp_ramp = _parse_ramp_cell(cell(row, "temp_sp", cell(row, "temperature_setpoint")))
            pressure_target, pressure_ramp = _parse_ramp_cell(cell(row, "pressure_sp", cell(row, "pressure_setpoint")))
            explicit_actions = _parse_controller_actions_cell(cell(row, "controller_actions", ""))
            step = ScheduleStep(
                index=int(cell(row, "index", row_idx) or row_idx),
                enabled=as_bool(cell(row, "enabled", True), True),
                name=str(cell(row, "step_name", cell(row, "name", f"Step {row_idx + 1}")) or f"Step {row_idx + 1}"),
                temperature_setpoint=temp_target,
                temperature_ramp_per_s=temp_ramp if temp_ramp is not None else as_float(cell(row, "temp_ramp_per_s")),
                pressure_setpoint=pressure_target,
                pressure_ramp_per_s=pressure_ramp if pressure_ramp is not None else as_float(cell(row, "pressure_ramp_per_s")),
                allow_add_gas=_parse_optional_bool(cell(row, "allow_add_gas")),
                wait_type=_normalize_wait_type(cell(row, "wait_type", "elapsed_time")),
                wait_source=str(cell(row, "wait_source", "") or "").strip(),
                operator=str(cell(row, "operator", ">=") or ">=").strip().lower(),
                threshold=as_float(cell(row, "threshold")),
                threshold_low=as_float(cell(row, "threshold_low")),
                threshold_high=as_float(cell(row, "threshold_high")),
                duration_s=as_float(cell(row, "duration_s")) if as_float(cell(row, "duration_s")) is not None else as_float(cell(row, "time_s")),
                hold_for_s=max(0.0, (as_float(cell(row, "hold_for_s")) if as_float(cell(row, "hold_for_s")) is not None else (as_float(cell(row, "time_s")) or 0.0))),
                valid_sources=valid_sources,
                require_confirmation=as_bool(cell(row, "require_confirmation", False), False),
                confirmation_message=str(cell(row, "confirmation_message", "") or "").strip(),
                agitator_on=_parse_optional_bool(cell(row, "agitator_on")),
                agitator_duty_cycle=as_float(cell(row, "agitator_duty_cycle")),
                controller_actions=list(explicit_actions),
            )
            if step.operator not in OPERATOR_KEYS:
                step.operator = ">=" if step.wait_type == "signal" else ("valid_for" if step.wait_type == "all_valid" else step.operator)
            if step.wait_type == "elapsed_time" and step.duration_s is None:
                step.duration_s = max(0.0, float(step.hold_for_s or 0.0))
            elif step.wait_type in {"signal", "all_valid"} and not float(step.hold_for_s or 0.0):
                step.hold_for_s = max(0.0, float(step.duration_s or 0.0))
            if step.confirmation_message:
                step.require_confirmation = True
            ag_on, ag_duty = _parse_agitator_cell(cell(row, "agitator"))
            if ag_on is not None:
                step.agitator_on = ag_on
            if ag_duty is not None:
                step.agitator_duty_cycle = ag_duty
            elif step.agitator_on is False:
                step.agitator_duty_cycle = 0.0
            step.controller_actions = _merge_controller_actions(
                step.controller_actions,
                temp_target=step.temperature_setpoint,
                temp_ramp=step.temperature_ramp_per_s,
                pressure_target=step.pressure_setpoint,
                pressure_ramp=step.pressure_ramp_per_s,
                allow_add_gas=step.allow_add_gas,
                agitator_on=step.agitator_on,
                agitator_duty=step.agitator_duty_cycle,
            )
            steps.append(step)

        self.workbook_path = path
        self.sheet_name = target_sheet
        return ScheduleLoadResult(True, f"Loaded schedule: {len(steps)} step(s)", self.sheet_names, target_sheet, steps)


def _parse_ramp_cell(value) -> tuple[float | None, float | None]:
    if value in (None, ""):
        return None, None
    txt = str(value).strip()
    if ":" not in txt:
        try:
            return float(txt), None
        except Exception:
            return None, None
    parts = [part.strip() for part in txt.split(":")]
    try:
        target = float(parts[0])
    except Exception:
        return None, None
    ramp = None
    if len(parts) > 1 and parts[1] not in {"", "-"}:
        try:
            ramp = abs(float(parts[1]))
        except Exception:
            ramp = None
    return target, ramp


def _parse_optional_bool(value):
    if value in (None, ""):
        return None
    txt = str(value).strip().lower()
    if txt in {"", "none", "keep", "default", "inherit"}:
        return None
    if txt in {"1", "true", "yes", "y", "on"}:
        return True
    if txt in {"0", "false", "no", "n", "off"}:
        return False
    return None


def _parse_agitator_cell(value):
    if value in (None, ""):
        return None, None
    b = _parse_optional_bool(value)
    if b is not None:
        return bool(b), (0.0 if not b else None)
    try:
        duty = float(value)
    except Exception:
        return None, None
    duty = max(0.0, min(100.0, duty))
    return duty > 0.0, duty


def _normalize_wait_type(value: str) -> str:
    txt = str(value or "elapsed_time").strip().lower()
    if txt in {"signal_threshold", "threshold", "twin_threshold"}:
        return "signal"
    if txt in {"valid_all", "valid"}:
        return "all_valid"
    if txt in {"time", "duration"}:
        return "elapsed_time"
    return txt or "elapsed_time"


def _parse_controller_value(value_text: str):
    b = _parse_optional_bool(value_text)
    if b is not None:
        return b
    try:
        return float(value_text)
    except Exception:
        return value_text


def _parse_controller_action_entry(text: str) -> ControllerAction | None:
    raw = str(text or "").strip()
    if not raw:
        return None
    parts = [part.strip() for part in raw.split(":")]
    if len(parts) < 2:
        return None
    target = parts[0]
    value_text = parts[1]
    ramp = None
    if len(parts) >= 3 and parts[2] not in {"", "-"}:
        try:
            ramp = abs(float(parts[2]))
        except Exception:
            ramp = None
    controller_key, _dot, field = target.partition(".")
    controller_key = controller_key.strip()
    if not controller_key:
        return None
    if not field:
        field = "command" if controller_key == "agitator" else "setpoint"
    return ControllerAction(
        controller_key=controller_key,
        field=field,
        value=_parse_controller_value(value_text),
        ramp_per_s=ramp,
        raw_value=value_text,
    )


def _parse_controller_actions_cell(value) -> list[ControllerAction]:
    if value in (None, ""):
        return []
    text = str(value).replace("\n", ";")
    actions: list[ControllerAction] = []
    for chunk in text.split(";"):
        action = _parse_controller_action_entry(chunk)
        if action is not None:
            actions.append(action)
    return actions


def _merge_controller_actions(explicit_actions: list[ControllerAction], *, temp_target, temp_ramp, pressure_target, pressure_ramp, allow_add_gas, agitator_on, agitator_duty) -> list[ControllerAction]:
    merged: dict[tuple[str, str], ControllerAction] = {(a.controller_key, a.field): a for a in explicit_actions}
    if temp_target is not None:
        merged[("temperature", "setpoint")] = ControllerAction("temperature", "setpoint", temp_target, temp_ramp, str(temp_target))
    if pressure_target is not None:
        merged[("pressure", "setpoint")] = ControllerAction("pressure", "setpoint", pressure_target, pressure_ramp, str(pressure_target))
    if allow_add_gas is not None:
        merged[("pressure", "allow_add_gas")] = ControllerAction("pressure", "allow_add_gas", bool(allow_add_gas), None, str(allow_add_gas))
    if agitator_duty is not None:
        merged[("agitator", "command")] = ControllerAction("agitator", "command", float(agitator_duty), None, str(agitator_duty))
    elif agitator_on is not None:
        merged[("agitator", "command")] = ControllerAction("agitator", "command", bool(agitator_on), None, str(agitator_on))
    return list(merged.values())
