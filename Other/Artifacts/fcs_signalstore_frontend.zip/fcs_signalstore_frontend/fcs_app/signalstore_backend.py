from __future__ import annotations

import threading
from dataclasses import asdict
from typing import Any

from .models import ControllerAction, SignalStoreMapping

try:
    from parameterdb_core.client import SignalSession
except Exception:  # pragma: no cover
    SignalSession = None  # type: ignore


class SignalStoreBackend:
    """Thin adapter around SignalStore / ParameterDB.

    Replace mapping names with your real parameter names and keep all regulator
    logic in the backend service. The UI should never write directly to these.
    """

    def __init__(self, *, host: str = "127.0.0.1", port: int = 8765, timeout: float = 2.0, mapping: SignalStoreMapping | None = None) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self.mapping = mapping or SignalStoreMapping()
        self._lock = threading.RLock()
        self._client = SignalSession(host=host, port=port, timeout=timeout) if SignalSession is not None else None

    def connected(self) -> bool:
        try:
            return bool(self._client and self._client.ping())
        except Exception:
            return False

    def ping(self) -> str:
        if self._client is None:
            return "parameterdb_core not importable"
        return str(self._client.ping())

    def get_value(self, name: str, default: Any = None) -> Any:
        if self._client is None:
            return default
        try:
            with self._lock:
                return self._client.get_value(name, default)
        except Exception:
            return default

    def set_value(self, name: str, value: Any) -> bool:
        if self._client is None:
            return False
        try:
            with self._lock:
                return bool(self._client.set_value(name, value))
        except Exception:
            return False

    def apply_action(self, action: ControllerAction, *, stepped_value: Any | None = None) -> bool:
        target = self.mapping.resolve(action.controller_key, action.field)
        if not target:
            return False
        return self.set_value(target, action.value if stepped_value is None else stepped_value)

    def reset_twin(self) -> bool:
        return self.set_value(self.mapping.twin_reset, True)

    def run_startup(self, *, connect_relays: bool, connect_can: bool, power_psu: bool, reset_twin: bool) -> list[str]:
        events: list[str] = []
        if connect_relays:
            self.set_value(self.mapping.relay_connect, True)
            events.append(f"Set {self.mapping.relay_connect}=True")
        if connect_can:
            self.set_value(self.mapping.can_connect, True)
            events.append(f"Set {self.mapping.can_connect}=True")
        if power_psu:
            self.set_value(self.mapping.psu_power, True)
            events.append(f"Set {self.mapping.psu_power}=True")
        if reset_twin:
            self.reset_twin()
            events.append(f"Triggered {self.mapping.twin_reset}")
        return events

    def snapshot(self, names: list[str]) -> dict[str, Any]:
        return {name: self.get_value(name) for name in names}

    def describe_mapping(self) -> dict[str, Any]:
        return asdict(self.mapping)
