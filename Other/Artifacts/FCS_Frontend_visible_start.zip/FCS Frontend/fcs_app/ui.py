from __future__ import annotations

import json
from dataclasses import dataclass
from urllib import request

from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QColor, QTextCursor
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QComboBox,
    QHeaderView,
)

from .template_exporter import ScheduleTemplateExporter, TemplateExportOptions


@dataclass(slots=True)
class ApiClient:
    base_url: str

    def get(self, path: str) -> dict:
        with request.urlopen(f"{self.base_url}{path}", timeout=3.0) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def post(self, path: str, payload: dict | None = None) -> dict:
        data = json.dumps(payload or {}).encode("utf-8")
        req = request.Request(f"{self.base_url}{path}", data=data, headers={"Content-Type": "application/json"}, method="POST")
        with request.urlopen(req, timeout=5.0) as resp:
            return json.loads(resp.read().decode("utf-8"))


class MainWindow(QMainWindow):
    def __init__(self, api: ApiClient) -> None:
        super().__init__()
        self.api = api
        self.template_exporter = ScheduleTemplateExporter()
        self.setWindowTitle("FCS Scheduler Client")
        root = QWidget()
        layout = QVBoxLayout(root)

        top_group = QGroupBox("Workbook")
        top = QGridLayout(top_group)
        self.workbook_path = QLineEdit()
        self.btn_browse = QPushButton("Browse…")
        self.btn_load = QPushButton("Load workbook")
        self.template_mode = QComboBox()
        self.template_mode.addItems(["Blank template", "Test routine template"])
        self.btn_export_template = QPushButton("Export template")
        top.addWidget(QLabel("Workbook"), 0, 0)
        top.addWidget(self.workbook_path, 0, 1)
        top.addWidget(self.btn_browse, 0, 2)
        top.addWidget(self.btn_load, 0, 3)
        top.addWidget(QLabel("Template mode"), 1, 0)
        top.addWidget(self.template_mode, 1, 1, 1, 3)
        top.addWidget(self.btn_export_template, 0, 4, 2, 1)
        top.setColumnStretch(1, 1)
        layout.addWidget(top_group)

        self.confirm_banner = QLabel("")
        self.confirm_banner.setVisible(False)
        self.confirm_banner.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.confirm_banner)

        ctrl = QHBoxLayout()
        self.btn_primary = QPushButton("Start")
        self.btn_stop = QPushButton("Stop")
        self.btn_prev = QPushButton("Previous")
        self.btn_next = QPushButton("Next")
        for btn in [self.btn_primary, self.btn_stop, self.btn_prev, self.btn_next]:
            btn.setMinimumHeight(44)
            ctrl.addWidget(btn)
        layout.addLayout(ctrl)

        status_group = QGroupBox("Runtime status")
        status_form = QFormLayout(status_group)
        self.state_lbl = QLabel("—")
        self.phase_lbl = QLabel("—")
        self.step_lbl = QLabel("—")
        self.elapsed_lbl = QLabel("—")
        self.hold_lbl = QLabel("—")
        self.wait_lbl = QLabel("—")
        self.confirm_lbl = QLabel("—")
        self.transition_lbl = QLabel("—")
        status_form.addRow("State", self.state_lbl)
        status_form.addRow("Phase", self.phase_lbl)
        status_form.addRow("Current step", self.step_lbl)
        status_form.addRow("Step elapsed", self.elapsed_lbl)
        status_form.addRow("Hold elapsed", self.hold_lbl)
        status_form.addRow("Waiting", self.wait_lbl)
        status_form.addRow("Confirmation", self.confirm_lbl)
        status_form.addRow("Last transition", self.transition_lbl)
        layout.addWidget(status_group)

        self.tabs = QTabWidget()
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.startup_table = QTableWidget(0, 8)
        self.startup_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.plan_table = QTableWidget(0, 8)
        self.plan_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.tabs.addTab(self.startup_table, "StartupRoutine")
        self.tabs.addTab(self.plan_table, "Plan")
        layout.addWidget(self.tabs)

        self.events = QTextEdit()
        self.events.setReadOnly(True)
        layout.addWidget(self.events)

        self.setCentralWidget(root)
        self._blink_on = False
        self._last_status = {}
        self._auto_tab_follow = True
        self._wire()
        self._apply_unified_style()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_status)
        self.timer.start(1000)
        self.blink_timer = QTimer(self)
        self.blink_timer.timeout.connect(self._toggle_confirm_blink)
        self.refresh_status()

    def _wire(self) -> None:
        self.btn_browse.clicked.connect(self.browse_workbook)
        self.btn_load.clicked.connect(self.load_schedule)
        self.btn_export_template.clicked.connect(self.export_template)
        self.btn_primary.clicked.connect(self.on_primary_button)
        self.btn_stop.clicked.connect(lambda: self._post("/run/stop"))
        self.btn_prev.clicked.connect(lambda: self._post("/run/previous"))
        self.btn_next.clicked.connect(lambda: self._post("/run/next"))

    def browse_workbook(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select schedule workbook", self.workbook_path.text().strip(), "Excel Workbook (*.xlsx *.xlsm)")
        if path:
            self.workbook_path.setText(path)

    def export_template(self) -> None:
        suggested_name = "fcs_test_routine_template.xlsx" if self.template_mode.currentIndex() == 1 else "fcs_schedule_template.xlsx"
        path, _ = QFileDialog.getSaveFileName(self, "Export schedule template", suggested_name, "Excel Workbook (*.xlsx)")
        if not path:
            return
        try:
            options = TemplateExportOptions(include_examples=True, include_test_routine=self.template_mode.currentIndex() == 1)
            exported = self.template_exporter.export(path, options)
            self.workbook_path.setText(str(exported))
            QMessageBox.information(self, "Template exported", f"Template written to:\n{exported}")
        except Exception as exc:
            QMessageBox.critical(self, "Template export failed", str(exc))

    def load_schedule(self) -> None:
        self._post("/schedule/load", {"workbook_path": self.workbook_path.text().strip()}, refresh=True)

    def on_primary_button(self) -> None:
        state = str(self._last_status.get("state", "idle"))
        waiting_confirmation = bool(self._last_status.get("awaiting_confirmation", False))
        if waiting_confirmation or state == "waiting_confirmation":
            self._post("/run/confirm")
            return
        if state == "paused":
            self._post("/run/resume")
            return
        if state in {"running", "startup"}:
            self._post("/run/pause")
            return
        self._post("/run/start")

    def _apply_unified_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow, QWidget { background: #f3f5f7; color: #1f2937; }
            QGroupBox { font-weight: 600; border: 1px solid #d0d7de; border-radius: 8px; margin-top: 12px; padding-top: 12px; background: #ffffff; }
            QLabel { background: transparent; }
            QGroupBox QLabel[role="value"] { background: #f8fafc; border: 1px solid #dbe2ea; border-radius: 6px; padding: 4px 8px; }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
            QLineEdit, QComboBox, QTextEdit, QTableWidget {
                background: #ffffff; border: 1px solid #c8d1da; border-radius: 6px; padding: 4px;
            }
            QPushButton {
                background: #d1d5db; color: #111827; border: 1px solid #b8c0cc; border-radius: 8px; padding: 8px 16px; font-weight: 600;
            }
            QPushButton:hover { background: #c5cad3; }
            QHeaderView::section { background: #123b64; color: white; padding: 6px; border: none; font-weight: 600; }
            QTabWidget::pane { background: #ffffff; border: 1px solid #c3ced8; border-radius: 8px; top: -1px; }
            QTabBar::tab { background: #e7edf3; padding: 8px 16px; border: 1px solid #c3ced8; border-bottom: none; border-top-left-radius: 6px; border-top-right-radius: 6px; min-width: 120px; }
            QTabBar::tab:selected { background: #ffffff; margin-bottom: -1px; }
            """
        )
        for table in [self.startup_table, self.plan_table]:
            table.verticalHeader().setVisible(False)
            table.setAlternatingRowColors(False)
            table.setSelectionBehavior(QTableWidget.SelectRows)
            table.setSelectionMode(QTableWidget.NoSelection)
            table.horizontalHeader().setStretchLastSection(True)
            table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.confirm_banner.setStyleSheet("background: #dcfce7; color: #166534; border: 1px solid #86efac; border-radius: 8px; padding: 10px; font-weight: 700;")
        for label in [self.state_lbl, self.phase_lbl, self.step_lbl, self.elapsed_lbl, self.hold_lbl, self.wait_lbl, self.confirm_lbl, self.transition_lbl]:
            label.setProperty("role", "value")
            label.style().unpolish(label)
            label.style().polish(label)

    def _set_button_role_style(self, button: QPushButton, role: str, blink_on: bool = False) -> None:
        colors = {
            "green": ("#16a34a", "white"),
            "yellow": ("#facc15", "#111827"),
            "grey": ("#d1d5db", "#111827"),
            "blue": ("#2563eb", "white"),
            "blink": (("#22c55e" if blink_on else "#bbf7d0"), ("white" if blink_on else "#166534")),
        }
        bg, fg = colors[role]
        button.setStyleSheet(f"background: {bg}; color: {fg}; border: 1px solid #94a3b8; border-radius: 8px; padding: 8px 16px; font-weight: 700;")

    def _update_button_states(self, status: dict) -> None:
        state = str(status.get("state", "idle"))
        waiting_confirmation = bool(status.get("awaiting_confirmation", False)) or state == "waiting_confirmation"
        active = state in {"running", "startup", "waiting_confirmation", "paused"}

        if waiting_confirmation:
            self.btn_primary.setText("Confirm")
            self._set_button_role_style(self.btn_primary, "blink", self._blink_on)
            if not self.blink_timer.isActive():
                self.blink_timer.start(500)
        else:
            if self.blink_timer.isActive():
                self.blink_timer.stop()
            if state in {"running", "startup"}:
                self.btn_primary.setText("Pause")
                self._set_button_role_style(self.btn_primary, "green")
            elif state == "paused":
                self.btn_primary.setText("Resume")
                self._set_button_role_style(self.btn_primary, "yellow")
            else:
                self.btn_primary.setText("Start")
                self._set_button_role_style(self.btn_primary, "grey")

        for button in [self.btn_stop, self.btn_prev, self.btn_next]:
            self._set_button_role_style(button, "grey")
            button.setEnabled(active)
        self.btn_stop.setEnabled(active)
        self.btn_prev.setEnabled(active)
        self.btn_next.setEnabled(active)
        self.btn_primary.setEnabled(True)

        message = str(status.get("confirmation_message", "") or "")
        self.confirm_banner.setVisible(waiting_confirmation and bool(message))
        self.confirm_banner.setText(message)

    def _toggle_confirm_blink(self) -> None:
        self._blink_on = not self._blink_on
        self._update_button_states(self._last_status)

    def refresh_status(self) -> None:
        try:
            status = self.api.get("/status")
        except Exception as exc:
            self._last_status = {"state": "disconnected"}
            self.state_lbl.setText(f"Disconnected ({exc})")
            self.phase_lbl.setText("—")
            self.step_lbl.setText("—")
            self.wait_lbl.setText("Service unavailable")
            self._update_button_states(self._last_status)
            return

        self._last_status = status
        self.state_lbl.setText(str(status.get("state", "—")))
        self.phase_lbl.setText(str(status.get("phase", "—")))
        idx = int(status.get("current_step_index", -1) or -1)
        name = str(status.get("current_step_name", "") or "")
        self.step_lbl.setText(f"{idx + 1 if idx >= 0 else '—'} | {name if name else '—'}")
        self.elapsed_lbl.setText(f"{float(status.get('step_elapsed_s', 0.0)):.1f} s")
        self.hold_lbl.setText(f"{float(status.get('hold_elapsed_s', 0.0)):.1f} s")
        self.wait_lbl.setText(str(status.get("wait_reason", "—")))
        self.confirm_lbl.setText(str(status.get("confirmation_message", "—")))
        self.transition_lbl.setText(str(status.get("last_transition", "—")))
        active_phase = str(status.get("phase", ""))
        active_index = idx
        self._fill_table(self.startup_table, status.get("startup_steps", []), active=(active_phase == "startup", active_index))
        self._fill_table(self.plan_table, status.get("plan_steps", []), active=(active_phase == "plan", active_index))
        if self._auto_tab_follow:
            self.tabs.setCurrentIndex(0 if active_phase == "startup" else 1)
        self.events.setPlainText("\n".join(status.get("event_log", [])))
        self.events.moveCursor(QTextCursor.End)
        scrollbar = self.events.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        self._update_button_states(status)


    def _on_tab_changed(self, index: int) -> None:
        if self.tabs.isVisible():
            self._auto_tab_follow = False

    def enable_auto_tab_follow(self) -> None:
        self._auto_tab_follow = True

    def _fill_table(self, table: QTableWidget, steps: list[dict], active: tuple[bool, int]) -> None:
        is_active_phase, active_index = active
        table.setRowCount(len(steps))
        for row, step in enumerate(steps):
            actions = "; ".join(action.get("display_text", "") for action in step.get("controller_actions", []))
            criteria = self._criteria_text(step)
            step_index = int(step.get("index", row))
            values = [
                step_index + 1,
                step.get("enabled", True),
                step.get("name", ""),
                actions,
                step.get("wait_type", ""),
                step.get("wait_source", ""),
                criteria,
                step.get("confirmation_message", "") or step.get("require_confirmation", False),
            ]
            highlight = is_active_phase and step_index == active_index
            bg = QColor("#fde68a") if highlight else QColor("#ffffff")
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setBackground(bg)
                if highlight:
                    item.setForeground(QColor("#111827"))
                table.setItem(row, col, item)
        table.resizeColumnsToContents()

    def _criteria_text(self, step: dict) -> str:
        wait_type = step.get("wait_type", "")
        if wait_type == "signal":
            operator = step.get("operator", "")
            if operator in {"in_range", "out_of_range"}:
                return f"{operator} [{step.get('threshold_low', '')}, {step.get('threshold_high', '')}] hold={step.get('hold_for_s', 0)}s"
            return f"{operator} {step.get('threshold', '')} hold={step.get('hold_for_s', 0)}s"
        if wait_type == "all_valid":
            return f"{', '.join(step.get('valid_sources', []))} hold={step.get('hold_for_s', 0)}s"
        return f"{step.get('duration_s', 0)}s"

    def _post(self, path: str, payload: dict | None = None, *, refresh: bool = True) -> None:
        try:
            result = self.api.post(path, payload)
            if refresh:
                self.refresh_status()
            if not result.get("ok", True):
                QMessageBox.warning(self, "FCS service", str(result.get("message", "Unknown error")))
        except Exception as exc:
            QMessageBox.critical(self, "FCS service", str(exc))


def run_ui(base_url: str = "http://127.0.0.1:8769", *, start_minimized: bool = False) -> int:
    app = QApplication([])
    window = MainWindow(ApiClient(base_url=base_url.rstrip("/")))
    window.resize(1280, 860)
    if start_minimized:
        window.showMinimized()
    else:
        window.show()
    return app.exec()
