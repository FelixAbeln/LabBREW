from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class RunState(str, Enum):
    IDLE = "idle"
    STARTUP = "startup"
    RUNNING = "running"
    PAUSED = "paused"
    WAITING_CONFIRMATION = "waiting_confirmation"
    COMPLETED = "completed"
    FAULTED = "faulted"
    STOPPED = "stopped"


@dataclass(slots=True)
class StepAction:
    """A direct write to a ParameterDB / SignalStore key."""

    target_key: str
    value: Any
    ramp_per_s: float | None = None
    raw_value: str = ""

    @property
    def display_text(self) -> str:
        if self.ramp_per_s is None:
            return f"{self.target_key}:{self.value}"
        return f"{self.target_key}:{self.value}:{self.ramp_per_s}"


@dataclass(slots=True)
class ScheduleStep:
    index: int
    enabled: bool = True
    name: str = ""
    wait_type: str = "elapsed_time"
    wait_source: str = ""
    operator: str = ">="
    threshold: float | bool | str | None = None
    threshold_low: float | None = None
    threshold_high: float | None = None
    duration_s: float | None = None
    hold_for_s: float = 0.0
    valid_sources: list[str] = field(default_factory=list)
    require_confirmation: bool = False
    confirmation_message: str = ""
    actions: list[StepAction] = field(default_factory=list)
    notes: str = ""


@dataclass(slots=True)
class StartupStatus:
    active: bool = False
    stage: str = "idle"
    message: str = ""


@dataclass(slots=True)
class RunStatus:
    state: str = RunState.IDLE.value
    phase: str = "idle"
    workbook_path: str = ""
    startup_sheet_name: str = ""
    plan_sheet_name: str = ""
    current_step_index: int = -1
    current_step_name: str = ""
    step_elapsed_s: float = 0.0
    hold_elapsed_s: float = 0.0
    wait_reason: str = "Idle"
    awaiting_confirmation: bool = False
    confirmation_message: str = ""
    last_transition: str = ""
    startup: StartupStatus = field(default_factory=StartupStatus)
    active_actions: list[dict[str, Any]] = field(default_factory=list)
    startup_steps: list[dict[str, Any]] = field(default_factory=list)
    plan_steps: list[dict[str, Any]] = field(default_factory=list)
    steps: list[dict[str, Any]] = field(default_factory=list)
    event_log: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
