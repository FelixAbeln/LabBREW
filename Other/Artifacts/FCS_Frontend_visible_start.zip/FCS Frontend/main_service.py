from __future__ import annotations

from fcs_app.http_api import run_http_server
from fcs_app.runtime import FcsRuntimeService
from fcs_app.signalstore_backend import SignalStoreBackend


def main() -> None:
    backend = SignalStoreBackend(host="127.0.0.1", port=8765)
    runtime = FcsRuntimeService(backend)
    runtime.start_background()
    server = run_http_server(runtime, host="127.0.0.1", port=8769)
    print("FCS runtime service listening on http://127.0.0.1:8769")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        runtime.shutdown()


if __name__ == "__main__":
    main()
