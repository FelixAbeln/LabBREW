from __future__ import annotations


class WindowRuntimeBridge:
    """Coordinates targeted GUI updates in response to explicit app intents."""

    def __init__(self, window):
        self.window = window
        self.refresh = None

    def set_refresh_coordinator(self, refresh) -> None:
        self.refresh = refresh

    def append_frame_log(self, frame, obj) -> None:
        if self.refresh is not None and obj is not None:
            self.window.brew_panel.log.appendPlainText(str(obj))

    def refresh_footer(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        self.refresh.footer.refresh()
        return True

    def refresh_table(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        self.refresh.devices.refresh_table()
        return True

    def refresh_control_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        self.refresh.control.refresh()
        return True

    def refresh_safety_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        self.refresh.safety.refresh()
        return True

    def refresh_twin_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        self.refresh.twin.refresh()
        return True

    def refresh_scheduler_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        self.refresh.scheduler.refresh()
        return True

    def refresh_relay_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        self.refresh.relays.refresh()
        return True

    def refresh_sources(self) -> None:
        self.window.source_controller.refresh_all_sources()

    def update_agitator_runtime(self) -> None:
        self.window.commands.update_agitator_runtime()

    def refresh_all(self, *, force: bool = False) -> None:
        self.refresh_footer(force=force)
        self.refresh_table(force=force)
        self.refresh_control_panel(force=force)
        self.refresh_safety_panel(force=force)
        self.refresh_twin_panel(force=force)
        self.refresh_scheduler_panel(force=force)
        self.refresh_relay_panel(force=force)

    def sync_runtime_targets(self) -> None:
        snap = self.window.queries.snapshot()
        self.window.ui_state.loading_scheduler_ui = True
        try:
            changed = self.window.control_panel.apply_scheduler_targets(
                snap.controls.temperature.setpoint,
                snap.controls.pressure.setpoint,
                snap.controls.pressure.allow_add_gas,
                snap.controls.agitator.on,
                snap.controls.agitator.duty_cycle,
            )
        finally:
            self.window.ui_state.loading_scheduler_ui = False
        if changed:
            self.window.config_controller.save_settings_to_state(validate=False)
            self.refresh_control_panel(force=True)
