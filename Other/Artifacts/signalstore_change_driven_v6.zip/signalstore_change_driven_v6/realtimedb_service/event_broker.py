
from __future__ import annotations

import queue
import threading
import uuid
from typing import Any


class EventBroker:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._subs: dict[str, tuple[queue.Queue[dict[str, Any]], set[str] | None]] = {}

    def subscribe(self, names: list[str] | None = None, max_queue: int = 1000) -> tuple[str, queue.Queue[dict[str, Any]]]:
        token = uuid.uuid4().hex
        q: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=max_queue)
        filters = set(names) if names else None
        with self._lock:
            self._subs[token] = (q, filters)
        return token, q

    def unsubscribe(self, token: str) -> None:
        with self._lock:
            self._subs.pop(token, None)

    def publish(self, event: dict[str, Any]) -> None:
        name = event.get('name')
        with self._lock:
            items = list(self._subs.items())
        stale: list[str] = []
        for token, (q, filters) in items:
            if filters is not None and name not in filters:
                continue
            try:
                q.put_nowait(event)
            except queue.Full:
                stale.append(token)
        if stale:
            with self._lock:
                for token in stale:
                    self._subs.pop(token, None)
