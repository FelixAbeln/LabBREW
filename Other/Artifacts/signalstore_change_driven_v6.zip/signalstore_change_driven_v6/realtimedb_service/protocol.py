from __future__ import annotations

import io
import struct
from typing import Any, BinaryIO

import msgpack


class ProtocolError(Exception):
    pass


_LENGTH_STRUCT = struct.Struct("!I")


def encode_message(payload: dict[str, Any]) -> bytes:
    body = msgpack.packb(payload, use_bin_type=True)
    return _LENGTH_STRUCT.pack(len(body)) + body


def decode_message_bytes(data: bytes) -> dict[str, Any]:
    try:
        obj = msgpack.unpackb(data, raw=False)
    except Exception as exc:
        raise ProtocolError(f"Invalid message payload: {exc}") from exc
    if not isinstance(obj, dict):
        raise ProtocolError("Message must be a map/object")
    return obj


def read_message(stream: BinaryIO) -> dict[str, Any] | None:
    header = stream.read(_LENGTH_STRUCT.size)
    if not header:
        return None
    if len(header) != _LENGTH_STRUCT.size:
        raise ProtocolError("Incomplete message header")
    (length,) = _LENGTH_STRUCT.unpack(header)
    body = stream.read(length)
    if len(body) != length:
        raise ProtocolError("Incomplete message body")
    return decode_message_bytes(body)


def pack_message_for_tests(payload: dict[str, Any]) -> dict[str, Any]:
    return decode_message_bytes(encode_message(payload)[_LENGTH_STRUCT.size :])
