from __future__ import annotations

import json
import tkinter as tk
from tkinter import messagebox, ttk


def open_editor(root, client, name: str, desc: dict) -> None:
    win = tk.Toplevel(root)
    win.title(f"Edit held value: {name}")
    win.geometry("500x240")
    ttk.Label(win, text="Value (JSON)").pack(anchor="w", padx=10, pady=(10, 0))
    text = tk.Text(win, height=8)
    text.pack(fill=tk.BOTH, expand=True, padx=10)
    text.insert("1.0", json.dumps(desc.get("value"), indent=2))

    def save() -> None:
        try:
            client.set_value(name, json.loads(text.get("1.0", "end").strip() or "null"))
            win.destroy()
        except Exception as exc:
            messagebox.showerror("Save failed", str(exc), parent=win)

    ttk.Button(win, text="Save", command=save).pack(anchor="e", padx=10, pady=10)
