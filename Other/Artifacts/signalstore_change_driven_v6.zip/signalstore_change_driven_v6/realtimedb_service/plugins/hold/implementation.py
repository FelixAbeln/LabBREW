from __future__ import annotations

from realtimedb_service.plugin_api import ParameterBase, PluginSpec


class HoldParameter(ParameterBase):
    plugin_type = "hold"
    display_name = "Held Value"
    description = "Passive retained value updated only by external writes or config edits."

    def scan(self, ctx) -> None:
        return


class HoldPlugin(PluginSpec):
    plugin_type = "hold"
    display_name = "Held Value"
    description = "Just keeps its last value until something changes it."

    def create(self, name: str, *, config=None, value=None, metadata=None) -> ParameterBase:
        return HoldParameter(name, config=config, value=value, metadata=metadata)


PLUGIN = HoldPlugin()
