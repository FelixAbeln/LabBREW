from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk


def open_editor(root, client, name: str, desc: dict) -> None:
    win = tk.Toplevel(root)
    win.title(f"Edit script: {name}")
    win.geometry("700x280")
    ttk.Label(win, text="Expression (use read('name'), dt, now, value)").pack(anchor="w", padx=10, pady=(10, 0))
    text = tk.Text(win, height=8)
    text.pack(fill=tk.BOTH, expand=True, padx=10)
    text.insert("1.0", str(desc.get("config", {}).get("expr", "0")))

    def save() -> None:
        try:
            client.update_config(name, expr=text.get("1.0", "end").strip())
            win.destroy()
        except Exception as exc:
            messagebox.showerror("Save failed", str(exc), parent=win)

    ttk.Button(win, text="Save", command=save).pack(anchor="e", padx=10, pady=10)
