from __future__ import annotations

from realtimedb_service.plugin_api import ParameterBase, PluginSpec


class ScriptParameter(ParameterBase):
    plugin_type = "script"
    display_name = "Python Expression"
    description = "Evaluates a Python expression every scan using the store and dt."

    def on_added(self, store) -> None:
        self.config.setdefault("expr", "0")
        if self.value is None:
            self.value = 0

    def scan(self, ctx) -> None:
        expr = str(self.config.get("expr", "0"))
        def read(name, default=None):
            return ctx.store.get_value(name, default)
        safe_globals = {"__builtins__": {"min": min, "max": max, "abs": abs, "round": round}}
        safe_locals = {"read": read, "dt": ctx.dt, "now": ctx.now, "value": self.value}
        self.value = eval(expr, safe_globals, safe_locals)


class ScriptPlugin(PluginSpec):
    plugin_type = "script"
    display_name = "Python Expression"
    description = "Runs a small expression each scan and stores the result as the parameter value."

    def create(self, name: str, *, config=None, value=None, metadata=None) -> ParameterBase:
        return ScriptParameter(name, config=config, value=value, metadata=metadata)

    def default_config(self) -> dict:
        return {"expr": "0"}

    def schema(self) -> dict:
        return {"expr": "python-expression"}


PLUGIN = ScriptPlugin()
