from __future__ import annotations

from realtimedb_service.plugin_api import ParameterBase, PluginSpec


class PIDParameter(ParameterBase):
    plugin_type = "pid"
    display_name = "PID Controller"
    description = "Computes an output every scan from PV and SP source parameters."

    def on_added(self, store) -> None:
        self.config.setdefault("pv", "")
        self.config.setdefault("sp", "")
        self.config.setdefault("kp", 1.0)
        self.config.setdefault("ki", 0.0)
        self.config.setdefault("kd", 0.0)
        self.config.setdefault("out_min", 0.0)
        self.config.setdefault("out_max", 100.0)
        self.state.setdefault("integral", 0.0)
        self.state.setdefault("prev_error", 0.0)
        if self.value is None:
            self.value = 0.0

    def scan(self, ctx) -> None:
        pv = float(ctx.store.get_value(self.config.get("pv"), 0.0) or 0.0)
        sp = float(ctx.store.get_value(self.config.get("sp"), 0.0) or 0.0)
        error = sp - pv
        self.state["integral"] += error * ctx.dt
        derivative = 0.0 if ctx.dt <= 0 else (error - self.state.get("prev_error", 0.0)) / ctx.dt
        out = (
            float(self.config.get("kp", 1.0)) * error
            + float(self.config.get("ki", 0.0)) * self.state["integral"]
            + float(self.config.get("kd", 0.0)) * derivative
        )
        out = max(float(self.config.get("out_min", 0.0)), min(float(self.config.get("out_max", 100.0)), out))
        self.value = out
        self.state["prev_error"] = error
        self.state["pv"] = pv
        self.state["sp"] = sp
        self.state["error"] = error


class PIDPlugin(PluginSpec):
    plugin_type = "pid"
    display_name = "PID Controller"
    description = "Active parameter that runs every scan and computes a control output."

    def create(self, name: str, *, config=None, value=None, metadata=None) -> ParameterBase:
        return PIDParameter(name, config=config, value=value, metadata=metadata)

    def default_config(self) -> dict:
        return {"pv": "", "sp": "", "kp": 1.0, "ki": 0.0, "kd": 0.0, "out_min": 0.0, "out_max": 100.0}

    def schema(self) -> dict:
        return {
            "pv": "str",
            "sp": "str",
            "kp": "float",
            "ki": "float",
            "kd": "float",
            "out_min": "float",
            "out_max": "float",
        }


PLUGIN = PIDPlugin()
