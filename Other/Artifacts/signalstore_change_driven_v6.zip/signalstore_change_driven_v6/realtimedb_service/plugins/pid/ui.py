from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk


def open_editor(root, client, name: str, desc: dict) -> None:
    win = tk.Toplevel(root)
    win.title(f"Edit PID: {name}")
    win.geometry("420x360")
    cfg = dict(desc.get("config", {}))
    fields = {}
    for key in ["pv", "sp", "kp", "ki", "kd", "out_min", "out_max"]:
        ttk.Label(win, text=key).pack(anchor="w", padx=10, pady=(8 if key in {"pv","sp"} else 4, 0))
        var = tk.StringVar(value=str(cfg.get(key, "")))
        fields[key] = var
        ttk.Entry(win, textvariable=var).pack(fill=tk.X, padx=10)

    def save() -> None:
        try:
            client.update_config(
                name,
                pv=fields["pv"].get().strip(),
                sp=fields["sp"].get().strip(),
                kp=float(fields["kp"].get()),
                ki=float(fields["ki"].get()),
                kd=float(fields["kd"].get()),
                out_min=float(fields["out_min"].get()),
                out_max=float(fields["out_max"].get()),
            )
            win.destroy()
        except Exception as exc:
            messagebox.showerror("Save failed", str(exc), parent=win)

    ttk.Button(win, text="Save", command=save).pack(anchor="e", padx=10, pady=10)
