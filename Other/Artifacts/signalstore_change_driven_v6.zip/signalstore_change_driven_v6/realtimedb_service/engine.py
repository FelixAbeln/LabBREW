from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any

from .runtime import GraphSnapshot, build_graph_snapshot
from .store import ParameterStore


@dataclass(slots=True)
class ScanContext:
    now: float
    dt: float
    cycle_count: int
    store: ParameterStore


class ScanEngine:
    def __init__(self, period_s: float, store: ParameterStore | None = None) -> None:
        self.period_s = period_s
        self.store = store or ParameterStore()
        self._running = False
        self._thread: threading.Thread | None = None
        self._cycle_count = 0
        self._last_scan_started_at: float | None = None
        self._last_scan_duration_s = 0.0
        self._graph_lock = threading.RLock()
        self._graph = GraphSnapshot(
            store_revision=-1,
            scan_order=[],
            dependencies={},
            reverse_dependencies={},
            write_targets={},
            scan_modes={},
            active_parameters=[],
            always_parameters=[],
            warnings=[],
        )
        self._full_rescan_needed = True

    def _rebuild_graph_if_needed(self) -> bool:
        rev = self.store.revision()
        with self._graph_lock:
            if rev == self._graph.store_revision:
                return False
            self._graph = build_graph_snapshot(self.store.items_for_scan(), rev)
            self._full_rescan_needed = True
            return True

    def get_scan_order(self) -> list[str]:
        self._rebuild_graph_if_needed()
        with self._graph_lock:
            return list(self._graph.scan_order)

    def graph_info(self) -> dict[str, Any]:
        self._rebuild_graph_if_needed()
        with self._graph_lock:
            return {
                "store_revision": self._graph.store_revision,
                "scan_order": list(self._graph.scan_order),
                "dependencies": {k: list(v) for k, v in self._graph.dependencies.items()},
                "reverse_dependencies": {k: list(v) for k, v in self._graph.reverse_dependencies.items()},
                "write_targets": {k: list(v) for k, v in self._graph.write_targets.items()},
                "scan_modes": dict(self._graph.scan_modes),
                "active_parameters": list(self._graph.active_parameters),
                "always_parameters": list(self._graph.always_parameters),
                "warnings": list(self._graph.warnings),
            }

    def _collect_run_set(self) -> set[str]:
        self._rebuild_graph_if_needed()
        changed = set(self.store.drain_changed_names())
        with self._graph_lock:
            graph = self._graph
            full_rescan = self._full_rescan_needed or self._cycle_count == 0
            if full_rescan:
                self._full_rescan_needed = False

        run_set: set[str] = set(graph.always_parameters)
        if full_rescan:
            run_set.update(graph.active_parameters)
            return run_set

        queue_names = list(changed)
        seen = set(changed)
        while queue_names:
            source = queue_names.pop(0)
            for dependent in graph.reverse_dependencies.get(source, []):
                if dependent in seen:
                    continue
                seen.add(dependent)
                queue_names.append(dependent)
                if graph.scan_modes.get(dependent) != "passive":
                    run_set.add(dependent)

        if any(name in graph.always_parameters for name in changed):
            run_set.update(graph.always_parameters)

        return run_set

    def scan_once(self, dt: float) -> None:
        started = time.perf_counter()
        now = time.time()
        self._last_scan_started_at = now
        ctx = ScanContext(now=now, dt=dt, cycle_count=self._cycle_count, store=self.store)

        run_set = self._collect_run_set()
        if run_set:
            with self._graph_lock:
                scan_order = list(self._graph.scan_order)
                reverse_dependencies = {k: list(v) for k, v in self._graph.reverse_dependencies.items()}
                scan_modes = dict(self._graph.scan_modes)

            for name in scan_order:
                if name not in run_set:
                    continue
                try:
                    param = self.store.get_param(name)
                except KeyError:
                    continue
                old_value = param.get_value()
                try:
                    param.scan(ctx)
                except Exception as exc:
                    param.state["last_error"] = str(exc)
                new_value = param.get_value()
                changed = self.store.publish_scan_value_if_changed(param.name, old_value, new_value)
                self.store.publish_scan_state(param.name, dict(param.state))
                if changed:
                    for dependent in reverse_dependencies.get(param.name, []):
                        if scan_modes.get(dependent) != "passive":
                            run_set.add(dependent)

        self._cycle_count += 1
        self._last_scan_duration_s = time.perf_counter() - started

    def _run_loop(self) -> None:
        last = time.perf_counter()
        while self._running:
            start = time.perf_counter()
            dt = start - last
            last = start
            self.scan_once(dt)
            elapsed = time.perf_counter() - start
            time.sleep(max(0.0, self.period_s - elapsed))

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name="ParameterScanEngine", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    def stats(self) -> dict[str, Any]:
        graph = self.graph_info()
        return {
            "running": self._running,
            "period_s": self.period_s,
            "cycle_count": self._cycle_count,
            "last_scan_started_at": self._last_scan_started_at,
            "last_scan_duration_s": self._last_scan_duration_s,
            "parameter_count": len(self.store.list_names()),
            "store_revision": graph["store_revision"],
            "graph_warning_count": len(graph["warnings"]),
            "scan_order": graph["scan_order"],
            "active_parameters": graph["active_parameters"],
            "always_parameters": graph["always_parameters"],
        }
