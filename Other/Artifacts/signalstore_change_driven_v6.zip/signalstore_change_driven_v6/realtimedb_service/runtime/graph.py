from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..plugin_api import ParameterBase


@dataclass(slots=True)
class GraphSnapshot:
    store_revision: int
    scan_order: list[str]
    dependencies: dict[str, list[str]]
    reverse_dependencies: dict[str, list[str]]
    write_targets: dict[str, list[str]]
    scan_modes: dict[str, str]
    active_parameters: list[str]
    always_parameters: list[str]
    warnings: list[str] = field(default_factory=list)


VALID_SCAN_MODES = {"passive", "on_change", "always"}


def build_graph_snapshot(params: list["ParameterBase"], store_revision: int) -> GraphSnapshot:
    names = {p.name for p in params}
    dependencies: dict[str, list[str]] = {}
    downstream: dict[str, set[str]] = {name: set() for name in names}
    write_targets: dict[str, list[str]] = {}
    scan_modes: dict[str, str] = {}
    warnings: list[str] = []
    indegree: dict[str, int] = {name: 0 for name in names}
    writers: dict[str, list[str]] = defaultdict(list)

    for param in params:
        name = param.name
        mode = str(param.scan_mode()).strip().lower()
        if mode not in VALID_SCAN_MODES:
            warnings.append(f"{name}: invalid scan mode '{mode}', using 'on_change'")
            mode = "on_change"
        scan_modes[name] = mode

        deps_for_param: list[str] = []
        seen_deps: set[str] = set()
        for dep in param.dependencies():
            dep_name = str(dep).strip()
            if not dep_name or dep_name == name or dep_name in seen_deps:
                continue
            seen_deps.add(dep_name)
            deps_for_param.append(dep_name)
            if dep_name in names:
                downstream[dep_name].add(name)
                indegree[name] += 1
            else:
                warnings.append(f"{name}: dependency '{dep_name}' does not exist")
        dependencies[name] = deps_for_param

        targets_for_param: list[str] = []
        seen_targets: set[str] = set()
        for target in param.write_targets():
            target_name = str(target).strip()
            if not target_name or target_name == name or target_name in seen_targets:
                continue
            seen_targets.add(target_name)
            targets_for_param.append(target_name)
            writers[target_name].append(name)
        write_targets[name] = targets_for_param

    for target, source_names in sorted(writers.items()):
        if len(source_names) > 1:
            warnings.append(f"multiple writers for '{target}': {', '.join(sorted(source_names))}")

    indegree_work = dict(indegree)
    q = deque(sorted([name for name, deg in indegree_work.items() if deg == 0]))
    ordered: list[str] = []
    while q:
        name = q.popleft()
        ordered.append(name)
        for child in sorted(downstream[name]):
            indegree_work[child] -= 1
            if indegree_work[child] == 0:
                q.append(child)

    if len(ordered) != len(names):
        cyclic = sorted(name for name, deg in indegree_work.items() if deg > 0)
        warnings.append("dependency cycle detected; falling back to stable order for: " + ", ".join(cyclic))
        remaining = [p.name for p in params if p.name not in ordered]
        ordered.extend(remaining)

    active_parameters = sorted([name for name, mode in scan_modes.items() if mode != "passive"])
    always_parameters = sorted([name for name, mode in scan_modes.items() if mode == "always"])

    return GraphSnapshot(
        store_revision=store_revision,
        scan_order=ordered,
        dependencies={k: list(v) for k, v in dependencies.items()},
        reverse_dependencies={k: sorted(v) for k, v in downstream.items()},
        write_targets={k: list(v) for k, v in write_targets.items()},
        scan_modes=dict(scan_modes),
        active_parameters=active_parameters,
        always_parameters=always_parameters,
        warnings=warnings,
    )
