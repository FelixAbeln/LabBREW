
from __future__ import annotations

from pathlib import Path

from .engine import ScanEngine
from .loader import PluginRegistry, autodiscover_plugins
from .server import SignalTCPServer


def build_service(host: str = '127.0.0.1', port: int = 8765, period_s: float = 0.05, plugin_root: str = './plugins'):
    registry = PluginRegistry()
    loaded = autodiscover_plugins(plugin_root, registry)
    engine = ScanEngine(period_s=period_s)
    server = SignalTCPServer(host, port, engine, registry)
    return engine, server, registry, loaded
