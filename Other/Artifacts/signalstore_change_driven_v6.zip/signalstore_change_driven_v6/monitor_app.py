from __future__ import annotations

import argparse
import json
import queue
import threading
import tkinter as tk
from tkinter import ttk


from realtimedb_service.client import SignalClient


class MonitorApp:
    def __init__(self, root: tk.Tk, client: SignalClient) -> None:
        self.root = root
        self.client = client
        self.events: queue.Queue = queue.Queue()
        self.rows: dict[str, dict] = {}
        self.stop_flag = threading.Event()

        root.title("RealtimeDB Monitor")
        root.geometry("1400x700")

        top = ttk.Frame(root, padding=8)
        top.pack(fill=tk.X)

        self.status_var = tk.StringVar(value="Connecting...")
        ttk.Label(top, textvariable=self.status_var).pack(side=tk.LEFT)

        cols = ("name", "plugin_type", "value", "config", "state", "metadata")
        self.tree = ttk.Treeview(root, columns=cols, show="headings")
        for col, width in [
            ("name", 220),
            ("plugin_type", 120),
            ("value", 180),
            ("config", 280),
            ("state", 280),
            ("metadata", 220),
        ]:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        self.load_initial()
        self.start_subscription_thread()
        self.root.after(100, self.process_events)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def load_initial(self) -> None:
        data = self.client.describe()
        self.rows = dict(data)
        for name, desc in sorted(self.rows.items()):
            self.upsert_row(name, desc)
        self.status_var.set(f"Connected | parameters={len(self.rows)}")

    def upsert_row(self, name: str, desc: dict) -> None:
        values = (
            name,
            desc.get("plugin_type", ""),
            repr(desc.get("value")),
            json.dumps(desc.get("config", {}), sort_keys=True),
            json.dumps(desc.get("state", {}), sort_keys=True),
            json.dumps(desc.get("metadata", {}), sort_keys=True),
        )
        if self.tree.exists(name):
            self.tree.item(name, values=values)
        else:
            self.tree.insert("", "end", iid=name, values=values)

    def remove_row(self, name: str) -> None:
        if self.tree.exists(name):
            self.tree.delete(name)

    def start_subscription_thread(self) -> None:
        def worker() -> None:
            try:
                with self.client.subscribe(send_initial=False) as sub:
                    for event in sub:
                        if self.stop_flag.is_set():
                            break
                        self.events.put(event)
            except Exception as exc:
                self.events.put({"event": "monitor_error", "error": str(exc)})

        threading.Thread(target=worker, daemon=True).start()

    def process_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                et = event.get("event")

                if et == "parameter_added":
                    name = event["name"]
                    self.rows[name] = {
                        "plugin_type": event.get("plugin_type"),
                        "value": event.get("value"),
                        "config": event.get("config", {}),
                        "state": event.get("state", {}),
                        "metadata": event.get("metadata", {}),
                    }
                    self.upsert_row(name, self.rows[name])

                elif et == "parameter_removed":
                    name = event["name"]
                    self.rows.pop(name, None)
                    self.remove_row(name)

                elif et == "parameter_snapshot":
                    name = event["name"]
                    self.rows[name] = {
                        "plugin_type": event.get("plugin_type"),
                        "value": event.get("value"),
                        "config": event.get("config", {}),
                        "state": event.get("state", {}),
                        "metadata": event.get("metadata", {}),
                    }
                    self.upsert_row(name, self.rows[name])

                elif et == "value_changed":
                    name = event["name"]
                    if name in self.rows:
                        self.rows[name]["value"] = event.get("value")
                        self.upsert_row(name, self.rows[name])

                elif et == "config_changed":
                    name = event["name"]
                    if name in self.rows:
                        self.rows[name]["config"] = event.get("config", {})
                        self.upsert_row(name, self.rows[name])

                elif et == "metadata_changed":
                    name = event["name"]
                    if name in self.rows:
                        self.rows[name]["metadata"] = event.get("metadata", {})
                        self.upsert_row(name, self.rows[name])

                elif et == "state_changed":
                    name = event["name"]
                    if name in self.rows:
                        self.rows[name]["state"] = event.get("state", {})
                        self.upsert_row(name, self.rows[name])

                elif et == "monitor_error":
                    self.status_var.set(f"Disconnected: {event.get('error')}")

            # unreachable
        except queue.Empty:
            self.status_var.set(f"Connected | parameters={len(self.rows)}")

        self.root.after(100, self.process_events)

    def on_close(self) -> None:
        self.stop_flag.set()
        self.root.destroy()


def main() -> None:
    parser = argparse.ArgumentParser(description="RealtimeDB live monitor")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    root = tk.Tk()
    client = SignalClient(args.host, args.port, timeout=5.0)
    MonitorApp(root, client)
    root.mainloop()


if __name__ == "__main__":
    main()