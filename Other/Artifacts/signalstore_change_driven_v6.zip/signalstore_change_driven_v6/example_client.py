
from realtimedb_service.client import SignalClient

c = SignalClient()
print('ping:', c.ping())
print('plugins:', c.list_plugin_types())

try:
    c.create_parameter('tank.level', 'hold', value=10.0)
except Exception:
    pass
try:
    c.create_parameter('tank.sp', 'hold', value=20.0)
except Exception:
    pass
try:
    c.create_parameter('tank.out', 'hold', value=0.0)
except Exception:
    pass
try:
    c.create_parameter('tank.pid', 'pid', config={
        'pv': 'tank.level',
        'sp': 'tank.sp',
        'out_param': 'tank.out',
        'kp': 2.0,
        'ki': 0.1,
        'kd': 0.0,
        'out_min': 0.0,
        'out_max': 100.0,
    })
except Exception:
    pass

with c.subscribe() as events:
    for event in events:
        print(event)
