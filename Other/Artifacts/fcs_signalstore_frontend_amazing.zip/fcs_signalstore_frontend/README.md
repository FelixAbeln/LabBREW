# FCS frontend/service scaffold for SignalStore

This is a Python starter project for the architecture you described:

- **SignalStore / ParameterDB stays the backend of record**
- a **headless runtime service** loads an Excel schedule and runs it
- the runtime can perform a **startup routine**
- the runtime can **reset the digital twin**
- the runtime watches **criteria for advancing to the next step**
- a **PySide6 UI** attaches to the service for launch, status, and control
- the UI is **not required** for the sequence to keep running
- the UI can now **export a schedule template or a test-routine workbook** directly

## Layout

- `fcs_app/models.py` – runtime DTOs and enums
- `fcs_app/excel_loader.py` – workbook -> normalized schedule plan
- `fcs_app/signalstore_backend.py` – adapter around ParameterDB / SignalStore
- `fcs_app/runtime.py` – headless scheduler engine + startup sequence
- `fcs_app/http_api.py` – lightweight JSON API over `ThreadingHTTPServer`
- `fcs_app/ui.py` – PySide6 operator UI client
- `fcs_app/template_exporter.py` – frontend-side Excel template exporter
- `main_service.py` – start the headless runtime service
- `main_ui.py` – start the UI client

## Important integration points

The scaffold does **not** hard-code your real SignalStore names.
Instead, edit `SignalStoreMapping` in `main_service.py` or load it from a file.

Typical mappings you will want to wire:

- controller setpoint targets
- regulator enable/allow-add-gas flags
- agitator command target
- relay connection state / command
- CAN connection state / command
- PSU power state / command
- digital twin reset parameter
- digital twin status parameter

## Running

### 1. Start the headless service

```bash
python main_service.py
```

### 2. Start the UI in another process

```bash
python main_ui.py
```

By default the UI talks to `http://127.0.0.1:8769`.

## Template export

The frontend can export two workbook styles:

- **Blank template** – just the schedule structure and reference sheets
- **Test routine template** – includes a practical smoke-test sequence for startup, ramps, signal-based advance, validity gating, and operator confirmation

The exported workbook includes:

- `Schedule`
- `Wait Types`
- `Operators`
- `Signal Key Guide`
- `How To Use`
- `Test Routine Notes` (test-routine mode only)

The `Schedule` sheet keeps the format aligned with your current scheduler:

- `enabled`
- `step_name`
- `controller_actions`
- `temp_sp`
- `pressure_sp`
- `allow_add_gas`
- `agitator`
- `wait_type`
- `wait_source`
- `operator`
- `threshold`
- `threshold_low`
- `threshold_high`
- `time_s`
- `valid_sources`
- `confirmation_message`

`controller_actions` accepts a semicolon-separated syntax such as:

```text
temperature:20:0.05;pressure:0.80:0.01;pressure.allow_add_gas:false;agitator:40
```

## Notes

This is intentionally a **clean scaffold** rather than a drop-in final implementation.
The service/runtime split is the important part, and the frontend now helps operators generate known-good test schedules without depending on the backend.
