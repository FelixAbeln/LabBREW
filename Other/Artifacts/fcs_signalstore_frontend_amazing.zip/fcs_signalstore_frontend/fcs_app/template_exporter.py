from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation


WAIT_TYPES: list[tuple[str, str]] = [
    ("elapsed_time", "Advance after time_s seconds elapse."),
    ("signal", "Advance when wait_source satisfies operator/threshold and stays true for time_s seconds."),
    ("all_valid", "Advance when every valid_sources signal is valid/true for time_s seconds."),
]

OPERATORS: list[tuple[str, str]] = [
    (">=", "Signal is greater than or equal to threshold."),
    ("<=", "Signal is less than or equal to threshold."),
    (">", "Signal is greater than threshold."),
    ("<", "Signal is less than threshold."),
    ("==", "Signal equals threshold."),
    ("!=", "Signal does not equal threshold."),
    ("in_range", "Signal is between threshold_low and threshold_high."),
    ("out_of_range", "Signal is outside threshold_low and threshold_high."),
    ("valid_for", "Used with all_valid to require validity for time_s seconds."),
]

SCHEDULE_HEADERS = [
    "enabled",
    "step_name",
    "controller_actions",
    "temp_sp",
    "pressure_sp",
    "allow_add_gas",
    "agitator",
    "wait_type",
    "wait_source",
    "operator",
    "threshold",
    "threshold_low",
    "threshold_high",
    "time_s",
    "valid_sources",
    "confirmation_message",
]


@dataclass(slots=True)
class TemplateExportOptions:
    include_examples: bool = True
    include_test_routine: bool = True
    workbook_title: str = "FCS Schedule Template"
    discovered_signals: list[tuple[str, str, str]] | None = None


class ScheduleTemplateExporter:
    def export(self, path: str | Path, options: TemplateExportOptions | None = None) -> Path:
        options = options or TemplateExportOptions()
        target = Path(path)
        if target.suffix.lower() != ".xlsx":
            target = target.with_suffix(".xlsx")
        wb = Workbook()
        self.populate_workbook(wb, options)
        wb.save(target)
        return target

    def populate_workbook(self, wb: Workbook, options: TemplateExportOptions) -> None:
        ws = wb.active
        ws.title = "Schedule"
        ws.append(SCHEDULE_HEADERS)
        if options.include_examples:
            for row in self._example_rows(include_test_routine=options.include_test_routine):
                ws.append(row)
        self._style_schedule_sheet(ws)
        self._add_validations(ws)

        wait_sheet = wb.create_sheet("Wait Types")
        wait_sheet.append(["Wait type", "Meaning"])
        for row in WAIT_TYPES:
            wait_sheet.append(list(row))
        self._style_reference_sheet(wait_sheet, {"A": 18, "B": 92})

        op_sheet = wb.create_sheet("Operators")
        op_sheet.append(["Operator", "Meaning"])
        for row in OPERATORS:
            op_sheet.append(list(row))
        self._style_reference_sheet(op_sheet, {"A": 18, "B": 92})

        signal_sheet = wb.create_sheet("Signal Key Guide")
        signal_sheet.append(["Signal key", "Friendly name", "Unit"])
        discovered = options.discovered_signals or self._default_signal_rows()
        for row in discovered:
            signal_sheet.append(list(row))
        self._style_reference_sheet(signal_sheet, {"A": 34, "B": 30, "C": 12})

        howto = wb.create_sheet("How To Use")
        howto.append(["What to edit", "Details"])
        help_rows = [
            ("Schedule sheet", "Keep row 1 as the header row. Add one recipe step per row starting on row 2."),
            ("controller_actions", "Semicolon-separated controller:value:ramp entries. Examples: temperature:20:0.05; pressure:0.8:0.01; pressure.allow_add_gas:false; agitator:40"),
            ("temp_sp / pressure_sp", "Optional convenience columns. Use a number for an immediate target or target:rate for a ramp."),
            ("agitator", "Leave blank to keep current state. Use false/off to stop, true/on to run, or a duty value like 40."),
            ("wait_type", "Choose elapsed_time, signal, or all_valid from the dropdown."),
            ("wait_source", "For signal waits, use a signal key from the Signal Key Guide sheet."),
            ("operator", "For signal waits use >=, <=, >, <, ==, !=, in_range, or out_of_range. For all_valid use valid_for."),
            ("threshold / low / high", "Use threshold for single-value comparisons. Use threshold_low and threshold_high for range checks."),
            ("time_s", "For elapsed_time this is the step duration. For signal/all_valid it becomes the hold time before advancing."),
            ("valid_sources", "Comma-separated signals that must be valid/healthy before advancing."),
            ("confirmation_message", "When filled, the service waits for operator confirmation before moving on."),
            ("Test routine", "The example rows are intentionally safe and simple so you can start with a smoke test and adapt it."),
        ]
        for row in help_rows:
            howto.append(list(row))
        self._style_reference_sheet(howto, {"A": 24, "B": 100})

        if options.include_test_routine:
            tests = wb.create_sheet("Test Routine Notes")
            tests.append(["Check", "Goal", "How it maps to the schedule"])
            rows = [
                ("Startup sequence", "Verify relay/CAN/PSU/twin reset orchestration before the first control step.", "Configure startup from the UI and use a short settle delay."),
                ("Setpoint jump", "Verify a direct setpoint write reaches SignalStore.", "Step 1 writes a temperature setpoint without a ramp."),
                ("Ramp behavior", "Verify the runtime ramps a setpoint instead of jumping.", "Step 2 uses pressure:target:ramp syntax."),
                ("Signal-based advance", "Verify hold timing after a measured signal crosses threshold.", "Step 3 waits on sensor:pressure:1:1 >= 0.55 for 10 seconds."),
                ("Validity gating", "Verify bad/invalid signals block progression.", "Step 4 uses all_valid with valid_sources."),
                ("Operator gate", "Verify the UI can resume a waiting sequence.", "Final step uses confirmation_message."),
            ]
            for row in rows:
                tests.append(list(row))
            self._style_reference_sheet(tests, {"A": 24, "B": 36, "C": 80})

    def _example_rows(self, include_test_routine: bool) -> list[list[object]]:
        if not include_test_routine:
            return [
                [1, "Example hold", "temperature:20:0.05;agitator:35", "20:0.05", 0.30, "", "35", "elapsed_time", "", ">=", "", "", "", 300, "", ""],
            ]
        valid_combo = "sensor:temperature:1:1,sensor:pressure:1:1,twin:model_pressure"
        return [
            [1, "Baseline temperature", "temperature:18", 18.0, "", "", "", "elapsed_time", "", ">=", "", "", "", 20, "", ""],
            [1, "Pressure ramp test", "temperature:18;pressure:0.60:0.01;pressure.allow_add_gas:true;agitator:30", 18.0, "0.60:0.01", 1, 30, "elapsed_time", "", ">=", "", "", "", 30, "sensor:pressure:1:1", ""],
            [1, "Wait for measured pressure", "temperature:18;pressure:0.60;agitator:30", 18.0, 0.60, "", 30, "signal", "sensor:pressure:1:1", ">=", 0.55, "", "", 10, "sensor:pressure:1:1", ""],
            [1, "All signals valid", "temperature:18;pressure:0.55;agitator:false", 18.0, 0.55, 0, "false", "all_valid", "", "valid_for", "", "", "", 8, valid_combo, ""],
            [1, "Operator inspection gate", "temperature:16:0.02;pressure:0.50:0.01", "16:0.02", "0.50:0.01", "", "", "elapsed_time", "", ">=", "", "", "", 15, "", "Confirm vents, hoses, and trend stability before finish"],
        ]

    def _style_schedule_sheet(self, ws) -> None:
        self._style_header_row(ws)
        widths = {
            "A": 10, "B": 28, "C": 52, "D": 14, "E": 14, "F": 14, "G": 12,
            "H": 16, "I": 34, "J": 14, "K": 12, "L": 14, "M": 14, "N": 12, "O": 44, "P": 44,
        }
        for col, width in widths.items():
            ws.column_dimensions[col].width = width
        ws.freeze_panes = "A2"
        ws.sheet_view.showGridLines = True
        for row_idx in range(2, ws.max_row + 1):
            fill = PatternFill("solid", fgColor="F8FBFF" if row_idx % 2 == 0 else "EEF5FC")
            for cell in ws[row_idx]:
                cell.fill = fill
                cell.alignment = Alignment(vertical="center", wrap_text=True)
        for cell in ws["A"]:
            if cell.row > 1:
                cell.alignment = Alignment(horizontal="center")

    def _style_reference_sheet(self, ws, widths: dict[str, float]) -> None:
        self._style_header_row(ws)
        for col, width in widths.items():
            ws.column_dimensions[col].width = width
        ws.freeze_panes = "A2"
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)

    def _style_header_row(self, ws) -> None:
        fill = PatternFill("solid", fgColor="1F4E78")
        font = Font(color="FFFFFF", bold=True)
        border = Border(bottom=Side(style="thin", color="D9E2F3"))
        for cell in ws[1]:
            cell.fill = fill
            cell.font = font
            cell.border = border
            cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 22

    def _add_validations(self, ws) -> None:
        op_col = get_column_letter(SCHEDULE_HEADERS.index("operator") + 1)
        wait_col = get_column_letter(SCHEDULE_HEADERS.index("wait_type") + 1)
        bool_col = get_column_letter(SCHEDULE_HEADERS.index("allow_add_gas") + 1)
        wait_validation = DataValidation(type="list", formula1=f"='Wait Types'!$A$2:$A${len(WAIT_TYPES)+1}", allow_blank=True)
        op_validation = DataValidation(type="list", formula1=f"='Operators'!$A$2:$A${len(OPERATORS)+1}", allow_blank=True)
        bool_validation = DataValidation(type="list", formula1='"1,0,true,false,yes,no,on,off"', allow_blank=True)
        ws.add_data_validation(wait_validation)
        ws.add_data_validation(op_validation)
        ws.add_data_validation(bool_validation)
        wait_validation.add(f"{wait_col}2:{wait_col}300")
        op_validation.add(f"{op_col}2:{op_col}300")
        bool_validation.add(f"{bool_col}2:{bool_col}300")

    def _default_signal_rows(self) -> list[tuple[str, str, str]]:
        return [
            ("sensor:temperature:1:1", "Vessel temperature", "°C"),
            ("sensor:pressure:1:1", "Vessel pressure", "bar"),
            ("twin:model_pressure", "Digital twin pressure", "bar"),
            ("status:temperature:valid", "Temperature validity", "bool"),
            ("status:pressure:valid", "Pressure validity", "bool"),
        ]
