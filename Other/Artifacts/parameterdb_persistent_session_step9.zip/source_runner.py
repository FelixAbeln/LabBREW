from signalstore_sources.runner import main

if __name__ == '__main__':
    main()
