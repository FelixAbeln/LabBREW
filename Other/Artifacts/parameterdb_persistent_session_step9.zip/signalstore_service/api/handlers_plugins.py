from __future__ import annotations

from pathlib import Path
from typing import Any

from .validation import validate_empty_ok, validate_get_plugin_ui, validate_load_plugin_folder


def register_plugin_handlers(server: Any) -> None:
    d = server.dispatcher
    d.register("list_plugin_types", server.api_list_plugin_types)
    d.register("list_plugin_ui", server.api_list_plugin_ui)
    d.register("get_plugin_ui", server.api_get_plugin_ui)
    d.register("load_plugin_folder", server.api_load_plugin_folder)
