from signalstore_core.plugin_ui.spec import *
