# realtime parameter service

This package is a small scan-cycle data system.

The key idea is:
- every named item in the database is a **parameter object**
- each parameter object has a plugin type
- some plugin types are passive values
- some plugin types do work every scan cycle
- each plugin can ship its own editor UI in `ui.py`

## plugin folder structure

Each plugin lives in its own folder:

```text
plugins/
  hold/
    implementation.py
    ui.py
  pid/
    implementation.py
    ui.py
```

`implementation.py` must expose:

```python
PLUGIN = SomePluginSpec()
```

`ui.py` may expose:

```python
def open_editor(root, client, name, desc):
    ...
```

## built-in plugins

- `hold` - passive retained value
- `pid` - active scan-cycle PID controller
- `script` - active Python expression

## run

```bash
python -m pip install -e .
mkdir -p ./plugins
cp -r realtimedb_service/plugins/* ./plugins/
realtimedb-service --host 127.0.0.1 --port 8765 --period 0.05 --plugin-root ./plugins
```

## monitor

```bash
realtimedb-monitor --host 127.0.0.1 --port 8765 --plugin-root ./plugins
```

## client example

```python
from realtimedb_service.client import SignalClient

c = SignalClient()
c.create_parameter("tank.level", "hold", value=12.5)
c.create_parameter("tank.sp", "hold", value=20.0)
c.create_parameter(
    "tank.pid",
    "pid",
    config={"pv": "tank.level", "sp": "tank.sp", "kp": 2.0, "ki": 0.5, "kd": 0.0, "out_min": 0.0, "out_max": 100.0},
)
print(c.describe())
```

## notes

The protocol is MessagePack over TCP with a length prefix.

For plugin-specific editor UIs, the monitor app needs access to the same plugin folders so it can import each plugin's `ui.py`.


## Package layout

- `signalstore_core`: shared protocol, client, and plugin-UI helpers
- `signalstore_service`: backend runtime, loader, engine, and server
- `signalstore_monitor`: monitor/editor UI
- `realtimedb_service`: compatibility imports for older code and plugins
