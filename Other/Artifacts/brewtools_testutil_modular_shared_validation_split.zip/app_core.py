from __future__ import annotations

import signal
import time
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QCoreApplication, QTimer, Signal

from application.config_models import ApplicationConfigModel
from application.config_validation import validate_application_config
from application.normalization import normalize_control_source_key
from application.events import ApplicationEvents
from settings import AppSettings, SettingsManager
from state import SafetyRule, SchedulerStep, StateStore
from services.can_service import CANService
from services.control_service import DeadbandControlService
from services.digital_twin_service import DigitalTwinService
from services.psu_service import PSUService
from services.relay_service import RelayService
from services.runtime_service import AppRuntimeService
from services.app_command_service import AppCommandService
from services.app_query_service import AppQueryService
from services.safety_service import SafetyService
from services.scheduler_service import SchedulerService
from services.scheduler_template_service import SchedulerTemplateService
from services.settings_mapper_service import SettingsMapperService




class AppCore(QObject):
    status = Signal(str)
    cycle_completed = Signal()
    command_failed = Signal(str, str)
    frame_decoded = Signal(object, object)
    can_connection_changed = Signal(bool)

    def __init__(
        self,
        *,
        settings_path: str | Path | None = None,
        parent: Optional[QObject] = None,
    ) -> None:
        super().__init__(parent)
        self.events = ApplicationEvents(self)
        self.base_dir = Path(__file__).resolve().parent
        self.settings_path = Path(settings_path) if settings_path else (self.base_dir / 'brewtools_can_settings.json')
        self.state_store = StateStore()
        self.settings_manager = SettingsManager(self.settings_path)
        self.settings = self.settings_manager.load()

        self.can_service = CANService(self)
        self.psu_service = PSUService()
        self.control_service = DeadbandControlService()
        self.safety_service = SafetyService()
        self.digital_twin_service = DigitalTwinService()
        self.relay_service = RelayService()
        self.scheduler_service = SchedulerService()

        self.settings_mapper = SettingsMapperService()

        self.runtime_service = AppRuntimeService(
            state_store=self.state_store,
            can_service=self.can_service,
            psu_service=self.psu_service,
            control_service=self.control_service,
            safety_service=self.safety_service,
            digital_twin_service=self.digital_twin_service,
            relay_service=self.relay_service,
            scheduler_service=self.scheduler_service,
            scheduler_override=self._scheduler_runtime_override,
            parent=self,
        )
        self.queries = AppQueryService(
            state_store=self.state_store,
            runtime_service=self.runtime_service,
            scheduler_service=self.scheduler_service,
            digital_twin_service=self.digital_twin_service,
            scheduler_startup_state_callback=self.scheduler_startup_state,
            scheduler_startup_active_callback=self.is_scheduler_startup_active,
        )
        self.scheduler_template_service = SchedulerTemplateService(queries=self.queries)
        self.commands = AppCommandService(
            state_store=self.state_store,
            runtime_service=self.runtime_service,
            scheduler_service=self.scheduler_service,
            digital_twin_service=self.digital_twin_service,
            relay_service=self.relay_service,
            scheduler_template_service=self.scheduler_template_service,
            status_callback=self.status.emit,
            start_scheduler_callback=self.start_scheduler,
            pause_scheduler_callback=self.pause_scheduler,
            stop_scheduler_callback=self.stop_scheduler,
            previous_scheduler_step_callback=self.scheduler_previous_step,
            next_scheduler_step_callback=self.scheduler_next_step,
            confirm_scheduler_step_callback=self.confirm_scheduler_step,
            apply_configuration_callback=self.apply_configuration,
            set_status_callback=self.set_status_message,
        )

        self._scheduler_startup_active = False
        self._scheduler_startup_deadline = 0.0
        self._scheduler_startup_started_at = 0.0
        self._scheduler_startup_message = ''
        self._scheduler_startup_summary = ''
        self._scheduler_startup_timer = QTimer(self)
        self._scheduler_startup_timer.setInterval(250)
        self._scheduler_startup_timer.timeout.connect(self._advance_scheduler_startup)

        self.runtime_service.status.connect(self.status)
        self.runtime_service.cycle_completed.connect(self.cycle_completed)
        self.runtime_service.command_failed.connect(self.command_failed)
        self.can_service.frame_received.connect(self._on_can_frame)
        self.can_service.status.connect(self.status)
        self.can_service.connection_changed.connect(self._on_can_connection_changed)

        self.status.connect(self.events.status)
        self.cycle_completed.connect(self.events.cycle_completed)
        self.command_failed.connect(self.events.command_failed)
        self.frame_decoded.connect(self.events.frame_decoded)
        self.can_connection_changed.connect(self.events.can_connection_changed)

        self.apply_settings(self.settings)

    def _on_can_connection_changed(self, connected: bool) -> None:
        self.state_store.set_can_connected(bool(connected))
        self.can_connection_changed.emit(bool(connected))

    def _on_can_frame(self, frame, obj) -> None:
        sender_node_type = int(frame.can_id.sender_node_type)
        node_id = int(frame.can_id.secondary_node_id)
        now = time.time()
        if obj is not None:
            self.state_store.update_device_from_obj(sender_node_type, node_id, obj, now)
        else:
            self.state_store.update_device_seen(sender_node_type, node_id, obj, now)
        self.can_service.note_decoded_frame(frame, obj)
        self.frame_decoded.emit(frame, obj)
        self.runtime_service.on_can_frame()

    def apply_settings(self, settings: Optional[AppSettings] = None) -> None:
        self.settings = settings or self.settings_manager.load()
        channel_label = f'Channel {self.settings.can_channel}' if self.settings.can_channel is not None else ''
        self.settings_mapper.apply_settings_to_state(self.state_store, self.settings, can_channel_label=channel_label)
        self._load_supporting_models()
        self.runtime_service.evaluate_scheduler()
        self.runtime_service.evaluate_controls()
        self.runtime_service.sync_relays()

    def apply_configuration(self, config: ApplicationConfigModel, *, persist: bool = False) -> tuple[bool, str]:
        validation = validate_application_config(config)
        if not validation.is_valid:
            return False, validation.summary()
        settings = self.settings_mapper.config_to_settings(config)
        relay_manual_states = {int(k): bool(v) for k, v in (config.relay.manual_states or {}).items()}
        self.settings = settings
        self.settings_mapper.apply_settings_to_state(
            self.state_store,
            settings,
            can_channel_label=str(config.can_channel_label or ''),
            relay_manual_states=relay_manual_states,
        )
        if persist:
            self.settings_manager.save(settings)
        self.runtime_service.evaluate_scheduler()
        self.runtime_service.evaluate_controls()
        self.runtime_service.sync_relays()
        return True, 'Configuration applied.' if not persist else 'Configuration saved.'

    def set_status_message(self, message: str) -> tuple[bool, str]:
        self.state_store.set_status(str(message))
        self.status.emit(str(message))
        return True, str(message)

    def _load_supporting_models(self) -> None:
        twin_path = str(self.settings.twin.fmu_path or '').strip()
        if twin_path:
            result = self.commands.load_twin_model(twin_path)
            self.status.emit(result.message)
        workbook = str(self.settings.scheduler.workbook_path or '').strip()
        if workbook:
            try:
                result = self.scheduler_service.load_workbook(workbook, str(self.settings.scheduler.sheet_name or ''))
                self.status.emit(result.message)
            except Exception as exc:
                self.status.emit(f'Schedule load failed: {exc}')

    def start(self) -> None:
        self.runtime_service.start()
        self.digital_twin_service.start_background(self.state_store.snapshot, period_s=0.25)

    def stop(self) -> None:
        self._cancel_scheduler_startup()
        self.runtime_service.stop()
        self.digital_twin_service.stop_background()
        try:
            if self.state_store.snapshot().psu_power_on:
                self.psu_service.power_off()
        except Exception:
            pass
        self.psu_service.close()
        self.relay_service.close()
        self.can_service.disconnect_bus()

    def run_headless_bootstrap(self) -> None:
        self.start()
        should_start_scheduler = bool(getattr(self.settings.scheduler, 'enabled', False) and getattr(self.settings.scheduler, 'auto_start', False))
        if should_start_scheduler:
            ok, message = self.start_scheduler()
            self.status.emit(message)
        self.status.emit('Headless core started.')


    def scheduler_startup_state(self) -> dict:
        return {
            'active': bool(self._scheduler_startup_active),
            'started_at': float(self._scheduler_startup_started_at),
            'deadline': float(self._scheduler_startup_deadline),
            'message': str(self._scheduler_startup_message or ''),
            'summary': str(self._scheduler_startup_summary or ''),
        }

    def is_scheduler_startup_active(self) -> bool:
        return bool(self._scheduler_startup_active)

    def _scheduler_has_startup_sequence(self) -> bool:
        sched = self.settings.scheduler
        return bool(
            getattr(sched, 'startup_sequence_enabled', False) and (
                getattr(sched, 'startup_auto_connect_relays', False)
                or getattr(sched, 'startup_auto_connect_can', False)
                or getattr(sched, 'startup_auto_power_psu', False)
                or getattr(sched, 'startup_auto_load_twin', False)
                or float(getattr(sched, 'startup_delay_s', 0.0) or 0.0) > 0.0
            )
        )

    def _cancel_scheduler_startup(self) -> None:
        self._scheduler_startup_active = False
        self._scheduler_startup_deadline = 0.0
        self._scheduler_startup_started_at = 0.0
        self._scheduler_startup_message = ''
        self._scheduler_startup_summary = ''
        self._scheduler_startup_timer.stop()

    def _complete_scheduler_startup(self) -> tuple[bool, str]:
        self._cancel_scheduler_startup()
        ok, message = self.scheduler_service.start()
        self.status.emit(message)
        self.runtime_service.evaluate_scheduler()
        return ok, message

    def _advance_scheduler_startup(self) -> None:
        if not self._scheduler_startup_active:
            self._scheduler_startup_timer.stop()
            return
        self.runtime_service.evaluate_scheduler()

    def _scheduler_runtime_override(self) -> Optional[dict]:
        if not self._scheduler_startup_active:
            return None
        now = time.monotonic()
        remaining = max(0.0, self._scheduler_startup_deadline - now)
        elapsed = max(0.0, now - self._scheduler_startup_started_at)
        total = max(elapsed + remaining, 0.0)
        self._scheduler_startup_message = f'Starting up… settling {elapsed:.1f}/{total:.1f} s'
        if remaining <= 0.0:
            QTimer.singleShot(0, self._complete_scheduler_startup)
            return {
                'running': False,
                'paused': False,
                'current_step_index': -1,
                'current_step_name': '',
                'current_step_started_at_monotonic': None,
                'current_step_elapsed_s': 0.0,
                'waiting_reason': 'Finalizing startup…',
                'last_transition': self._scheduler_startup_summary or 'Startup sequence active',
                'hold_elapsed_s': 0.0,
                'schedule_loaded': bool(self.scheduler_service.steps),
                'awaiting_confirmation': False,
                'confirmation_message': '',
                'active_temperature_setpoint': None,
                'active_pressure_setpoint': None,
                'active_allow_add_gas': None,
                'active_agitator_on': None,
                'active_agitator_duty_cycle': None,
            }
        return {
            'running': False,
            'paused': False,
            'current_step_index': -1,
            'current_step_name': '',
            'current_step_started_at_monotonic': None,
            'current_step_elapsed_s': 0.0,
            'waiting_reason': self._scheduler_startup_message,
            'last_transition': self._scheduler_startup_summary or 'Startup sequence active',
            'hold_elapsed_s': 0.0,
            'schedule_loaded': bool(self.scheduler_service.steps),
            'awaiting_confirmation': False,
            'confirmation_message': '',
            'active_temperature_setpoint': None,
            'active_pressure_setpoint': None,
            'active_allow_add_gas': None,
            'active_agitator_on': None,
            'active_agitator_duty_cycle': None,
        }

    def start_scheduler(self, *, skip_startup: bool = False) -> tuple[bool, str]:
        if self._scheduler_startup_active:
            return True, self._scheduler_startup_message or 'Startup sequence running'
        if not skip_startup and self._scheduler_has_startup_sequence():
            actions: list[str] = []
            sched = self.settings.scheduler
            try:
                if getattr(sched, 'startup_auto_connect_relays', False):
                    result = self.commands.ensure_relays_connected()
                    if not result.ok:
                        return False, result.message
                    actions.append(result.message)
                if getattr(sched, 'startup_auto_connect_can', False):
                    result = self.commands.ensure_can_connected()
                    if not result.ok:
                        return False, result.message
                    actions.append(result.message)
                if getattr(sched, 'startup_auto_power_psu', False):
                    snap = self.state_store.snapshot()
                    if not snap.psu_power_on:
                        result = self.commands.toggle_psu_power()
                        if not result.ok:
                            return False, result.message
                        actions.append(result.message)
                    else:
                        actions.append('PSU already on')
                if getattr(sched, 'startup_auto_load_twin', False):
                    twin_path = str(self.settings.twin.fmu_path or '').strip()
                    if not twin_path:
                        return False, 'No FMU selected'
                    result = self.commands.load_twin_model(twin_path)
                    if not result.ok:
                        return False, result.message
                    actions.append(result.message)
                    self.status.emit(result.message)
            except Exception as exc:
                return False, str(exc)
            delay = max(0.0, float(getattr(sched, 'startup_delay_s', 0.0) or 0.0))
            if delay <= 0.0:
                return self._complete_scheduler_startup()
            self._scheduler_startup_active = True
            self._scheduler_startup_started_at = time.monotonic()
            self._scheduler_startup_deadline = self._scheduler_startup_started_at + delay
            self._scheduler_startup_summary = '; '.join(actions) if actions else 'Startup delay'
            self._scheduler_startup_message = f'Starting up… settling for {delay:.1f} s'
            self._scheduler_startup_timer.start()
            self.runtime_service.evaluate_scheduler()
            return True, self._scheduler_startup_message
        return self._complete_scheduler_startup()

    def pause_scheduler(self) -> tuple[bool, str]:
        snap = self.state_store.snapshot()
        if snap.scheduler_runtime.running and snap.scheduler_runtime.paused:
            self.scheduler_service.resume()
            self.runtime_service.evaluate_scheduler()
            self.status.emit('Scheduler resumed')
            return True, 'Scheduler resumed'
        self.scheduler_service.pause()
        self.runtime_service.evaluate_scheduler()
        self.status.emit('Scheduler paused')
        return True, 'Scheduler paused'

    def stop_scheduler(self) -> tuple[bool, str]:
        self._cancel_scheduler_startup()
        self.scheduler_service.stop()
        self.runtime_service.evaluate_scheduler()
        self.status.emit('Scheduler stopped')
        return True, 'Scheduler stopped'

    def confirm_scheduler_step(self) -> tuple[bool, str]:
        ok, message = self.scheduler_service.confirm_step()
        self.runtime_service.evaluate_scheduler()
        self.status.emit(message)
        return ok, message

    def scheduler_previous_step(self) -> tuple[bool, str]:
        ok, message = self.scheduler_service.previous_step()
        self.runtime_service.evaluate_scheduler()
        self.status.emit(message)
        return ok, message

    def scheduler_next_step(self) -> tuple[bool, str]:
        ok, message = self.scheduler_service.next_step()
        self.runtime_service.evaluate_scheduler()
        self.status.emit(message)
        return ok, message


def install_signal_handlers(core: AppCore, app: QCoreApplication) -> None:
    def _shutdown(*_args):
        core.status.emit('Shutdown requested.')
        core.stop()
        app.quit()
    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)
