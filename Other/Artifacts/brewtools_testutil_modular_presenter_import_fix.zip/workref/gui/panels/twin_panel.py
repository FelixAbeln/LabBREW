from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from gui.panel_facades import TwinPanelFacade


class TwinPanel(QWidget):
    def __init__(self, facade: TwinPanelFacade, parent: QWidget | None = None):
        super().__init__(parent)
        self.facade = facade
        self.twin_input_combos: dict[str, QComboBox] = {}
        self.twin_output_widgets: dict[str, QWidget] = {}
        self.twin_input_meta: dict[str, object] = {}
        self.twin_output_meta: dict[str, object] = {}

        layout = QVBoxLayout(self)
        info = QLabel('Prepare an OpenModelica digital twin by assigning live inputs from sensors, virtual outputs, or relay states. The twin acts as an estimator alongside the real process values, not a replacement for the control logic.')
        info.setWordWrap(True)
        layout.addWidget(info)
        self.twin_enabled = QCheckBox('Enable digital twin service')
        self.twin_enabled.setChecked(True)
        layout.addWidget(self.twin_enabled)
        twin_model_group = QGroupBox('FMU model')
        twin_model_layout = QHBoxLayout(twin_model_group)
        self.twin_fmu_path = QLineEdit()
        self.twin_fmu_path.setPlaceholderText('Select OpenModelica FMU (.fmu)')
        self.btn_twin_browse = QPushButton('Browse…')
        self.btn_twin_load = QPushButton('Load FMU')
        self.twin_fmu_label = QLabel('No FMU loaded')
        twin_model_layout.addWidget(QLabel('FMU:'))
        twin_model_layout.addWidget(self.twin_fmu_path, 1)
        twin_model_layout.addWidget(self.btn_twin_browse)
        twin_model_layout.addWidget(self.btn_twin_load)
        twin_model_layout.addWidget(self.twin_fmu_label)
        layout.addWidget(twin_model_group)
        twin_grid = QGridLayout()
        twin_grid.addWidget(self._build_twin_inputs_group(), 0, 0)
        twin_grid.addWidget(self._build_twin_outputs_group(), 0, 1)
        twin_grid.setColumnStretch(0, 1)
        twin_grid.setColumnStretch(1, 1)
        layout.addLayout(twin_grid)
        layout.addStretch(1)

    def _build_twin_inputs_group(self) -> QGroupBox:
        group = QGroupBox('Digital twin inputs')
        self.twin_inputs_form = QFormLayout(group)
        self.twin_input_combos = {}
        self.twin_input_meta = {}
        self.twin_inputs_form.addRow('Waiting for FMU', QLabel('Load an FMU to discover assignable inputs.'))
        return group

    def _build_twin_outputs_group(self) -> QGroupBox:
        group = QGroupBox('Digital twin outputs')
        outer = QVBoxLayout(group)

        self.twin_outputs_container = QWidget()
        self.twin_outputs_form = QFormLayout(self.twin_outputs_container)
        self.twin_outputs_form.setContentsMargins(6, 6, 6, 6)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(self.twin_outputs_container)
        scroll.setMinimumHeight(260)

        outer.addWidget(scroll)

        self.twin_output_widgets = {}
        self.twin_output_meta = {}
        self.twin_fmu_name = QLabel('—')
        self.twin_status = QLabel('Idle')
        self.twin_step_count = QLabel('0')
        self.twin_sim_time = QLabel('0.0 s')
        self.twin_last_dt = QLabel('—')
        self.twin_last_age = QLabel('—')
        self.twin_worker_period = QLabel('—')
        self.twin_runtime_mode = QLabel('—')
        self.twin_outputs_form.addRow('Loaded FMU', self.twin_fmu_name)
        self.twin_outputs_form.addRow('Model status', self.twin_status)
        self.twin_outputs_form.addRow('Runtime mode', self.twin_runtime_mode)
        self.twin_outputs_form.addRow('Step count', self.twin_step_count)
        self.twin_outputs_form.addRow('Sim time', self.twin_sim_time)
        self.twin_outputs_form.addRow('Last dt', self.twin_last_dt)
        self.twin_outputs_form.addRow('Last step age', self.twin_last_age)
        self.twin_outputs_form.addRow('Worker period', self.twin_worker_period)
        self.twin_outputs_form.addRow('Waiting for FMU', QLabel('Load an FMU to discover available outputs.'))
        return group

    def _clear_form_layout(self, form: QFormLayout) -> None:
        while form.rowCount() > 0:
            form.removeRow(0)

    def _pretty_twin_var_name(self, name: str) -> str:
        return name.replace('_', ' ')

    def _twin_binding_items_for_var(self, var_type: str):
        items = [('— Unassigned —', None)]
        type_name = (var_type or '').lower()
        for rec in self.facade.signal_records():
            if type_name == 'boolean':
                if rec.key.startswith(('virtual:', 'relay:')):
                    items.append((rec.label, rec.key))
            else:
                if rec.key.startswith(('sensor:', 'virtual:', 'relay:', 'psu:measured_voltage', 'twin:')):
                    items.append((rec.label, rec.key))
        return items

    def rebuild_variable_widgets(self) -> None:
        input_vars = self.facade.twin_input_variables()
        output_vars = self.facade.twin_output_variables()
        snap = self.facade.snapshot()
        bindings = dict(snap.twin.input_bindings)

        self._clear_form_layout(self.twin_inputs_form)
        self.twin_input_combos = {}
        self.twin_input_meta = {}
        if not input_vars:
            self.twin_inputs_form.addRow('Waiting for FMU', QLabel('Load an FMU to discover assignable inputs.'))
        else:
            for var in input_vars:
                combo = QComboBox()
                combo.currentIndexChanged.connect(self.facade.save_settings)
                label = self._pretty_twin_var_name(var.name)
                if var.description:
                    label += f' — {var.description}'
                self.twin_inputs_form.addRow(f'{label} ({var.var_type})', combo)
                self.twin_input_combos[var.name] = combo
                self.twin_input_meta[var.name] = var

        self._clear_form_layout(self.twin_outputs_form)
        self.twin_output_widgets = {}
        self.twin_output_meta = {}
        current_outputs = (self.facade.latest_twin_result() or {}).get('outputs', {}) or {}
        fmu_text = str(current_outputs.get('fmu_name', self.facade.twin_model_name() or '—'))
        status_text = str(current_outputs.get('status_text', self.facade.twin_status_text() or 'Idle'))
        self.twin_fmu_name = QLabel(fmu_text)
        self.twin_status = QLabel(status_text)
        self.twin_runtime_mode = QLabel(str(current_outputs.get('runtime_mode', '—')))
        self.twin_step_count = QLabel(str(current_outputs.get('step_count', 0)))
        sim_time = current_outputs.get('sim_time_s')
        last_dt = current_outputs.get('last_dt_s')
        last_age = current_outputs.get('last_step_age_s')
        period = current_outputs.get('worker_period_s')
        self.twin_sim_time = QLabel(f'{sim_time:.3f} s' if isinstance(sim_time, (int, float)) else '—')
        self.twin_last_dt = QLabel(f'{last_dt:.3f} s' if isinstance(last_dt, (int, float)) else '—')
        self.twin_last_age = QLabel(f'{last_age:.3f} s' if isinstance(last_age, (int, float)) else '—')
        self.twin_worker_period = QLabel(f'{period:.3f} s' if isinstance(period, (int, float)) else '—')
        self.twin_outputs_form.addRow('Loaded FMU', self.twin_fmu_name)
        self.twin_outputs_form.addRow('Model status', self.twin_status)
        self.twin_outputs_form.addRow('Runtime mode', self.twin_runtime_mode)
        self.twin_outputs_form.addRow('Step count', self.twin_step_count)
        self.twin_outputs_form.addRow('Sim time', self.twin_sim_time)
        self.twin_outputs_form.addRow('Last dt', self.twin_last_dt)
        self.twin_outputs_form.addRow('Last step age', self.twin_last_age)
        self.twin_outputs_form.addRow('Worker period', self.twin_worker_period)
        if not output_vars:
            self.twin_outputs_form.addRow('Waiting for FMU', QLabel('Load an FMU to discover available outputs.'))
        else:
            for var in output_vars:
                is_bool = (var.var_type or '').lower() == 'boolean'
                widget = self.facade.make_output_badge(var.name) if is_bool else QLabel('—')
                if isinstance(widget, QLabel) and not is_bool:
                    widget.setTextInteractionFlags(Qt.TextSelectableByMouse)
                label = self._pretty_twin_var_name(var.name)
                if var.description:
                    label += f' — {var.description}'
                self.twin_outputs_form.addRow(f'{label} ({var.var_type})', widget)
                self.twin_output_widgets[var.name] = widget
                self.twin_output_meta[var.name] = var

        for name, combo in self.twin_input_combos.items():
            meta = self.twin_input_meta.get(name)
            items = self._twin_binding_items_for_var(getattr(meta, 'var_type', 'Real'))
            self.facade.refresh_binding_combo(combo, items, bindings.get(name))

    def refresh_sources(self) -> None:
        bindings = self.facade.snapshot().twin.input_bindings
        if not self.twin_input_combos and self.facade.twin_input_variables():
            self.rebuild_variable_widgets()
        for name, combo in self.twin_input_combos.items():
            meta = self.twin_input_meta.get(name)
            items = self._twin_binding_items_for_var(getattr(meta, 'var_type', 'Real'))
            self.facade.refresh_binding_combo(combo, items, bindings.get(name))

    def wire_signals(self) -> None:
        self.twin_enabled.toggled.connect(self.facade.save_settings)
        self.twin_fmu_path.editingFinished.connect(self.facade.save_settings)
        self.btn_twin_browse.clicked.connect(self.browse_twin_fmu)
        self.btn_twin_load.clicked.connect(self.load_twin_fmu)

    def browse_twin_fmu(self) -> None:
        start = self.twin_fmu_path.text().strip() or str(Path.home())
        path, _ = QFileDialog.getOpenFileName(self, 'Select FMU', start, 'FMU files (*.fmu);;All files (*)')
        if path:
            self.twin_fmu_path.setText(path)
            self.facade.save_settings()
            self.load_twin_fmu()

    def load_twin_fmu(self) -> None:
        self.facade.set_loading_twin_widgets(True)
        try:
            result = self.facade.load_twin_model(self.twin_fmu_path.text().strip())
            self.facade.set_status(result.message)
            if result.ok:
                self.rebuild_variable_widgets()
                self.facade.refresh_twin_panel()
                self.facade.refresh_footer()
                self.facade.save_settings_to_state()
            else:
                self.facade.refresh_twin_panel()
        finally:
            self.facade.set_loading_twin_widgets(False)
