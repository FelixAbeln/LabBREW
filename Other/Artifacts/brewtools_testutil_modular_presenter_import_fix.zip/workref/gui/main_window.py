from __future__ import annotations

import sys
import time
from pathlib import Path

from typing import Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
    QScrollArea, QSpinBox, QStatusBar, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout,
    QFrame,
    QWidget,
    QSizePolicy
)
from PySide6.QtWidgets import QHeaderView

from brewtools_can import CanFrame

from helpers import format_node_type, list_kvaser_channels, list_serial_ports
from settings import AppSettings, SettingsManager, DEFAULT_CAN_BITRATE, DEFAULT_PSU_VOLTAGE, ControllerSettings, AgitatorSettings, RelaySettings, DigitalTwinSettings, SafetySettings, SafetyRuleSettings, SchedulerSettings, SchedulerStepSettings
from state import AppState, DeviceKey, DeviceState, StateStore, SchedulerStep, SafetyRule
from app_core import AppCore
from gui.constants import OUTPUT_LABELS
from gui.config_adapters import ApplicationConfigBuilder
from gui.panel_facades import build_panel_facades
from gui.config_controller import WindowConfigController
from gui.discovery_controller import WindowDiscoveryController
from gui.runtime_bridge import WindowRuntimeBridge
from gui.settings_loader import WindowSettingsLoader
from gui.source_controller import WindowSourceController
from gui.ui_helpers import find_data_index, normalize_signal_key, make_output_badge, set_output_badge
from gui.panels import (
    BrewPanel,
    ControlPanel,
    LogPanel,
    RelayPanel,
    SafetyPanel,
    SchedulerPanel,
    TwinPanel,
)
from gui.presenters import MainWindowRefreshCoordinator
from gui.send_dialog import SendDialog
from gui.widgets.band_indicator import BandIndicator


def normalize_control_source_key(key):
    """Normalize saved controller source keys for backward compatibility."""
    if key is None:
        return None
    if isinstance(key, str):
        return key
    if isinstance(key, (tuple, list)):
        try:
            if len(key) == 2:
                return f"sensor:temperature:{int(key[0])}:{int(key[1])}"
        except Exception:
            return None
    return None


class MainWindow(QMainWindow):
    def __init__(self, *, core: AppCore):
        super().__init__()
        self.setWindowTitle('Brewtools CAN Test Utility')
        self.resize(1220, 820)

        self.core = core
        self.settings_manager = self.core.settings_manager
        self.settings = self.core.settings

        self.commands = self.core.commands
        self.queries = self.core.queries
        self.events = self.core.events
        self._action_labels = self.queries.safety_action_labels()
        self._operator_options = self.queries.operator_options()
        self._operator_keys = [opt.key for opt in self._operator_options]

        self._control_combo_sync_block = False
        self._pending_temp_source_key = normalize_control_source_key(self.settings.temp_controller.source_key)
        self._pending_pressure_source_key = normalize_control_source_key(self.settings.pressure_controller.source_key)
        self._last_temp_source_keys = []
        self._last_pressure_source_keys = []
        self._last_safety_signal_keys = []
        self._last_agitator_target_keys = []
        self._safety_rules: list[SafetyRule] = []
        self._loading_twin_widgets = False
        self._loading_scheduler_ui = False
        self.OUTPUT_LABELS = OUTPUT_LABELS
        self.relay_channel_rows: dict[int, dict[str, object]] = {}
        self._config_builder = ApplicationConfigBuilder(self)
        self.config_controller = WindowConfigController(self, self._config_builder)
        self.discovery_controller = WindowDiscoveryController(self)
        self.runtime_bridge = WindowRuntimeBridge(self)
        self.source_controller = WindowSourceController(self)
        self.settings_loader = WindowSettingsLoader(self)

        self._panel_facades = build_panel_facades(self)
        self._build_ui()
        self._wire_signals()
        self._refresh = MainWindowRefreshCoordinator(self, self.queries)

        self._loading_settings = True
        try:
            self.discovery_controller.populate_psu_ports()
            self.discovery_controller.populate_channels()
            self.discovery_controller.populate_relay_targets()
            self.settings_loader.apply()
        finally:
            self._loading_settings = False
        self.source_controller.refresh_control_sources()
        self.source_controller.refresh_twin_sources()
        self.runtime_bridge.refresh_footer()
        self.commands.set_status_message('Ready. Select PSU port, choose CAN voltage, power the rail, then connect CAN.')

        self.events.status.connect(self._on_status_event)
        self.events.cycle_completed.connect(self._on_runtime_cycle_completed)
        self.events.command_failed.connect(self._show_runtime_error)

        self._confirm_blink_timer = QTimer(self)
        self._confirm_blink_timer.setInterval(700)
        self._confirm_blink_timer.timeout.connect(self._toggle_confirm_blink)
        self._confirm_blink_state = False

        self.twin_refresh_timer = QTimer(self)
        self.twin_refresh_timer.setInterval(250)
        self.twin_refresh_timer.timeout.connect(self._poll_twin_runtime)
        self.twin_refresh_timer.start()

        self.refresh_footer()
        self.refresh_table()
        self.source_controller.refresh_control_sources()
        self._update_agitator_runtime()
        self.refresh_control_panel()
        self.refresh_safety_panel()
        self.source_controller.refresh_twin_sources()
        self.refresh_twin_panel()
        self.refresh_scheduler_panel()
        self.refresh_relay_panel()

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)

        self.tabs = QTabWidget()
        outer.addWidget(self.tabs)

        self.brew_panel = BrewPanel(self._panel_facades.brew)
        self.control_panel = ControlPanel(self._panel_facades.control)
        self.safety_panel = SafetyPanel(self._panel_facades.safety)
        self.log_panel = LogPanel()
        self.twin_panel = TwinPanel(self._panel_facades.twin)
        self.scheduler_panel = SchedulerPanel(self._panel_facades.scheduler)
        self.relay_panel = RelayPanel(self._panel_facades.relay)

        self.tabs.addTab(self.brew_panel, 'Brewtools')
        self.tabs.addTab(self.control_panel, 'Control')
        self.tabs.addTab(self.safety_panel, 'Safety')
        self.tabs.addTab(self.log_panel, 'System Log')
        self.tabs.addTab(self.twin_panel, 'Twin')
        self.tabs.addTab(self.scheduler_panel, 'Scheduler')
        self.tabs.addTab(self.relay_panel, 'Relays')
        self.footer_event_lbl = None
        self.footer_state_lbl = None


    def _build_temperature_group(self) -> QGroupBox:
        group = QGroupBox('Temperature deadband controller')
        form = QFormLayout(group)
        self.control_panel.temp_ctrl_enabled = QCheckBox('Enabled')
        self.control_panel.temp_source_combo = QComboBox()
        self.control_panel.temp_setpoint = QDoubleSpinBox()
        self.control_panel.temp_setpoint.setRange(-50.0, 300.0)
        self.control_panel.temp_setpoint.setDecimals(1)
        self.control_panel.temp_setpoint.setSuffix(' °C')
        self.control_panel.temp_deadband = QDoubleSpinBox()
        self.control_panel.temp_deadband.setRange(0.1, 50.0)
        self.control_panel.temp_deadband.setDecimals(1)
        self.control_panel.temp_deadband.setSuffix(' °C')
        self.control_panel.temp_pv = QLabel('—')
        self.control_panel.temp_state = QLabel('Disabled')
        self.control_panel.temp_band = BandIndicator()
        form.addRow('', self.control_panel.temp_ctrl_enabled)
        form.addRow('Temperature source', self.control_panel.temp_source_combo)
        form.addRow('Setpoint', self.control_panel.temp_setpoint)
        form.addRow('Deadband', self.control_panel.temp_deadband)
        form.addRow('Process value', self.control_panel.temp_pv)
        form.addRow('Controller state', self.control_panel.temp_state)
        form.addRow('Band', self.control_panel.temp_band)
        return group

    def _build_pressure_group(self) -> QGroupBox:
        group = QGroupBox('Pressure deadband controller')
        form = QFormLayout(group)
        self.control_panel.pressure_ctrl_enabled = QCheckBox('Enabled')
        self.control_panel.pressure_source_combo = QComboBox()
        self.control_panel.pressure_setpoint = QDoubleSpinBox()
        self.control_panel.pressure_setpoint.setRange(0.0, 10.0)
        self.control_panel.pressure_setpoint.setDecimals(3)
        self.control_panel.pressure_setpoint.setSuffix(' bar')
        self.control_panel.pressure_deadband = QDoubleSpinBox()
        self.control_panel.pressure_deadband.setRange(0.001, 5.0)
        self.control_panel.pressure_deadband.setDecimals(3)
        self.control_panel.pressure_deadband.setSuffix(' bar')
        self.control_panel.pressure_allow_add_gas = QCheckBox('Allow regulator to add gas')
        self.control_panel.pressure_allow_add_gas.setChecked(True)
        self.control_panel.pressure_pv = QLabel('—')
        self.control_panel.pressure_state = QLabel('Disabled')
        self.control_panel.pressure_band = BandIndicator()
        form.addRow('', self.control_panel.pressure_ctrl_enabled)
        form.addRow('Pressure source', self.control_panel.pressure_source_combo)
        form.addRow('Setpoint', self.control_panel.pressure_setpoint)
        form.addRow('Deadband', self.control_panel.pressure_deadband)
        form.addRow('', self.control_panel.pressure_allow_add_gas)
        form.addRow('Process value', self.control_panel.pressure_pv)
        form.addRow('Controller state', self.control_panel.pressure_state)
        form.addRow('Band', self.control_panel.pressure_band)
        return group


    def _build_agitator_group(self) -> QGroupBox:
        group = QGroupBox('Agitator control')
        form = QFormLayout(group)
        self.control_panel.agitator_enabled = QCheckBox('Enabled')
        self.control_panel.agitator_target_combo = QComboBox()
        self.control_panel.agitator_target_combo.setEditable(False)
        self.control_panel.agitator_on = QCheckBox('Run agitator')
        self.control_panel.agitator_mode_lbl = QLabel('Output')
        self.control_panel.agitator_control_mode = QComboBox()
        self.control_panel.agitator_control_mode.addItem('Manual duty', 'manual')
        self.control_panel.agitator_control_mode.addItem('Speed PID', 'pid')
        self.control_panel.agitator_command_lbl = QLabel('Duty cycle')
        self.control_panel.agitator_duty = QDoubleSpinBox()
        self.control_panel.agitator_duty.setRange(0.0, 100.0)
        self.control_panel.agitator_duty.setDecimals(1)
        self.control_panel.agitator_duty.setSuffix(' %')
        self.control_panel.agitator_duty.setValue(100.0)
        self.control_panel.agitator_speed_setpoint = QDoubleSpinBox()
        self.control_panel.agitator_speed_setpoint.setRange(0.0, 5000.0)
        self.control_panel.agitator_speed_setpoint.setDecimals(1)
        self.control_panel.agitator_speed_setpoint.setSuffix(' rpm')
        self.control_panel.agitator_speed_setpoint.setValue(120.0)
        self.control_panel.agitator_pid_kp = QDoubleSpinBox(); self.control_panel.agitator_pid_kp.setRange(0.0, 10.0); self.control_panel.agitator_pid_kp.setDecimals(3); self.control_panel.agitator_pid_kp.setSingleStep(0.01); self.control_panel.agitator_pid_kp.setValue(0.30)
        self.control_panel.agitator_pid_ki = QDoubleSpinBox(); self.control_panel.agitator_pid_ki.setRange(0.0, 10.0); self.control_panel.agitator_pid_ki.setDecimals(3); self.control_panel.agitator_pid_ki.setSingleStep(0.01); self.control_panel.agitator_pid_ki.setValue(0.05)
        self.control_panel.agitator_pid_kd = QDoubleSpinBox(); self.control_panel.agitator_pid_kd.setRange(0.0, 10.0); self.control_panel.agitator_pid_kd.setDecimals(3); self.control_panel.agitator_pid_kd.setSingleStep(0.01); self.control_panel.agitator_pid_kd.setValue(0.00)
        self.control_panel.agitator_rpm = QLabel('—')
        self.control_panel.agitator_commanded = QLabel('—')
        self.control_panel.agitator_state = QLabel('Disabled')
        form.addRow('', self.control_panel.agitator_enabled)
        form.addRow(self.control_panel.agitator_mode_lbl, self.control_panel.agitator_target_combo)
        form.addRow('', self.control_panel.agitator_on)
        form.addRow('Control mode', self.control_panel.agitator_control_mode)
        form.addRow(self.control_panel.agitator_command_lbl, self.control_panel.agitator_duty)
        form.addRow('Speed setpoint', self.control_panel.agitator_speed_setpoint)
        form.addRow('PID Kp', self.control_panel.agitator_pid_kp)
        form.addRow('PID Ki', self.control_panel.agitator_pid_ki)
        form.addRow('PID Kd', self.control_panel.agitator_pid_kd)
        form.addRow('Speed feedback', self.control_panel.agitator_rpm)
        form.addRow('Commanded duty', self.control_panel.agitator_commanded)
        form.addRow('State', self.control_panel.agitator_state)
        return group

    def _wire_signals(self) -> None:
        self.brew_panel.wire_signals()
        self.control_panel.wire_signals()
        self.safety_panel.wire_signals()
        self.twin_panel.wire_signals()
        self.scheduler_panel.wire_signals()
        self.relay_panel.wire_signals()

        self.events.frame_decoded.connect(self.on_frame)
        self.events.can_connection_changed.connect(self._on_can_connection_changed)

    def _set_toggle_style(self, button: QPushButton, active: bool) -> None:
        button.setChecked(active)
        if active:
            button.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _toggle_confirm_blink(self) -> None:
        panel = self.queries.scheduler_panel()
        if not panel.awaiting_confirmation:
            if self._confirm_blink_timer.isActive():
                self._confirm_blink_timer.stop()
            self._confirm_blink_state = False
            self.scheduler_panel.btn_scheduler_confirm.setText('Confirm / Continue')
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')
            return
        self._confirm_blink_state = not self._confirm_blink_state
        self.scheduler_panel.btn_scheduler_confirm.setText('Confirm Step')
        if self._confirm_blink_state:
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _update_confirm_button_state(self, awaiting_confirmation: bool) -> None:
        if awaiting_confirmation:
            self.scheduler_panel.btn_scheduler_confirm.setText('Confirm Step')
            if not self._confirm_blink_timer.isActive():
                self._confirm_blink_state = False
                self._confirm_blink_timer.start()
                self._toggle_confirm_blink()
        else:
            if self._confirm_blink_timer.isActive():
                self._confirm_blink_timer.stop()
            self._confirm_blink_state = False
            self.scheduler_panel.btn_scheduler_confirm.setText('Confirm / Continue')
            self.scheduler_panel.btn_scheduler_confirm.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _make_output_badge(self, text: str) -> QLabel:
        return make_output_badge(text)

    def _set_output_badge(self, label: QLabel, active: bool, active_text: str = 'ON', inactive_text: str = 'OFF') -> None:
        set_output_badge(label, active, active_text, inactive_text)

    def _normalize_signal_key(self, value) -> Optional[str]:
        return normalize_signal_key(value)

    def _find_data_index(self, combo: QComboBox, target) -> int:
        return find_data_index(combo, target)

    def _source_label_for_key(self, key: Optional[str], measurement: str, available: bool = True) -> str:
        if key is None:
            return '— Select discovered %s channel —' % measurement
        rec = self.queries.signal_map().get(str(key))
        base = rec.label if rec is not None else f'Saved {measurement.title()} source'
        return base if available else f'{base} (unavailable)'

    def _selected_or_pending_source_key(self, combo: QComboBox, pending: Optional[str]) -> Optional[str]:
        return self.source_controller.selected_or_pending_source_key(combo, pending)

    def _binding_combo_pairs(self, kind: str):
        items = [('— Unassigned —', None)]
        for rec in self.queries.signal_records():
            if kind == 'temperature' and rec.key.startswith('sensor:temperature:'):
                items.append((rec.label, rec.key))
            elif kind == 'pressure' and rec.key.startswith('sensor:pressure:'):
                items.append((rec.label, rec.key))
            elif kind == 'command' and rec.key.startswith(('sensor:temperature:', 'sensor:pressure:', 'sensor:density:', 'virtual:', 'relay:')):
                items.append((rec.label, rec.key))
        return items

    def _refresh_binding_combo(self, combo: QComboBox, items, selected):
        from gui.ui_helpers import refresh_binding_combo
        refresh_binding_combo(combo, items, selected)

    def _relay_assignments_from_ui(self) -> dict[int, Optional[str]]:
        return {ch: row['combo'].currentData() for ch, row in self.relay_channel_rows.items()}

    def _relay_auto_from_ui(self) -> dict[int, bool]:
        return {ch: bool(row['auto'].isChecked()) for ch, row in self.relay_channel_rows.items()}

    def _relay_manual_from_ui(self) -> dict[int, bool]:
        return {ch: bool(row['test'].isChecked()) for ch, row in self.relay_channel_rows.items()}

    def _apply_loaded_settings(self) -> None:
        self.settings_loader.apply()

    def _create_collapsible_section(self, title: str, content: QWidget, expanded: bool = True) -> QWidget:
        from gui.ui_helpers import create_collapsible_section
        return create_collapsible_section(title, content, expanded)

    def _build_application_config_model(self):
        return self._config_builder.build()

    def _save_settings_to_state(self) -> None:
        self.config_controller.save_settings_to_state()

    def _save_settings_from_ui(self, *args) -> None:
        self.config_controller.save_settings(*args)

    def _on_bitrate_changed(self, *args) -> None:
        self.config_controller.on_bitrate_changed(*args)

    def _on_temp_source_changed(self, *args) -> None:
        self.control_panel._on_temp_source_changed(*args)

    def _on_pressure_source_changed(self, *args) -> None:
        self.control_panel._on_pressure_source_changed(*args)

    def _browse_twin_fmu(self) -> None:
        self.twin_panel.browse_twin_fmu()



    def _refresh_scheduler_sheet_combo(self, sheet_names: list[str], target: str = '') -> None:
        self.discovery_controller.refresh_scheduler_sheet_combo(sheet_names, target)

    def _toggle_scheduler_startup_details(self, checked: bool) -> None:
        self.scheduler_panel.toggle_startup_details(checked)

    def _refresh_scheduler_startup_summary(self) -> None:
        if hasattr(self, 'scheduler_panel'):
            self.scheduler_panel.refresh_startup_summary()

    def _browse_schedule_file(self) -> None:
        self.scheduler_panel.browse_schedule_file()

    def create_schedule_template(self) -> None:
        self._create_schedule_template()

    def _create_schedule_template(self) -> None:
        self.discovery_controller.create_schedule_template()

    def _load_schedule_file(self, auto: bool = False) -> None:
        self.scheduler_panel.load_schedule_file(auto=auto)

    def _start_scheduler(self) -> None:
        self.scheduler_panel.start_scheduler()

    def _pause_scheduler(self) -> None:
        self.scheduler_panel.pause_scheduler()

    def _stop_scheduler(self) -> None:
        self.scheduler_panel.stop_scheduler()

    def _scheduler_prev_step(self) -> None:
        self.scheduler_panel.scheduler_prev_step()

    def _scheduler_next_step(self) -> None:
        self.scheduler_panel.scheduler_next_step()

    def _scheduler_confirm_step(self) -> None:
        self.scheduler_panel.scheduler_confirm_step()

    def _refresh_agitator_control_ui(self) -> None:
        self.control_panel.refresh_agitator_control_ui()

    def _apply_scheduler_targets(self, temp_sp: Optional[float], pressure_sp: Optional[float], allow_add_gas: Optional[bool] = None, agitator_on: Optional[bool] = None, agitator_duty: Optional[float] = None) -> None:
        changed = False
        self._loading_scheduler_ui = True
        try:
            if temp_sp is not None and abs(self.control_panel.temp_setpoint.value() - float(temp_sp)) > 1e-9:
                self.control_panel.temp_setpoint.setValue(float(temp_sp))
                changed = True
            if pressure_sp is not None and abs(self.control_panel.pressure_setpoint.value() - float(pressure_sp)) > 1e-9:
                self.control_panel.pressure_setpoint.setValue(float(pressure_sp))
                changed = True
            if allow_add_gas is not None and self.control_panel.pressure_allow_add_gas.isChecked() != bool(allow_add_gas):
                self.control_panel.pressure_allow_add_gas.setChecked(bool(allow_add_gas))
                changed = True
            if agitator_on is not None and self.control_panel.agitator_on.isChecked() != bool(agitator_on):
                self.control_panel.agitator_on.setChecked(bool(agitator_on))
                changed = True
            if agitator_duty is not None and abs(self.control_panel.agitator_duty.value() - float(agitator_duty)) > 1e-9:
                self.control_panel.agitator_duty.setValue(float(agitator_duty))
                changed = True
        finally:
            self._loading_scheduler_ui = False
        if changed:
            self._save_settings_to_state()
            self.refresh_control_panel()

    def evaluate_scheduler(self) -> None:
        self.commands.evaluate_scheduler()

    def refresh_scheduler_panel(self) -> None:
        self.runtime_bridge.refresh_scheduler_panel()

    def _load_twin_fmu(self) -> None:
        self.twin_panel.load_twin_fmu()

    def _on_status_event(self, message: str) -> None:
        self.statusBar().showMessage(str(message))
        self.refresh_footer()

    def set_status(self, message: str) -> None:
        self.discovery_controller.set_status(str(message))

    def refresh_footer(self) -> None:
        self.runtime_bridge.refresh_footer()

    def update_ui_locked_states(self) -> None:
        self._refresh.footer.refresh()

    def populate_channels(self) -> None:
        self.discovery_controller.populate_channels()

    def populate_psu_ports(self) -> None:
        self.discovery_controller.populate_psu_ports()

    def populate_relay_targets(self) -> None:
        self.discovery_controller.populate_relay_targets()

    def toggle_psu_power(self) -> None:
        self._save_settings_to_state()
        self.commands.toggle_psu_power()

    def poll_psu_measurements(self) -> None:
        self.commands.poll_psu_measurements()

    def toggle_can_connection(self) -> None:
        self._save_settings_to_state()
        self.commands.toggle_can_connection()

    def toggle_relay_connection(self) -> None:
        self._save_settings_to_state()
        self.commands.toggle_relay_connection()

    def _on_can_connection_changed(self, connected: bool) -> None:
        self.refresh_footer()

    def open_send_dialog(self) -> None:
        snap = self.queries.snapshot()
        if not snap.devices:
            QMessageBox.information(self, 'No devices', 'No devices discovered yet. Connect and wait for traffic.')
            return
        dlg = SendDialog(self, snap.devices, int(self.brew_panel.channel_combo.currentData()), int(self.brew_panel.bitrate.value()))
        dlg.exec()

    def on_frame(self, frame: CanFrame, obj: Optional[object]) -> None:
        self.runtime_bridge.on_frame(frame, obj)

    def refresh_table(self) -> None:
        self.runtime_bridge.refresh_table()

    def _refresh_control_source_combo(self, combo: QComboBox, measurement: str, sources, target: Optional[str], cache_attr: str) -> None:
        self.source_controller._refresh_control_source_combo(combo, measurement, sources, target, cache_attr)

    def _agitator_target_options(self):
        return self.source_controller._agitator_target_options()

    def _refresh_agitator_target_combo(self) -> None:
        self.source_controller._refresh_agitator_target_combo()

    def refresh_control_sources(self) -> None:
        self.source_controller.refresh_control_sources()

    def _safety_rule_from_editor(self) -> SafetyRule:
        return self.safety_panel.safety_rule_from_editor()

    def _safety_condition_text(self, rule: SafetyRule) -> str:
        return self.safety_panel.safety_condition_text(rule)

    def _refresh_safety_editor_visibility(self) -> None:
        self.safety_panel.refresh_editor_visibility()

    def _refresh_safety_rules_table(self) -> None:
        self.safety_panel.refresh_rules_table()

    def _clear_safety_rule_editor(self) -> None:
        self.safety_panel.clear_rule_editor()

    def _load_safety_rule_into_editor(self, row: int) -> None:
        self.safety_panel.load_rule_into_editor(row)

    def _add_safety_rule(self) -> None:
        self.safety_panel.add_rule()

    def _update_safety_rule(self) -> None:
        self.safety_panel.update_rule()

    def _delete_safety_rule(self) -> None:
        self.safety_panel.delete_rule()

    def evaluate_controls(self) -> None:
        self.commands.evaluate_controls()

    def _update_agitator_runtime(self) -> None:
        self.commands.update_agitator_runtime()

    def _on_runtime_cycle_completed(self) -> None:
        self.runtime_bridge.on_runtime_cycle_completed()

    def _show_runtime_error(self, title: str, message: str) -> None:
        QMessageBox.critical(self, title, message)

    def refresh_control_panel(self) -> None:
        self.runtime_bridge.refresh_control_panel()

    def refresh_safety_panel(self) -> None:
        self.runtime_bridge.refresh_safety_panel()

    def refresh_twin_sources(self) -> None:
        self.source_controller.refresh_twin_sources()

    def _poll_twin_runtime(self) -> None:
        self.refresh_twin_panel()
        self.runtime_bridge.refresh_footer()

    def evaluate_twin(self) -> None:
        self.commands.request_twin_cycle()

    def refresh_twin_panel(self) -> None:
        self.runtime_bridge.refresh_twin_panel()

    def _desired_relay_states(self, snap: AppState) -> dict[int, bool]:
        return self.queries.desired_relay_states(snap)

    def sync_relays(self) -> None:
        self.commands.sync_relays()

    def _on_relay_auto_toggled(self, channel: int, checked: bool) -> None:
        self.relay_panel.on_relay_auto_toggled(channel, checked)

    def _on_relay_test_toggled(self, channel: int, checked: bool) -> None:
        self.relay_panel.on_relay_test_toggled(channel, checked)

    def refresh_relay_panel(self) -> None:
        self.runtime_bridge.refresh_relay_panel()

    def closeEvent(self, event) -> None:
        self._save_settings_from_ui()
        super().closeEvent(event)


def run() -> int:
    from app import run_gui
    return run_gui()
