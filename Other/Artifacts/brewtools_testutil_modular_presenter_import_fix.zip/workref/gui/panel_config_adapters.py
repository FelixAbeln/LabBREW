from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from application.config_models import (
    AgitatorConfigModel,
    ControllerConfigModel,
    RelayConfigModel,
    SafetyConfigModel,
    SafetyRuleConfigModel,
    SchedulerConfigModel,
    SchedulerStepConfigModel,
    TwinConfigModel,
)


@dataclass
class BrewPanelConfigAdapter:
    panel: object

    def to_dict(self) -> dict[str, object]:
        return {
            'bitrate': int(self.panel.bitrate.value()),
            'can_channel': self.panel.channel_combo.currentData(),
            'can_channel_label': self.panel.channel_combo.currentText().strip() if self.panel.channel_combo.count() else '',
            'psu_com_port': self.panel.psu_port_combo.currentData() or '',
            'voltage': float(self.panel.psu_voltage.value()),
        }


@dataclass
class ControlPanelConfigAdapter:
    panel: object
    settings: object
    selected_or_pending_source_key: object
    pending_temp_source_key_getter: object
    pending_pressure_source_key_getter: object

    def temp_controller(self) -> ControllerConfigModel:
        return ControllerConfigModel(
            enabled=self.panel.temp_ctrl_enabled.isChecked(),
            source_key=self.selected_or_pending_source_key(self.panel.temp_source_combo, self.pending_temp_source_key_getter()),
            setpoint=float(self.panel.temp_setpoint.value()),
            deadband=float(self.panel.temp_deadband.value()),
        )

    def pressure_controller(self) -> ControllerConfigModel:
        return ControllerConfigModel(
            enabled=self.panel.pressure_ctrl_enabled.isChecked(),
            source_key=self.selected_or_pending_source_key(self.panel.pressure_source_combo, self.pending_pressure_source_key_getter()),
            setpoint=float(self.panel.pressure_setpoint.value()),
            deadband=float(self.panel.pressure_deadband.value()),
            allow_add_gas=self.panel.pressure_allow_add_gas.isChecked(),
        )

    def agitator(self) -> AgitatorConfigModel:
        return AgitatorConfigModel(
            enabled=self.panel.agitator_enabled.isChecked(),
            target=self.panel.agitator_target_combo.currentData() or getattr(self.settings.agitator, 'target', 'relay'),
            on=self.panel.agitator_on.isChecked(),
            duty_cycle=float(self.panel.agitator_duty.value()),
            mode=str(self.panel.agitator_control_mode.currentData() or 'manual'),
            speed_setpoint_rpm=float(self.panel.agitator_speed_setpoint.value()),
            pid_kp=float(self.panel.agitator_pid_kp.value()),
            pid_ki=float(self.panel.agitator_pid_ki.value()),
            pid_kd=float(self.panel.agitator_pid_kd.value()),
        )


@dataclass
class RelayPanelConfigAdapter:
    panel: object
    relay_channel_rows: dict[int, dict[str, object]]

    def assignments(self) -> dict[str, Optional[str]]:
        return {str(ch): row['combo'].currentData() for ch, row in self.relay_channel_rows.items()}

    def auto_enabled(self) -> dict[str, bool]:
        return {str(ch): bool(row['auto'].isChecked()) for ch, row in self.relay_channel_rows.items()}

    def manual_states(self) -> dict[str, bool]:
        return {str(ch): bool(row['test'].isChecked()) for ch, row in self.relay_channel_rows.items()}

    def relay(self) -> RelayConfigModel:
        return RelayConfigModel(
            host=self.panel.relay_host.currentText().strip(),
            tcp_port=int(self.panel.relay_tcp_port.value()),
            assignments=self.assignments(),
            auto_enabled=self.auto_enabled(),
            manual_states=self.manual_states(),
        )


@dataclass
class SafetyPanelConfigAdapter:
    panel: object
    safety_rules_getter: object

    def safety(self) -> SafetyConfigModel:
        return SafetyConfigModel(
            enabled=self.panel.safety_enabled.isChecked(),
            stale_timeout_s=float(self.panel.safety_stale_timeout.value()),
            min_switch_time_s=float(self.panel.safety_min_switch.value()),
            require_can_connected=self.panel.safety_require_can.isChecked(),
            require_psu_power=self.panel.safety_require_psu.isChecked(),
            require_relays_connected=self.panel.safety_require_relays.isChecked(),
            max_temperature_enabled=self.panel.safety_max_temp_enabled.isChecked(),
            max_temperature_c=float(self.panel.safety_max_temp.value()),
            max_pressure_enabled=self.panel.safety_max_pressure_enabled.isChecked(),
            max_pressure_bar=float(self.panel.safety_max_pressure.value()),
            power_off_psu_on_trip=self.panel.safe_psu_off.isChecked(),
            all_relays_off_on_trip=self.panel.safe_all_relays_off.isChecked(),
            rules=[
                SafetyRuleConfigModel(
                    name=r.name,
                    enabled=r.enabled,
                    signal_key=r.signal_key,
                    operator=r.operator,
                    threshold=r.threshold,
                    threshold_low=r.threshold_low,
                    threshold_high=r.threshold_high,
                    stale_for_s=r.stale_for_s,
                    actions=list(r.actions),
                )
                for r in self.safety_rules_getter()
            ],
            safe_outputs={
                'heat': self.panel.safe_heat.isChecked(),
                'cool': self.panel.safe_cool.isChecked(),
                'add_gas': self.panel.safe_add_gas.isChecked(),
                'remove_gas': self.panel.safe_remove_gas.isChecked(),
                'agitator': self.panel.safe_agitator.isChecked(),
            },
        )


@dataclass
class SchedulerPanelConfigAdapter:
    panel: object
    queries: object

    def scheduler(self) -> SchedulerConfigModel:
        return SchedulerConfigModel(
            enabled=self.panel.scheduler_enabled.isChecked(),
            workbook_path=self.panel.scheduler_path.text().strip(),
            sheet_name=self.panel.scheduler_sheet.currentText().strip(),
            auto_start=self.panel.scheduler_auto_start.isChecked(),
            startup_sequence_enabled=self.panel.scheduler_startup_enabled.isChecked(),
            startup_auto_connect_relays=self.panel.scheduler_startup_connect_relays.isChecked(),
            startup_auto_connect_can=self.panel.scheduler_startup_connect_can.isChecked(),
            startup_auto_power_psu=self.panel.scheduler_startup_power_psu.isChecked(),
            startup_auto_load_twin=self.panel.scheduler_startup_load_twin.isChecked(),
            startup_delay_s=float(self.panel.scheduler_startup_delay.value()),
            startup_show_advanced=self.panel.scheduler_startup_section.toggle_button.isChecked(),
            steps=[
                SchedulerStepConfigModel(
                    index=step.index,
                    enabled=step.enabled,
                    name=step.name,
                    temperature_setpoint=step.temperature_setpoint,
                    temperature_ramp_per_s=step.temperature_ramp_per_s,
                    pressure_setpoint=step.pressure_setpoint,
                    pressure_ramp_per_s=step.pressure_ramp_per_s,
                    allow_add_gas=step.allow_add_gas,
                    wait_type=step.wait_type,
                    wait_source=step.wait_source,
                    operator=step.operator,
                    threshold=step.threshold,
                    threshold_low=step.threshold_low,
                    threshold_high=step.threshold_high,
                    duration_s=step.duration_s,
                    hold_for_s=step.hold_for_s,
                    valid_sources=list(step.valid_sources),
                    require_confirmation=step.require_confirmation,
                    confirmation_message=step.confirmation_message,
                    agitator_on=step.agitator_on,
                    agitator_duty_cycle=step.agitator_duty_cycle,
                )
                for step in self.queries.scheduler_steps()
            ],
        )


@dataclass
class TwinPanelConfigAdapter:
    panel: object
    settings: object
    queries: object

    def collect_input_bindings(self) -> dict[str, Optional[str]]:
        existing = dict(getattr(self.settings.twin, 'input_bindings', {}) or {})
        try:
            existing.update(dict(self.queries.snapshot().twin.input_bindings))
        except Exception:
            pass
        if not self.panel.twin_input_combos:
            return existing
        merged = dict(existing)
        for name, combo in self.panel.twin_input_combos.items():
            if combo.count() <= 0:
                continue
            idx = combo.currentIndex()
            if idx < 0:
                continue
            merged[name] = combo.itemData(idx)
        return merged

    def twin(self) -> TwinConfigModel:
        return TwinConfigModel(
            enabled=self.panel.twin_enabled.isChecked(),
            fmu_path=self.panel.twin_fmu_path.text().strip(),
            input_bindings=self.collect_input_bindings(),
        )
