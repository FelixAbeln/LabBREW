from __future__ import annotations

from application.config_models import (
    AgitatorConfigModel,
    ApplicationConfigModel,
    ControllerConfigModel,
    RelayConfigModel,
    SafetyConfigModel,
    SafetyRuleConfigModel,
    SchedulerConfigModel,
    SchedulerStepConfigModel,
    TwinConfigModel,
)
from settings import (
    AgitatorSettings,
    AppSettings,
    ControllerSettings,
    DigitalTwinSettings,
    RelaySettings,
    SafetyRuleSettings,
    SafetySettings,
    SchedulerSettings,
    SchedulerStepSettings,
)
from state import SafetyRule, SchedulerStep, StateStore


def normalize_control_source_key(key):
    if key is None:
        return None
    if isinstance(key, str):
        return key
    if isinstance(key, (tuple, list)):
        try:
            if len(key) == 2:
                return f"sensor:temperature:{int(key[0])}:{int(key[1])}"
        except Exception:
            return None
    return None


class SettingsMapperService:
    def config_to_settings(self, config: ApplicationConfigModel) -> AppSettings:
        return AppSettings(
            bitrate=int(config.bitrate),
            can_channel=config.can_channel,
            psu_com_port=str(config.psu_com_port or ''),
            voltage=float(config.voltage),
            temp_controller=ControllerSettings(
                enabled=bool(config.temp_controller.enabled),
                source_key=normalize_control_source_key(config.temp_controller.source_key),
                setpoint=float(config.temp_controller.setpoint),
                deadband=float(config.temp_controller.deadband),
                allow_add_gas=bool(config.temp_controller.allow_add_gas),
            ),
            pressure_controller=ControllerSettings(
                enabled=bool(config.pressure_controller.enabled),
                source_key=normalize_control_source_key(config.pressure_controller.source_key),
                setpoint=float(config.pressure_controller.setpoint),
                deadband=float(config.pressure_controller.deadband),
                allow_add_gas=bool(config.pressure_controller.allow_add_gas),
            ),
            agitator=AgitatorSettings(
                enabled=bool(config.agitator.enabled),
                target=str(config.agitator.target or 'relay'),
                on=bool(config.agitator.on),
                duty_cycle=float(config.agitator.duty_cycle),
                mode=str(config.agitator.mode or 'manual'),
                speed_setpoint_rpm=float(config.agitator.speed_setpoint_rpm),
                pid_kp=float(config.agitator.pid_kp),
                pid_ki=float(config.agitator.pid_ki),
                pid_kd=float(config.agitator.pid_kd),
            ),
            relay=RelaySettings(
                host=str(config.relay.host or '127.0.0.1'),
                tcp_port=int(config.relay.tcp_port),
                assignments=dict(config.relay.assignments),
                auto_enabled={str(k): bool(v) for k, v in config.relay.auto_enabled.items()},
            ),
            safety=SafetySettings(
                enabled=bool(config.safety.enabled),
                stale_timeout_s=float(config.safety.stale_timeout_s),
                min_switch_time_s=float(config.safety.min_switch_time_s),
                require_can_connected=bool(config.safety.require_can_connected),
                require_psu_power=bool(config.safety.require_psu_power),
                require_relays_connected=bool(config.safety.require_relays_connected),
                max_temperature_enabled=bool(config.safety.max_temperature_enabled),
                max_temperature_c=float(config.safety.max_temperature_c),
                max_pressure_enabled=bool(config.safety.max_pressure_enabled),
                max_pressure_bar=float(config.safety.max_pressure_bar),
                power_off_psu_on_trip=bool(config.safety.power_off_psu_on_trip),
                all_relays_off_on_trip=bool(config.safety.all_relays_off_on_trip),
                rules=[SafetyRuleSettings(
                    name=r.name,
                    enabled=bool(r.enabled),
                    signal_key=str(r.signal_key or ''),
                    operator=str(r.operator or '>'),
                    threshold=r.threshold,
                    threshold_low=r.threshold_low,
                    threshold_high=r.threshold_high,
                    stale_for_s=float(r.stale_for_s),
                    actions=list(r.actions),
                ) for r in config.safety.rules],
                safe_outputs=dict(config.safety.safe_outputs),
            ),
            scheduler=SchedulerSettings(
                enabled=bool(config.scheduler.enabled),
                workbook_path=str(config.scheduler.workbook_path or ''),
                sheet_name=str(config.scheduler.sheet_name or ''),
                auto_start=bool(config.scheduler.auto_start),
                startup_sequence_enabled=bool(config.scheduler.startup_sequence_enabled),
                startup_auto_connect_relays=bool(config.scheduler.startup_auto_connect_relays),
                startup_auto_connect_can=bool(config.scheduler.startup_auto_connect_can),
                startup_auto_power_psu=bool(config.scheduler.startup_auto_power_psu),
                startup_auto_load_twin=bool(config.scheduler.startup_auto_load_twin),
                startup_delay_s=float(config.scheduler.startup_delay_s),
                startup_show_advanced=bool(config.scheduler.startup_show_advanced),
                steps=[SchedulerStepSettings(
                    index=int(step.index),
                    enabled=bool(step.enabled),
                    name=str(step.name or ''),
                    temperature_setpoint=step.temperature_setpoint,
                    temperature_ramp_per_s=step.temperature_ramp_per_s,
                    pressure_setpoint=step.pressure_setpoint,
                    pressure_ramp_per_s=step.pressure_ramp_per_s,
                    allow_add_gas=step.allow_add_gas,
                    wait_type=str(step.wait_type or 'elapsed_time'),
                    wait_source=str(step.wait_source or ''),
                    operator=str(step.operator or '>='),
                    threshold=step.threshold,
                    threshold_low=step.threshold_low,
                    threshold_high=step.threshold_high,
                    duration_s=step.duration_s,
                    hold_for_s=float(step.hold_for_s or 0.0),
                    valid_sources=list(step.valid_sources),
                    require_confirmation=bool(step.require_confirmation),
                    confirmation_message=str(step.confirmation_message or ''),
                    agitator_on=step.agitator_on,
                    agitator_duty_cycle=step.agitator_duty_cycle,
                ) for step in config.scheduler.steps],
            ),
            twin=DigitalTwinSettings(
                enabled=bool(config.twin.enabled),
                fmu_path=str(config.twin.fmu_path or ''),
                input_bindings=dict(config.twin.input_bindings),
            ),
        )

    def apply_settings_to_state(self, state_store: StateStore, settings: AppSettings, *, can_channel_label: str | None = None, relay_manual_states: dict[int, bool] | None = None) -> None:
        s = settings
        channel_label = str(can_channel_label if can_channel_label is not None else (f'Channel {s.can_channel}' if s.can_channel is not None else ''))
        state_store.set_can_config(channel=s.can_channel, channel_label=channel_label, bitrate=int(s.bitrate))
        state_store.set_psu_config(port=str(s.psu_com_port or ''), set_voltage=float(s.voltage))
        state_store.set_controller_config(
            'temperature',
            enabled=bool(s.temp_controller.enabled),
            source_key=normalize_control_source_key(s.temp_controller.source_key),
            setpoint=float(s.temp_controller.setpoint),
            deadband=float(s.temp_controller.deadband),
        )
        state_store.set_controller_config(
            'pressure',
            enabled=bool(s.pressure_controller.enabled),
            source_key=normalize_control_source_key(s.pressure_controller.source_key),
            setpoint=float(s.pressure_controller.setpoint),
            deadband=float(s.pressure_controller.deadband),
            allow_add_gas=bool(s.pressure_controller.allow_add_gas),
        )
        state_store.set_agitator_config(
            enabled=bool(s.agitator.enabled),
            target=str(getattr(s.agitator, 'target', 'relay') or 'relay'),
            on=bool(s.agitator.on),
            duty_cycle=float(s.agitator.duty_cycle),
            mode=str(s.agitator.mode or 'manual'),
            speed_setpoint_rpm=float(s.agitator.speed_setpoint_rpm),
            pid_kp=float(s.agitator.pid_kp),
            pid_ki=float(s.agitator.pid_ki),
            pid_kd=float(s.agitator.pid_kd),
        )
        state_store.set_safety_config(
            enabled=bool(s.safety.enabled),
            stale_timeout_s=float(s.safety.stale_timeout_s),
            min_switch_time_s=float(s.safety.min_switch_time_s),
            require_can_connected=bool(s.safety.require_can_connected),
            require_psu_power=bool(s.safety.require_psu_power),
            require_relays_connected=bool(s.safety.require_relays_connected),
            max_temperature_enabled=bool(s.safety.max_temperature_enabled),
            max_temperature_c=float(s.safety.max_temperature_c),
            max_pressure_enabled=bool(s.safety.max_pressure_enabled),
            max_pressure_bar=float(s.safety.max_pressure_bar),
            power_off_psu_on_trip=bool(s.safety.power_off_psu_on_trip),
            all_relays_off_on_trip=bool(s.safety.all_relays_off_on_trip),
            rules=[SafetyRule(
                name=r.name,
                enabled=bool(r.enabled),
                signal_key=str(r.signal_key or ''),
                operator=str(r.operator or '>'),
                threshold=r.threshold,
                threshold_low=r.threshold_low,
                threshold_high=r.threshold_high,
                stale_for_s=float(r.stale_for_s),
                actions=list(r.actions),
            ) for r in s.safety.rules],
            safe_outputs=dict(s.safety.safe_outputs),
        )
        state_store.set_twin_config(
            enabled=bool(s.twin.enabled),
            fmu_path=str(s.twin.fmu_path or ''),
            input_bindings=dict(s.twin.input_bindings),
        )
        state_store.set_scheduler_config(
            enabled=bool(s.scheduler.enabled),
            workbook_path=str(s.scheduler.workbook_path or ''),
            sheet_name=str(s.scheduler.sheet_name or ''),
            auto_start=bool(s.scheduler.auto_start),
            steps=[SchedulerStep(
                index=int(step.index),
                enabled=bool(step.enabled),
                name=str(step.name or ''),
                temperature_setpoint=step.temperature_setpoint,
                temperature_ramp_per_s=step.temperature_ramp_per_s,
                pressure_setpoint=step.pressure_setpoint,
                pressure_ramp_per_s=step.pressure_ramp_per_s,
                allow_add_gas=step.allow_add_gas,
                wait_type=str(step.wait_type or 'elapsed_time'),
                wait_source=str(step.wait_source or ''),
                operator=str(step.operator or '>='),
                threshold=step.threshold,
                threshold_low=step.threshold_low,
                threshold_high=step.threshold_high,
                duration_s=step.duration_s,
                hold_for_s=float(step.hold_for_s or 0.0),
                valid_sources=list(step.valid_sources),
                require_confirmation=bool(step.require_confirmation),
                confirmation_message=str(step.confirmation_message or ''),
                agitator_on=step.agitator_on,
                agitator_duty_cycle=step.agitator_duty_cycle,
            ) for step in s.scheduler.steps],
        )
        channel_count = max(8, len(getattr(s.relay, 'assignments', {}) or {}), len(getattr(s.relay, 'auto_enabled', {}) or {}), len(relay_manual_states or {}))
        assignments = {i: None for i in range(1, channel_count + 1)}
        assignments.update({int(k): v for k, v in (s.relay.assignments or {}).items()})
        auto_enabled = {i: True for i in range(1, channel_count + 1)}
        auto_enabled.update({int(k): bool(v) for k, v in (s.relay.auto_enabled or {}).items()})
        manual_states = {i: False for i in range(1, channel_count + 1)}
        manual_states.update({int(k): bool(v) for k, v in (relay_manual_states or {}).items()})
        state_store.set_relay_config(
            host=str(s.relay.host or '127.0.0.1'),
            tcp_port=int(s.relay.tcp_port),
            channel_count=channel_count,
            assignments=assignments,
            auto_enabled=auto_enabled,
            manual_states=manual_states,
        )

