from __future__ import annotations

from typing import Callable, Optional

from PySide6.QtCore import QObject, QTimer, Signal

from application.registry import AppRegistry
from state import AppState, ControllerInstanceState, StateStore
from services.integrations.can import CANService
from services.features.control import DeadbandControlService
from services.features.twin import DigitalTwinService
from services.integrations.psu import PSUService
from services.features.relay import RelayService
from services.features.safety import SafetyService
from services.features.scheduler import SchedulerService
from services.signal_registry import make_signal_key, signal_lookup


class AppRuntimeService(QObject):
    status = Signal(str)
    cycle_completed = Signal()
    command_failed = Signal(str, str)

    def __init__(
        self,
        *,
        state_store: StateStore,
        can_service: CANService,
        psu_service: PSUService,
        control_service: DeadbandControlService,
        safety_service: SafetyService,
        digital_twin_service: DigitalTwinService,
        relay_service: RelayService,
        scheduler_service: SchedulerService,
        registry: AppRegistry,
        scheduler_override: Optional[Callable[[], Optional[dict]]] = None,
        parent: Optional[QObject] = None,
    ) -> None:
        super().__init__(parent)
        self.state_store = state_store
        self.can_service = can_service
        self.psu_service = psu_service
        self.control_service = control_service
        self.safety_service = safety_service
        self.digital_twin_service = digital_twin_service
        self.relay_service = relay_service
        self.scheduler_service = scheduler_service
        self.registry = registry
        self._scheduler_override = scheduler_override

        self.psu_poll_timer = QTimer(self)
        self.psu_poll_timer.setInterval(1000)
        self.psu_poll_timer.timeout.connect(self.poll_psu_measurements)

        self.control_timer = QTimer(self)
        self.control_timer.setInterval(250)
        self.control_timer.timeout.connect(self.evaluate_controls)

        self.scheduler_timer = QTimer(self)
        self.scheduler_timer.setInterval(250)
        self.scheduler_timer.timeout.connect(self.evaluate_scheduler)

        self.relay_timer = QTimer(self)
        self.relay_timer.setInterval(250)
        self.relay_timer.timeout.connect(self.sync_relays)

    def start(self) -> None:
        self.psu_poll_timer.start()
        self.control_timer.start()
        self.scheduler_timer.start()
        self.relay_timer.start()

    def stop(self) -> None:
        for timer in (self.psu_poll_timer, self.control_timer, self.scheduler_timer, self.relay_timer):
            timer.stop()

    def request_cycle(self) -> None:
        self.evaluate_scheduler()
        self.evaluate_controls()
        self.sync_relays()

    def on_can_frame(self) -> None:
        self.request_cycle()
        self.digital_twin_service.request_cycle()

    def _emit_failure(self, title: str, message: str) -> None:
        self.command_failed.emit(title, message)
        self.status.emit(f'{title}: {message}')

    def toggle_psu_power(self) -> tuple[bool, str]:
        snap = self.state_store.snapshot()
        try:
            port = snap.psu_port or ''
            voltage = float(snap.psu_set_voltage)
            if snap.psu_power_on:
                self.psu_service.power_off()
                self.state_store.set_psu_state(power_on=False, measured_voltage=None, measured_current=None)
                message = 'PSU output turned off.'
            else:
                self.psu_service.power_on(port, voltage)
                mv, mi = self.psu_service.read_measurements()
                self.state_store.set_psu_state(power_on=True, measured_voltage=mv, measured_current=mi)
                message = f'PSU output turned on at {voltage:.1f} V.'
            self.status.emit(message)
            self.cycle_completed.emit()
            return True, message
        except Exception as exc:
            self.state_store.set_psu_state(power_on=False, measured_voltage=None, measured_current=None)
            self._emit_failure('PSU error', str(exc))
            self.cycle_completed.emit()
            return False, str(exc)

    def ensure_can_connected(self) -> tuple[bool, str]:
        snap = self.state_store.snapshot()
        if snap.can_connected:
            return True, 'CAN already connected'
        channel = snap.can_channel
        if channel is None:
            return False, 'No CAN channel selected'
        bitrate = int(snap.can_bitrate)
        try:
            self.can_service.connect_bus(int(channel), bitrate)
            self.state_store.set_can_connected(True)
            message = f'Connecting CAN on channel {channel} at {bitrate} bit/s…'
            self.status.emit(message)
            self.cycle_completed.emit()
            return True, message
        except Exception as exc:
            self.state_store.set_can_connected(False)
            self._emit_failure('CAN error', str(exc))
            self.cycle_completed.emit()
            return False, str(exc)

    def toggle_can_connection(self) -> tuple[bool, str]:
        snap = self.state_store.snapshot()
        if snap.can_connected:
            self.can_service.disconnect_bus()
            self.state_store.set_can_connected(False)
            message = 'CAN disconnected.'
            self.status.emit(message)
            self.cycle_completed.emit()
            return True, message
        return self.ensure_can_connected()

    def ensure_relays_connected(self) -> tuple[bool, str]:
        snap = self.state_store.snapshot()
        if snap.relay.connected:
            return True, 'Relays already connected'
        host = snap.relay.host.strip()
        tcp_port = int(snap.relay.tcp_port)
        if not host:
            return False, 'No relay IP or host entered'
        try:
            board = self.relay_service.connect(host, tcp_port)
            channel_states = self.relay_service.states()
            self.state_store.set_relay_config(
                host=host,
                tcp_port=tcp_port,
                channel_count=len(board.available_channels()),
                assignments=dict(snap.relay.assignments),
                auto_enabled=dict(snap.relay.auto_enabled),
                manual_states=dict(snap.relay.manual_states),
            )
            self.state_store.set_relay_state(connected=True, channel_states=channel_states)
            message = f'Relays connected on {host}:{tcp_port}.'
            self.status.emit(message)
            self.cycle_completed.emit()
            return True, message
        except Exception as exc:
            self.state_store.set_relay_state(connected=False, channel_states={})
            self._emit_failure('Relay error', str(exc))
            self.cycle_completed.emit()
            return False, str(exc)

    def toggle_relay_connection(self) -> tuple[bool, str]:
        snap = self.state_store.snapshot()
        if snap.relay.connected:
            self.relay_service.disconnect()
            self.state_store.set_relay_state(connected=False, channel_states={})
            message = 'Relays disconnected.'
            self.status.emit(message)
            self.cycle_completed.emit()
            return True, message
        return self.ensure_relays_connected()

    def poll_psu_measurements(self) -> None:
        snap = self.state_store.snapshot()
        if not snap.psu_power_on and not self.psu_service.is_connected:
            return
        try:
            mv, mi = self.psu_service.read_measurements()
            self.state_store.set_psu_state(power_on=snap.psu_power_on, measured_voltage=mv, measured_current=mi)
        except Exception:
            self.state_store.set_psu_state(power_on=snap.psu_power_on, measured_voltage=None, measured_current=None)
        self.cycle_completed.emit()

    def evaluate_scheduler(self) -> None:
        override_result = self._scheduler_override() if self._scheduler_override is not None else None
        result = override_result if override_result is not None else self.scheduler_service.evaluate(self.state_store.snapshot())
        self.state_store.set_scheduler_runtime(
            running=result.get('running', False),
            paused=result.get('paused', False),
            current_step_index=result.get('current_step_index', -1),
            current_step_name=result.get('current_step_name', ''),
            current_step_started_at_monotonic=result.get('current_step_started_at_monotonic'),
            current_step_elapsed_s=result.get('current_step_elapsed_s', 0.0),
            waiting_reason=result.get('waiting_reason', 'Idle'),
            last_transition=result.get('last_transition', ''),
            hold_elapsed_s=result.get('hold_elapsed_s', 0.0),
            schedule_loaded=result.get('schedule_loaded', False),
            awaiting_confirmation=result.get('awaiting_confirmation', False),
            confirmation_message=result.get('confirmation_message', ''),
        )
        actions = list(result.get('active_controller_actions') or [])
        if actions:
            self._apply_scheduler_controller_actions(actions)
        else:
            self._apply_scheduler_targets(
                result.get('active_temperature_setpoint'),
                result.get('active_pressure_setpoint'),
                result.get('active_allow_add_gas'),
                result.get('active_agitator_on'),
                result.get('active_agitator_duty_cycle'),
            )
        self.cycle_completed.emit()

    def _apply_scheduler_controller_actions(self, actions) -> None:
        snapshot = self.state_store.snapshot()
        for action in actions:
            handler = self.registry.get_controller_handler(getattr(action, 'controller_key', None))
            if handler is None:
                continue
            handler.apply_scheduler_action(self.state_store, snapshot, action)
            snapshot = self.state_store.snapshot()

    def _apply_scheduler_targets(
        self,
        temperature_setpoint,
        pressure_setpoint,
        allow_add_gas,
        agitator_on,
        agitator_duty,
    ) -> None:
        snap = self.state_store.snapshot()
        if temperature_setpoint is not None:
            self.state_store.set_controller_config(
                'temperature',
                enabled=snap.controls.temperature.enabled,
                source_key=snap.controls.temperature.source_key,
                setpoint=float(temperature_setpoint),
                deadband=snap.controls.temperature.deadband,
            )
        if pressure_setpoint is not None or allow_add_gas is not None:
            self.state_store.set_controller_config(
                'pressure',
                enabled=snap.controls.pressure.enabled,
                source_key=snap.controls.pressure.source_key,
                setpoint=float(pressure_setpoint if pressure_setpoint is not None else snap.controls.pressure.setpoint),
                deadband=snap.controls.pressure.deadband,
                allow_add_gas=(snap.controls.pressure.allow_add_gas if allow_add_gas is None else bool(allow_add_gas)),
            )
        if agitator_on is not None or agitator_duty is not None:
            ag = snap.controls.agitator
            self.state_store.set_agitator_config(
                enabled=ag.enabled,
                target=ag.target,
                on=ag.on if agitator_on is None else bool(agitator_on),
                duty_cycle=ag.duty_cycle if agitator_duty is None else float(agitator_duty),
                mode=ag.mode,
                speed_setpoint_rpm=ag.speed_setpoint_rpm,
                pid_kp=ag.pid_kp,
                pid_ki=ag.pid_ki,
                pid_kd=ag.pid_kd,
            )

    def evaluate_controls(self) -> None:
        snap = self.state_store.snapshot()
        result = self.control_service.evaluate(snap)
        self.state_store.set_controller_outputs('temperature', **result['temperature'])
        self.state_store.set_controller_outputs('pressure', **result['pressure'])
        dyn_outputs, dyn_states, dyn_process_values = self._evaluate_dynamic_controller_instances(self.state_store.snapshot())
        self.state_store.set_dynamic_controller_runtime(outputs=dyn_outputs, states=dyn_states, process_values=dyn_process_values)

        safety_result = self.safety_service.evaluate(self.state_store.snapshot())
        self.state_store.set_safety_runtime(
            tripped=safety_result.get('tripped', False),
            reason=safety_result.get('reason', 'OK'),
            effective_outputs=safety_result.get('effective_outputs', {}),
            active_rules=safety_result.get('active_rules', []),
            active_actions=safety_result.get('active_actions', []),
        )
        self.update_agitator_runtime()
        snap_after = self.state_store.snapshot()
        if safety_result.get('request_stop_scheduler') and snap_after.scheduler_runtime.running:
            self.scheduler_service.stop()
        elif safety_result.get('request_pause_scheduler') and snap_after.scheduler_runtime.running and not snap_after.scheduler_runtime.paused:
            self.scheduler_service.pause()
        if safety_result.get('request_power_off_psu') and snap_after.psu_power_on:
            try:
                self.psu_service.power_off()
            except Exception as exc:
                self.status.emit(f'PSU safety power-off failed: {exc}')
            self.state_store.set_psu_state(power_on=False)
        self.digital_twin_service.request_cycle()
        self.cycle_completed.emit()

    def _evaluate_dynamic_controller_instances(self, snap: AppState) -> tuple[dict[str, bool], dict[str, str], dict[str, float | None]]:
        outputs: dict[str, bool] = {}
        states: dict[str, str] = {}
        process_values: dict[str, float | None] = {}
        stale_after = float(snap.safety.stale_timeout_s)
        for inst in getattr(snap, 'controller_instances', []) or []:
            record = self._evaluate_dynamic_controller_instance(snap, inst, stale_after)
            key = str(getattr(inst, 'id', '') or getattr(inst, 'target_key', '') or getattr(inst, 'controller_key', '') or 'controller')
            states[key] = record['state_text']
            process_values[key] = record['process_value']
            target_key = str(getattr(inst, 'target_key', '') or '')
            if target_key and record['output_value'] is not None:
                outputs[target_key] = bool(outputs.get(target_key, False) or bool(record['output_value']))
        return outputs, states, process_values

    def _evaluate_dynamic_controller_instance(self, snap: AppState, inst: ControllerInstanceState, stale_after: float) -> dict[str, object]:
        definition = self.registry.get_controller_definition(getattr(inst, 'controller_key', None))
        if definition is None:
            return {'process_value': None, 'output_value': False, 'state_text': 'Unknown controller'}
        if not getattr(inst, 'enabled', False):
            return {'process_value': None, 'output_value': False, 'state_text': 'Disabled'}
        if definition.kind != 'deadband':
            return {'process_value': None, 'output_value': False, 'state_text': f"{definition.label} uses specialized runtime"}
        measurement_kind = str(getattr(inst, 'extra', {}).get('measurement_kind') or getattr(definition, 'measurement_kind', '') or definition.key)
        allow_output_a = bool(getattr(inst, 'extra', {}).get('allow_output_a', True))
        if definition.key == 'pressure' and 'allow_output_a' not in getattr(inst, 'extra', {}):
            allow_output_a = False
        result = self.control_service.evaluate_deadband_controller(
            snap,
            source_key=getattr(inst, 'source_key', None),
            measurement_kind=measurement_kind,
            setpoint=float(getattr(inst, 'setpoint', 0.0) or 0.0),
            deadband=float(getattr(inst, 'deadband', 0.0) or 0.0),
            stale_after=stale_after,
            allow_output_a=allow_output_a,
        )
        output_value = self._select_dynamic_output_value(inst, result)
        return {
            'process_value': result['process_value'],
            'output_value': output_value,
            'state_text': str(result['state_text']),
        }

    def _select_dynamic_output_value(self, inst: ControllerInstanceState, result: dict[str, object]) -> bool:
        target_key = str(getattr(inst, 'target_key', '') or '')
        side = str(getattr(inst, 'extra', {}).get('target_side', '') or '').strip().lower()
        if side not in {'a', 'b'}:
            if target_key.endswith(':cool') or target_key.endswith(':remove_gas'):
                side = 'b'
            else:
                side = 'a'
        return bool(result['output_a'] if side == 'a' else result['output_b'])

    def update_agitator_runtime(self) -> None:
        snap = self.state_store.snapshot()
        cfg = snap.controls.agitator
        eff = snap.safety_runtime.effective_outputs or {}
        allowed_by_safety = bool(eff.get('agitator', True))
        effective_on = bool(cfg.enabled and cfg.on and allowed_by_safety)
        rpm_feedback = None
        pid_active = False
        target_rpm = None
        state_text = 'Disabled' if not cfg.enabled else ('Stopped (0% command)' if not cfg.on else ('Blocked by safety — 0% command' if not allowed_by_safety else 'Relay virtual output active'))
        target = str(cfg.target or 'relay')
        is_can = target.startswith('can:')
        if is_can:
            try:
                node_id = int(target.split(':', 1)[1])
            except Exception:
                node_id = None
            if node_id is not None:
                rec = signal_lookup(snap).get(make_signal_key('sensor', 'rpm', 6, node_id))
                if rec is not None and rec.value is not None:
                    try:
                        rpm_feedback = float(rec.value)
                    except Exception:
                        rpm_feedback = None
                commanded_duty, pid_active = self.control_service.agitator_pid.compute(
                    enabled=cfg.enabled,
                    mode=getattr(cfg, 'mode', 'manual'),
                    is_can_target=True,
                    requested_on=cfg.on,
                    allowed=allowed_by_safety,
                    manual_duty=float(cfg.duty_cycle),
                    speed_setpoint_rpm=float(getattr(cfg, 'speed_setpoint_rpm', 0.0)),
                    rpm_feedback=rpm_feedback,
                    kp=float(getattr(cfg, 'pid_kp', 0.30)),
                    ki=float(getattr(cfg, 'pid_ki', 0.05)),
                    kd=float(getattr(cfg, 'pid_kd', 0.00)),
                )
                if pid_active:
                    target_rpm = float(getattr(cfg, 'speed_setpoint_rpm', 0.0))
                if not self.can_service.is_connected:
                    state_text = 'CAN not connected' if effective_on else 'CAN agitator stopped (0% command)'
                else:
                    try:
                        self.can_service.send_agitator_pwm(node_id, commanded_duty)
                    except Exception as exc:
                        state_text = f'CAN send failed: {exc}'
                    else:
                        if effective_on:
                            if pid_active:
                                if isinstance(rpm_feedback, (int, float)):
                                    state_text = f'CAN node {node_id} PID {commanded_duty:.1f}% → {rpm_feedback:.1f}/{target_rpm:.1f} rpm'
                                else:
                                    state_text = f'CAN node {node_id} PID {commanded_duty:.1f}% → target {target_rpm:.1f} rpm'
                            else:
                                if isinstance(rpm_feedback, (int, float)):
                                    state_text = f'CAN node {node_id} command {commanded_duty:.1f}% → {rpm_feedback:.1f} rpm'
                                else:
                                    state_text = f'CAN node {node_id} command {commanded_duty:.1f}%'
                        elif cfg.on and not allowed_by_safety:
                            if isinstance(rpm_feedback, (int, float)) and rpm_feedback > 1.0:
                                state_text = f'Blocked by safety — 0% command, coasting at {rpm_feedback:.1f} rpm'
                            else:
                                state_text = 'Blocked by safety — 0% command sent'
                        else:
                            if isinstance(rpm_feedback, (int, float)) and rpm_feedback > 1.0:
                                state_text = f'Stopped — 0% command, coasting at {rpm_feedback:.1f} rpm'
                            else:
                                state_text = 'Stopped — 0% command sent'
            else:
                commanded_duty = 0.0
        else:
            commanded_duty, pid_active = self.control_service.agitator_pid.compute(
                enabled=cfg.enabled,
                mode='manual',
                is_can_target=False,
                requested_on=cfg.on,
                allowed=allowed_by_safety,
                manual_duty=100.0,
                speed_setpoint_rpm=0.0,
                rpm_feedback=None,
                kp=0.0,
                ki=0.0,
                kd=0.0,
            )
            commanded_duty = 100.0 if effective_on else 0.0
            if cfg.enabled and cfg.on and allowed_by_safety:
                state_text = 'Relay virtual output active'
        self.state_store.set_agitator_runtime(
            effective_on=effective_on,
            effective_duty_cycle=commanded_duty,
            rpm_feedback=rpm_feedback,
            state_text=state_text,
            target_rpm=target_rpm,
            pid_active=pid_active,
        )

    def desired_relay_states(self, snap: AppState) -> dict[int, bool]:
        outputs = dict(getattr(snap.controls, 'dynamic_outputs', {}) or {})
        if snap.safety_runtime.effective_outputs:
            outputs.update(dict(snap.safety_runtime.effective_outputs))
        else:
            outputs.update({
                'heat': snap.controls.heat_cool.output_a,
                'cool': snap.controls.heat_cool.output_b,
                'add_gas': snap.controls.gas.output_a,
                'remove_gas': snap.controls.gas.output_b,
                'agitator': snap.controls.agitator_runtime.effective_on,
            })
        desired: dict[int, bool] = {}
        for ch in range(1, int(snap.relay.channel_count) + 1):
            assigned = snap.relay.assignments.get(ch)
            auto = snap.relay.auto_enabled.get(ch, True)
            manual = snap.relay.manual_states.get(ch, False)
            desired[ch] = bool(outputs.get(assigned, False)) if auto and assigned else bool(manual)
        return desired

    def sync_relays(self) -> None:
        snap = self.state_store.snapshot()
        if not snap.relay.connected or not self.relay_service.is_connected:
            self.cycle_completed.emit()
            return
        desired = self.desired_relay_states(snap)
        if 'All relays off' in snap.safety_runtime.active_actions:
            desired = {ch: False for ch in desired.keys()}
        try:
            self.relay_service.apply_channel_states(desired)
            states = self.relay_service.states()
            self.state_store.set_relay_state(connected=True, channel_states=states)
        except Exception as exc:
            self.state_store.set_relay_state(connected=False, channel_states={})
            self.status.emit(f'Relay error: {exc}')
        self.digital_twin_service.request_cycle()
        self.cycle_completed.emit()
