from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Protocol, runtime_checkable

from application.registry import ControllerDefinition, OutputTargetRecord
from application.view_models import (
    ControlPanelViewModel,
    DeviceRowViewModel,
    FooterStatusViewModel,
    RelayPanelViewModel,
    SafetyPanelViewModel,
    SchedulerPanelViewModel,
    TwinPanelViewModel,
)
from state import AppState


@dataclass(frozen=True)
class OperatorOption:
    key: str
    meaning: str
    uses_threshold_or_range: bool
    uses_time: bool
    example: str

    @property
    def label(self) -> str:
        return self.key


@dataclass(frozen=True)
class WaitTypeOption:
    key: str
    meaning: str

    @property
    def label(self) -> str:
        return self.key




@dataclass(frozen=True)
class ConfiguredControllerRecord:
    id: str
    controller_key: str
    label: str
    enabled: bool
    source_key: str
    target_key: str
    setpoint: float
    deadband: float
    ramp_per_s: float | None


@dataclass(frozen=True)
class StartupStatus:
    active: bool
    started_at: float
    deadline: float
    message: str
    summary: str


@runtime_checkable
class ApplicationQueries(Protocol):
    def snapshot(self) -> AppState: ...
    def signal_records(self, snapshot: Optional[AppState] = None): ...
    def signal_map(self, snapshot: Optional[AppState] = None): ...
    def signal_value(self, key: str, default: Any = None, snapshot: Optional[AppState] = None): ...
    def twin_input_variables(self): ...
    def twin_output_variables(self): ...
    def twin_runtime_mode(self) -> str: ...
    def twin_model_name(self) -> str: ...
    def twin_status_text(self) -> str: ...
    def latest_twin_result(self) -> dict[str, Any]: ...
    def scheduler_steps(self): ...
    def desired_relay_states(self, snapshot: Optional[AppState] = None) -> dict[int, bool]: ...
    def scheduler_startup_status(self) -> StartupStatus: ...
    def is_scheduler_startup_active(self) -> bool: ...
    def safety_action_labels(self) -> dict[str, str]: ...
    def operator_options(self) -> list[OperatorOption]: ...
    def operator_keys(self) -> list[str]: ...
    def wait_type_options(self) -> list[WaitTypeOption]: ...

    def controller_definitions(self) -> list[ControllerDefinition]: ...
    def configured_controllers(self) -> list[ConfiguredControllerRecord]: ...
    def output_targets(self) -> list[OutputTargetRecord]: ...
    def output_targets_for_controller(self, controller_key: str) -> list[OutputTargetRecord]: ...
    def footer_status(self) -> FooterStatusViewModel: ...
    def device_rows(self, now: Optional[float] = None) -> list[DeviceRowViewModel]: ...
    def control_panel(self) -> ControlPanelViewModel: ...
    def safety_panel(self) -> SafetyPanelViewModel: ...
    def twin_panel(self) -> TwinPanelViewModel: ...
    def scheduler_panel(self) -> SchedulerPanelViewModel: ...
    def relay_panel(self) -> RelayPanelViewModel: ...
