from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Callable, Optional

from application.queries import ConfiguredControllerRecord, OperatorOption, StartupStatus, WaitTypeOption
from application.view_models import (
    ControlPanelViewModel,
    DeviceRowViewModel,
    FooterStatusViewModel,
    RelayChannelViewModel,
    RelayPanelViewModel,
    SafetyPanelViewModel,
    SchedulerPanelViewModel,
    SchedulerStepRowViewModel,
    TwinOutputFieldViewModel,
    TwinPanelViewModel,
)
from helpers import format_node_type
from services.features.twin import DigitalTwinService
from services.core.runtime_service import AppRuntimeService
from services.features.scheduler import SchedulerService
from application.registry import AppRegistry
from services.core.signal_registry_service import SignalRegistryService
from state import AppState, DeviceState, SchedulerStep, StateStore


class AppQueryService:
    """Read-side application query surface for GUI/CLI/web clients."""

    def __init__(
        self,
        *,
        state_store: StateStore,
        runtime_service: AppRuntimeService,
        scheduler_service: SchedulerService,
        digital_twin_service: DigitalTwinService,
        scheduler_startup_state_callback: Optional[Callable[[], dict]] = None,
        scheduler_startup_active_callback: Optional[Callable[[], bool]] = None,
        signal_registry_service: SignalRegistryService,
        registry: AppRegistry,
        settings_callback: Optional[Callable[[], Any]] = None,
    ) -> None:
        self.state_store = state_store
        self.runtime_service = runtime_service
        self.scheduler_service = scheduler_service
        self.digital_twin_service = digital_twin_service
        self._scheduler_startup_state_callback = scheduler_startup_state_callback
        self._scheduler_startup_active_callback = scheduler_startup_active_callback
        self.signal_registry_service = signal_registry_service
        self.registry = registry
        self._settings_callback = settings_callback

    def snapshot(self) -> AppState:
        return self.state_store.snapshot()

    def signal_records(self, snapshot: Optional[AppState] = None):
        snap = snapshot or self.state_store.snapshot()
        return self.signal_registry_service.build_signal_registry(snap)

    def signal_map(self, snapshot: Optional[AppState] = None):
        snap = snapshot or self.state_store.snapshot()
        return self.signal_registry_service.signal_lookup(snap)

    def signal_value(self, key: str, default: Any = None, snapshot: Optional[AppState] = None):
        rec = self.signal_map(snapshot).get(str(key))
        if rec is None:
            return default
        value = getattr(rec, 'value', default)
        return default if value is None else value

    def twin_input_variables(self):
        return self.digital_twin_service.input_variables()

    def twin_output_variables(self):
        return self.digital_twin_service.output_variables()

    def twin_runtime_mode(self) -> str:
        return str(self.digital_twin_service.runtime_mode or '')

    def twin_model_name(self) -> str:
        return str(self.digital_twin_service.model_name or '')

    def twin_status_text(self) -> str:
        return str(self.digital_twin_service.last_status_text or '')

    def latest_twin_result(self) -> dict:
        return self.digital_twin_service.latest_result()

    def scheduler_steps(self):
        return list(self.scheduler_service.steps)

    def desired_relay_states(self, snapshot: Optional[AppState] = None) -> dict[int, bool]:
        snap = snapshot or self.state_store.snapshot()
        return self.runtime_service.desired_relay_states(snap)

    def scheduler_startup_status(self) -> StartupStatus:
        data = self._scheduler_startup_state_callback() if self._scheduler_startup_state_callback is not None else {}
        return StartupStatus(
            active=bool(data.get('active', False)),
            started_at=float(data.get('started_at', 0.0)),
            deadline=float(data.get('deadline', 0.0)),
            message=str(data.get('message', '') or ''),
            summary=str(data.get('summary', '') or ''),
        )

    def is_scheduler_startup_active(self) -> bool:
        if self._scheduler_startup_active_callback is not None:
            return bool(self._scheduler_startup_active_callback())
        return self.scheduler_startup_status().active

    def safety_action_labels(self) -> dict[str, str]:
        return {key: item.label for key, item in self.registry.safety_actions.items()}

    def operator_options(self) -> list[OperatorOption]:
        return [
            OperatorOption(
                key=item.key,
                meaning=item.meaning,
                uses_threshold_or_range=item.uses_threshold_or_range,
                uses_time=item.uses_time,
                example=item.example,
            )
            for item in self.registry.operators.values()
        ]

    def operator_keys(self) -> list[str]:
        return [row.key for row in self.operator_options()]

    def wait_type_options(self) -> list[WaitTypeOption]:
        return [WaitTypeOption(key=item.key, meaning=item.meaning) for item in self.registry.wait_types.values()]

    def controller_definitions(self):
        return list(self.registry.controllers.values())


    def configured_controllers(self):
        settings = self._settings_callback() if self._settings_callback is not None else None
        items = []
        for inst in getattr(settings, 'controller_instances', []) or []:
            items.append(ConfiguredControllerRecord(
                id=str(getattr(inst, 'id', '') or ''),
                controller_key=str(getattr(inst, 'controller_key', '') or ''),
                label=str(getattr(inst, 'label', '') or ''),
                enabled=bool(getattr(inst, 'enabled', False)),
                source_key=str(getattr(inst, 'source_key', '') or ''),
                target_key=str(getattr(inst, 'target_key', '') or ''),
                setpoint=float(getattr(inst, 'setpoint', 0.0) or 0.0),
                deadband=float(getattr(inst, 'deadband', 1.0) or 1.0),
                ramp_per_s=getattr(inst, 'ramp_per_s', None),
            ))
        return items


    def output_targets(self, snapshot: Optional[AppState] = None):
        snap = snapshot or self.state_store.snapshot()
        records = []
        for provider in self.registry.output_target_providers.values():
            records.extend(provider.provider(snap))
        return sorted(records, key=lambda rec: (rec.family, rec.label, rec.key))

    def output_targets_for_controller(self, controller_key: str):
        controller = self.registry.controllers.get(str(controller_key))
        if controller is None:
            return []
        allowed_families = set(controller.target_families)
        return [
            rec for rec in self.output_targets()
            if rec.family in allowed_families and (not rec.controller_keys or controller.key in rec.controller_keys)
        ]

    def footer_status(self) -> FooterStatusViewModel:
        snap = self.state_store.snapshot()
        return FooterStatusViewModel(
            can_connected=bool(snap.can_connected),
            psu_power_on=bool(snap.psu_power_on),
            relay_connected=bool(snap.relay.connected),
            twin_runtime_active=bool(snap.twin.enabled and self.twin_runtime_mode() == 'runtime'),
            status_message=str(snap.last_status_message or ''),
        )

    def _device_status_text(self, age_s: float) -> str:
        if age_s <= 3:
            return 'Online'
        if age_s <= 10:
            return 'Idle'
        return 'Stale'

    def _format_measurements(self, st: DeviceState) -> str:
        parts = []
        if st.pressure is not None:
            parts.append(f'Pressure {st.pressure:.3f} bar')
        if st.density is not None:
            parts.append(f'Density {st.density:.6f}')
        if st.temperature is not None:
            parts.append(f'Temp {st.temperature:.1f} °C')
        if st.level is not None:
            parts.append(f'Level {st.level:.3f}')
        if st.rpm is not None:
            parts.append(f'RPM {st.rpm:.1f}')
        if st.min_val is not None or st.max_val is not None:
            lo = f'{st.min_val:.3f}' if st.min_val is not None else '—'
            hi = f'{st.max_val:.3f}' if st.max_val is not None else '—'
            parts.append(f'Range {lo}..{hi}')
        return '  •  '.join(parts) if parts else '—'

    def device_rows(self, now: Optional[float] = None) -> list[DeviceRowViewModel]:
        snap = self.state_store.snapshot()
        current = float(now if now is not None else time.time())
        rows: list[DeviceRowViewModel] = []
        for st in sorted(snap.devices.values(), key=lambda x: (x.sender_node_type, x.node_id)):
            age_s = max(0.0, current - st.last_seen)
            status = self._device_status_text(age_s)
            rows.append(DeviceRowViewModel(
                device_label=format_node_type(st.sender_node_type),
                node_label=str(st.node_id),
                last_seen_text=time.strftime('%H:%M:%S', time.localtime(st.last_seen)),
                status_text=status,
                measurements_text=self._format_measurements(st),
                is_stale=status == 'Stale',
            ))
        return rows

    def control_panel(self) -> ControlPanelViewModel:
        snap = self.state_store.snapshot()
        hc = snap.controls.heat_cool
        gas = snap.controls.gas
        eff = snap.safety_runtime.effective_outputs
        ag = snap.controls.agitator_runtime
        if isinstance(ag.rpm_feedback, (int, float)) and ag.pid_active and isinstance(ag.target_rpm, (int, float)):
            agitator_rpm_text = f'{ag.rpm_feedback:.1f} / {ag.target_rpm:.1f} rpm'
        else:
            agitator_rpm_text = f'{ag.rpm_feedback:.1f} rpm' if isinstance(ag.rpm_feedback, (int, float)) else '—'
        return ControlPanelViewModel(
            temperature_pv_text=f'{hc.process_value:.1f} °C' if isinstance(hc.process_value, (int, float)) else '—',
            temperature_state_text=str(hc.state_text or '—'),
            pressure_pv_text=f'{gas.process_value:.3f} bar' if isinstance(gas.process_value, (int, float)) else '—',
            pressure_state_text=str(gas.state_text or '—'),
            heat_active=bool(eff.get('heat', hc.output_a)),
            cool_active=bool(eff.get('cool', hc.output_b)),
            add_gas_active=bool(eff.get('add_gas', gas.output_a)),
            remove_gas_active=bool(eff.get('remove_gas', gas.output_b)),
            agitator_active=bool(eff.get('agitator', ag.effective_on)),
            agitator_rpm_text=agitator_rpm_text,
            agitator_commanded_text=f'{ag.effective_duty_cycle:.1f} %' if isinstance(ag.effective_duty_cycle, (int, float)) else '—',
            agitator_state_text=str(ag.state_text or 'Disabled'),
            temperature_band_value=hc.process_value if isinstance(hc.process_value, (int, float)) else None,
            pressure_band_value=gas.process_value if isinstance(gas.process_value, (int, float)) else None,
        )

    def safety_panel(self) -> SafetyPanelViewModel:
        snap = self.state_store.snapshot()
        tripped = snap.safety_runtime.tripped
        return SafetyPanelViewModel(
            state_text=f"TRIPPED — {snap.safety_runtime.reason}" if tripped else 'OK',
            state_style='color: #b00020; font-weight: bold;' if tripped else 'color: #166534; font-weight: bold;',
            effective_outputs_text=', '.join(k.upper() for k, v in snap.safety_runtime.effective_outputs.items() if v) or 'All off',
            active_actions_text=', '.join(snap.safety_runtime.active_actions) or '—',
            event_log_lines=list(snap.event_log[-200:]),
        )

    def twin_panel(self) -> TwinPanelViewModel:
        out = (self.digital_twin_service.latest_result() or {}).get('outputs', {}) or {}
        output_fields: dict[str, TwinOutputFieldViewModel] = {}
        meta_by_name = {getattr(v, 'name', ''): v for v in self.twin_output_variables()}
        for name, value in out.items():
            if name in {'fmu_name', 'status_text', 'runtime_mode', 'step_count', 'sim_time_s', 'last_dt_s', 'last_step_age_s', 'worker_period_s'}:
                continue
            meta = meta_by_name.get(name)
            is_badge = str(getattr(meta, 'var_type', '')).lower() == 'boolean'
            if is_badge:
                value_text = name
                active = bool(value)
            else:
                active = False
                if isinstance(value, (int, float)):
                    value_text = f'{value:.6g}'
                elif value is None:
                    value_text = '—'
                else:
                    value_text = str(value)
            output_fields[name] = TwinOutputFieldViewModel(name=name, value_text=value_text, is_badge=is_badge, active=active)
        return TwinPanelViewModel(
            fmu_name_text=str(out.get('fmu_name', '—')),
            status_text=str(out.get('status_text', 'Idle')),
            runtime_mode_text=str(out.get('runtime_mode', '—')),
            step_count_text=str(out.get('step_count', 0)),
            sim_time_text=f"{out.get('sim_time_s'):.3f} s" if isinstance(out.get('sim_time_s'), (int, float)) else '—',
            last_dt_text=f"{out.get('last_dt_s'):.3f} s" if isinstance(out.get('last_dt_s'), (int, float)) else '—',
            last_age_text=f"{out.get('last_step_age_s'):.3f} s" if isinstance(out.get('last_step_age_s'), (int, float)) else '—',
            worker_period_text=f"{out.get('worker_period_s'):.3f} s" if isinstance(out.get('worker_period_s'), (int, float)) else '—',
            output_fields=output_fields,
        )

    def _format_scheduler_condition(self, step: SchedulerStep) -> str:
        if step.wait_type in {'elapsed_time', 'time', 'duration'}:
            return f'{step.duration_s or 0:.0f} s'
        if step.wait_type in {'signal', 'signal_threshold', 'threshold', 'twin_threshold'}:
            if step.operator == 'in_range':
                return f'[{step.threshold_low}, {step.threshold_high}] hold {step.hold_for_s:.0f}s'
            if step.operator == 'out_of_range':
                return f'outside [{step.threshold_low}, {step.threshold_high}] hold {step.hold_for_s:.0f}s'
            if step.operator in {'stale', 'valid_for'}:
                return f'{step.operator} {step.hold_for_s:.0f}s'
            if step.operator in {'invalid', 'true', 'false'}:
                return step.operator
            return f'{step.operator} {step.threshold} hold {step.hold_for_s:.0f}s'
        if step.wait_type in {'all_valid', 'valid_all', 'valid'}:
            return f'valid {step.hold_for_s:.0f}s'
        return ''

    def _format_scheduler_step_row(self, step: SchedulerStep, *, is_active: bool) -> SchedulerStepRowViewModel:
        temp_text = '—'
        if step.temperature_setpoint is not None:
            temp_text = f'{step.temperature_setpoint:.3g}'
            if step.temperature_ramp_per_s not in (None, 0):
                temp_text += f' : {step.temperature_ramp_per_s:.3g}/s'
        pressure_text = '—'
        if step.pressure_setpoint is not None:
            pressure_text = f'{step.pressure_setpoint:.3g}'
            if step.pressure_ramp_per_s not in (None, 0):
                pressure_text += f' : {step.pressure_ramp_per_s:.3g}/s'
        gas_text = 'Default' if step.allow_add_gas is None else ('Allow' if step.allow_add_gas else 'Natural only')
        if step.agitator_duty_cycle is not None:
            agitator_value = float(step.agitator_duty_cycle)
            agitator_text = f'{agitator_value:.0f}%' if abs(agitator_value - round(agitator_value)) < 1e-9 else f'{agitator_value:.1f}%'
        elif step.agitator_on is True:
            agitator_text = 'On'
        elif step.agitator_on is False:
            agitator_text = 'Off'
        else:
            agitator_text = 'Default'
        return SchedulerStepRowViewModel(
            index_text=str(step.index),
            enabled_text='Yes' if step.enabled else 'No',
            name_text=str(step.name or ''),
            temperature_text=temp_text,
            pressure_text=pressure_text,
            gas_text=gas_text,
            agitator_text=agitator_text,
            wait_type_text=str(step.wait_type or ''),
            wait_source_text=str(step.wait_source or ', '.join(step.valid_sources)),
            condition_text=self._format_scheduler_condition(step),
            confirm_text=str(step.confirmation_message or '—'),
            is_active=is_active,
        )

    def scheduler_panel(self) -> SchedulerPanelViewModel:
        snap = self.state_store.snapshot()
        cfg = snap.scheduler
        rt = snap.scheduler_runtime
        starting = self.is_scheduler_startup_active()
        state_text = 'Starting' if starting else ('Waiting confirm' if rt.awaiting_confirmation else ('Running' if rt.running and not rt.paused else ('Paused' if rt.running and rt.paused else 'Stopped')))
        steps = [self._format_scheduler_step_row(step, is_active=(row == rt.current_step_index and rt.running)) for row, step in enumerate(cfg.steps)]
        file_status = f'{len(cfg.steps)} step(s) loaded from {Path(cfg.workbook_path).name}' if cfg.workbook_path and cfg.steps else 'No schedule loaded'
        return SchedulerPanelViewModel(
            state_text=state_text,
            current_step_text=rt.current_step_name or '—',
            elapsed_text=f'{rt.current_step_elapsed_s:.1f} s' if rt.current_step_index >= 0 else '—',
            wait_text=rt.waiting_reason or '—',
            hold_text=f'{rt.hold_elapsed_s:.1f} s' if rt.hold_elapsed_s else '—',
            transition_text=rt.last_transition or '—',
            confirmation_text=rt.confirmation_message or '—',
            file_status_text=file_status,
            start_active=starting or (rt.running and not rt.paused),
            pause_active=rt.running and rt.paused,
            load_active=bool(cfg.steps),
            awaiting_confirmation=rt.awaiting_confirmation,
            steps=steps,
        )

    def relay_panel(self) -> RelayPanelViewModel:
        snap = self.state_store.snapshot()
        channels: list[RelayChannelViewModel] = []
        for ch in range(1, int(snap.relay.channel_count) + 1):
            assigned = snap.relay.assignments.get(ch)
            active = bool(snap.relay.channel_states.get(ch, False))
            auto = bool(snap.relay.auto_enabled.get(ch, True))
            channels.append(RelayChannelViewModel(
                channel=ch,
                assigned_key=assigned,
                active=active,
                auto_enabled=auto,
                config_editable=not snap.relay.connected,
                manual_toggle_enabled=(not auto) and snap.relay.connected,
                manual_button_text='Closed' if active else 'Open',
                active_text='ACTIVE' if not assigned else str(assigned).replace('_', ' ').upper(),
                inactive_text='INACTIVE' if not assigned else str(assigned).replace('_', ' ').upper(),
            ))
        return RelayPanelViewModel(connected=bool(snap.relay.connected), channels=channels)
