from __future__ import annotations

from typing import Any, Callable


Handler = Callable[[dict[str, Any]], Any]


class CommandDispatcher:
    def __init__(self) -> None:
        self._handlers: dict[str, Handler] = {}

    def register(self, cmd: str, handler: Handler) -> None:
        if not isinstance(cmd, str) or not cmd.strip():
            raise ValueError("Command must be a non-empty string")
        self._handlers[cmd] = handler

    def dispatch(self, cmd: str, payload: dict[str, Any]) -> Any:
        handler = self._handlers.get(cmd)
        if handler is None:
            raise RuntimeError(f"Unknown command: {cmd}")
        return handler(payload)

    def list_commands(self) -> list[str]:
        return sorted(self._handlers.keys())
