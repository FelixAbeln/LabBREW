from __future__ import annotations

import socketserver
from pathlib import Path
from typing import Any

from signalstore_core.protocol import (
    encode_message,
    make_error_response,
    make_response,
    read_message,
    validate_request_envelope,
)

from .api import CommandDispatcher
from .engine import ScanEngine
from .loader import PluginRegistry, load_plugin_folder


class RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        while True:
            req_id: str | None = None
            try:
                req = read_message(self.rfile)
                if req is None:
                    break

                cmd, req_id, payload = validate_request_envelope(req)

                if cmd == "subscribe":
                    self.handle_subscribe(req_id=req_id, payload=payload)
                    break

                result = self.server.dispatch(cmd, payload)  # type: ignore[attr-defined]
                resp = make_response(req_id=req_id, result=result)
            except Exception as exc:
                resp = make_error_response(
                    req_id=req_id,
                    error_type=exc.__class__.__name__,
                    message=str(exc),
                )

            self.wfile.write(encode_message(resp))
            self.wfile.flush()

    def handle_subscribe(self, *, req_id: str | None, payload: dict[str, Any]) -> None:
        server = self.server  # type: ignore[attr-defined]
        store = server.engine.store
        names = set(payload.get("names") or [])
        send_initial = bool(payload.get("send_initial", True))

        q = store.subscribe()
        try:
            self.wfile.write(encode_message(make_response(req_id=req_id, result="subscribed")))
            self.wfile.flush()

            if send_initial:
                current = store.records()
                for name, desc in current.items():
                    if names and name not in names:
                        continue
                    self.wfile.write(encode_message({
                        "event": "parameter_snapshot",
                        "name": name,
                        **desc,
                    }))
                self.wfile.flush()

            while True:
                event = q.get()
                event_name = event.get("name")
                if names and event_name and event_name not in names:
                    continue
                self.wfile.write(encode_message(event))
                self.wfile.flush()

        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            store.unsubscribe(q)


class SignalTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, host: str, port: int, engine: ScanEngine, registry: PluginRegistry):
        super().__init__((host, port), RequestHandler)
        self.engine = engine
        self.registry = registry
        self.dispatcher = CommandDispatcher()
        self._register_handlers()

    def _register_handlers(self) -> None:
        d = self.dispatcher
        d.register("ping", self._cmd_ping)
        d.register("stats", self._cmd_stats)
        d.register("graph_info", self._cmd_graph_info)
        d.register("snapshot", self._cmd_snapshot)
        d.register("describe", self._cmd_describe)
        d.register("list_parameters", self._cmd_list_parameters)
        d.register("list_plugin_types", self._cmd_list_plugin_types)
        d.register("list_plugin_ui", self._cmd_list_plugin_ui)
        d.register("get_plugin_ui", self._cmd_get_plugin_ui)
        d.register("create_parameter", self._cmd_create_parameter)
        d.register("delete_parameter", self._cmd_delete_parameter)
        d.register("get_value", self._cmd_get_value)
        d.register("set_value", self._cmd_set_value)
        d.register("update_config", self._cmd_update_config)
        d.register("update_metadata", self._cmd_update_metadata)
        d.register("load_plugin_folder", self._cmd_load_plugin_folder)

    def dispatch(self, cmd: str, payload: dict[str, Any]) -> Any:
        return self.dispatcher.dispatch(cmd, payload)

    def _cmd_ping(self, payload: dict[str, Any]) -> str:
        return "pong"

    def _cmd_stats(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.engine.stats()

    def _cmd_graph_info(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.engine.graph_info()

    def _cmd_snapshot(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.engine.store.snapshot()

    def _cmd_describe(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.engine.store.records()

    def _cmd_list_parameters(self, payload: dict[str, Any]) -> list[str]:
        return self.engine.store.list_names()

    def _cmd_list_plugin_types(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.registry.list_types()

    def _cmd_list_plugin_ui(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.registry.list_ui()

    def _cmd_get_plugin_ui(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.registry.get_ui_spec(payload["plugin_type"])

    def _cmd_create_parameter(self, payload: dict[str, Any]) -> bool:
        store = self.engine.store
        spec = self.registry.get(payload["plugin_type"])
        param = spec.create(
            payload["name"],
            config=payload.get("config") or {},
            value=payload.get("value"),
            metadata=payload.get("metadata") or {},
        )
        store.add(param)
        param.on_added(store)
        return True

    def _cmd_delete_parameter(self, payload: dict[str, Any]) -> bool:
        store = self.engine.store
        param = store.remove(payload["name"])
        if param is not None:
            param.on_removed(store)
        return True

    def _cmd_get_value(self, payload: dict[str, Any]) -> Any:
        return self.engine.store.get_value(payload["name"], payload.get("default"))

    def _cmd_set_value(self, payload: dict[str, Any]) -> bool:
        self.engine.store.set_value(payload["name"], payload.get("value"))
        return True

    def _cmd_update_config(self, payload: dict[str, Any]) -> bool:
        self.engine.store.update_config(payload["name"], **(payload.get("changes") or {}))
        return True

    def _cmd_update_metadata(self, payload: dict[str, Any]) -> bool:
        self.engine.store.update_metadata(payload["name"], **(payload.get("changes") or {}))
        return True

    def _cmd_load_plugin_folder(self, payload: dict[str, Any]) -> str:
        return load_plugin_folder(Path(payload["folder"]), self.registry)
