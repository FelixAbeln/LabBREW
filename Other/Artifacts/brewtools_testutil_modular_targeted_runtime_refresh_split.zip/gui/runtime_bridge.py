from __future__ import annotations

from application.view_models import (
    ControlPanelViewModel,
    DeviceRowViewModel,
    FooterStatusViewModel,
    RelayPanelViewModel,
    SafetyPanelViewModel,
    SchedulerPanelViewModel,
    TwinPanelViewModel,
)


class WindowRuntimeBridge:
    """Coordinates targeted cross-panel refresh and runtime-driven GUI updates."""

    def __init__(self, window):
        self.window = window
        self.refresh = None
        self._last_footer_vm: FooterStatusViewModel | None = None
        self._last_device_rows: list[DeviceRowViewModel] | None = None
        self._last_control_vm: ControlPanelViewModel | None = None
        self._last_safety_vm: SafetyPanelViewModel | None = None
        self._last_twin_vm: TwinPanelViewModel | None = None
        self._last_scheduler_vm: SchedulerPanelViewModel | None = None
        self._last_relay_vm: RelayPanelViewModel | None = None
        self._last_signal_keys: list[str] | None = None

    def set_refresh_coordinator(self, refresh) -> None:
        self.refresh = refresh

    def _signal_keys_snapshot(self) -> list[str]:
        return [str(rec.key) for rec in self.window.queries.signal_records()]

    def refresh_footer(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        vm = self.window.queries.footer_status()
        if not force and vm == self._last_footer_vm:
            return False
        self.refresh.footer.refresh()
        self._last_footer_vm = vm
        return True

    def refresh_table(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        rows = self.window.queries.device_rows()
        if not force and rows == self._last_device_rows:
            return False
        self.refresh.devices.refresh_table()
        self._last_device_rows = rows
        return True

    def on_frame(self, frame, obj) -> None:
        if self.refresh is not None and obj is not None:
            self.window.brew_panel.log.appendPlainText(str(obj))
        self.refresh_table()
        signal_keys = self._signal_keys_snapshot()
        if signal_keys != self._last_signal_keys:
            self._last_signal_keys = signal_keys
            self.window.source_controller.refresh_control_sources()
            self.window.source_controller.refresh_twin_sources()

    def refresh_control_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        vm = self.window.queries.control_panel()
        if not force and vm == self._last_control_vm:
            return False
        self.refresh.control.refresh()
        self._last_control_vm = vm
        return True

    def refresh_safety_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        vm = self.window.queries.safety_panel()
        if not force and vm == self._last_safety_vm:
            return False
        self.refresh.safety.refresh()
        self._last_safety_vm = vm
        return True

    def refresh_twin_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        vm = self.window.queries.twin_panel()
        if not force and vm == self._last_twin_vm:
            return False
        self.refresh.twin.refresh()
        self._last_twin_vm = vm
        return True

    def refresh_scheduler_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        vm = self.window.queries.scheduler_panel()
        if not force and vm == self._last_scheduler_vm:
            return False
        self.refresh.scheduler.refresh()
        self._last_scheduler_vm = vm
        return True

    def refresh_relay_panel(self, *, force: bool = False) -> bool:
        if self.refresh is None:
            return False
        vm = self.window.queries.relay_panel()
        if not force and vm == self._last_relay_vm:
            return False
        self.refresh.relays.refresh()
        self._last_relay_vm = vm
        return True

    def refresh_sources(self) -> None:
        self.window.source_controller.refresh_all_sources()
        self._last_signal_keys = self._signal_keys_snapshot()

    def update_agitator_runtime(self) -> None:
        self.window.commands.update_agitator_runtime()

    def refresh_all(self, *, force: bool = False) -> None:
        self.refresh_footer(force=force)
        self.refresh_table(force=force)
        self.refresh_control_panel(force=force)
        self.refresh_safety_panel(force=force)
        self.refresh_twin_panel(force=force)
        self.refresh_scheduler_panel(force=force)
        self.refresh_relay_panel(force=force)
        self._last_signal_keys = self._signal_keys_snapshot()

    def on_runtime_cycle_completed(self) -> None:
        snap = self.window.queries.snapshot()
        self.window.ui_state.loading_scheduler_ui = True
        try:
            changed = self.window.control_panel.apply_scheduler_targets(
                snap.controls.temperature.setpoint,
                snap.controls.pressure.setpoint,
                snap.controls.pressure.allow_add_gas,
                snap.controls.agitator.on,
                snap.controls.agitator.duty_cycle,
            )
        finally:
            self.window.ui_state.loading_scheduler_ui = False
        if changed:
            self.window.config_controller.save_settings_to_state(validate=False)
            self.refresh_control_panel(force=True)
        else:
            self.refresh_control_panel()
        self.refresh_safety_panel()
        self.refresh_scheduler_panel()
        self.refresh_relay_panel()
        self.refresh_footer()
