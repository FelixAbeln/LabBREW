from __future__ import annotations

from PySide6.QtWidgets import QMessageBox

from gui.send_dialog import SendDialog


class WindowDeviceSessionController:
    """Owns device/session actions that used to live as thin MainWindow wrappers."""

    def __init__(self, window):
        self.window = window

    def toggle_psu_power(self) -> None:
        self.window.config_controller.save_settings_to_state()
        self.window.commands.toggle_psu_power()

    def poll_psu_measurements(self) -> None:
        self.window.commands.poll_psu_measurements()

    def toggle_can_connection(self) -> None:
        self.window.config_controller.save_settings_to_state()
        self.window.commands.toggle_can_connection()

    def toggle_relay_connection(self) -> None:
        self.window.config_controller.save_settings_to_state()
        self.window.commands.toggle_relay_connection()

    def open_send_dialog(self) -> None:
        snap = self.window.queries.snapshot()
        if not snap.devices:
            QMessageBox.information(self.window, 'No devices', 'No devices discovered yet. Connect and wait for traffic.')
            return
        dlg = SendDialog(
            self.window,
            snap.devices,
            int(self.window.brew_panel.channel_combo.currentData()),
            int(self.window.brew_panel.bitrate.value()),
        )
        dlg.exec()
