from __future__ import annotations

from application.config_models import ApplicationConfigModel
from gui.panel_config_adapters import (
    BrewPanelConfigAdapter,
    ControlPanelConfigAdapter,
    RelayPanelConfigAdapter,
    SafetyPanelConfigAdapter,
    SchedulerPanelConfigAdapter,
    TwinPanelConfigAdapter,
)


class ApplicationConfigBuilder:
    """Collects GUI form state into application-facing config DTOs."""

    def __init__(self, window):
        self.window = window

    def build(self) -> ApplicationConfigModel:
        w = self.window
        brew = BrewPanelConfigAdapter(w.brew_panel).to_dict()
        control = ControlPanelConfigAdapter(
            panel=w.control_panel,
            settings=w.settings,
            selected_or_pending_source_key=w.source_controller.selected_or_pending_source_key,
            pending_temp_source_key_getter=lambda: w._pending_temp_source_key,
            pending_pressure_source_key_getter=lambda: w._pending_pressure_source_key,
        )
        relay = RelayPanelConfigAdapter(w.relay_panel, w.relay_channel_rows)
        safety = SafetyPanelConfigAdapter(w.safety_panel, lambda: w._safety_rules)
        scheduler = SchedulerPanelConfigAdapter(w.scheduler_panel, w.queries)
        twin = TwinPanelConfigAdapter(w.twin_panel, w.settings, w.queries)
        return ApplicationConfigModel(
            bitrate=int(brew['bitrate']),
            can_channel=brew['can_channel'],
            can_channel_label=str(brew['can_channel_label']),
            psu_com_port=str(brew['psu_com_port']),
            voltage=float(brew['voltage']),
            temp_controller=control.temp_controller(),
            pressure_controller=control.pressure_controller(),
            agitator=control.agitator(),
            relay=relay.relay(),
            safety=safety.safety(),
            scheduler=scheduler.scheduler(),
            twin=twin.twin(),
        )
