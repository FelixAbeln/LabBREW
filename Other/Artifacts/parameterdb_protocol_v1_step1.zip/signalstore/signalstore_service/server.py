from __future__ import annotations

import socketserver
from pathlib import Path
from typing import Any

from signalstore_core.protocol import (
    encode_message,
    make_error_response,
    make_response,
    read_message,
    validate_request_envelope,
)

from .engine import ScanEngine
from .loader import PluginRegistry, load_plugin_folder


class RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        while True:
            req_id: str | None = None
            try:
                req = read_message(self.rfile)
                if req is None:
                    break

                cmd, req_id, payload = validate_request_envelope(req)

                if cmd == "subscribe":
                    self.handle_subscribe(req_id=req_id, payload=payload)
                    break

                result = self.server.dispatch(cmd, payload)  # type: ignore[attr-defined]
                resp = make_response(req_id=req_id, result=result)
            except Exception as exc:
                resp = make_error_response(
                    req_id=req_id,
                    error_type=exc.__class__.__name__,
                    message=str(exc),
                )

            self.wfile.write(encode_message(resp))
            self.wfile.flush()

    def handle_subscribe(self, *, req_id: str | None, payload: dict[str, Any]) -> None:
        server = self.server  # type: ignore[attr-defined]
        store = server.engine.store
        names = set(payload.get("names") or [])
        send_initial = bool(payload.get("send_initial", True))

        q = store.subscribe()
        try:
            self.wfile.write(encode_message(make_response(req_id=req_id, result="subscribed")))
            self.wfile.flush()

            if send_initial:
                current = store.records()
                for name, desc in current.items():
                    if names and name not in names:
                        continue
                    self.wfile.write(encode_message({
                        "event": "parameter_snapshot",
                        "name": name,
                        **desc,
                    }))
                self.wfile.flush()

            while True:
                event = q.get()
                event_name = event.get("name")
                if names and event_name and event_name not in names:
                    continue
                self.wfile.write(encode_message(event))
                self.wfile.flush()

        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            store.unsubscribe(q)


class SignalTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, host: str, port: int, engine: ScanEngine, registry: PluginRegistry):
        super().__init__((host, port), RequestHandler)
        self.engine = engine
        self.registry = registry

    def dispatch(self, cmd: str, payload: dict[str, Any]) -> Any:
        store = self.engine.store

        if cmd == "ping":
            return "pong"
        if cmd == "stats":
            return self.engine.stats()
        if cmd == "graph_info":
            return self.engine.graph_info()
        if cmd == "snapshot":
            return store.snapshot()
        if cmd == "describe":
            return store.records()
        if cmd == "list_parameters":
            return store.list_names()
        if cmd == "list_plugin_types":
            return self.registry.list_types()
        if cmd == "list_plugin_ui":
            return self.registry.list_ui()
        if cmd == "get_plugin_ui":
            return self.registry.get_ui_spec(payload["plugin_type"])
        if cmd == "create_parameter":
            spec = self.registry.get(payload["plugin_type"])
            param = spec.create(
                payload["name"],
                config=payload.get("config") or {},
                value=payload.get("value"),
                metadata=payload.get("metadata") or {},
            )
            store.add(param)
            param.on_added(store)
            return True
        if cmd == "delete_parameter":
            param = store.remove(payload["name"])
            if param is not None:
                param.on_removed(store)
            return True
        if cmd == "get_value":
            return store.get_value(payload["name"], payload.get("default"))
        if cmd == "set_value":
            store.set_value(payload["name"], payload.get("value"))
            return True
        if cmd == "update_config":
            store.update_config(payload["name"], **(payload.get("changes") or {}))
            return True
        if cmd == "update_metadata":
            store.update_metadata(payload["name"], **(payload.get("changes") or {}))
            return True
        if cmd == "load_plugin_folder":
            return load_plugin_folder(Path(payload["folder"]), self.registry)

        raise ValueError(f"Unknown cmd: {cmd}")
