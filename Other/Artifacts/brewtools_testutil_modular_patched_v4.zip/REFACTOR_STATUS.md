# Latest pass
- Fixed the next `StateStore` regression in `state.py`: restored `set_scheduler_runtime()` as a real `StateStore` method so startup can get past `AppRuntimeService.evaluate_scheduler()` during initial settings application.
- Ran a direct state-writer audit for `state_store.set_*` calls across the codebase and verified there are no remaining missing `StateStore` setter methods after this patch.
- Kept the migration trace intact: this confirms the current startup break was another state-surface refactor omission, not a new controller-runtime design failure.

Why this helps:
- The app can now move past scheduler runtime initialization instead of crashing immediately after settings are applied.
- We now have a checked baseline that every currently referenced `state_store.set_*` writer exists on `StateStore`, which reduces the chance of another immediate startup failure of the same class.
- This clears the way for the next cleanup pass to focus on dynamic controller UI/state flow instead of more missing state API fallout.

Still not fully fixed:
- This patch only closes the discovered `StateStore` API gap; it does not yet remove the remaining legacy built-in controller assumptions in UI/query/runtime code.
- Agitator is still on the dedicated legacy path by design for now.
- The next pass should trace the control-panel inventory/table refresh path and remove any code that still synthesizes built-in controllers instead of reading `AppState.controller_instances`.

# Latest pass
- Fixed the `StateStore` refactor regression in `state.py`: restored `set_safety_config`, `set_safety_runtime`, `set_twin_config`, `set_twin_runtime`, `set_scheduler_config`, and the deep-copying `set_controller_instances` as real `StateStore` methods instead of stray module-level functions. This unblocks startup during `AppCore.apply_settings()` and gets the GUI back to the point where it can render operator-defined controllers.
- Removed the duplicate legacy `set_controller_instances` implementation so live controller inventory now has a single authoritative state-write path.
- Tightened the dynamic-controller editor surface to explicitly treat `temperature`, `pressure`, and `agitator` as legacy dedicated controllers; the add/edit dialog now presents only operator-defined controller types instead of inviting new agitator instances.
- Added `NEXT_AGENT_CONTEXT.md` with a focused handoff so the next pass can keep cutting legacy paths without losing the reasoning trail.

Why this helps:
- The app can boot again, which is the prerequisite for proving whether the dynamic controller inventory is actually reaching the UI.
- Controller instances now round-trip through one mutable state path instead of a split between a shallow legacy setter and a half-moved refactor setter.
- Agitator remains available only through its dedicated legacy UI/runtime path for now, which matches the current direction: dynamic inventory should be PI/deadband oriented, not another bespoke agitator configuration surface.

Still not fully fixed:
- The dedicated agitator config/runtime path still exists in state, settings, scheduler compatibility, and control panels; this pass only stops treating it like a dynamic controller candidate.
- There are still legacy built-in assumptions scattered through runtime/query/UI code (`temperature`, `pressure`, `agitator`) that should be collapsed behind registry + instance-state reads.
- The next cleanup pass should verify that the control panel table is sourced only from `AppState.controller_instances` and then start removing duplicated built-in projection logic where it is no longer needed.

- Fixed dynamic controller registry startup: added missing generic deadband/PID controller action handlers in `services/registry_contributions/control_feature.py`.

# Latest pass
- Added first dynamic controller inventory UI in the Control panel with add/edit/remove flows.
- Added generic registry controller types for deadband and PID controllers.
- Added runtime support for generic PID instance evaluation plus dynamic numeric output handling.
- Added Controllers table refresh so the UI shows the actually configured dynamic controllers.

## Latest pass

- Moved dynamic controller instances onto the live app state (`AppState.controller_instances`) instead of only keeping them in saved settings, so runtime/query paths can work from the same mutable source of truth that GUI, headless, and services share.
- Extended `AppRuntimeService.evaluate_controls()` to evaluate configured deadband-style controller instances dynamically and publish their target outputs through `controls.dynamic_outputs`, instead of assuming only the fixed temperature/pressure/agitator inventory exists.
- Updated relay output resolution so dynamic controller target keys can now drive relay assignments directly via registered output-target keys, which is a prerequisite for user-created controllers mapping themselves onto relay outputs without hard-coded cases.
- Tightened dynamic-controller validation with duplicate-id checks and controller-target family compatibility checks, and switched query reads of configured controllers to come from live state instead of the persisted settings object.

Why this helps:
- The runtime now understands a mutable controller inventory instead of treating dynamic controllers as config-only records.
- Controller add/update/remove commands can immediately affect live behavior because the configured controller instances are applied into state and evaluated there.
- Dynamic relay routing is more realistic now: a controller instance can own a registered target key and drive that output without another bespoke hard-coded path.

Still not fully fixed:
- Specialized controllers like the agitator still use bespoke runtime behavior; this pass makes deadband-style dynamic controllers truly runtime-backed first.
- The GUI still needs a real controller manager/editor surface for creating/removing controller instances interactively.
- There are still compatibility wrapper modules in `services/` that can be retired as imports continue moving to package-oriented locations.

## Latest pass

- Added a first-class dynamic controller instance model across the app/config/settings boundary (`ControllerInstanceConfigModel` / `ControllerInstanceSettings`) so controllers can start becoming mutable configured entities instead of only hard-coded built-ins.
- Added command/query support for dynamic controller instances: the app command surface can now add, update, and remove controller instances, and the query surface can enumerate configured controller instances for future UI work.
- Passed the live settings into `AppQueryService` so non-GUI entrypoints can inspect the configured controller inventory without scraping widgets or hard-coding the built-in control set.
- Extended validation so dynamic controller instances are checked against the registry for known controller keys, signal families, output-target families, and sane deadband values.

Why this helps:
- The architecture now has an explicit place to store user-created controller instances, which is the key prerequisite for a mutable controller system.
- Future UI work can build a real add/remove/edit controller manager on top of command/query APIs instead of directly mutating settings blobs.
- Validation and persistence now understand dynamic controller instances, so they can round-trip through save/load paths instead of being an isolated UI concept later.

Still not fully fixed:
- The runtime control evaluator still only performs closed-loop behavior for the built-in temperature/pressure/agitator implementations; dynamic controller instances are persisted/validated/queryable first, not fully executed yet.
- The GUI still does not expose a true add/remove controller manager yet; this pass prepares the service boundary and persistence model for that next step.
- There are still compatibility wrapper modules in `services/` that can be retired as more imports move to the package-oriented paths.

## Latest pass

- Fixed scheduler settings persistence for generic `controller_actions` by adding `controller_actions` to `SchedulerStepSettings` and round-tripping it through settings load/save, unblocking startup after the dynamic controller action pass.
- Added registry-backed controller handlers so runtime scheduler application can dispatch through registered controller behavior instead of hard-coding every controller write path in `AppRuntimeService`.
- Implemented the first generic scheduler action model with `SchedulerControllerAction` plus a new `controller_actions` schedule column using `controller:value:ramp` and `controller.field:value` syntax, while still loading legacy temperature/pressure/agitator columns for backward compatibility.
- Updated scheduler runtime/template/validation paths so controller actions are exported, validated against the controller registry, and applied dynamically at runtime.
- Reduced active dependence on flat top-level service modules by switching the main runtime/query/command paths to package-oriented imports (`services.features.*`, `services.integrations.*`, `services.core.*`) even though compatibility shims still remain for now.

Why this helps:
- Controllers are now closer to being real extensible capabilities instead of only hard-coded UI/service cases.
- Schedule rows can start expressing controller behavior generically, which is the key prerequisite for adding new controllers without redesigning the workbook format every time.
- Runtime application now follows the registry/service ownership direction more closely: features register how controller actions are applied, and the runtime executes those registrations.

Still not fully fixed:
- Control evaluation itself is still built around the existing built-in implementations (`temperature`, `pressure`, `agitator`); this pass makes scheduling/output application dynamic first, not the full closed-loop evaluation path.
- The GUI control editor is still largely built around the current built-in controller set, so truly user-defined controllers will need a later dynamic editor/config pass.
- The service tree is less flat on the active path now, but some compatibility wrapper files still exist and can be retired as imports continue to migrate.

## Latest pass
- Added typed controller and output-target registry definitions (`ControllerDefinition`, `OutputTargetRecord`, `OutputTargetProviderDefinition`) so control capabilities and routable outputs are no longer just implicit hard-coded knowledge.
- Registered the current built-in controllers (`temperature`, `pressure`, `agitator`) and registered dynamic output targets for relay assignments and live agitator outputs, so the registry can now answer “what controllers exist?” and “what can they drive?”
- Extended the query/template path so `AppQueryService` can expose controller definitions and output targets, and `SchedulerTemplateService` now exports `Controllers` and `Output Targets` sheets for discovery/documentation.
- Started unflattening the `services/` tree by adding active `services/application/`, `services/core/`, and `services/features/*` package paths, then rewired the main composition path (`app_core.py`, `core_services.py`, `feature_services.py`) to load from those locations.

Why this helps:
- The app now has a real architectural seam for making controllers extensible instead of baking every controller case into UI/service code.
- Output routing metadata is now explicit and queryable, which is the first step toward dynamic controller-to-output mapping and less hard-coded scheduler/control behavior.
- The exported scheduler template now documents the available controllers/targets that the current app build knows about.
- The folder tree is beginning to match the architecture instead of staying mostly flat.

Still not fully fixed:
- Control evaluation/runtime behavior is still mostly hard-coded around the built-in temperature/pressure/agitator implementations; the registry now describes controllers, but runtime execution does not yet fully dispatch through registered controller handlers.
- Scheduler steps are still column-based for the legacy built-in controllers; the registry groundwork is in place, but the generic `controller | value | ramp` step/action model is not implemented yet.
- Several top-level legacy service modules still exist as compatibility paths while the new package structure settles in.

## Latest pass
- Rebuilt the registry around typed definitions (`OperatorDefinition`, `WaitTypeDefinition`, `SafetyActionDefinition`, `SignalProviderDefinition`) instead of loose dict-heavy entries.
- Added duplicate/conflict checks for signal-provider registration and explicit signal-family registration so startup composition fails fast on bad contributions.
- Split service ownership more cleanly into `CoreServices`, `IntegrationServices`, and `FeatureServices`, moving CAN and PSU under `services/integrations/` instead of treating them like core framework services.
- Integrated validation with the registry service boundary so operators, wait types, safety actions, and signal-key families are validated against the same composed registry used by the app.

## Latest pass
- Added a composed application registry so feature metadata and signal providers register explicitly instead of living in one hard-coded monolith.
- Split service ownership into `SystemServices` (required app services) and `FeatureServices` (brewing/automation capabilities built on top).
- Moved scheduler operators, wait types, safety actions, and signal-provider contributions behind explicit registry registration.

# Latest pass: snapshot clone strategy centralized

Fixed in this pass:
- Replaced the hand-written `StateStore.snapshot()` field-by-field reconstruction with a centralized recursive clone helper in `state.py`.
- The snapshot path now clones dataclasses, dicts, lists, and tuples generically, so newly added state fields no longer require manual snapshot plumbing.
- Kept opaque runtime objects as pass-through values instead of forcing a risky generic deep-copy, which preserves the previous shallow behavior for fields like `last_obj` while still isolating the structured app state.

Why this helps:
- `StateStore.snapshot()` is no longer a brittle maintenance trap where every new field has to be remembered in a long manual copy block.
- The clone strategy is now centralized in one helper instead of being spread across a very large constructor chain.
- This removes one of the last obvious structural weak links in the core state layer.

Still not fully fixed:
- A few GUI collaborators still do broader composition/orchestration work than ideal and can be trimmed further over time.
- There may still be some small legacy helpers/imports left to prune, but the active structure is much cleaner now.

# Latest pass: editor package split + shell trim

Fixed in this pass:
- Split the old monolithic `gui/panel_editors.py` into a real `gui/editors/` package with one editor module per area (`brew`, `control`, `relay`, `safety`, `scheduler`, `twin`) plus a small package-level builder.
- Removed dead editor glue such as the unused `_SignalBinder`, dropped the unused `queries` dependency from `TwinPanelEditor`, and stopped importing no-longer-used helper functions into the editor layer.
- Updated `gui/window_composer.py` to load editors from the new package path, so the active runtime path uses the trimmed structure instead of the old catch-all editor module.

Why this helps:
- The editor layer is now organized by panel/area just like the panels, controllers, and dispatchers.
- The tree is easier to navigate and maintain because edit-state logic no longer lives in one 450-line grab-bag file.
- This trims more refactor residue and makes future panel-local validation/editor work more straightforward.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- A few GUI collaborators still do broad composition work and could be trimmed further over time, but the active GUI tree is now much more area-shaped.

## Patch note: shell composition init-order fix

Fixed in this patch:
- Created `intent_dispatcher` before building panel facades in `gui/window_composer.py`, so facade callbacks like `refresh_twin_panel` and `refresh_scheduler_panel` have a real collaborator during shell construction.
- Kept `runtime_bridge`, validation, and session setup after shell build, since those collaborators depend on constructed panel widgets.

Why this helps:
- It fixes the startup crash caused by `build_panel_facades(...)` reaching for `window.intent_dispatcher` before it existed.
- It also makes the shell-composition order clearer: create facade-visible collaborators first, then build panels, then attach runtime/session collaborators that depend on the built UI.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- `panel_editors.py` and a few remaining GUI collaborators can still be split further by panel/area.
- A few small legacy helpers/imports may still remain and can be trimmed in later passes.


## Latest pass: shell/bootstrap composition trimmed further

Fixed in this pass:
- Added `gui/window_composer.py` and moved collaborator graph construction out of `MainWindowBootstrap`, including UI state creation, controller setup, shell build, editor creation, and runtime/session collaborator setup.
- Added `gui/window_startup.py` and moved startup discovery/settings application/initial validation out of `MainWindowBootstrap`.
- Reduced `gui/window_bootstrap.py` to a thin coordinator that composes the window, applies startup state, and starts the session.

Why this helps:
- Startup and shell composition responsibilities are now separated instead of being bundled into one bootstrap object.
- The active GUI load path is easier to read: compose collaborators, apply startup state, then start the session.
- This trims more shell/bootstrap glue without changing the app-facing behavior.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- Some GUI collaborators, especially `panel_editors.py`, are still broader than ideal and can be split further by panel/area.
- There is still room to trim small leftover legacy helpers/imports in a few GUI modules.


## Latest pass: intent dispatcher extraction and runtime bridge narrowing

Fixed in this pass:
- Added `gui/intent_dispatcher.py` and moved intent-level GUI refresh dispatch there, so presenter refresh routing no longer lives on `WindowRuntimeBridge`.
- `MainWindowSession` now subscribes application intent events directly to `intent_dispatcher` methods instead of broad bridge refresh methods.
- Narrowed `gui/runtime_bridge.py` so it now only owns runtime-side coordination that is not a pure refresh, such as frame-log append, agitator runtime sync, and scheduler target sync.
- Updated bootstrap, controllers, and panel facades to use `intent_dispatcher` for panel refreshes.

Why this helps:
- The old runtime bridge no longer acts like a grab-bag refresh coordinator.
- Intent-level refresh dispatch has a dedicated owner, which makes GUI collaborators easier to understand and easier to split further later.
- Runtime-side sync behavior is now separated from view refresh behavior.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- Some GUI collaborators are still fairly broad and can be split further by area or panel.
- There is still room to trim legacy helper imports and unused compatibility code in a few GUI modules.


## Latest pass: shared validator service + window bootstrap extraction

Fixed in this pass:
- Added `services/config_validation_service.py` and made it the canonical reusable validator service for application configuration.
- `AppCore` now owns `config_validation_service` and enforces validation through that service before applying config, so GUI, headless, and future CLI/web entrypoints share the same validation implementation.
- `gui/validation_controller.py` is now decoration-only; it asks `core.config_validation_service` for validation results instead of owning validation behavior.
- Added `gui/window_bootstrap.py` and moved the remaining window startup/shell composition glue there, including controller creation, facade creation, shell build, editor/session setup, startup discovery, settings load, initial validation, and initial session refresh.
- `gui/main_window.py` is now a much thinner composition root: it sets up core references and delegates the rest to `MainWindowBootstrap`.

Why this helps:
- Validation is no longer only “shared by function”; it now has an explicit reusable service owner below the GUI layer.
- Non-GUI entrypoints can rely on the same validator service through `AppCore`, which tightens the application boundary.
- `MainWindow` lost another large chunk of shell/startup composition glue and is closer to being just a thin Qt shell.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- Some refresh flows are still broader than ideal and could be narrowed with more targeted application events.
- `gui/main_window.py` is thin now, but there is still room to trim unused legacy imports/helpers left behind from the migration.


## Latest pass: richer panel editor models for config harvesting

Fixed in this pass:
- Expanded `gui/panel_field_models.py` from simple apply helpers into richer panel editor/form models with explicit `*FormState` dataclasses for Brew, Control, Relay, Safety, Scheduler, and Twin panels.
- Refactored `gui/config_adapters.py` so config harvesting now reads panel form state first and only then translates that state into application config DTOs.
- Reworked `gui/panel_config_adapters.py` into pure translators from panel form-state models to `application.config_models`, removing direct widget reads from those config adapters.
- Twin input binding collection and control/relay/safety/scheduler field reads are now encapsulated behind panel field adapters instead of being scattered across raw widget-centric config adapter code.

Why this helps:
- Config editing is less widget-centric and more form/editor-model centric.
- It becomes easier to validate, test, or reuse panel config logic without needing live Qt widgets everywhere in the translation layer.
- The boundary between “read UI state” and “build application config” is clearer and more consistent across panels.

Still not fully fixed:
- Some panel field models still read directly from Qt widgets, so there is still room to introduce richer validation objects or editor controllers later.
- `MainWindow` still owns some top-level shell composition and startup wiring, even though much less than before.
- `StateStore.snapshot()` is still manual and brittle.
- Some refresh flows are still broader than ideal and could eventually become more event-targeted.

# Refactor status

## Latest pass: UI state + safety-rule controller extraction

Fixed in this pass:
- Added `gui/ui_state.py` and moved the remaining window-scoped UI flags/state bags out of `MainWindow`, including pending control source keys, combo sync flags, loading flags, and source cache lists.
- Added `gui/safety_rules_controller.py` and moved editable safety-rule state out of `MainWindow`; panels/config adapters now use the controller instead of `window._safety_rules`.
- Centralized `normalize_control_source_key()` in `application/normalization.py` and updated `app_core.py`, `services/settings_mapper_service.py`, and `gui/main_window.py` to import the shared helper instead of copying it.
- Removed dead transitional `gui/window_actions.py`.

Why this helps:
- `MainWindow` lost more compatibility state and no longer acts as the owner of transient GUI rule/edit state.
- Facades now depend less on raw window attributes and more on focused controller/state objects.
- The normalization helper now has one source of truth instead of three copy-pasted implementations.

Still not fully fixed:
- `MainWindow` still owns top-level timer/event orchestration and refresh coordinator composition.
- Config editing is panel-adapter based now, but still fundamentally widget-centric rather than field/controller-object based.
- `StateStore.snapshot()` is still manual and brittle.
- Some refresh paths are still broad and should eventually become more targeted/event-driven.

## Latest pass: control/twin widget builders moved into panel-owned widgets


### Fixed in this pass

1. **Moved the control subgroup builders into `ControlPanel`.**
   - Temperature, pressure, and agitator widget construction now lives in `gui/panels/control_panel.py`.
   - `MainWindow` no longer needs to build those control subgroups itself.

2. **Moved twin input/output group construction and variable-widget rebuild logic into `TwinPanel`.**
   - FMU-driven input/output widget creation now lives in `gui/panels/twin_panel.py`.
   - `MainWindow.refresh_twin_sources()` now delegates to the panel instead of owning the twin widget rebuild path.

3. **Reduced facade leakage from `MainWindow` into the panels.**
   - The control facade no longer passes raw builder callbacks or a widget owner.
   - The twin facade now exposes query/service callbacks the panel needs instead of asking `MainWindow` to build widgets for it.

4. **Moved more control/twin widget access onto real panel objects.**
   - `MainWindow` and presenters now reference `control_panel`/`twin_panel` widgets directly for the migrated areas instead of assuming the window owns those widgets.

## Previously fixed

1. **Removed panel `refs()` compatibility plumbing.**
   - Deleted the `*PanelRefs` dataclasses and `refs()` methods from the GUI panels.
   - `MainWindow` no longer binds panel widget references onto itself via `_bind_panel_refs(...)`.

2. **Introduced explicit panel-facing facades.**
   - Added `gui/panel_facades.py`.
   - Panels now receive a narrower facade instead of depending directly on `MainWindow` as their action host.
   - This is a real step toward controller-style boundaries and away from “the window knows everything.”

3. **Kept panel-local behavior in the panel classes while reducing direct window coupling.**
   - `BrewPanel`, `ControlPanel`, `TwinPanel`, `SchedulerPanel`, `SafetyPanel`, and `RelayPanel` now talk to facade callbacks/services instead of calling `self.window` directly.
   - `SafetyPanel` now owns its own safety action checkbox collection instead of stashing it on the window.

4. **Preserved compileability during the migration.**
   - The updated code compiles after the facade split and `refs()` removal.
   - This pass was structural cleanup, not a behavior redesign.

1. **Moved panel-local handlers into the panel classes.**
   - `ControlPanel` owns source-selection and agitator-mode UI behavior.
   - `TwinPanel` owns FMU browse/load actions.
   - `SchedulerPanel` owns scheduler command handlers and startup-summary UI behavior.
   - `SafetyPanel` owns rule-editor add/update/delete/load/visibility logic.
   - `RelayPanel` owns relay auto/manual toggle handlers.

2. **Moved panel-local signal wiring out of `MainWindow`.**
   - Panel classes now own their local widget wiring.
   - `MainWindow._wire_signals()` is no longer the giant tab-local signal matrix.

3. **Converted tab builders into real panel widget classes.**
   - Replaced builder-style tab functions with dedicated widgets in `gui/panels/`.

4. **Split the main tabs into GUI panel modules.**
   - Added `gui/panels/` and moved top-level tab construction out of the giant `_build_ui()` body.

5. **Extracted GUI refresh/presenter responsibilities out of `MainWindow`.**
   - Added `gui/presenters.py`.
   - Footer, devices, control, safety, scheduler, twin, and relay refresh logic now live in dedicated presenter classes.

6. **Removed the most obvious GUI → state-store boundary violations.**
   - Config/state writes were pushed through config DTOs and command paths instead of direct `StateStore` mutation from the window.

7. **Moved runtime ownership toward core/services.**
   - The app has `AppCore`, commands, queries, events, a headless mode, and view-model-driven reads.
   - The GUI is much less privileged than it was originally.

## Still not fully fixed

1. **`MainWindow` is still too large.**
   - It still owns a lot of shell orchestration, compatibility glue, refresh routing, and file workflow behavior.

2. **Some panel widget access still goes through `MainWindow`-level code paths.**
   - Control/twin builders moved, but the window still contains a lot of panel orchestration and direct widget reads during save/apply flows.
   - The remaining path should keep moving toward panel-facing form adapters/controllers.

3. **Settings/form assembly is still too GUI-heavy.**
   - The write boundary is better.
   - But the GUI still gathers a lot of config/edit state manually instead of using dedicated form adapters or editors.

5. **`StateStore.snapshot()` is still manual and brittle.**
   - The state cloning plumbing has not been modernized yet.

6. **Some command/query methods are still thinner than they should be.**
   - The architecture is increasingly justified now.
   - But some service boundaries could still be sharpened or consolidated.

7. **Higher-level application events are still incomplete.**
   - The UI still refreshes broader sections opportunistically in several places.
   - A cleaner end state is more event-driven and panel-targeted.

## Recommended next steps

1. Move the remaining widget/subgroup builders out of `MainWindow` and into panel-owned builders or controller classes.

2. Remove the temporary `MainWindow.__getattr__` compatibility bridge by migrating remaining window methods to panel/view-model access.

3. Introduce dedicated form adapters or panel controllers for config editing.

4. Replace manual `StateStore.snapshot()` cloning with a safer centralized clone strategy.

5. Tighten the application event surface so panels refresh from higher-level app events instead of broad refresh calls.


## Latest pass: panel widget ownership cleanup

Fixed in this pass:
- Rewired `MainWindow` and `gui/presenters.py` to use panel-owned widgets directly for Brew, Safety, Scheduler, Twin, and Relay controls instead of stale window-level widget names.
- Corrected log panel ownership after the widget mapping pass, so the system log remains a top-level panel and presenters write to `window.log_panel.event_log`.
- This removes another chunk of fake `MainWindow` widget ownership and flushes out migration-time AttributeError paths such as `psu_port_combo` and `lbl_heat`.

Still not fully fixed:
- `MainWindow` still owns too much apply/save workflow and too many UI orchestration methods.
- Some refresh helpers are still window methods rather than panel-local presenters/controllers.
- Settings harvesting is still too GUI-heavy and should keep moving toward panel form adapters / config DTOs.


## Latest patch: Twin source refresh ownership fix

Fixed in this patch:
- `MainWindow.refresh_twin_sources()` now delegates fully to `TwinPanel.refresh_sources()` instead of trying to rebuild twin binding items itself.
- This removes another stale window-owned twin helper path that was left behind after moving twin widget ownership into `TwinPanel`.

Still not fully fixed:
- `MainWindow` still contains several legacy helper methods for control/twin construction that are now effectively dead code and should be removed in a later cleanup pass after verifying no callers remain.
- Save/apply/form harvesting logic is still too concentrated in `MainWindow`.

## Latest pass
- Moved scheduler template workbook generation out of `gui/main_window.py` into `services/scheduler_template_service.py`.
- Added `commands.export_scheduler_template(...)` so the GUI only asks for a path and invokes the command surface.
- Remaining cleanup: move more import/export/config translation helpers out of `MainWindow` the same way.


## Latest pass: window orchestration extraction

Fixed in this pass:
- Added `gui/window_actions.py` and moved panel-facing orchestration callbacks there, including save/apply settings, status updates, port/channel discovery, relay target discovery, scheduler sheet refresh, and template export.
- Added `gui/config_adapters.py` and moved application config harvesting out of `MainWindow` into an explicit `ApplicationConfigBuilder`.
- Updated `gui/panel_facades.py` so panels now depend on `window.actions` for most orchestration callbacks instead of pointing directly at `MainWindow` methods.
- Removed obvious migration residue from `MainWindow`, including the old device-status/measurement formatting helpers and the inline config-harvesting block.

Still not fully fixed:
- `MainWindow` still coordinates several cross-panel refresh and runtime response flows.
- Some facade callbacks still route through `window.actions`, which is cleaner than direct `MainWindow` coupling but still transitional glue until more panel/application controllers exist.
- Settings apply/load is cleaner, but UI-to-config mapping is still widget-centric rather than field-adapter-centric.
- `StateStore.snapshot()` is still manual and brittle.

## Latest pass: coordinator/controller split and panel config adapters

Fixed in this pass:
- Split the old `window.actions` glue into focused GUI-side collaborators:
  - `gui/config_controller.py` for apply/persist flows
  - `gui/discovery_controller.py` for discovery dialogs and pickers
  - `gui/runtime_bridge.py` for cross-panel refresh/runtime coordination
- Updated `gui/panel_facades.py` so panels now depend on these narrower controllers instead of the monolithic `window.actions` object.
- Refactored `gui/config_adapters.py` to compose dedicated panel config adapters from `gui/panel_config_adapters.py` rather than harvesting every field in one giant widget-centric block.
- Moved more cross-panel refresh/runtime response logic out of `MainWindow` into `WindowRuntimeBridge`, including frame handling and runtime-cycle refresh orchestration.

Still not fully fixed:
- `MainWindow` still exposes several compatibility wrapper methods that now only delegate to panels/controllers and can be removed in later cleanup passes.
- The GUI config side is more structured now, but panel edit flows are still widget-driven rather than true field/controller objects with validation boundaries.
- `StateStore.snapshot()` is still manual and brittle.
- Some presenter refresh paths are still broad and could be narrowed further with more targeted events.

- Fixed `runtime_bridge` init order in `MainWindow`.

## Latest pass: source/settings controller split and UI helper extraction

Fixed in this pass:
- Added `gui/source_controller.py` and moved cross-panel source reconciliation there, including control source combo refresh, safety signal source refresh, twin source refresh delegation, and agitator target discovery/rebuild.
- Added `gui/settings_loader.py` and moved the large persisted-settings -> widget application flow out of `MainWindow`.
- Added `gui/ui_helpers.py` and moved reusable UI primitives there, including collapsible section creation, output badge styling, signal-key normalization, combo data lookup, and twin binding combo refresh.
- Updated `gui/panel_facades.py`, presenters, and controllers to depend on those focused helpers/controllers instead of more raw `MainWindow` methods.

Why this helps:
- `MainWindow` owns less cross-panel coordination.
- The old facade callbacks now point less often at window methods and more often at narrower collaborators or reusable GUI helpers.
- Settings load/apply is less widget-centric inside the window itself, which is a step toward cleaner panel-specific edit controllers.

Still not fully fixed:
- `MainWindow` still contains compatibility wrapper methods for panel/controller calls and should keep shrinking.
- The config side still harvests raw widget values, even though it is now panel-adapter-shaped; deeper field/controller validation boundaries are still future work.
- `StateStore.snapshot()` is still manual and brittle.
- Some refresh paths are still broad rather than driven by narrower application events.

## Patch notes

- Fixed a `NameError` in `gui/presenters.py` by importing `set_output_badge` from `gui.ui_helpers`.


## Latest pass: MainWindow compatibility wrapper reduction

Fixed in this pass:
- Removed a large set of thin compatibility wrappers from `gui/main_window.py` and switched callers to use controllers, panels, or helpers directly.
- Added `gui/device_session_controller.py` so Brew/Relay panel actions no longer depend on window-owned toggle/send-dialog wrappers.
- Moved scheduler target application into `ControlPanel.apply_scheduler_targets(...)` and updated `WindowRuntimeBridge` to use the panel directly.
- Updated presenters to call panel methods and controllers directly instead of bouncing through `MainWindow` compatibility methods.
- Removed dead legacy control-group builder methods that were no longer part of the active UI path.

Still not fully fixed:
- `MainWindow` still owns some top-level Qt event wiring and cross-panel refresh objects.
- Settings/config harvesting is panel-adapter based now, but still fundamentally widget-centric rather than field-object/controller based.
- `StateStore.snapshot()` is still manual and brittle.
- Some facade callbacks still depend on window-scoped flags/state bags (`_pending_*`, `_loading_*`, `_safety_rules`).

## Patch notes

- Fixed startup break after wrapper reduction: initial agitator runtime sync now lives in `WindowRuntimeBridge.update_agitator_runtime()` instead of calling a removed `MainWindow._update_agitator_runtime()` wrapper.


## Latest pass: session orchestration split and panel field adapters

Fixed in this pass:
- Added `gui/window_session.py` and moved top-level timer/event orchestration plus refresh coordinator composition out of `MainWindow`.
- `WindowRuntimeBridge` now depends on an injected refresh coordinator instead of `MainWindow._refresh`, so `MainWindow` no longer owns refresh composition directly.
- Replaced the remaining big widget-by-widget settings apply flow with panel-level field adapters in `gui/panel_field_models.py`.
- Updated config harvesting to reuse those panel field models for Brew/Relay reads, reducing more raw widget-centric code.

Why this helps:
- `MainWindow` is now closer to a shell that assembles collaborators and panels, rather than the place that owns timers and runtime-event plumbing.
- Settings/edit flows are still widget-backed, but the access pattern is now panel-form shaped instead of controller code reaching into dozens of individual widgets directly.

Still not fully fixed:
- Some config adapters still read directly from panel widgets and could move further toward richer field objects or validated editor models.
- `WindowRuntimeBridge` still performs some broad refresh fan-out after runtime cycles; a more event-targeted surface would reduce that further.
- `StateStore.snapshot()` is still manual and brittle.


## Latest pass: shell/startup composition split and richer editor objects

Fixed in this pass:
- Added `gui/window_shell.py` and moved top-level shell assembly plus panel signal wiring out of `MainWindow`.
- Added `gui/panel_editors.py` with panel-specific editor objects so config building and settings application depend on editor collaborators instead of constructing field adapters inline.
- Updated `ApplicationConfigBuilder` to read panel form state through `window.editors.*`.
- Updated `WindowSettingsLoader` to apply persisted settings through those editor objects as well.

Why this helps:
- `MainWindow` is closer to a composition root and less of a shell/startup implementation bucket.
- The config/edit path is one step less widget-centric because callers now depend on panel editor collaborators rather than reaching for field adapters directly in multiple places.

Still not fully fixed:
- Panel editor objects still read from live widgets internally; richer validation-oriented editor/controllers are still future work.
- `MainWindow` still owns some top-level startup sequencing/order decisions even though shell assembly and runtime session ownership moved out.
- `StateStore.snapshot()` is still manual and brittle.


## Latest pass
- Reworked `gui/panel_editors.py` so editors own persistent form-state models and update them from Qt signals instead of reading live widget trees during config harvest.
- Simplified `gui/panel_field_models.py` to UI-facing form state dataclasses only.
- Wired twin dynamic input combo rebuilds back into the twin editor so FMU-driven binding widgets stay synchronized without widget-scraping in config adapters.
- Remaining cleanup: richer validation rules still live mostly in widget configuration and `StateStore.snapshot()` is still manual/brittle.


## Latest pass: explicit editor validation rules

Fixed in this pass:
- Added `gui/validation_controller.py` so config validation now lives in explicit controller rules instead of being implied only by widget ranges and combo contents.
- Save/apply flows now validate editor state before persisting configuration, and the loader re-runs validation after startup settings are applied.
- Validation now decorates the relevant panel fields (for example scheduler path, twin FMU path, relay host/port, control source selections, and safety thresholds) and shows a concise status summary when saves are blocked.

Why this helps:
- Validation rules now have a real owner and are no longer mostly implicit in Qt widget setup.
- Editor state stays the source of truth for config building, while validation operates on that state instead of scraping widgets.
- This gives the project a clearer path toward richer editor/controller workflows and future non-Qt frontends.

Still not fully fixed:
- Validation is now explicit, but it is still controller-driven rather than backed by reusable domain-level validator services shared with non-GUI entrypoints.
- `MainWindow` still owns some shell/startup composition glue, even though it is much smaller than before.
- `StateStore.snapshot()` is still manual and brittle.

Patch notes

- Fixed safety validation widget mapping to use `SafetyPanel.safety_rules_table` after panel ownership rename.


## Latest pass
- Moved configuration validation rules into shared `application/config_validation.py`.
- `AppCore.apply_configuration(...)` now validates configs before mutating state, so headless and non-Qt entrypoints use the same rules as the GUI.
- `gui/validation_controller.py` is now a decoration/status layer on top of shared validation results instead of owning the rules itself.

## Latest pass: panel controller package and shell trimming

Fixed in this pass:
- Trimmed `gui/main_window.py` down to the actual thin shell/composition role and removed the leftover legacy import bulk that no longer belonged there.
- Introduced a focused `gui/controllers/` package and split the old broad GUI workflow ownership into panel/window-scoped controllers:
  - `BrewPanelController`
  - `RelayPanelController`
  - `SchedulerPanelController`
  - `WindowSourceController`
- Updated bootstrap and panel facades so the new controller locations are the active runtime path.
- Removed dead transitional files that were no longer used:
  - `gui/discovery_controller.py`
  - `gui/device_session_controller.py`
  - legacy top-level `gui/source_controller.py`
- Stopped shipping `__pycache__` directories in the refactor artifact to reduce noise and make the tree easier to maintain.

Why this helps:
- The GUI tree is easier to read because panel-facing workflows now live in a controller package instead of being scattered across window helpers and transitional files.
- `MainWindow` is now much closer to a real composition root instead of a place that still appears to own half the app.
- Dead files and stale runtime paths are removed, which lowers maintenance risk and makes future moves safer.

Still not fully fixed:
- `WindowRuntimeBridge` still does fairly broad refresh fan-out after runtime cycles; the next step would be event-targeted refresh dispatch.
- `StateStore.snapshot()` is still manual and brittle.
- There is still room to split some remaining GUI collaborators further by panel/domain, but the main tree is now much cleaner and the active load path is explicit.


## Latest pass: targeted runtime refresh dispatch

Fixed in this pass:
- Reworked `gui/runtime_bridge.py` so runtime-driven refreshes are now view-model-aware instead of blindly fanning out across all panels after each cycle.
- Added cached view-model comparisons for footer, device table, control, safety, twin, scheduler, and relay panels, so unchanged panels are not re-rendered.
- Tightened CAN-frame handling so source-combo refreshes only run when discovered signal keys actually change instead of on every decoded frame.
- Simplified `gui/window_session.py` initial refresh to seed sources first and then force one full refresh through the bridge.

Still not fully fixed:
- Runtime refresh is more targeted now, but the event surface is still panel-level rather than truly intent-level (for example, distinct scheduler/safety/control update events from the core).
- `StateStore.snapshot()` is still manual and brittle.
- A few remaining GUI collaborators could still be split further, but the active refresh path is much cleaner now.


## Latest pass: intent-level runtime events

Fixed in this pass:
- Moved runtime refresh dispatch from panel-level cycle fan-out to explicit app intent events emitted by `AppCore`.
- Added intent signals on `application/events.py` for footer, device rows, control, safety, twin, scheduler, relay, and signal-registry changes.
- Reworked `AppCore` to diff query/view-model state and emit only the relevant intent events after runtime cycles, CAN frames, config application, and connection changes.
- Simplified `gui/runtime_bridge.py` so it now reacts to explicit intents instead of maintaining its own view-model diff cache.
- Updated `gui/window_session.py` to bind GUI refresh work directly to those intent events, while keeping `cycle_completed` only for scheduler-target synchronization.

Why this helps:
- Refresh ownership is now driven by application intents rather than a GUI-side guess about which panels might need repainting.
- The GUI bridge became simpler because the core now tells it what changed.
- This makes the event surface much closer to a future web/CLI/headless update model and reduces refresh-policy duplication.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- A few GUI collaborators could still be split further, but runtime refresh dispatch is now intent-level instead of broad panel fan-out.

## Latest pass: smaller GUI collaborators and tree trimming

Fixed in this pass:
- Split the broad intent-refresh collaborator into a dedicated `gui/dispatchers/` package with per-area refresh dispatchers for footer, devices, control, safety, twin, scheduler, and relays.
- Kept `WindowIntentDispatcher` only as a small composition root over those narrower refresh dispatchers instead of the place where all presenter ownership lives.
- Split the old broad source-refresh collaborator into panel-scoped controllers:
  - `ControlSourcesController`
  - `TwinSourcesController`
  - `WindowSourceController` is now only a thin composition wrapper.
- Trimmed leftover migration residue:
  - removed the unused `DeviceTablePresenter.on_frame(...)` path
  - removed stale unused imports in `gui/panel_facades.py` and `gui/panel_editors.py`
  - simplified `ControlPanelEditor` so it no longer carries an unused source-controller dependency.

Why this helps:
- The GUI tree is easier to reason about because refresh ownership and source-refresh ownership are now split by area instead of hidden inside a couple of broad helper objects.
- `WindowIntentDispatcher` and `WindowSourceController` are now much thinner, which makes future panel-by-panel splits safer.
- This also trims more migration residue, which lowers the chance of stale code paths lingering in the active runtime path.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- Some GUI composition/bootstrap classes are now much thinner, but there is still room to trim a few remaining shell-level helper relationships if you want to keep going.

- Patch: fixed `TwinPanelEditor.bind()` to update editor state via `_replace_state(...)` instead of calling a removed `_update(...)` helper.


## Latest pass: session collaborator split
- Split `gui/window_session.py` into a small coordinator plus `gui/session/events.py` and `gui/session/timers.py`.
- Moved runtime event subscriptions into `RuntimeEventSubscriber`.
- Moved confirm-blink/twin-poll timers into `WindowTimers`.
- Trimmed another broad GUI collaborator without changing the active startup path.

## Latest pass: composition/startup checklist split

Fixed in this pass:
- Split `gui/window_composer.py` into small composition pieces under `gui/composition/`:
  - `state.py`
  - `controllers.py`
  - `shell.py`
  - `runtime.py`
- Split startup workflow ownership under `gui/startup/`:
  - `discovery.py`
  - `settings.py`
  - `validation.py`
- Reduced `MainWindowComposer`, `MainWindowStartup`, and `MainWindowBootstrap` so the top-level GUI boot path now reads like a short checklist instead of a bag of mixed helper steps.

Why this helps:
- Composition is now grouped by concern instead of hiding multiple setup responsibilities in one file.
- Startup is easier to follow because discovery, persisted settings, and validation each have their own owner.
- The GUI boot path is cleaner and easier to maintain when new collaborators need to be added or moved.

Still not fully fixed:
- `StateStore.snapshot()` is still manual and brittle.
- There are still a few small helper/import cleanup opportunities, but the top-level GUI load path is now much closer to the intended checklist-style structure.
## 2026-03-17 follow-up patch
- Restored missing `AppRuntimeService` helpers introduced by the dynamic-controller refactor: `_evaluate_dynamic_pid_instance()` and `_apply_dynamic_numeric_outputs()`.
- Added a static audit pass for missing `StateStore.set_*` and `AppRuntimeService._*` call targets to catch more broken refactor edges before handoff.
- Hardened relay state resolution so both legacy keys (`heat`) and refactor keys (`relay_assignment:heat`) work during migration.
- Numeric dynamic outputs now drive CAN agitator targets directly when configured, without blocking startup if CAN is disconnected.


## 2026-03-17 patch
- Repaired `gui/panels/control_panel.py` after prior refactor left the class truncated after `refresh_agitator_control_ui()`.
- Restored operator-defined controller UI methods: `_build_dynamic_controllers_group`, selection/edit/remove handlers, and `refresh_dynamic_controller_table`.
- Dynamic inventory table now renders configured controller instances from `queries.configured_controllers()`.
- Agitator remains outside the operator-defined controller dialog (`LEGACY_CONTROLLER_KEYS` still excludes `agitator`).
- Full `python -m compileall -q .` pass succeeded after patch.
