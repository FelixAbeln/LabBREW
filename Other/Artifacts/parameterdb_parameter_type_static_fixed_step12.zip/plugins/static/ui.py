def get_ui_spec() -> dict:
    return {
        "parameter_type": "static",
        "display_name": "Static Value",
        "description": "Passive retained value changed by external apps or operators.",
        "create": {
            "required": ["name"],
            "defaults": {
                "value": 0,
                "config": {},
                "metadata": {},
            },
        },
        "edit": {
            "allow_rename": False,
            "sections": [
                {
                    "title": "Value",
                    "fields": [
                        {"key": "name", "label": "Name", "type": "string", "required": True, "readonly": True},
                        {"key": "value", "label": "Value", "type": "json"},
                    ],
                },
                {
                    "title": "Metadata",
                    "fields": [
                        {"key": "metadata.unit", "label": "Unit", "type": "string"},
                        {"key": "metadata.comment", "label": "Comment", "type": "text"},
                    ],
                },
            ],
        },
    }
