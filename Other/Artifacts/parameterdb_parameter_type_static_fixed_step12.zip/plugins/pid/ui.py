def get_ui_spec() -> dict:
    return {
        "parameter_type": "pid",
        "display_name": "PID Controller",
        "description": "Reads PV and SP from other parameters and writes output to itself.",
        "create": {
            "required": ["name", "config.pv", "config.sp"],
            "defaults": {
                "value": 0.0,
                "config": {
                    "pv": "",
                    "sp": "",
                    "enable_param": "",
                    "mode_param": "",
                    "manual_out_param": "",
                    "kp": 1.0,
                    "ki": 0.0,
                    "kd": 0.0,
                    "bias": 0.0,
                    "out_min": 0.0,
                    "out_max": 100.0,
                    "manual_out": 0.0,
                },
                "metadata": {},
            },
        },
        "edit": {
            "allow_rename": False,
            "sections": [
                {
                    "title": "Identity",
                    "fields": [
                        {"key": "name", "label": "Name", "type": "string", "readonly": True},
                        {"key": "value", "label": "Current Output", "type": "readonly"},
                    ],
                },
                {
                    "title": "Links",
                    "fields": [
                        {"key": "config.pv", "label": "Process Value", "type": "parameter_ref", "required": True},
                        {"key": "config.sp", "label": "Setpoint", "type": "parameter_ref", "required": True},
                        {"key": "config.enable_param", "label": "Enable Parameter", "type": "parameter_ref"},
                        {"key": "config.mode_param", "label": "Mode Parameter", "type": "parameter_ref"},
                        {"key": "config.manual_out_param", "label": "Manual Output Parameter", "type": "parameter_ref"},
                    ],
                },
                {
                    "title": "Tuning",
                    "fields": [
                        {"key": "config.kp", "label": "Kp", "type": "float", "required": True},
                        {"key": "config.ki", "label": "Ki", "type": "float", "required": True},
                        {"key": "config.kd", "label": "Kd", "type": "float", "required": True},
                        {"key": "config.bias", "label": "Bias", "type": "float"},
                        {"key": "config.out_min", "label": "Output Min", "type": "float", "required": True},
                        {"key": "config.out_max", "label": "Output Max", "type": "float", "required": True},
                        {"key": "config.manual_out", "label": "Manual Output", "type": "float"},
                    ],
                },
                {
                    "title": "State",
                    "fields": [
                        {"key": "state.integral", "label": "Integral", "type": "readonly"},
                        {"key": "state.prev_error", "label": "Previous Error", "type": "readonly"},
                        {"key": "state.error", "label": "Error", "type": "readonly"},
                        {"key": "state.last_error", "label": "Last Error", "type": "readonly"},
                    ],
                },
            ],
        },
    }
