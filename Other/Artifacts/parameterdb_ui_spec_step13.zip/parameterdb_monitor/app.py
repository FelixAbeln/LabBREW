from __future__ import annotations

import argparse
import json
import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk
from typing import Any

from parameterdb_core.client import SignalClient
from parameterdb_core.plugin_ui import deep_copy_payload, get_by_path, set_by_path
import time


class PluginTypeDialog(tk.Toplevel):
    def __init__(self, master: tk.Misc, plugin_map: dict[str, dict[str, Any]]) -> None:
        super().__init__(master)
        self.title("Choose Parameter Type")
        self.geometry("560x420")
        self.transient(master)
        self.grab_set()
        self.result: str | None = None
        self.plugin_map = plugin_map

        root = ttk.Frame(self, padding=10)
        root.pack(fill=tk.BOTH, expand=True)

        ttk.Label(root, text="Choose a parameter type to create:").pack(anchor="w")

        self.filter_var = tk.StringVar()
        ent = ttk.Entry(root, textvariable=self.filter_var)
        ent.pack(fill=tk.X, pady=(6, 8))
        ent.bind("<KeyRelease>", lambda e: self.refresh())

        body = ttk.Frame(root)
        body.pack(fill=tk.BOTH, expand=True)
        self.listbox = tk.Listbox(body)
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.listbox.bind("<Double-1>", lambda e: self.accept())
        self.listbox.bind("<<ListboxSelect>>", lambda e: self.update_details())
        sb = ttk.Scrollbar(body, orient="vertical", command=self.listbox.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.listbox.configure(yscrollcommand=sb.set)

        self.details = tk.Text(root, height=8, wrap="word")
        self.details.pack(fill=tk.BOTH, pady=(8, 8))
        self.details.configure(state="disabled")

        bar = ttk.Frame(root)
        bar.pack(fill=tk.X)
        ttk.Button(bar, text="Cancel", command=self.destroy).pack(side=tk.RIGHT)
        ttk.Button(bar, text="Use Type", command=self.accept).pack(side=tk.RIGHT, padx=6)

        self._visible: list[str] = []
        self.refresh()
        ent.focus_set()

    def refresh(self) -> None:
        needle = self.filter_var.get().strip().lower()
        self.listbox.delete(0, tk.END)
        self._visible = []
        for parameter_type in sorted(self.plugin_map):
            spec = self.plugin_map[parameter_type]
            hay = f"{parameter_type} {spec.get('display_name', '')} {spec.get('description', '')}".lower()
            if needle and needle not in hay:
                continue
            label = f"{parameter_type} — {spec.get('display_name', parameter_type)}"
            self.listbox.insert(tk.END, label)
            self._visible.append(parameter_type)
        if self._visible:
            self.listbox.selection_set(0)
            self.update_details()

    def update_details(self) -> None:
        self.details.configure(state="normal")
        self.details.delete("1.0", "end")
        idxs = self.listbox.curselection()
        if idxs:
            parameter_type = self._visible[idxs[0]]
            spec = self.plugin_map[parameter_type]
            info = {
                "parameter_type": parameter_type,
                "display_name": spec.get("display_name", parameter_type),
                "description": spec.get("description", ""),
                "required": spec.get("create", {}).get("required", []),
            }
            self.details.insert("1.0", json.dumps(info, indent=2))
        self.details.configure(state="disabled")

    def accept(self) -> None:
        idxs = self.listbox.curselection()
        if not idxs:
            return
        self.result = self._visible[idxs[0]]
        self.destroy()


class ParameterEditor(tk.Toplevel):
    def __init__(
        self,
        master: tk.Misc,
        client: SignalClient,
        plugin_ui: dict[str, Any],
        mode: str,
        record: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(master)
        self.client = client
        self.plugin_ui = plugin_ui
        self.mode = mode
        self.record = deep_copy_payload(record or {})
        self.field_vars: dict[str, tuple[tk.Variable | tk.Text, dict[str, Any]]] = {}
        self.result = False
        try:
            self.parameter_names = self.client.list_parameters()
        except Exception:
            self.parameter_names = []

        title = f"{mode.title()} {plugin_ui.get('display_name', plugin_ui.get('parameter_type', 'Parameter'))}"
        self.title(title)
        self.geometry("860x760")
        self.minsize(700, 520)
        self.transient(master)
        self.grab_set()

        root = ttk.Frame(self, padding=10)
        root.pack(fill=tk.BOTH, expand=True)
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)

        header = ttk.Frame(root)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(
            header,
            text=plugin_ui.get("display_name", plugin_ui.get("parameter_type", "Parameter")),
            font=("TkDefaultFont", 11, "bold"),
        ).pack(anchor="w")
        desc = plugin_ui.get("description", "")
        if desc:
            ttk.Label(header, text=desc, wraplength=780, justify="left").pack(anchor="w", pady=(4, 0))

        body = ttk.Panedwindow(root, orient=tk.HORIZONTAL)
        body.grid(row=1, column=0, sticky="nsew")

        form_host = ttk.Frame(body)
        body.add(form_host, weight=4)
        preview_host = ttk.LabelFrame(body, text="Payload Preview", padding=8)
        body.add(preview_host, weight=2)

        self.notebook = ttk.Notebook(form_host)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        self.preview = tk.Text(preview_host, wrap="word", height=20)
        self.preview.pack(fill=tk.BOTH, expand=True)
        self.preview.configure(state="disabled")

        bar = ttk.Frame(root)
        bar.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        self.error_var = tk.StringVar(value="")
        ttk.Label(bar, textvariable=self.error_var, foreground="#b00020").pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(bar, text="Cancel", command=self.destroy).pack(side=tk.RIGHT)
        ttk.Button(bar, text="Save", command=self.on_save).pack(side=tk.RIGHT, padx=6)

        self._build_form()
        self.refresh_preview()

    def _base_data(self) -> dict[str, Any]:
        if self.mode == "create":
            defaults = deep_copy_payload(self.plugin_ui.get("create", {}).get("defaults", {}))
            return {
                "name": defaults.get("name", ""),
                "parameter_type": self.plugin_ui["parameter_type"],
                "value": defaults.get("value"),
                "config": defaults.get("config", {}),
                "state": {},
                "metadata": defaults.get("metadata", {}),
            }
        return {
            "name": self.record.get("name", ""),
            "parameter_type": self.record.get("parameter_type", self.plugin_ui["parameter_type"]),
            "value": self.record.get("value"),
            "config": deep_copy_payload(self.record.get("config", {})),
            "state": deep_copy_payload(self.record.get("state", {})),
            "metadata": deep_copy_payload(self.record.get("metadata", {})),
        }

    def _iter_sections(self) -> list[dict[str, Any]]:
        if self.mode == "create":
            sections = deep_copy_payload(self.plugin_ui.get("create", {}).get("sections", []))
            if not sections:
                sections = deep_copy_payload(self.plugin_ui.get("edit", {}).get("sections", []))
                for section in sections:
                    section["fields"] = [f for f in section.get("fields", []) if not str(f.get("key", "")).startswith("state.")]
                sections = [s for s in sections if s.get("fields")]
        else:
            sections = deep_copy_payload(self.plugin_ui.get("edit", {}).get("sections", []))
        if not sections:
            sections = [
                {
                    "title": "General",
                    "fields": [
                        {"key": "name", "label": "Name", "type": "string", "required": True},
                        {"key": "value", "label": "Value", "type": "json"},
                    ],
                },
                {"title": "Config", "fields": [{"key": "config", "label": "Config", "type": "json"}]},
                {"title": "Metadata", "fields": [{"key": "metadata", "label": "Metadata", "type": "json"}]},
            ]
        return sections

    def _build_form(self) -> None:
        data = self._base_data()
        sections = self._iter_sections()

        if self.mode == "create" and not any(
            field.get("key") == "name"
            for section in sections
            for field in section.get("fields", [])
        ):
            identity = {"title": "Identity", "fields": [{"key": "name", "label": "Name", "type": "string", "required": True}]}
            sections = [identity] + sections

        for section in sections:
            frame = ttk.Frame(self.notebook, padding=10)
            frame.columnconfigure(1, weight=1)
            self.notebook.add(frame, text=section.get("title", "Section"))
            row = 0
            for field in section.get("fields", []):
                key = field["key"]
                ttk.Label(frame, text=field.get("label", key)).grid(row=row, column=0, sticky="nw", padx=(0, 8), pady=6)
                widget, var = self._make_input(frame, field, get_by_path(data, key))
                widget.grid(row=row, column=1, sticky="ew", pady=6)
                help_text = field.get("help", "")
                if help_text:
                    ttk.Label(frame, text=help_text, foreground="#666").grid(row=row + 1, column=1, sticky="w", pady=(0, 4))
                    row += 1
                self.field_vars[key] = (var, field)
                row += 1

    def _bind_change(self, widget: tk.Widget, holder: tk.Variable | tk.Text) -> None:
        if isinstance(holder, tk.Variable):
            holder.trace_add("write", lambda *_: self.refresh_preview())
        elif isinstance(holder, tk.Text):
            widget.bind("<KeyRelease>", lambda e: self.refresh_preview())
            widget.bind("<<Modified>>", lambda e: self._handle_modified(widget))

    def _handle_modified(self, widget: tk.Widget) -> None:
        if isinstance(widget, tk.Text) and widget.edit_modified():
            widget.edit_modified(False)
            self.refresh_preview()

    def _make_input(self, parent: tk.Misc, field: dict[str, Any], value: Any):
        field_type = field.get("type", "string")
        readonly = bool(field.get("readonly")) or field_type == "readonly"

        if field_type in {"text", "code", "json"}:
            wrap = "none" if field_type == "code" else "word"
            text = tk.Text(parent, height=8 if field_type in {"text", "code"} else 6, wrap=wrap)
            initial = ""
            if value is not None:
                if field_type == "json" and not isinstance(value, str):
                    initial = json.dumps(value, indent=2, sort_keys=True)
                else:
                    initial = str(value)
            text.insert("1.0", initial)
            if readonly:
                text.configure(state="disabled")
            self._bind_change(text, text)
            return text, text

        if field_type == "bool":
            var = tk.BooleanVar(value=bool(value))
            widget = ttk.Checkbutton(parent, variable=var)
            if readonly:
                widget.state(["disabled"])
            self._bind_change(widget, var)
            return widget, var

        if field_type in {"parameter_ref", "enum"}:
            options = field.get("options") or self.parameter_names
            if value not in (None, "") and value not in options:
                options = list(options) + [value]
            outer = ttk.Frame(parent)
            outer.columnconfigure(0, weight=1)
            var = tk.StringVar(value="" if value is None else str(value))
            state = "readonly" if not readonly else "disabled"
            combo = ttk.Combobox(outer, textvariable=var, values=list(options), state=state)
            combo.grid(row=0, column=0, sticky="ew")
            if not readonly:
                ttk.Button(outer, text="…", width=3, command=lambda v=var: self._choose_parameter(v)).grid(row=0, column=1, padx=(6, 0))
            self._bind_change(combo, var)
            return outer, var

        if field_type == "parameter_ref_list":
            outer = ttk.Frame(parent)
            outer.columnconfigure(0, weight=1)
            var = tk.StringVar(value=", ".join(value or []))
            entry = ttk.Entry(outer, textvariable=var)
            entry.grid(row=0, column=0, sticky="ew")
            if readonly:
                entry.state(["disabled"])
            else:
                ttk.Button(outer, text="Pick…", command=lambda v=var: self._choose_parameter_list(v)).grid(row=0, column=1, padx=(6, 0))
            self._bind_change(entry, var)
            return outer, var

        shown = "" if value is None else (json.dumps(value) if isinstance(value, (dict, list)) else str(value))
        var = tk.StringVar(value=shown)
        widget = ttk.Entry(parent, textvariable=var)
        if readonly:
            widget.state(["readonly"])
        self._bind_change(widget, var)
        return widget, var

    def _choose_parameter(self, var: tk.StringVar) -> None:
        dlg = PluginTypeDialog(self, {name: {"display_name": name, "description": ""} for name in self.parameter_names})
        self.wait_window(dlg)
        if dlg.result:
            var.set(dlg.result)

    def _choose_parameter_list(self, var: tk.StringVar) -> None:
        current = {x.strip() for x in var.get().split(",") if x.strip()}
        win = tk.Toplevel(self)
        win.title("Choose Parameters")
        win.geometry("320x420")
        win.transient(self)
        win.grab_set()
        vals: dict[str, tk.BooleanVar] = {}
        body = ttk.Frame(win, padding=10)
        body.pack(fill=tk.BOTH, expand=True)
        for name in self.parameter_names:
            bv = tk.BooleanVar(value=name in current)
            vals[name] = bv
            ttk.Checkbutton(body, text=name, variable=bv).pack(anchor="w")
        def apply() -> None:
            picked = [name for name, bv in vals.items() if bv.get()]
            var.set(", ".join(picked))
            win.destroy()
        bar = ttk.Frame(body)
        bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(bar, text="Cancel", command=win.destroy).pack(side=tk.RIGHT)
        ttk.Button(bar, text="Apply", command=apply).pack(side=tk.RIGHT, padx=6)
        self.wait_window(win)

    def _read_field_value(self, spec: dict[str, Any], holder: tk.Variable | tk.Text) -> Any:
        field_type = spec.get("type", "string")
        if isinstance(holder, tk.Text):
            raw = holder.get("1.0", "end").strip()
        else:
            raw = holder.get()
        if field_type == "readonly":
            return raw
        if field_type in {"text", "code", "string", "parameter_ref", "enum"}:
            return raw
        if field_type == "json":
            return None if raw == "" else json.loads(raw)
        if field_type == "bool":
            return bool(raw)
        if field_type == "int":
            return None if raw == "" else int(raw)
        if field_type == "float":
            return None if raw == "" else float(raw)
        if field_type == "parameter_ref_list":
            return [item.strip() for item in raw.split(",") if item.strip()]
        return raw

    def _collect_data(self) -> dict[str, Any]:
        data = self._base_data()
        for key, (holder, spec) in self.field_vars.items():
            set_by_path(data, key, self._read_field_value(spec, holder))
        return data

    def _validate(self, data: dict[str, Any]) -> None:
        required = set(self.plugin_ui.get("create", {}).get("required", []))
        for _, spec in self.field_vars.values():
            if spec.get("required"):
                required.add(spec["key"])
        missing = []
        for path in sorted(required):
            value = get_by_path(data, path)
            if value in (None, "", []):
                missing.append(path)
        if missing:
            raise ValueError("Missing required fields: " + ", ".join(missing))

    def refresh_preview(self) -> None:
        try:
            data = self._collect_data()
            text = json.dumps(data, indent=2, sort_keys=True)
            self.error_var.set("")
        except Exception as exc:
            text = f"Invalid form data:\n{exc}"
            self.error_var.set(str(exc))
        self.preview.configure(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", text)
        self.preview.configure(state="disabled")

    def on_save(self) -> None:
        try:
            data = self._collect_data()
            self._validate(data)
            if self.mode == "create":
                self.client.create_parameter(
                    data["name"],
                    self.plugin_ui["parameter_type"],
                    value=data.get("value"),
                    config=data.get("config", {}),
                    metadata=data.get("metadata", {}),
                )
            else:
                name = data["name"]
                self.client.set_value(name, data.get("value"))
                self.client.update_config(name, **data.get("config", {}))
                self.client.update_metadata(name, **data.get("metadata", {}))
            self.result = True
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Save failed", str(exc), parent=self)


class MonitorApp:
    def __init__(self, root: tk.Tk, client: SignalClient) -> None:
        self.root = root
        self.client = client
        self.events: queue.Queue = queue.Queue()
        self.rows: dict[str, dict[str, Any]] = {}
        self.stop_flag = threading.Event()
        self.plugin_ui_cache: dict[str, dict[str, Any]] = {}
        self.graph: dict[str, Any] = {}

        root.title("ParameterDB Monitor")
        root.geometry("1650x850")

        toolbar = ttk.Frame(root, padding=8)
        toolbar.pack(fill=tk.X)
        ttk.Button(toolbar, text="Create", command=self.create_parameter).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Edit", command=self.edit_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Delete", command=self.delete_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Refresh Graph", command=self.refresh_graph).pack(side=tk.LEFT, padx=10)
        ttk.Button(toolbar, text="Snapshot", command=self.show_snapshot).pack(side=tk.LEFT, padx=2)
        ttk.Label(toolbar, text="Filter").pack(side=tk.LEFT, padx=(20, 4))
        self.filter_var = tk.StringVar()
        filter_entry = ttk.Entry(toolbar, textvariable=self.filter_var, width=30)
        filter_entry.pack(side=tk.LEFT)
        filter_entry.bind("<KeyRelease>", lambda e: self.refresh_tree())

        self.status_var = tk.StringVar(value="Connecting...")
        ttk.Label(toolbar, textvariable=self.status_var).pack(side=tk.RIGHT)

        cols = ("name", "parameter_type", "value", "deps", "dependents", "config", "state", "metadata")
        self.tree = ttk.Treeview(root, columns=cols, show="headings", height=20)
        widths = {
            "name": 180,
            "parameter_type": 100,
            "value": 140,
            "deps": 170,
            "dependents": 170,
            "config": 280,
            "state": 260,
            "metadata": 180,
        }
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=widths[col], anchor="w")
        self.tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.update_details())
        self.tree.bind("<Double-1>", lambda e: self.edit_selected())

        detail = ttk.LabelFrame(root, text="Selected", padding=8)
        detail.pack(fill=tk.BOTH, padx=8, pady=(0, 8))
        self.detail_text = tk.Text(detail, height=14, wrap="word")
        self.detail_text.pack(fill=tk.BOTH, expand=True)

        self.load_initial()
        self.start_subscription_thread()
        self.root.after(150, self.process_events)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def load_initial(self) -> None:
        self.plugin_ui_cache = self.client.list_parameter_type_ui()
        self.rows = {}
        for name, desc in self.client.describe().items():
            record = dict(desc)
            record["name"] = name
            self.rows[name] = record
        self.refresh_graph()
        self.refresh_tree()

    def refresh_graph(self) -> None:
        try:
            self.graph = self.client.graph_info()
        except Exception as exc:
            messagebox.showerror("Graph error", str(exc), parent=self.root)
            self.graph = {"dependencies": {}, "warnings": [], "scan_order": []}
        self.refresh_tree()
        self.update_status()
        self.update_details()

    def deps_for(self, name: str) -> list[str]:
        return list((self.graph.get("dependencies") or {}).get(name, []))

    def dependents_for(self, name: str) -> list[str]:
        deps = self.graph.get("dependencies") or {}
        return sorted([param for param, values in deps.items() if name in values])

    def row_values(self, name: str, desc: dict[str, Any]) -> tuple[Any, ...]:
        return (
            name,
            desc.get("parameter_type", ""),
            repr(desc.get("value")),
            ", ".join(self.deps_for(name)),
            ", ".join(self.dependents_for(name)),
            json.dumps(desc.get("config", {}), sort_keys=True),
            json.dumps(desc.get("state", {}), sort_keys=True),
            json.dumps(desc.get("metadata", {}), sort_keys=True),
        )

    def refresh_tree(self) -> None:
        needle = self.filter_var.get().strip().lower()
        existing = set(self.tree.get_children())
        wanted = set()
        for name, desc in sorted(self.rows.items()):
            hay = " ".join([
                name,
                str(desc.get("parameter_type", "")),
                json.dumps(desc.get("config", {}), sort_keys=True),
                json.dumps(desc.get("metadata", {}), sort_keys=True),
            ]).lower()
            if needle and needle not in hay:
                continue
            wanted.add(name)
            values = self.row_values(name, desc)
            if self.tree.exists(name):
                self.tree.item(name, values=values)
            else:
                self.tree.insert("", "end", iid=name, values=values)
        for iid in existing - wanted:
            self.tree.delete(iid)
        self.update_status()

    def selected_name(self) -> str | None:
        selected = self.tree.selection()
        return selected[0] if selected else None

    def selected_record(self) -> dict[str, Any] | None:
        name = self.selected_name()
        if not name:
            return None
        return self.rows.get(name)

    def get_parameter_type_ui(self, parameter_type: str) -> dict[str, Any]:
        if parameter_type not in self.plugin_ui_cache:
            self.plugin_ui_cache[parameter_type] = self.client.get_parameter_type_ui(parameter_type)
        return self.plugin_ui_cache[parameter_type]

    def create_parameter(self) -> None:
        plugin_map = self.client.list_parameter_type_ui()
        if not plugin_map:
            messagebox.showwarning("No plugins", "No plugin UIs are available.", parent=self.root)
            return
        dlg = PluginTypeDialog(self.root, plugin_map)
        self.root.wait_window(dlg)
        if not dlg.result:
            return
        editor = ParameterEditor(self.root, self.client, self.get_parameter_type_ui(dlg.result), "create")
        self.root.wait_window(editor)

    def edit_selected(self) -> None:
        record = self.selected_record()
        if not record:
            return
        ui = self.get_parameter_type_ui(record["parameter_type"])
        dlg = ParameterEditor(self.root, self.client, ui, "edit", record=record)
        self.root.wait_window(dlg)

    def delete_selected(self) -> None:
        name = self.selected_name()
        if not name:
            return
        if messagebox.askyesno("Delete parameter", f"Delete '{name}'?", parent=self.root):
            try:
                self.client.delete_parameter(name)
            except Exception as exc:
                messagebox.showerror("Delete failed", str(exc), parent=self.root)

    def show_snapshot(self) -> None:
        try:
            data = self.client.snapshot()
        except Exception as exc:
            messagebox.showerror("Snapshot failed", str(exc), parent=self.root)
            return
        win = tk.Toplevel(self.root)
        win.title("Snapshot")
        txt = tk.Text(win, wrap="word")
        txt.pack(fill=tk.BOTH, expand=True)
        txt.insert("1.0", json.dumps(data, indent=2, sort_keys=True))

    def update_details(self) -> None:
        self.detail_text.delete("1.0", "end")
        record = self.selected_record()
        if not record:
            return
        name = record["name"]
        payload = {
            "name": name,
            "parameter_type": record.get("parameter_type"),
            "value": record.get("value"),
            "config": record.get("config", {}),
            "state": record.get("state", {}),
            "metadata": record.get("metadata", {}),
            "dependencies": self.deps_for(name),
            "dependents": self.dependents_for(name),
        }
        self.detail_text.insert("1.0", json.dumps(payload, indent=2, sort_keys=True))

    def update_status(self) -> None:
        try:
            stats = self.client.stats()
            self.status_var.set(
                f"Connected | params={len(self.rows)} | cycles={stats.get('cycle_count')} | last_scan={stats.get('last_scan_duration_s'):.6f}s | warnings={len(self.graph.get('warnings', []))}"
            )
        except Exception as exc:
            self.status_var.set(f"Disconnected: {exc}")

    def start_subscription_thread(self) -> None:
        def worker() -> None:
            while not self.stop_flag.is_set():
                try:
                    with self.client.subscribe(send_initial=True) as sub:
                        self.events.put({"event": "monitor_status", "status": "subscribed"})
                        for event in sub:
                            if self.stop_flag.is_set():
                                break
                            self.events.put(event)
                    if not self.stop_flag.is_set():
                        self.events.put({"event": "monitor_error", "error": "Subscription ended; reconnecting..."})
                except Exception as exc:
                    if self.stop_flag.is_set():
                        break
                    self.events.put({"event": "monitor_error", "error": f"{exc} | reconnecting..."})
                time.sleep(1.0)

        threading.Thread(target=worker, daemon=True).start()

    def process_events(self) -> None:
        graph_dirty = False
        try:
            while True:
                event = self.events.get_nowait()
                et = event.get("event")
                name = event.get("name")
                if et in {"parameter_added", "parameter_snapshot"} and name:
                    record = {
                        "name": name,
                        "parameter_type": event.get("parameter_type"),
                        "value": event.get("value"),
                        "config": event.get("config", {}),
                        "state": event.get("state", {}),
                        "metadata": event.get("metadata", {}),
                    }
                    self.rows[name] = record
                    graph_dirty = True
                elif et == "parameter_removed" and name:
                    self.rows.pop(name, None)
                    graph_dirty = True
                elif et == "value_changed" and name in self.rows:
                    self.rows[name]["value"] = event.get("value")
                elif et == "config_changed" and name in self.rows:
                    self.rows[name]["config"] = event.get("config", {})
                    graph_dirty = True
                elif et == "metadata_changed" and name in self.rows:
                    self.rows[name]["metadata"] = event.get("metadata", {})
                elif et == "state_changed" and name in self.rows:
                    self.rows[name]["state"] = event.get("state", {})
                elif et == "monitor_error":
                    self.status_var.set(f"Disconnected: {event.get('error')}")
                elif et == "monitor_status":
                    self.status_var.set("Connected | resynced subscription")
        except queue.Empty:
            pass

        if graph_dirty:
            try:
                self.graph = self.client.graph_info()
            except Exception:
                pass
        self.refresh_tree()
        self.update_details()
        self.root.after(150, self.process_events)

    def on_close(self) -> None:
        self.stop_flag.set()
        self.root.destroy()


def main() -> None:
    parser = argparse.ArgumentParser(description="ParameterDB monitor")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    root = tk.Tk()
    client = SignalClient(args.host, args.port, timeout=5.0).session()
    client.connect()
    try:
        MonitorApp(root, client)
        root.mainloop()
    finally:
        client.close()


if __name__ == "__main__":
    main()
