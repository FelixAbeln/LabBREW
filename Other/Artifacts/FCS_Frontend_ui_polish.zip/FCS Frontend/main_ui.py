from __future__ import annotations

import ctypes
import sys

from fcs_app.ui import run_ui


def _hide_console_on_windows() -> None:
    if sys.platform != "win32":
        return
    try:
        kernel32 = ctypes.windll.kernel32
        user32 = ctypes.windll.user32
        hwnd = kernel32.GetConsoleWindow()
        if hwnd:
            user32.ShowWindow(hwnd, 0)
    except Exception:
        pass


if __name__ == "__main__":
    _hide_console_on_windows()
    raise SystemExit(run_ui(start_minimized=True))
