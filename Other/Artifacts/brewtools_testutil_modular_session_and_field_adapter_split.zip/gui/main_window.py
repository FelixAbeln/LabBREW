from __future__ import annotations

import sys
import time
from pathlib import Path

from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
    QScrollArea, QSpinBox, QStatusBar, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout,
    QFrame,
    QWidget,
    QSizePolicy
)
from PySide6.QtWidgets import QHeaderView

from brewtools_can import CanFrame

from helpers import format_node_type, list_kvaser_channels, list_serial_ports
from settings import AppSettings, SettingsManager, DEFAULT_CAN_BITRATE, DEFAULT_PSU_VOLTAGE, ControllerSettings, AgitatorSettings, RelaySettings, DigitalTwinSettings, SafetySettings, SafetyRuleSettings, SchedulerSettings, SchedulerStepSettings
from state import AppState, DeviceKey, DeviceState, StateStore, SchedulerStep, SafetyRule
from app_core import AppCore
from gui.constants import OUTPUT_LABELS
from gui.config_adapters import ApplicationConfigBuilder
from gui.panel_facades import build_panel_facades
from gui.config_controller import WindowConfigController
from gui.discovery_controller import WindowDiscoveryController
from gui.device_session_controller import WindowDeviceSessionController
from gui.runtime_bridge import WindowRuntimeBridge
from gui.safety_rules_controller import SafetyRulesController
from gui.settings_loader import WindowSettingsLoader
from gui.source_controller import WindowSourceController
from gui.ui_state import WindowUIState
from gui.ui_helpers import find_data_index, normalize_signal_key, make_output_badge, set_output_badge
from application.normalization import normalize_control_source_key
from gui.panels import (
    BrewPanel,
    ControlPanel,
    LogPanel,
    RelayPanel,
    SafetyPanel,
    SchedulerPanel,
    TwinPanel,
)
from gui.window_session import MainWindowSession
from gui.send_dialog import SendDialog
from gui.widgets.band_indicator import BandIndicator



class MainWindow(QMainWindow):
    def __init__(self, *, core: AppCore):
        super().__init__()
        self.setWindowTitle('Brewtools CAN Test Utility')
        self.resize(1220, 820)

        self.core = core
        self.settings_manager = self.core.settings_manager
        self.settings = self.core.settings

        self.commands = self.core.commands
        self.queries = self.core.queries
        self.events = self.core.events
        self._action_labels = self.queries.safety_action_labels()
        self._operator_options = self.queries.operator_options()
        self._operator_keys = [opt.key for opt in self._operator_options]

        self.ui_state = WindowUIState(
            pending_temp_source_key=normalize_control_source_key(self.settings.temp_controller.source_key),
            pending_pressure_source_key=normalize_control_source_key(self.settings.pressure_controller.source_key),
        )
        self.safety_rules_controller = SafetyRulesController()
        self.OUTPUT_LABELS = OUTPUT_LABELS
        self.relay_channel_rows: dict[int, dict[str, object]] = {}
        self._config_builder = ApplicationConfigBuilder(self)
        self.config_controller = WindowConfigController(self, self._config_builder)
        self.discovery_controller = WindowDiscoveryController(self)
        self.device_controller = WindowDeviceSessionController(self)
        self.runtime_bridge = WindowRuntimeBridge(self)
        self.source_controller = WindowSourceController(self)
        self.settings_loader = WindowSettingsLoader(self)

        self._panel_facades = build_panel_facades(self)
        self._build_ui()
        self.session = MainWindowSession(self)
        self._wire_signals()
        self.session.bind_runtime_events()

        self.ui_state.loading_settings = True
        try:
            self.discovery_controller.populate_psu_ports()
            self.discovery_controller.populate_channels()
            self.discovery_controller.populate_relay_targets()
            self.settings_loader.apply()
        finally:
            self.ui_state.loading_settings = False
        self.source_controller.refresh_control_sources()
        self.source_controller.refresh_twin_sources()
        self.runtime_bridge.refresh_footer()
        self.commands.set_status_message('Ready. Select PSU port, choose CAN voltage, power the rail, then connect CAN.')

        self.session.start()
        self.session.initial_refresh()

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)

        self.tabs = QTabWidget()
        outer.addWidget(self.tabs)

        self.brew_panel = BrewPanel(self._panel_facades.brew)
        self.control_panel = ControlPanel(self._panel_facades.control)
        self.safety_panel = SafetyPanel(self._panel_facades.safety)
        self.log_panel = LogPanel()
        self.twin_panel = TwinPanel(self._panel_facades.twin)
        self.scheduler_panel = SchedulerPanel(self._panel_facades.scheduler)
        self.relay_panel = RelayPanel(self._panel_facades.relay)

        self.tabs.addTab(self.brew_panel, 'Brewtools')
        self.tabs.addTab(self.control_panel, 'Control')
        self.tabs.addTab(self.safety_panel, 'Safety')
        self.tabs.addTab(self.log_panel, 'System Log')
        self.tabs.addTab(self.twin_panel, 'Twin')
        self.tabs.addTab(self.scheduler_panel, 'Scheduler')
        self.tabs.addTab(self.relay_panel, 'Relays')
        self.footer_event_lbl = None
        self.footer_state_lbl = None


    def _wire_signals(self) -> None:
        self.brew_panel.wire_signals()
        self.control_panel.wire_signals()
        self.safety_panel.wire_signals()
        self.twin_panel.wire_signals()
        self.scheduler_panel.wire_signals()
        self.relay_panel.wire_signals()


    def _set_toggle_style(self, button: QPushButton, active: bool) -> None:
        button.setChecked(active)
        if active:
            button.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def closeEvent(self, event) -> None:
        self.session.stop()
        self.config_controller.save_settings()
        super().closeEvent(event)


def run() -> int:
    from app import run_gui
    return run_gui()
