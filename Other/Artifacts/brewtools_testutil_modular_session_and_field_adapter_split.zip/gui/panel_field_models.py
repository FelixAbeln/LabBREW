from __future__ import annotations

from dataclasses import dataclass

from gui.ui_helpers import find_data_index, normalize_signal_key


@dataclass
class BrewPanelFields:
    panel: object

    def read(self) -> dict[str, object]:
        return {
            'bitrate': int(self.panel.bitrate.value()),
            'can_channel': self.panel.channel_combo.currentData(),
            'can_channel_label': self.panel.channel_combo.currentText().strip() if self.panel.channel_combo.count() else '',
            'psu_com_port': self.panel.psu_port_combo.currentData() or '',
            'voltage': float(self.panel.psu_voltage.value()),
        }

    def apply(self, settings) -> None:
        self.panel.bitrate.setValue(settings.bitrate)
        self.panel.psu_voltage.setValue(settings.voltage)
        idx = self.panel.channel_combo.findData(settings.can_channel)
        if idx >= 0:
            self.panel.channel_combo.setCurrentIndex(idx)
        idx = self.panel.psu_port_combo.findData(settings.psu_com_port)
        if idx >= 0:
            self.panel.psu_port_combo.setCurrentIndex(idx)


@dataclass
class ControlPanelFields:
    panel: object

    def apply(self, settings, ui_state) -> None:
        ui_state.pending_temp_source_key = normalize_signal_key(settings.temp_controller.source_key)
        ui_state.pending_pressure_source_key = normalize_signal_key(settings.pressure_controller.source_key)
        self.panel.temp_ctrl_enabled.setChecked(settings.temp_controller.enabled)
        self.panel.temp_setpoint.setValue(settings.temp_controller.setpoint)
        self.panel.temp_deadband.setValue(settings.temp_controller.deadband)
        self.panel.pressure_ctrl_enabled.setChecked(settings.pressure_controller.enabled)
        self.panel.pressure_setpoint.setValue(settings.pressure_controller.setpoint)
        self.panel.pressure_deadband.setValue(settings.pressure_controller.deadband)
        self.panel.pressure_allow_add_gas.setChecked(bool(getattr(settings.pressure_controller, 'allow_add_gas', True)))
        self.panel.agitator_enabled.setChecked(bool(getattr(settings.agitator, 'enabled', False)))
        self.panel.agitator_on.setChecked(bool(getattr(settings.agitator, 'on', False)))
        self.panel.agitator_duty.setValue(float(getattr(settings.agitator, 'duty_cycle', 100.0)))
        self.panel.agitator_speed_setpoint.setValue(float(getattr(settings.agitator, 'speed_setpoint_rpm', 120.0)))
        self.panel.agitator_pid_kp.setValue(float(getattr(settings.agitator, 'pid_kp', 0.30)))
        self.panel.agitator_pid_ki.setValue(float(getattr(settings.agitator, 'pid_ki', 0.05)))
        self.panel.agitator_pid_kd.setValue(float(getattr(settings.agitator, 'pid_kd', 0.00)))
        idx = self.panel.agitator_control_mode.findData(getattr(settings.agitator, 'mode', 'manual'))
        self.panel.agitator_control_mode.setCurrentIndex(idx if idx >= 0 else 0)
        self.panel.refresh_agitator_control_ui()


@dataclass
class RelayPanelFields:
    panel: object
    relay_channel_rows: dict[int, dict[str, object]]

    def assignments(self) -> dict[str, str | None]:
        return {str(ch): row['combo'].currentData() for ch, row in self.relay_channel_rows.items()}

    def auto_enabled(self) -> dict[str, bool]:
        return {str(ch): bool(row['auto'].isChecked()) for ch, row in self.relay_channel_rows.items()}

    def manual_states(self) -> dict[str, bool]:
        return {str(ch): bool(row['test'].isChecked()) for ch, row in self.relay_channel_rows.items()}

    def apply(self, settings) -> None:
        self.panel.relay_host.setEditText(settings.relay.host)
        self.panel.relay_tcp_port.setValue(int(settings.relay.tcp_port))
        for ch, row in self.relay_channel_rows.items():
            key = str(ch)
            target = settings.relay.assignments.get(key)
            idx = find_data_index(row['combo'], target)
            row['combo'].setCurrentIndex(idx if idx >= 0 else 0)
            row['auto'].setChecked(bool(settings.relay.auto_enabled.get(key, True)))
            row['test'].setChecked(False)


@dataclass
class SafetyPanelFields:
    panel: object
    rules_controller: object

    def apply(self, settings) -> None:
        self.panel.safety_enabled.setChecked(settings.safety.enabled)
        self.panel.safety_require_can.setChecked(settings.safety.require_can_connected)
        self.panel.safety_require_psu.setChecked(settings.safety.require_psu_power)
        self.panel.safety_require_relays.setChecked(settings.safety.require_relays_connected)
        self.panel.safety_stale_timeout.setValue(float(settings.safety.stale_timeout_s))
        self.panel.safety_min_switch.setValue(float(settings.safety.min_switch_time_s))
        self.panel.safety_max_temp_enabled.setChecked(bool(settings.safety.max_temperature_enabled))
        self.panel.safety_max_temp.setValue(float(settings.safety.max_temperature_c))
        self.panel.safety_max_pressure_enabled.setChecked(bool(settings.safety.max_pressure_enabled))
        self.panel.safety_max_pressure.setValue(float(settings.safety.max_pressure_bar))
        self.panel.safe_heat.setChecked(bool(settings.safety.safe_outputs.get('heat', False)))
        self.panel.safe_cool.setChecked(bool(settings.safety.safe_outputs.get('cool', False)))
        self.panel.safe_add_gas.setChecked(bool(settings.safety.safe_outputs.get('add_gas', False)))
        self.panel.safe_remove_gas.setChecked(bool(settings.safety.safe_outputs.get('remove_gas', False)))
        self.panel.safe_psu_off.setChecked(bool(settings.safety.power_off_psu_on_trip))
        self.panel.safe_all_relays_off.setChecked(bool(settings.safety.all_relays_off_on_trip))
        self.panel.safe_agitator.setChecked(bool(settings.safety.safe_outputs.get('agitator', False)))
        self.rules_controller.load_from_settings(getattr(settings.safety, 'rules', []))
        self.panel.refresh_rules_table()
        self.panel.clear_rule_editor()


@dataclass
class TwinPanelFields:
    panel: object

    def apply(self, settings) -> None:
        self.panel.twin_enabled.setChecked(settings.twin.enabled)
        self.panel.twin_fmu_path.setText(settings.twin.fmu_path)


@dataclass
class SchedulerPanelFields:
    panel: object

    def apply(self, settings) -> None:
        self.panel.scheduler_enabled.setChecked(settings.scheduler.enabled)
        self.panel.scheduler_auto_start.setChecked(settings.scheduler.auto_start)
        self.panel.scheduler_path.setText(settings.scheduler.workbook_path)
        self.panel.scheduler_startup_enabled.setChecked(bool(getattr(settings.scheduler, 'startup_sequence_enabled', False)))
        self.panel.scheduler_startup_connect_relays.setChecked(bool(getattr(settings.scheduler, 'startup_auto_connect_relays', False)))
        self.panel.scheduler_startup_connect_can.setChecked(bool(getattr(settings.scheduler, 'startup_auto_connect_can', False)))
        self.panel.scheduler_startup_power_psu.setChecked(bool(getattr(settings.scheduler, 'startup_auto_power_psu', False)))
        self.panel.scheduler_startup_load_twin.setChecked(bool(getattr(settings.scheduler, 'startup_auto_load_twin', False)))
        self.panel.scheduler_startup_delay.setValue(float(getattr(settings.scheduler, 'startup_delay_s', 3.0) or 0.0))
        self.panel.scheduler_startup_section.toggle_button.setChecked(bool(getattr(settings.scheduler, 'startup_show_advanced', False)))
