from __future__ import annotations

from gui.panel_field_models import BrewPanelFields, ControlPanelFields, RelayPanelFields, SafetyPanelFields, SchedulerPanelFields, TwinPanelFields


class WindowSettingsLoader:
    """Applies persisted settings into panel-level field adapters instead of making MainWindow the field-by-field owner."""

    def __init__(self, window):
        self.window = window

    def apply(self) -> None:
        w = self.window
        s = w.settings
        w.ui_state.loading_settings = True

        BrewPanelFields(w.brew_panel).apply(s)
        ControlPanelFields(w.control_panel).apply(s, w.ui_state)
        RelayPanelFields(w.relay_panel, w.relay_channel_rows).apply(s)
        SafetyPanelFields(w.safety_panel, w.safety_rules_controller).apply(s)
        TwinPanelFields(w.twin_panel).apply(s)
        SchedulerPanelFields(w.scheduler_panel).apply(s)

        w.config_controller.save_settings_to_state()
        w.ui_state.loading_twin_widgets = True
        try:
            if s.twin.fmu_path:
                w.commands.load_twin_model(s.twin.fmu_path)
            w.twin_panel.rebuild_variable_widgets()
            w.source_controller.refresh_all_sources()
            w.config_controller.save_settings_to_state()
        finally:
            w.ui_state.loading_twin_widgets = False
        w.ui_state.loading_scheduler_ui = False
        w.runtime_bridge.refresh_footer()
