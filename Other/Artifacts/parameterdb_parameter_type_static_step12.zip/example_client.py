from signalstore_core.client import SignalClient

c = SignalClient()

with c.session() as s:
    print("Ping:", s.ping())
    print("Plugins:", s.list_parameter_types())
    print("Parameters:", s.list_parameters())
