import sys

from PySide6.QtWidgets import QApplication

from app_core import AppCore
from brewtools_can import register_default_bodies, register_default_domain_handlers


def run_gui() -> int:
    from gui.main_window import MainWindow

    app = QApplication(sys.argv)
    core = AppCore()
    core.start()
    app.aboutToQuit.connect(core.stop)
    window = MainWindow(core=core)
    window.show()
    return app.exec()


def run_headless(argv: list[str] | None = None) -> int:
    from headless import run
    return run(argv)


if __name__ == "__main__":
    register_default_bodies()
    register_default_domain_handlers()
    args = sys.argv[1:]
    if '--headless' in args:
        filtered = [a for a in args if a != '--headless']
        raise SystemExit(run_headless(filtered))
    raise SystemExit(run_gui())
