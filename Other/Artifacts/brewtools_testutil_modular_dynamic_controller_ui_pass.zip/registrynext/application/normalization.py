from __future__ import annotations


def normalize_control_source_key(key):
    """Normalize saved controller source keys for backward compatibility."""
    if key is None:
        return None
    if isinstance(key, str):
        return key
    if isinstance(key, (tuple, list)):
        try:
            if len(key) == 2:
                return f"sensor:temperature:{int(key[0])}:{int(key[1])}"
        except Exception:
            return None
    return None
