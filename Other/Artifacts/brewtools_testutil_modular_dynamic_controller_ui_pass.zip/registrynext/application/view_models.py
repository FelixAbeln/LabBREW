from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class FooterStatusViewModel:
    can_connected: bool
    psu_power_on: bool
    relay_connected: bool
    twin_runtime_active: bool
    status_message: str


@dataclass(frozen=True)
class DeviceRowViewModel:
    device_label: str
    node_label: str
    last_seen_text: str
    status_text: str
    measurements_text: str
    is_stale: bool = False


@dataclass(frozen=True)
class ControlPanelViewModel:
    temperature_pv_text: str
    temperature_state_text: str
    pressure_pv_text: str
    pressure_state_text: str
    heat_active: bool
    cool_active: bool
    add_gas_active: bool
    remove_gas_active: bool
    agitator_active: bool
    agitator_rpm_text: str
    agitator_commanded_text: str
    agitator_state_text: str
    temperature_band_value: Optional[float]
    pressure_band_value: Optional[float]


@dataclass(frozen=True)
class SafetyPanelViewModel:
    state_text: str
    state_style: str
    effective_outputs_text: str
    active_actions_text: str
    event_log_lines: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class TwinOutputFieldViewModel:
    name: str
    value_text: str
    is_badge: bool
    active: bool


@dataclass(frozen=True)
class TwinPanelViewModel:
    fmu_name_text: str
    status_text: str
    runtime_mode_text: str
    step_count_text: str
    sim_time_text: str
    last_dt_text: str
    last_age_text: str
    worker_period_text: str
    output_fields: dict[str, TwinOutputFieldViewModel] = field(default_factory=dict)


@dataclass(frozen=True)
class SchedulerStepRowViewModel:
    index_text: str
    enabled_text: str
    name_text: str
    temperature_text: str
    pressure_text: str
    gas_text: str
    agitator_text: str
    wait_type_text: str
    wait_source_text: str
    condition_text: str
    confirm_text: str
    is_active: bool = False


@dataclass(frozen=True)
class SchedulerPanelViewModel:
    state_text: str
    current_step_text: str
    elapsed_text: str
    wait_text: str
    hold_text: str
    transition_text: str
    confirmation_text: str
    file_status_text: str
    start_active: bool
    pause_active: bool
    load_active: bool
    awaiting_confirmation: bool
    steps: list[SchedulerStepRowViewModel] = field(default_factory=list)


@dataclass(frozen=True)
class RelayChannelViewModel:
    channel: int
    assigned_key: Optional[str]
    active: bool
    auto_enabled: bool
    config_editable: bool
    manual_toggle_enabled: bool
    manual_button_text: str
    active_text: str
    inactive_text: str


@dataclass(frozen=True)
class RelayPanelViewModel:
    connected: bool
    channels: list[RelayChannelViewModel] = field(default_factory=list)
