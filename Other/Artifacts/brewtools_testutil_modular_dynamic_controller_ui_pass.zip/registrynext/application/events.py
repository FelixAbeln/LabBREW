from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QObject, Signal


class ApplicationEvents(QObject):
    status = Signal(str)
    cycle_completed = Signal()
    command_failed = Signal(str, str)
    frame_decoded = Signal(object, object)
    can_connection_changed = Signal(bool)

    footer_changed = Signal()
    device_rows_changed = Signal()
    control_changed = Signal()
    safety_changed = Signal()
    twin_changed = Signal()
    scheduler_changed = Signal()
    relay_changed = Signal()
    signal_registry_changed = Signal()

    def __init__(self, parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
