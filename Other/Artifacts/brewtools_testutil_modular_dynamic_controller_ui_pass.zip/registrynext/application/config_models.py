from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class ControllerConfigModel:
    enabled: bool = False
    source_key: Optional[object] = None
    setpoint: float = 0.0
    deadband: float = 1.0
    allow_add_gas: bool = True


@dataclass(frozen=True)
class AgitatorConfigModel:
    enabled: bool = False
    target: str = 'relay'
    on: bool = False
    duty_cycle: float = 100.0
    mode: str = 'manual'
    speed_setpoint_rpm: float = 120.0
    pid_kp: float = 0.30
    pid_ki: float = 0.05
    pid_kd: float = 0.00




@dataclass(frozen=True)
class ControllerInstanceConfigModel:
    id: str
    controller_key: str
    label: str = ''
    enabled: bool = False
    source_key: Optional[object] = None
    target_key: str = ''
    setpoint: float = 0.0
    deadband: float = 1.0
    ramp_per_s: float | None = None
    extra: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class RelayConfigModel:
    host: str = '127.0.0.1'
    tcp_port: int = 502
    assignments: dict[str, Optional[str]] = field(default_factory=dict)
    auto_enabled: dict[str, bool] = field(default_factory=dict)
    manual_states: dict[str, bool] = field(default_factory=dict)


@dataclass(frozen=True)
class SafetyRuleConfigModel:
    name: str = ''
    enabled: bool = True
    signal_key: str = ''
    operator: str = '>'
    threshold: float | None = None
    threshold_low: float | None = None
    threshold_high: float | None = None
    stale_for_s: float = 10.0
    actions: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class SafetyConfigModel:
    enabled: bool = True
    stale_timeout_s: float = 10.0
    min_switch_time_s: float = 3.0
    require_can_connected: bool = True
    require_psu_power: bool = False
    require_relays_connected: bool = False
    max_temperature_enabled: bool = False
    max_temperature_c: float = 35.0
    max_pressure_enabled: bool = False
    max_pressure_bar: float = 2.5
    power_off_psu_on_trip: bool = False
    all_relays_off_on_trip: bool = False
    rules: list[SafetyRuleConfigModel] = field(default_factory=list)
    safe_outputs: dict[str, bool] = field(default_factory=dict)


@dataclass(frozen=True)
class SchedulerStepConfigModel:
    index: int = 0
    enabled: bool = True
    name: str = ''
    temperature_setpoint: float | None = None
    temperature_ramp_per_s: float | None = None
    pressure_setpoint: float | None = None
    pressure_ramp_per_s: float | None = None
    allow_add_gas: bool | None = None
    wait_type: str = 'elapsed_time'
    wait_source: str = ''
    operator: str = '>='
    threshold: float | None = None
    threshold_low: float | None = None
    threshold_high: float | None = None
    duration_s: float | None = None
    hold_for_s: float = 0.0
    valid_sources: list[str] = field(default_factory=list)
    require_confirmation: bool = False
    confirmation_message: str = ''
    agitator_on: bool | None = None
    agitator_duty_cycle: float | None = None
    controller_actions: list[dict[str, object]] = field(default_factory=list)


@dataclass(frozen=True)
class SchedulerConfigModel:
    enabled: bool = False
    workbook_path: str = ''
    sheet_name: str = ''
    auto_start: bool = False
    startup_sequence_enabled: bool = False
    startup_auto_connect_relays: bool = False
    startup_auto_connect_can: bool = False
    startup_auto_power_psu: bool = False
    startup_auto_load_twin: bool = False
    startup_delay_s: float = 3.0
    startup_show_advanced: bool = False
    steps: list[SchedulerStepConfigModel] = field(default_factory=list)


@dataclass(frozen=True)
class TwinConfigModel:
    enabled: bool = True
    fmu_path: str = ''
    input_bindings: dict[str, Optional[str]] = field(default_factory=dict)


@dataclass(frozen=True)
class ApplicationConfigModel:
    bitrate: int
    can_channel: int | None
    can_channel_label: str = ''
    psu_com_port: str = ''
    voltage: float = 24.0
    temp_controller: ControllerConfigModel = field(default_factory=ControllerConfigModel)
    pressure_controller: ControllerConfigModel = field(default_factory=ControllerConfigModel)
    agitator: AgitatorConfigModel = field(default_factory=AgitatorConfigModel)
    controller_instances: list[ControllerInstanceConfigModel] = field(default_factory=list)
    relay: RelayConfigModel = field(default_factory=RelayConfigModel)
    safety: SafetyConfigModel = field(default_factory=SafetyConfigModel)
    scheduler: SchedulerConfigModel = field(default_factory=SchedulerConfigModel)
    twin: TwinConfigModel = field(default_factory=TwinConfigModel)
