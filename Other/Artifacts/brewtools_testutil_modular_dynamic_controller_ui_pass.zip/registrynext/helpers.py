from __future__ import annotations

import struct
from typing import Optional

import can
from serial.tools import list_ports
from brewtools_can.enums import NodeType


def format_node_type(v: int) -> str:
    try:
        nt = NodeType(v)
        return nt.name.replace("NODE_TYPE_", "").replace("_", " ").title()
    except ValueError:
        return f"Unknown ({v})"


def float_to_hex_le(value: float) -> str:
    b = struct.pack("<f", value)
    return " ".join(f"{x:02X}" for x in b)


def hex_bytes(b: bytes) -> str:
    return " ".join(f"{x:02X}" for x in b)


def u32_to_hex_be(value: int) -> str:
    if not (0 <= value <= 0xFFFFFFFF):
        raise ValueError("u32 must be 0..4294967295")
    return hex_bytes(int(value).to_bytes(4, "big", signed=False))


def parse_hex_bytes(s: str) -> bytes:
    s = s.strip().replace(",", " ").replace("0x", "").replace("0X", "")
    if not s:
        return b""
    if " " in s:
        parts = [p for p in s.split() if p]
        return bytes(int(p, 16) for p in parts)
    if len(s) % 2 != 0:
        raise ValueError("Hex string must have even length when no spaces are used.")
    return bytes(int(s[i:i+2], 16) for i in range(0, len(s), 2))


def list_kvaser_channels(bitrate: int, max_probe: int = 16) -> list[tuple[int, str]]:
    try:
        from canlib import canlib as kv
        n = kv.getNumberOfChannels()
        out: list[tuple[int, str]] = []
        for ch in range(n):
            cd = kv.ChannelData(ch)
            name = getattr(cd, "channel_name", None) or "Kvaser channel"
            out.append((ch, f"{name}"))
        if out:
            return out
    except Exception:
        pass

    out: list[tuple[int, str]] = []
    for ch in range(max_probe):
        try:
            bus = can.Bus(interface="kvaser", channel=ch, bitrate=bitrate)
            try:
                msg = bus.recv(timeout=0.05)
                traffic = " (traffic)" if msg is not None else ""
            finally:
                bus.shutdown()
            out.append((ch, f"Kvaser channel {ch}{traffic}"))
        except Exception:
            continue
    return out or [(i, f"Kvaser channel {i}") for i in range(4)]


def list_serial_ports() -> list[tuple[str, str]]:
    ports = []
    for p in list_ports.comports():
        label = p.device
        if p.description and p.description != "n/a":
            label = f"{p.device} - {p.description}"
        ports.append((p.device, label))
    return ports
