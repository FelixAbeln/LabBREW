from __future__ import annotations

import argparse
import sys

from PySide6.QtCore import QCoreApplication

from app_core import AppCore, install_signal_handlers
from brewtools_can import register_default_bodies, register_default_domain_handlers


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='Run Brewtools control core without the GUI.')
    parser.add_argument('--settings', default='', help='Optional path to brewtools_can_settings.json')
    parser.add_argument('--no-startup', action='store_true', help='Do not run configured startup actions automatically')
    return parser


def run(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    register_default_bodies()
    register_default_domain_handlers()
    app = QCoreApplication(sys.argv)
    core = AppCore(settings_path=(args.settings or None))
    core.status.connect(lambda msg: print(msg, flush=True))
    core.command_failed.connect(lambda title, msg: print(f'{title}: {msg}', flush=True))
    install_signal_handlers(core, app)
    if args.no_startup:
        core.start()
        core.status.emit('Headless core started without automatic startup sequence.')
    else:
        core.run_headless_bootstrap()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(run())
