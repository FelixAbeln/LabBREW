from __future__ import annotations

from dataclasses import dataclass
import threading
from typing import Dict, List


@dataclass
class RelayBoardInfo:
    host: str
    port: int
    label: str
    channel_count: int = 8


class RelayError(Exception):
    pass


class RelayBoard:
    """Dummy Modbus-TCP style relay board.

    All development behavior lives here so the service and GUI can stay stable.
    Replace this file later with a real Modbus TCP implementation that keeps the
    same method names.
    """

    def __init__(self, host: str, port: int = 502, channel_count: int = 8):
        if not host:
            raise RelayError('Enter a relay IP or host name first.')
        self.host = host.strip()
        self.port = int(port)
        self.channel_count = int(channel_count)
        self._connected = False
        self._lock = threading.RLock()
        self._states: Dict[int, bool] = {i: False for i in range(1, self.channel_count + 1)}

    @property
    def is_connected(self) -> bool:
        return self._connected

    def connect(self) -> bool:
        # Dummy behavior: any non-empty host connects.
        self._connected = True
        return True

    def available_channels(self) -> List[int]:
        return list(range(1, self.channel_count + 1))

    def set_channel(self, channel: int, value: bool) -> None:
        if not self._connected:
            raise RelayError('Relay board is not connected.')
        if channel not in self._states:
            raise RelayError(f'Invalid relay channel: {channel}')
        with self._lock:
            self._states[channel] = bool(value)

    def get_channel(self, channel: int) -> bool:
        if channel not in self._states:
            raise RelayError(f'Invalid relay channel: {channel}')
        with self._lock:
            return bool(self._states[channel])

    def all_states(self) -> Dict[int, bool]:
        with self._lock:
            return dict(self._states)


    def close(self) -> None:
        self._connected = False
        with self._lock:
            for key in self._states:
                self._states[key] = False


def auto_find_relays() -> list[RelayBoardInfo]:
    """Dummy discovery targets for development.

    Real network discovery should be implemented here later if the hardware
    supports it. For now this keeps all simulated relay behavior inside this
    module so the service and UI can remain unchanged.
    """
    return [
        RelayBoardInfo(host='127.0.0.1', port=502, label='Local dummy relay board', channel_count=8),
        RelayBoardInfo(host='192.168.0.250', port=502, label='Example Modbus TCP relay board', channel_count=8),
    ]
