# Brewtools CAN Test Utility - modular split

This is a refactor of the single-file test utility into smaller parts:

- `app.py` - entry point
- `gui/main_window.py` - Qt UI
- `gui/send_dialog.py` - send-message dialog
- `services/can_service.py` - CAN connect/receive service
- `services/decode_service.py` - wraps your decoder library
- `services/psu_service.py` - wraps `PSU/psu.py`
- `services/opcua_service.py` - placeholder for the next step
- `state.py` - shared live state
- `settings.py` - JSON settings load/save
- `helpers.py` - utility helpers and port/channel discovery

## Notes

- Keep your existing `PSU/psu.py` alongside this project root.
- Settings save automatically to `brewtools_can_settings.json`.
- The UI still behaves like the current tool, but the wiring is cleaner so adding OPC UA next is easier.

Run with:

```bash
python app.py
```
