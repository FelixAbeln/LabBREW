from __future__ import annotations

from gui.dispatchers import (
    ControlRefreshDispatcher,
    DeviceTableRefreshDispatcher,
    FooterRefreshDispatcher,
    RelayRefreshDispatcher,
    SafetyRefreshDispatcher,
    SchedulerRefreshDispatcher,
    TwinRefreshDispatcher,
)


class WindowIntentDispatcher:
    """Owns intent-level GUI refresh dispatch for the window."""

    def __init__(self, window):
        self.window = window
        self.footer = FooterRefreshDispatcher(window)
        self.devices = DeviceTableRefreshDispatcher(window)
        self.control = ControlRefreshDispatcher(window)
        self.safety = SafetyRefreshDispatcher(window)
        self.twin = TwinRefreshDispatcher(window)
        self.scheduler = SchedulerRefreshDispatcher(window)
        self.relay = RelayRefreshDispatcher(window)

    def refresh_footer(self, *, force: bool = False) -> bool:
        self.footer.refresh()
        return True

    def refresh_table(self, *, force: bool = False) -> bool:
        self.devices.refresh()
        return True

    def refresh_control_panel(self, *, force: bool = False) -> bool:
        self.control.refresh()
        return True

    def refresh_safety_panel(self, *, force: bool = False) -> bool:
        self.safety.refresh()
        return True

    def refresh_twin_panel(self, *, force: bool = False) -> bool:
        self.twin.refresh()
        return True

    def refresh_scheduler_panel(self, *, force: bool = False) -> bool:
        self.scheduler.refresh()
        return True

    def refresh_relay_panel(self, *, force: bool = False) -> bool:
        self.relay.refresh()
        return True

    def refresh_sources(self) -> None:
        self.window.source_controller.refresh_all_sources()

    def refresh_all(self, *, force: bool = False) -> None:
        self.refresh_footer(force=force)
        self.refresh_table(force=force)
        self.refresh_control_panel(force=force)
        self.refresh_safety_panel(force=force)
        self.refresh_twin_panel(force=force)
        self.refresh_scheduler_panel(force=force)
        self.refresh_relay_panel(force=force)
