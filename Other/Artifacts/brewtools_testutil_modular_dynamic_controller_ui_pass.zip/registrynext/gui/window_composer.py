from __future__ import annotations

from gui.composition import (
    WindowControllersComposer,
    WindowRuntimeComposer,
    WindowShellComposer,
    WindowStateComposer,
)


class MainWindowComposer:
    """Builds the window collaborator graph in a small checklist-style sequence."""

    def __init__(self, window):
        self.window = window
        self.state = WindowStateComposer(window)
        self.controllers = WindowControllersComposer(window)
        self.shell = WindowShellComposer(window)
        self.runtime = WindowRuntimeComposer(window)

    def compose(self) -> None:
        self.state.compose()
        self.controllers.compose()
        self.shell.compose()
        self.runtime.compose()
