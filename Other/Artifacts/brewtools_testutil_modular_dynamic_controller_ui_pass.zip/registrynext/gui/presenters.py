from __future__ import annotations

import time

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QTableWidgetItem

from application.queries import ApplicationQueries
from application.view_models import RelayPanelViewModel
from gui.ui_helpers import set_output_badge


class FooterPresenter:
    def __init__(self, window, queries: ApplicationQueries):
        self.window = window
        self.queries = queries

    def refresh(self) -> None:
        footer = self.queries.footer_status()
        relay_panel = self.queries.relay_panel()
        self.window._set_toggle_style(self.window.brew_panel.btn_connect, footer.can_connected)
        self.window._set_toggle_style(self.window.brew_panel.btn_psu_toggle, footer.psu_power_on)
        self.window._set_toggle_style(self.window.relay_panel.btn_relay_connect, relay_panel.connected)
        self.window._set_toggle_style(self.window.twin_panel.btn_twin_load, footer.twin_runtime_active)
        self.window.brew_panel.btn_connect.setText('Disconnect CAN' if footer.can_connected else 'Connect CAN')
        self.window.brew_panel.btn_psu_toggle.setText('Power OFF' if footer.psu_power_on else 'Power ON')
        self.window.relay_panel.btn_relay_connect.setText('Disconnect Relays' if relay_panel.connected else 'Connect Relays')
        self.window.brew_panel.channel_combo.setEnabled(not footer.can_connected)
        self.window.brew_panel.btn_refresh_channels.setEnabled(not footer.can_connected)
        self.window.brew_panel.bitrate.setEnabled(not footer.can_connected)
        self.window.brew_panel.btn_send.setEnabled(footer.can_connected)
        self.window.brew_panel.psu_port_combo.setEnabled(not footer.psu_power_on)
        self.window.brew_panel.btn_refresh_psu_ports.setEnabled(not footer.psu_power_on)
        self.window.brew_panel.psu_voltage.setEnabled(not footer.psu_power_on)
        self.window.relay_panel.relay_host.setEnabled(not relay_panel.connected)
        self.window.relay_panel.relay_tcp_port.setEnabled(not relay_panel.connected)
        self.window.relay_panel.btn_refresh_relays.setEnabled(not relay_panel.connected)
        relay_by_channel = {item.channel: item for item in relay_panel.channels}
        for ch, row in self.window.relay_channel_rows.items():
            vm = relay_by_channel.get(ch)
            row['test'].setEnabled(bool(vm.manual_toggle_enabled) if vm is not None else False)
        self.window.scheduler_panel.refresh_startup_summary()


class DeviceTablePresenter:
    def __init__(self, window, queries: ApplicationQueries):
        self.window = window
        self.queries = queries

    def refresh_table(self) -> None:
        rows = self.queries.device_rows(now=time.time())
        self.window.brew_panel.table.setRowCount(len(rows))
        for r, row_vm in enumerate(rows):
            row = [
                row_vm.device_label,
                row_vm.node_label,
                row_vm.last_seen_text,
                row_vm.status_text,
                row_vm.measurements_text,
            ]
            for c, text in enumerate(row):
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignVCenter | (Qt.AlignLeft if c == 4 else Qt.AlignCenter))
                self.window.brew_panel.table.setItem(r, c, item)
                if row_vm.is_stale:
                    item.setForeground(Qt.gray)
            self.window.brew_panel.table.setRowHeight(r, 34)


class ControlPanelPresenter:
    def __init__(self, window, queries: ApplicationQueries):
        self.window = window
        self.queries = queries

    def refresh(self) -> None:
        panel = self.queries.control_panel()
        self.window.control_panel.temp_pv.setText(panel.temperature_pv_text)
        self.window.control_panel.temp_state.setText(panel.temperature_state_text)
        self.window.control_panel.pressure_pv.setText(panel.pressure_pv_text)
        self.window.control_panel.pressure_state.setText(panel.pressure_state_text)
        set_output_badge(self.window.control_panel.lbl_heat, panel.heat_active, 'HEAT', 'HEAT')
        set_output_badge(self.window.control_panel.lbl_cool, panel.cool_active, 'COOL', 'COOL')
        set_output_badge(self.window.control_panel.lbl_add_gas, panel.add_gas_active, 'ADD GAS', 'ADD GAS')
        set_output_badge(self.window.control_panel.lbl_remove_gas, panel.remove_gas_active, 'REMOVE GAS', 'REMOVE GAS')
        set_output_badge(self.window.control_panel.lbl_agitator, panel.agitator_active, 'AGITATOR', 'AGITATOR')
        self.window.control_panel.agitator_rpm.setText(panel.agitator_rpm_text)
        self.window.control_panel.agitator_commanded.setText(panel.agitator_commanded_text)
        self.window.control_panel.agitator_state.setText(panel.agitator_state_text)
        self.window.control_panel.refresh_agitator_control_ui()
        self.window.control_panel.temp_band.set_values(panel.temperature_band_value, self.window.control_panel.temp_setpoint.value(), self.window.control_panel.temp_deadband.value())
        self.window.control_panel.pressure_band.set_values(panel.pressure_band_value, self.window.control_panel.pressure_setpoint.value(), self.window.control_panel.pressure_deadband.value())
        self.window.control_panel.refresh_dynamic_controller_table(self.queries.configured_controllers())


class SafetyPanelPresenter:
    def __init__(self, window, queries: ApplicationQueries):
        self.window = window
        self.queries = queries

    def refresh(self) -> None:
        panel = self.queries.safety_panel()
        self.window.safety_panel.safety_state.setText(panel.state_text)
        self.window.safety_panel.safety_state.setStyleSheet(panel.state_style)
        self.window.safety_panel.safety_effective.setText(panel.effective_outputs_text)
        self.window.safety_panel.safety_actions.setText(panel.active_actions_text)
        self.window.safety_panel.refresh_rules_table()
        if hasattr(self.window, 'log_panel'):
            self.window.log_panel.event_log.setPlainText('\n'.join(panel.event_log_lines))
            self.window.log_panel.event_log.verticalScrollBar().setValue(self.window.log_panel.event_log.verticalScrollBar().maximum())


class SchedulerPanelPresenter:
    def __init__(self, window, queries: ApplicationQueries):
        self.window = window
        self.queries = queries

    def refresh(self) -> None:
        panel = self.queries.scheduler_panel()
        self.window.scheduler_panel.scheduler_running_lbl.setText(panel.state_text)
        self.window.scheduler_panel.scheduler_current_step_lbl.setText(panel.current_step_text)
        self.window.scheduler_panel.scheduler_elapsed_lbl.setText(panel.elapsed_text)
        self.window.scheduler_panel.scheduler_wait_lbl.setText(panel.wait_text)
        self.window.scheduler_panel.scheduler_hold_lbl.setText(panel.hold_text)
        self.window.scheduler_panel.scheduler_transition_lbl.setText(panel.transition_text)
        self.window.scheduler_panel.scheduler_confirmation_lbl.setText(panel.confirmation_text)
        self.window.scheduler_panel.scheduler_file_status.setText(panel.file_status_text)
        self.window.scheduler_panel.refresh_startup_summary()
        self.window._set_toggle_style(self.window.scheduler_panel.btn_scheduler_start, panel.start_active)
        self.window._set_toggle_style(self.window.scheduler_panel.btn_scheduler_pause, panel.pause_active)
        self.window.session.update_confirm_button_state(panel.awaiting_confirmation)
        self.window._set_toggle_style(self.window.scheduler_panel.btn_scheduler_load, panel.load_active)
        self.window.scheduler_panel.scheduler_table.setRowCount(len(panel.steps))
        for row, step in enumerate(panel.steps):
            row_values = [
                step.index_text,
                step.enabled_text,
                step.name_text,
                step.temperature_text,
                step.pressure_text,
                step.gas_text,
                step.agitator_text,
                step.wait_type_text,
                step.wait_source_text,
                step.condition_text,
                step.confirm_text,
            ]
            for col, value in enumerate(row_values):
                item = QTableWidgetItem(value)
                self.window.scheduler_panel.scheduler_table.setItem(row, col, item)
                if step.is_active:
                    item.setBackground(Qt.green)
        self.window.scheduler_panel.scheduler_table.resizeRowsToContents()


class TwinPanelPresenter:
    def __init__(self, window, queries: ApplicationQueries):
        self.window = window
        self.queries = queries

    def refresh(self) -> None:
        panel = self.queries.twin_panel()
        self.window.twin_panel.twin_fmu_name.setText(panel.fmu_name_text)
        self.window.twin_panel.twin_fmu_label.setText(panel.status_text)
        self.window.twin_panel.twin_status.setText(panel.status_text)
        self.window.twin_panel.twin_runtime_mode.setText(panel.runtime_mode_text)
        self.window.twin_panel.twin_step_count.setText(panel.step_count_text)
        self.window.twin_panel.twin_sim_time.setText(panel.sim_time_text)
        self.window.twin_panel.twin_last_dt.setText(panel.last_dt_text)
        self.window.twin_panel.twin_last_age.setText(panel.last_age_text)
        self.window.twin_panel.twin_worker_period.setText(panel.worker_period_text)
        for name, widget in self.window.twin_panel.twin_output_widgets.items():
            field_vm = panel.output_fields.get(name)
            if field_vm is None:
                if hasattr(widget, 'setText'):
                    widget.setText('—')
                continue
            if field_vm.is_badge:
                set_output_badge(widget, field_vm.active, field_vm.value_text, field_vm.value_text)
            else:
                widget.setText(field_vm.value_text)


class RelayPanelPresenter:
    def __init__(self, window, queries: ApplicationQueries):
        self.window = window
        self.queries = queries

    def refresh(self) -> RelayPanelViewModel:
        panel = self.queries.relay_panel()
        self.window._set_toggle_style(self.window.relay_panel.btn_relay_connect, panel.connected)
        relay_by_channel = {item.channel: item for item in panel.channels}
        for ch, row in self.window.relay_channel_rows.items():
            vm = relay_by_channel.get(ch)
            if vm is None:
                continue
            row['label'].setText(f'Relay {ch}')
            row['combo'].setEnabled(vm.config_editable)
            row['auto'].setEnabled(vm.config_editable)
            row['test'].setEnabled(vm.manual_toggle_enabled)
            self.window._set_toggle_style(row['test'], vm.active)
            row['test'].setText(vm.manual_button_text)
            assigned = row['combo'].currentData()
            active_text = self.window.OUTPUT_LABELS.get(assigned, vm.active_text) if assigned else vm.active_text
            inactive_text = self.window.OUTPUT_LABELS.get(assigned, vm.inactive_text) if assigned else vm.inactive_text
            set_output_badge(row['active'], vm.active, active_text=active_text, inactive_text=inactive_text)
        return panel


class MainWindowRefreshCoordinator:
    def __init__(self, window, queries: ApplicationQueries):
        self.footer = FooterPresenter(window, queries)
        self.devices = DeviceTablePresenter(window, queries)
        self.control = ControlPanelPresenter(window, queries)
        self.safety = SafetyPanelPresenter(window, queries)
        self.scheduler = SchedulerPanelPresenter(window, queries)
        self.twin = TwinPanelPresenter(window, queries)
        self.relays = RelayPanelPresenter(window, queries)
