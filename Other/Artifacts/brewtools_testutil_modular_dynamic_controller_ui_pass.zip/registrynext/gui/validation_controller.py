from __future__ import annotations

from application.config_validation import ValidationResult


class WindowValidationController:
    """GUI decoration layer for shared application config validation rules."""

    ERROR_STYLE = "border: 1px solid #d32f2f;"
    WARNING_STYLE = "border: 1px solid #ed6c02;"

    def __init__(self, window):
        self.window = window
        self.last_result = ValidationResult()

    def validate_current(self, *, decorate: bool = True, show_status: bool = False) -> ValidationResult:
        config = self.window.config_controller.build_config()
        result = self.window.core.config_validation_service.validate(config)
        self.last_result = result
        if decorate:
            self._decorate(result)
        if show_status:
            self.window.statusBar().showMessage(result.summary())
        return result

    def can_apply(self, *, show_status: bool = True) -> bool:
        return self.validate_current(decorate=True, show_status=show_status).is_valid

    def _decorate(self, result: ValidationResult) -> None:
        severity_map: dict[tuple[str, str], str] = {(issue.panel, issue.field): issue.severity for issue in result.issues}
        message_map: dict[tuple[str, str], list[str]] = {}
        for issue in result.issues:
            message_map.setdefault((issue.panel, issue.field), []).append(issue.message)
        for panel, field_widgets in self._field_widgets().items():
            for field, widgets in field_widgets.items():
                widgets = widgets if isinstance(widgets, (list, tuple)) else [widgets]
                severity = severity_map.get((panel, field))
                message = "\n".join(message_map.get((panel, field), []))
                for widget in widgets:
                    self._style_widget(widget, severity, message)

    def _style_widget(self, widget, severity: str | None, message: str) -> None:
        if widget is None:
            return
        if severity == "error":
            widget.setStyleSheet(self.ERROR_STYLE)
            widget.setToolTip(message)
        elif severity == "warning":
            widget.setStyleSheet(self.WARNING_STYLE)
            widget.setToolTip(message)
        else:
            widget.setStyleSheet("")
            widget.setToolTip("")

    def _field_widgets(self) -> dict[str, dict[str, object]]:
        w = self.window
        return {
            "brew": {
                "bitrate": w.brew_panel.bitrate,
                "voltage": w.brew_panel.psu_voltage,
            },
            "control": {
                "temp_source_key": w.control_panel.temp_source_combo,
                "temp_deadband": w.control_panel.temp_deadband,
                "pressure_source_key": w.control_panel.pressure_source_combo,
                "pressure_deadband": w.control_panel.pressure_deadband,
                "agitator_target": w.control_panel.agitator_target_combo,
                "agitator_duty_cycle": w.control_panel.agitator_duty,
                "agitator_speed_setpoint_rpm": w.control_panel.agitator_speed_setpoint,
                "agitator_pid_kp": w.control_panel.agitator_pid_kp,
                "agitator_pid_ki": w.control_panel.agitator_pid_ki,
                "agitator_pid_kd": w.control_panel.agitator_pid_kd,
            },
            "relay": {
                "host": w.relay_panel.relay_host,
                "tcp_port": w.relay_panel.relay_tcp_port,
                "assignments": [row["combo"] for row in w.relay_channel_rows.values()],
            },
            "safety": {
                "stale_timeout_s": w.safety_panel.safety_stale_timeout,
                "min_switch_time_s": w.safety_panel.safety_min_switch,
                "max_temperature_c": w.safety_panel.safety_max_temp,
                "max_pressure_bar": w.safety_panel.safety_max_pressure,
                "rules": w.safety_panel.safety_rules_table,
            },
            "scheduler": {
                "workbook_path": w.scheduler_panel.scheduler_path,
                "sheet_name": w.scheduler_panel.scheduler_sheet,
                "startup_delay_s": w.scheduler_panel.scheduler_startup_delay,
            },
            "twin": {
                "fmu_path": w.twin_panel.twin_fmu_path,
            },
        }
