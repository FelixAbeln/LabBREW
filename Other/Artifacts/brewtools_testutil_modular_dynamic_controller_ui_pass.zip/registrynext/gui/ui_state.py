from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class WindowUIState:
    control_combo_sync_block: bool = False
    pending_temp_source_key: object = None
    pending_pressure_source_key: object = None
    last_temp_source_keys: list[object] = field(default_factory=list)
    last_pressure_source_keys: list[object] = field(default_factory=list)
    last_safety_signal_keys: list[object] = field(default_factory=list)
    last_agitator_target_keys: list[object] = field(default_factory=list)
    loading_twin_widgets: bool = False
    loading_scheduler_ui: bool = False
    loading_settings: bool = False

    def set_pending_temp_source_key(self, value: object) -> None:
        self.pending_temp_source_key = value

    def set_pending_pressure_source_key(self, value: object) -> None:
        self.pending_pressure_source_key = value
