from __future__ import annotations

from PySide6.QtWidgets import QMainWindow, QPushButton

from app_core import AppCore
from gui.window_bootstrap import MainWindowBootstrap


class MainWindow(QMainWindow):
    def __init__(self, *, core: AppCore):
        super().__init__()
        self.setWindowTitle('Brewtools CAN Test Utility')
        self.resize(1220, 820)

        self.core = core
        self.settings_manager = self.core.settings_manager
        self.settings = self.core.settings

        self.commands = self.core.commands
        self.queries = self.core.queries
        self.events = self.core.events
        self._action_labels = self.queries.safety_action_labels()
        self._operator_options = self.queries.operator_options()
        self._operator_keys = [opt.key for opt in self._operator_options]

        self.bootstrap = MainWindowBootstrap(self)
        self.bootstrap.initialize()

    def _set_toggle_style(self, button: QPushButton, active: bool) -> None:
        button.setChecked(active)
        if active:
            button.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def closeEvent(self, event) -> None:
        self.session.stop()
        self.config_controller.save_settings()
        super().closeEvent(event)


def run() -> int:
    from app import run_gui
    return run_gui()
