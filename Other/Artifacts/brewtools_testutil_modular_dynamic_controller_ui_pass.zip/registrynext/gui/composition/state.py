from __future__ import annotations

from application.normalization import normalize_control_source_key
from gui.constants import OUTPUT_LABELS
from gui.safety_rules_controller import SafetyRulesController
from gui.ui_state import WindowUIState


class WindowStateComposer:
    def __init__(self, window):
        self.window = window

    def compose(self) -> None:
        w = self.window
        w.ui_state = WindowUIState(
            pending_temp_source_key=normalize_control_source_key(w.settings.temp_controller.source_key),
            pending_pressure_source_key=normalize_control_source_key(w.settings.pressure_controller.source_key),
        )
        w.safety_rules_controller = SafetyRulesController()
        w.OUTPUT_LABELS = OUTPUT_LABELS
        w.relay_channel_rows = {}
