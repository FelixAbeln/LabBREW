from __future__ import annotations

from gui.editors import build_main_window_editors
from gui.intent_dispatcher import WindowIntentDispatcher
from gui.panel_facades import build_panel_facades
from gui.window_shell import MainWindowShell


class WindowShellComposer:
    def __init__(self, window):
        self.window = window

    def compose(self) -> None:
        w = self.window
        self._create_facade_visible_collaborators()
        w._panel_facades = build_panel_facades(w)
        w.shell = MainWindowShell(w)
        w.shell.build()
        w.editors = build_main_window_editors(w)
        w.shell.wire_signals()

    def _create_facade_visible_collaborators(self) -> None:
        self.window.intent_dispatcher = WindowIntentDispatcher(self.window)
