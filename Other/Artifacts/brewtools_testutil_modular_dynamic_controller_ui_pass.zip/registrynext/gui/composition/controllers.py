from __future__ import annotations

from gui.config_adapters import ApplicationConfigBuilder
from gui.config_controller import WindowConfigController
from gui.controllers import (
    BrewPanelController,
    ControlSourcesController,
    RelayPanelController,
    SchedulerPanelController,
    TwinSourcesController,
    WindowSourceController,
    ControllerInventoryController,
)
from gui.settings_loader import WindowSettingsLoader


class WindowControllersComposer:
    def __init__(self, window):
        self.window = window

    def compose(self) -> None:
        w = self.window
        w._config_builder = ApplicationConfigBuilder(w)
        w.config_controller = WindowConfigController(w, w._config_builder)
        w.brew_controller = BrewPanelController(w)
        w.relay_controller = RelayPanelController(w)
        w.scheduler_controller = SchedulerPanelController(w)
        w.control_sources_controller = ControlSourcesController(w)
        w.twin_sources_controller = TwinSourcesController(w)
        w.source_controller = WindowSourceController(w.control_sources_controller, w.twin_sources_controller)
        w.controller_inventory_controller = ControllerInventoryController(w)
        w.settings_loader = WindowSettingsLoader(w)
