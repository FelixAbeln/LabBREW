from __future__ import annotations

from gui.runtime_bridge import WindowRuntimeBridge
from gui.validation_controller import WindowValidationController
from gui.window_session import MainWindowSession


class WindowRuntimeComposer:
    def __init__(self, window):
        self.window = window

    def compose(self) -> None:
        w = self.window
        w.runtime_bridge = WindowRuntimeBridge(w)
        w.validation_controller = WindowValidationController(w)
        w.session = MainWindowSession(w)
        w.session.bind_runtime_events()
