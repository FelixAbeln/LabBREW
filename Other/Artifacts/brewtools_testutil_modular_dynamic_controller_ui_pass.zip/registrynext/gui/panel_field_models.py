from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class BrewPanelFormState:
    bitrate: int
    can_channel: object
    can_channel_label: str
    psu_com_port: str
    voltage: float


@dataclass(frozen=True)
class ControlPanelFormState:
    temp_enabled: bool
    temp_source_key: Optional[object]
    temp_setpoint: float
    temp_deadband: float
    pressure_enabled: bool
    pressure_source_key: Optional[object]
    pressure_setpoint: float
    pressure_deadband: float
    pressure_allow_add_gas: bool
    agitator_enabled: bool
    agitator_target: str
    agitator_on: bool
    agitator_duty_cycle: float
    agitator_mode: str
    agitator_speed_setpoint_rpm: float
    agitator_pid_kp: float
    agitator_pid_ki: float
    agitator_pid_kd: float


@dataclass(frozen=True)
class RelayPanelFormState:
    host: str
    tcp_port: int
    assignments: dict[str, Optional[str]] = field(default_factory=dict)
    auto_enabled: dict[str, bool] = field(default_factory=dict)
    manual_states: dict[str, bool] = field(default_factory=dict)


@dataclass(frozen=True)
class SafetyPanelFormState:
    enabled: bool
    stale_timeout_s: float
    min_switch_time_s: float
    require_can_connected: bool
    require_psu_power: bool
    require_relays_connected: bool
    max_temperature_enabled: bool
    max_temperature_c: float
    max_pressure_enabled: bool
    max_pressure_bar: float
    power_off_psu_on_trip: bool
    all_relays_off_on_trip: bool
    safe_outputs: dict[str, bool] = field(default_factory=dict)


@dataclass(frozen=True)
class SchedulerPanelFormState:
    enabled: bool
    workbook_path: str
    sheet_name: str
    auto_start: bool
    startup_sequence_enabled: bool
    startup_auto_connect_relays: bool
    startup_auto_connect_can: bool
    startup_auto_power_psu: bool
    startup_auto_load_twin: bool
    startup_delay_s: float
    startup_show_advanced: bool


@dataclass(frozen=True)
class TwinPanelFormState:
    enabled: bool
    fmu_path: str
    input_bindings: dict[str, Optional[str]] = field(default_factory=dict)
