from __future__ import annotations

from PySide6.QtWidgets import QWidget, QVBoxLayout, QTabWidget

from gui.panels import (
    BrewPanel,
    ControlPanel,
    LogPanel,
    RelayPanel,
    SafetyPanel,
    SchedulerPanel,
    TwinPanel,
)


class MainWindowShell:
    """Owns top-level window assembly so MainWindow stays focused on composition."""

    def __init__(self, window):
        self.window = window

    def build(self) -> None:
        w = self.window
        root = QWidget()
        w.setCentralWidget(root)
        outer = QVBoxLayout(root)

        w.tabs = QTabWidget()
        outer.addWidget(w.tabs)

        w.brew_panel = BrewPanel(w._panel_facades.brew)
        w.control_panel = ControlPanel(w._panel_facades.control)
        w.safety_panel = SafetyPanel(w._panel_facades.safety)
        w.log_panel = LogPanel()
        w.twin_panel = TwinPanel(w._panel_facades.twin)
        w.scheduler_panel = SchedulerPanel(w._panel_facades.scheduler)
        w.relay_panel = RelayPanel(w._panel_facades.relay)

        w.tabs.addTab(w.brew_panel, 'Brewtools')
        w.tabs.addTab(w.control_panel, 'Control')
        w.tabs.addTab(w.safety_panel, 'Safety')
        w.tabs.addTab(w.log_panel, 'System Log')
        w.tabs.addTab(w.twin_panel, 'Twin')
        w.tabs.addTab(w.scheduler_panel, 'Scheduler')
        w.tabs.addTab(w.relay_panel, 'Relays')
        w.footer_event_lbl = None
        w.footer_state_lbl = None

    def wire_signals(self) -> None:
        w = self.window
        w.brew_panel.wire_signals()
        w.control_panel.wire_signals()
        w.safety_panel.wire_signals()
        w.twin_panel.wire_signals()
        w.scheduler_panel.wire_signals()
        w.relay_panel.wire_signals()
