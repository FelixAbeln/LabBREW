from __future__ import annotations

from dataclasses import dataclass

from gui.editors.base import EditorStateMixin
from gui.panel_field_models import BrewPanelFormState


@dataclass
class BrewPanelEditor(EditorStateMixin):
    panel: object
    settings: object
    state: BrewPanelFormState | None = None

    def __post_init__(self) -> None:
        self.state = BrewPanelFormState(
            bitrate=int(self.settings.bitrate),
            can_channel=self.settings.can_channel,
            can_channel_label='',
            psu_com_port=str(self.settings.psu_com_port or ''),
            voltage=float(self.settings.voltage),
        )

    def bind(self) -> None:
        self.panel.bitrate.valueChanged.connect(lambda value: self._replace_state(BrewPanelFormState, bitrate=int(value)))
        self.panel.channel_combo.currentIndexChanged.connect(self._on_channel_changed)
        self.panel.psu_port_combo.currentIndexChanged.connect(self._on_psu_port_changed)
        self.panel.psu_voltage.valueChanged.connect(lambda value: self._replace_state(BrewPanelFormState, voltage=float(value)))

    def _on_channel_changed(self, _index: int) -> None:
        self._replace_state(
            BrewPanelFormState,
            can_channel=self.panel.channel_combo.currentData(),
            can_channel_label=self.panel.channel_combo.currentText().strip() if self.panel.channel_combo.count() else '',
        )

    def _on_psu_port_changed(self, _index: int) -> None:
        self._replace_state(BrewPanelFormState, psu_com_port=str(self.panel.psu_port_combo.currentData() or ''))

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        self.state = BrewPanelFormState(
            bitrate=int(settings.bitrate),
            can_channel=settings.can_channel,
            can_channel_label=self.state.can_channel_label,
            psu_com_port=str(settings.psu_com_port or ''),
            voltage=float(settings.voltage),
        )
        self.panel.bitrate.setValue(settings.bitrate)
        self.panel.psu_voltage.setValue(settings.voltage)
        idx = self.panel.channel_combo.findData(settings.can_channel)
        if idx >= 0:
            self.panel.channel_combo.setCurrentIndex(idx)
        idx = self.panel.psu_port_combo.findData(settings.psu_com_port)
        if idx >= 0:
            self.panel.psu_port_combo.setCurrentIndex(idx)
