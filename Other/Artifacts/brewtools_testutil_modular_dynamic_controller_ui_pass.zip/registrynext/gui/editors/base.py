from __future__ import annotations

class EditorStateMixin:
    def _replace_state(self, state_type, **changes) -> None:
        self.state = state_type(**{**self.state.__dict__, **changes})
