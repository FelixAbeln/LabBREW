from __future__ import annotations

from dataclasses import dataclass

from gui.editors.base import EditorStateMixin
from gui.panel_field_models import RelayPanelFormState
from gui.ui_helpers import find_data_index

@dataclass
class RelayPanelEditor(EditorStateMixin):
    panel: object
    relay_channel_rows: dict[int, dict[str, object]]
    settings: object
    state: RelayPanelFormState | None = None

    def __post_init__(self) -> None:
        self.state = RelayPanelFormState(
            host=str(self.settings.relay.host),
            tcp_port=int(self.settings.relay.tcp_port),
            assignments={str(k): v for k, v in self.settings.relay.assignments.items()},
            auto_enabled={str(k): bool(v) for k, v in self.settings.relay.auto_enabled.items()},
            manual_states={str(k): False for k in self.settings.relay.assignments.keys()},
        )

    def bind(self) -> None:
        self.panel.relay_host.editTextChanged.connect(lambda text: self._replace_state(RelayPanelFormState, host=text.strip()))
        self.panel.relay_tcp_port.valueChanged.connect(lambda value: self._replace_state(RelayPanelFormState, tcp_port=int(value)))
        for ch, row in self.relay_channel_rows.items():
            key = str(ch)
            row['combo'].currentIndexChanged.connect(lambda _i, k=key, combo=row['combo']: self._set_assignment(k, combo.currentData()))
            row['auto'].toggled.connect(lambda value, k=key: self._set_auto(k, bool(value)))
            row['test'].toggled.connect(lambda value, k=key: self._set_manual(k, bool(value)))


    def _set_assignment(self, key: str, value) -> None:
        assignments = dict(self.state.assignments)
        assignments[key] = value
        self._replace_state(RelayPanelFormState, assignments=assignments)

    def _set_auto(self, key: str, value: bool) -> None:
        auto = dict(self.state.auto_enabled)
        auto[key] = value
        self._replace_state(RelayPanelFormState, auto_enabled=auto)

    def _set_manual(self, key: str, value: bool) -> None:
        manual = dict(self.state.manual_states)
        manual[key] = value
        self._replace_state(RelayPanelFormState, manual_states=manual)

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        self.state = RelayPanelFormState(
            host=str(settings.relay.host),
            tcp_port=int(settings.relay.tcp_port),
            assignments={str(k): v for k, v in settings.relay.assignments.items()},
            auto_enabled={str(k): bool(v) for k, v in settings.relay.auto_enabled.items()},
            manual_states={str(k): False for k in settings.relay.assignments.keys()},
        )
        self.panel.relay_host.setEditText(settings.relay.host)
        self.panel.relay_tcp_port.setValue(int(settings.relay.tcp_port))
        for ch, row in self.relay_channel_rows.items():
            key = str(ch)
            target = settings.relay.assignments.get(key)
            idx = find_data_index(row['combo'], target)
            row['combo'].setCurrentIndex(idx if idx >= 0 else 0)
            row['auto'].setChecked(bool(settings.relay.auto_enabled.get(key, True)))
            row['test'].setChecked(False)
