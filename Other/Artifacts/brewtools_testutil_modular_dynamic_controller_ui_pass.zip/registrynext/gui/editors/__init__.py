from __future__ import annotations

from dataclasses import dataclass

from gui.editors.brew import BrewPanelEditor
from gui.editors.control import ControlPanelEditor
from gui.editors.relay import RelayPanelEditor
from gui.editors.safety import SafetyPanelEditor
from gui.editors.scheduler import SchedulerPanelEditor
from gui.editors.twin import TwinPanelEditor


@dataclass
class MainWindowEditors:
    brew: BrewPanelEditor
    control: ControlPanelEditor
    relay: RelayPanelEditor
    safety: SafetyPanelEditor
    scheduler: SchedulerPanelEditor
    twin: TwinPanelEditor


def build_main_window_editors(window) -> MainWindowEditors:
    editors = MainWindowEditors(
        brew=BrewPanelEditor(window.brew_panel, window.settings),
        control=ControlPanelEditor(window.control_panel, window.ui_state, window.settings),
        relay=RelayPanelEditor(window.relay_panel, window.relay_channel_rows, window.settings),
        safety=SafetyPanelEditor(window.safety_panel, window.safety_rules_controller, window.settings),
        scheduler=SchedulerPanelEditor(window.scheduler_panel, window.settings),
        twin=TwinPanelEditor(window.twin_panel, window.settings),
    )
    editors.brew.bind()
    editors.control.bind()
    editors.relay.bind()
    editors.safety.bind()
    editors.scheduler.bind()
    editors.twin.bind()
    return editors
