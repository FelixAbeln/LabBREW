from __future__ import annotations

from dataclasses import dataclass

from gui.editors.base import EditorStateMixin
from gui.panel_field_models import SafetyPanelFormState

@dataclass
class SafetyPanelEditor(EditorStateMixin):
    panel: object
    rules_controller: object
    settings: object
    state: SafetyPanelFormState | None = None

    def __post_init__(self) -> None:
        s = self.settings.safety
        self.state = SafetyPanelFormState(
            enabled=bool(s.enabled), stale_timeout_s=float(s.stale_timeout_s), min_switch_time_s=float(s.min_switch_time_s),
            require_can_connected=bool(s.require_can_connected), require_psu_power=bool(s.require_psu_power), require_relays_connected=bool(s.require_relays_connected),
            max_temperature_enabled=bool(s.max_temperature_enabled), max_temperature_c=float(s.max_temperature_c),
            max_pressure_enabled=bool(s.max_pressure_enabled), max_pressure_bar=float(s.max_pressure_bar),
            power_off_psu_on_trip=bool(s.power_off_psu_on_trip), all_relays_off_on_trip=bool(s.all_relays_off_on_trip),
            safe_outputs={k: bool(v) for k, v in s.safe_outputs.items()},
        )

    def bind(self) -> None:
        p=self.panel
        p.safety_enabled.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, enabled=bool(value)))
        p.safety_stale_timeout.valueChanged.connect(lambda value: self._replace_state(SafetyPanelFormState, stale_timeout_s=float(value)))
        p.safety_min_switch.valueChanged.connect(lambda value: self._replace_state(SafetyPanelFormState, min_switch_time_s=float(value)))
        p.safety_require_can.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, require_can_connected=bool(value)))
        p.safety_require_psu.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, require_psu_power=bool(value)))
        p.safety_require_relays.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, require_relays_connected=bool(value)))
        p.safety_max_temp_enabled.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, max_temperature_enabled=bool(value)))
        p.safety_max_temp.valueChanged.connect(lambda value: self._replace_state(SafetyPanelFormState, max_temperature_c=float(value)))
        p.safety_max_pressure_enabled.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, max_pressure_enabled=bool(value)))
        p.safety_max_pressure.valueChanged.connect(lambda value: self._replace_state(SafetyPanelFormState, max_pressure_bar=float(value)))
        p.safe_psu_off.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, power_off_psu_on_trip=bool(value)))
        p.safe_all_relays_off.toggled.connect(lambda value: self._replace_state(SafetyPanelFormState, all_relays_off_on_trip=bool(value)))
        for key, cb in [('heat',p.safe_heat),('cool',p.safe_cool),('add_gas',p.safe_add_gas),('remove_gas',p.safe_remove_gas),('agitator',p.safe_agitator)]:
            cb.toggled.connect(lambda value, k=key: self._set_safe_output(k, bool(value)))


    def _set_safe_output(self, key: str, value: bool) -> None:
        outputs = dict(self.state.safe_outputs)
        outputs[key] = value
        self._replace_state(SafetyPanelFormState, safe_outputs=outputs)

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        s = settings.safety
        self.state = SafetyPanelFormState(
            enabled=bool(s.enabled), stale_timeout_s=float(s.stale_timeout_s), min_switch_time_s=float(s.min_switch_time_s),
            require_can_connected=bool(s.require_can_connected), require_psu_power=bool(s.require_psu_power), require_relays_connected=bool(s.require_relays_connected),
            max_temperature_enabled=bool(s.max_temperature_enabled), max_temperature_c=float(s.max_temperature_c),
            max_pressure_enabled=bool(s.max_pressure_enabled), max_pressure_bar=float(s.max_pressure_bar),
            power_off_psu_on_trip=bool(s.power_off_psu_on_trip), all_relays_off_on_trip=bool(s.all_relays_off_on_trip),
            safe_outputs={k: bool(v) for k, v in s.safe_outputs.items()},
        )
        p=self.panel
        p.safety_enabled.setChecked(s.enabled)
        p.safety_require_can.setChecked(s.require_can_connected)
        p.safety_require_psu.setChecked(s.require_psu_power)
        p.safety_require_relays.setChecked(s.require_relays_connected)
        p.safety_stale_timeout.setValue(float(s.stale_timeout_s))
        p.safety_min_switch.setValue(float(s.min_switch_time_s))
        p.safety_max_temp_enabled.setChecked(bool(s.max_temperature_enabled))
        p.safety_max_temp.setValue(float(s.max_temperature_c))
        p.safety_max_pressure_enabled.setChecked(bool(s.max_pressure_enabled))
        p.safety_max_pressure.setValue(float(s.max_pressure_bar))
        p.safe_heat.setChecked(bool(s.safe_outputs.get('heat', False)))
        p.safe_cool.setChecked(bool(s.safe_outputs.get('cool', False)))
        p.safe_add_gas.setChecked(bool(s.safe_outputs.get('add_gas', False)))
        p.safe_remove_gas.setChecked(bool(s.safe_outputs.get('remove_gas', False)))
        p.safe_psu_off.setChecked(bool(s.power_off_psu_on_trip))
        p.safe_all_relays_off.setChecked(bool(s.all_relays_off_on_trip))
        p.safe_agitator.setChecked(bool(s.safe_outputs.get('agitator', False)))
        self.rules_controller.load_from_settings(getattr(s, 'rules', []))
        p.refresh_rules_table()
        p.clear_rule_editor()
