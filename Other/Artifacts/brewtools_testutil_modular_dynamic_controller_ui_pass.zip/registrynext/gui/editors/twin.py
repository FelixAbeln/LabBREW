from __future__ import annotations

from dataclasses import dataclass

from gui.editors.base import EditorStateMixin
from gui.panel_field_models import TwinPanelFormState

@dataclass
class TwinPanelEditor(EditorStateMixin):
    panel: object
    settings: object
    state: TwinPanelFormState | None = None

    def __post_init__(self) -> None:
        t = self.settings.twin
        self.state = TwinPanelFormState(enabled=bool(t.enabled), fmu_path=str(t.fmu_path), input_bindings=dict(getattr(t, 'input_bindings', {}) or {}))

    def bind(self) -> None:
        self.panel.twin_enabled.toggled.connect(lambda value: self._replace_state(TwinPanelFormState, enabled=bool(value)))
        self.panel.twin_fmu_path.textChanged.connect(lambda text: self._replace_state(TwinPanelFormState, fmu_path=text.strip()))
        self.bind_dynamic_inputs()

    def bind_dynamic_inputs(self) -> None:
        for name, combo in self.panel.twin_input_combos.items():
            try:
                combo.currentIndexChanged.disconnect()
            except Exception:
                pass
            combo.currentIndexChanged.connect(lambda idx, n=name, c=combo: self._set_input_binding(n, c.itemData(idx) if idx >= 0 else None))
            if combo.count() and combo.currentIndex() >= 0:
                self._set_input_binding(name, combo.currentData())


    def _set_input_binding(self, name: str, value) -> None:
        bindings = dict(self.state.input_bindings)
        bindings[name] = value
        self._replace_state(TwinPanelFormState, input_bindings=bindings)

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        t = settings.twin
        self.state = TwinPanelFormState(enabled=bool(t.enabled), fmu_path=str(t.fmu_path), input_bindings=dict(getattr(t, 'input_bindings', {}) or {}))
        self.panel.twin_enabled.setChecked(t.enabled)
        self.panel.twin_fmu_path.setText(t.fmu_path)
