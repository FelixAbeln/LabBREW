from __future__ import annotations

from dataclasses import dataclass

from gui.editors.base import EditorStateMixin
from gui.panel_field_models import SchedulerPanelFormState

@dataclass
class SchedulerPanelEditor(EditorStateMixin):
    panel: object
    settings: object
    state: SchedulerPanelFormState | None = None

    def __post_init__(self) -> None:
        s = self.settings.scheduler
        self.state = SchedulerPanelFormState(
            enabled=bool(s.enabled), workbook_path=str(s.workbook_path), sheet_name=str(s.sheet_name), auto_start=bool(s.auto_start),
            startup_sequence_enabled=bool(s.startup_sequence_enabled), startup_auto_connect_relays=bool(s.startup_auto_connect_relays),
            startup_auto_connect_can=bool(s.startup_auto_connect_can), startup_auto_power_psu=bool(s.startup_auto_power_psu),
            startup_auto_load_twin=bool(s.startup_auto_load_twin), startup_delay_s=float(s.startup_delay_s), startup_show_advanced=bool(s.startup_show_advanced),
        )

    def bind(self) -> None:
        p=self.panel
        p.scheduler_enabled.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, enabled=bool(value)))
        p.scheduler_path.textChanged.connect(lambda text: self._replace_state(SchedulerPanelFormState, workbook_path=text.strip()))
        p.scheduler_sheet.currentTextChanged.connect(lambda text: self._replace_state(SchedulerPanelFormState, sheet_name=text.strip()))
        p.scheduler_auto_start.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, auto_start=bool(value)))
        p.scheduler_startup_enabled.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, startup_sequence_enabled=bool(value)))
        p.scheduler_startup_connect_relays.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, startup_auto_connect_relays=bool(value)))
        p.scheduler_startup_connect_can.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, startup_auto_connect_can=bool(value)))
        p.scheduler_startup_power_psu.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, startup_auto_power_psu=bool(value)))
        p.scheduler_startup_load_twin.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, startup_auto_load_twin=bool(value)))
        p.scheduler_startup_delay.valueChanged.connect(lambda value: self._replace_state(SchedulerPanelFormState, startup_delay_s=float(value)))
        p.scheduler_startup_section.toggle_button.toggled.connect(lambda value: self._replace_state(SchedulerPanelFormState, startup_show_advanced=bool(value)))


    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        s = settings.scheduler
        self.state = SchedulerPanelFormState(
            enabled=bool(s.enabled), workbook_path=str(s.workbook_path), sheet_name=str(s.sheet_name), auto_start=bool(s.auto_start),
            startup_sequence_enabled=bool(s.startup_sequence_enabled), startup_auto_connect_relays=bool(s.startup_auto_connect_relays),
            startup_auto_connect_can=bool(s.startup_auto_connect_can), startup_auto_power_psu=bool(s.startup_auto_power_psu),
            startup_auto_load_twin=bool(s.startup_auto_load_twin), startup_delay_s=float(s.startup_delay_s), startup_show_advanced=bool(s.startup_show_advanced),
        )
        p=self.panel
        p.scheduler_enabled.setChecked(s.enabled)
        p.scheduler_auto_start.setChecked(s.auto_start)
        p.scheduler_path.setText(s.workbook_path)
        p.scheduler_startup_enabled.setChecked(bool(s.startup_sequence_enabled))
        p.scheduler_startup_connect_relays.setChecked(bool(s.startup_auto_connect_relays))
        p.scheduler_startup_connect_can.setChecked(bool(s.startup_auto_connect_can))
        p.scheduler_startup_power_psu.setChecked(bool(s.startup_auto_power_psu))
        p.scheduler_startup_load_twin.setChecked(bool(s.startup_auto_load_twin))
        p.scheduler_startup_delay.setValue(float(s.startup_delay_s or 0.0))
        p.scheduler_startup_section.toggle_button.setChecked(bool(s.startup_show_advanced))
