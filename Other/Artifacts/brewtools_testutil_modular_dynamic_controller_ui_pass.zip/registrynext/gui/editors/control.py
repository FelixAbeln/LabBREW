from __future__ import annotations

from dataclasses import dataclass

from gui.editors.base import EditorStateMixin
from gui.panel_field_models import ControlPanelFormState
from gui.ui_helpers import normalize_signal_key


@dataclass
class ControlPanelEditor(EditorStateMixin):
    panel: object
    ui_state: object
    settings: object
    state: ControlPanelFormState | None = None

    def __post_init__(self) -> None:
        a = self.settings.agitator
        self.state = ControlPanelFormState(
            temp_enabled=bool(self.settings.temp_controller.enabled),
            temp_source_key=normalize_signal_key(self.settings.temp_controller.source_key),
            temp_setpoint=float(self.settings.temp_controller.setpoint),
            temp_deadband=float(self.settings.temp_controller.deadband),
            pressure_enabled=bool(self.settings.pressure_controller.enabled),
            pressure_source_key=normalize_signal_key(self.settings.pressure_controller.source_key),
            pressure_setpoint=float(self.settings.pressure_controller.setpoint),
            pressure_deadband=float(self.settings.pressure_controller.deadband),
            pressure_allow_add_gas=bool(getattr(self.settings.pressure_controller, 'allow_add_gas', True)),
            agitator_enabled=bool(getattr(a, 'enabled', False)),
            agitator_target=(str(getattr(a, 'target', 'relay') or 'relay') if str(getattr(a, 'target', 'relay') or 'relay').startswith('agitator_target:') else f"agitator_target:{str(getattr(a, 'target', 'relay') or 'relay')}"),
            agitator_on=bool(getattr(a, 'on', False)),
            agitator_duty_cycle=float(getattr(a, 'duty_cycle', 100.0)),
            agitator_mode=str(getattr(a, 'mode', 'manual') or 'manual'),
            agitator_speed_setpoint_rpm=float(getattr(a, 'speed_setpoint_rpm', 120.0)),
            agitator_pid_kp=float(getattr(a, 'pid_kp', 0.30)),
            agitator_pid_ki=float(getattr(a, 'pid_ki', 0.05)),
            agitator_pid_kd=float(getattr(a, 'pid_kd', 0.00)),
        )

    def bind(self) -> None:
        p = self.panel
        p.temp_ctrl_enabled.toggled.connect(lambda value: self._replace_state(ControlPanelFormState, temp_enabled=bool(value)))
        p.temp_source_combo.currentIndexChanged.connect(
            lambda _i: self._replace_state(
                ControlPanelFormState,
                temp_source_key=normalize_signal_key(p.temp_source_combo.currentData()) or self.state.temp_source_key,
            )
        )
        p.temp_setpoint.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, temp_setpoint=float(value)))
        p.temp_deadband.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, temp_deadband=float(value)))
        p.pressure_ctrl_enabled.toggled.connect(lambda value: self._replace_state(ControlPanelFormState, pressure_enabled=bool(value)))
        p.pressure_source_combo.currentIndexChanged.connect(
            lambda _i: self._replace_state(
                ControlPanelFormState,
                pressure_source_key=normalize_signal_key(p.pressure_source_combo.currentData()) or self.state.pressure_source_key,
            )
        )
        p.pressure_setpoint.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, pressure_setpoint=float(value)))
        p.pressure_deadband.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, pressure_deadband=float(value)))
        p.pressure_allow_add_gas.toggled.connect(lambda value: self._replace_state(ControlPanelFormState, pressure_allow_add_gas=bool(value)))
        p.agitator_enabled.toggled.connect(lambda value: self._replace_state(ControlPanelFormState, agitator_enabled=bool(value)))
        p.agitator_target_combo.currentIndexChanged.connect(self._on_agitator_target_changed)
        p.agitator_on.toggled.connect(lambda value: self._replace_state(ControlPanelFormState, agitator_on=bool(value)))
        p.agitator_duty.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, agitator_duty_cycle=float(value)))
        p.agitator_control_mode.currentIndexChanged.connect(self._on_agitator_mode_changed)
        p.agitator_speed_setpoint.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, agitator_speed_setpoint_rpm=float(value)))
        p.agitator_pid_kp.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, agitator_pid_kp=float(value)))
        p.agitator_pid_ki.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, agitator_pid_ki=float(value)))
        p.agitator_pid_kd.valueChanged.connect(lambda value: self._replace_state(ControlPanelFormState, agitator_pid_kd=float(value)))

    def _on_agitator_target_changed(self, _index: int) -> None:
        self._replace_state(ControlPanelFormState, agitator_target=str(self.panel.agitator_target_combo.currentData() or self.state.agitator_target))

    def _on_agitator_mode_changed(self, _index: int) -> None:
        self._replace_state(ControlPanelFormState, agitator_mode=str(self.panel.agitator_control_mode.currentData() or self.state.agitator_mode))

    def read_form_state(self):
        return self.state

    def apply_settings(self, settings) -> None:
        self.ui_state.pending_temp_source_key = normalize_signal_key(settings.temp_controller.source_key)
        self.ui_state.pending_pressure_source_key = normalize_signal_key(settings.pressure_controller.source_key)
        a = settings.agitator
        self.state = ControlPanelFormState(
            temp_enabled=bool(settings.temp_controller.enabled),
            temp_source_key=normalize_signal_key(settings.temp_controller.source_key),
            temp_setpoint=float(settings.temp_controller.setpoint),
            temp_deadband=float(settings.temp_controller.deadband),
            pressure_enabled=bool(settings.pressure_controller.enabled),
            pressure_source_key=normalize_signal_key(settings.pressure_controller.source_key),
            pressure_setpoint=float(settings.pressure_controller.setpoint),
            pressure_deadband=float(settings.pressure_controller.deadband),
            pressure_allow_add_gas=bool(getattr(settings.pressure_controller, 'allow_add_gas', True)),
            agitator_enabled=bool(getattr(a, 'enabled', False)),
            agitator_target=(str(getattr(a, 'target', 'relay') or 'relay') if str(getattr(a, 'target', 'relay') or 'relay').startswith('agitator_target:') else f"agitator_target:{str(getattr(a, 'target', 'relay') or 'relay')}"),
            agitator_on=bool(getattr(a, 'on', False)),
            agitator_duty_cycle=float(getattr(a, 'duty_cycle', 100.0)),
            agitator_mode=str(getattr(a, 'mode', 'manual') or 'manual'),
            agitator_speed_setpoint_rpm=float(getattr(a, 'speed_setpoint_rpm', 120.0)),
            agitator_pid_kp=float(getattr(a, 'pid_kp', 0.30)),
            agitator_pid_ki=float(getattr(a, 'pid_ki', 0.05)),
            agitator_pid_kd=float(getattr(a, 'pid_kd', 0.00)),
        )
        p = self.panel
        p.temp_ctrl_enabled.setChecked(settings.temp_controller.enabled)
        p.temp_setpoint.setValue(settings.temp_controller.setpoint)
        p.temp_deadband.setValue(settings.temp_controller.deadband)
        p.pressure_ctrl_enabled.setChecked(settings.pressure_controller.enabled)
        p.pressure_setpoint.setValue(settings.pressure_controller.setpoint)
        p.pressure_deadband.setValue(settings.pressure_controller.deadband)
        p.pressure_allow_add_gas.setChecked(bool(getattr(settings.pressure_controller, 'allow_add_gas', True)))
        p.agitator_enabled.setChecked(bool(getattr(a, 'enabled', False)))
        p.agitator_on.setChecked(bool(getattr(a, 'on', False)))
        p.agitator_duty.setValue(float(getattr(a, 'duty_cycle', 100.0)))
        p.agitator_speed_setpoint.setValue(float(getattr(a, 'speed_setpoint_rpm', 120.0)))
        p.agitator_pid_kp.setValue(float(getattr(a, 'pid_kp', 0.30)))
        p.agitator_pid_ki.setValue(float(getattr(a, 'pid_ki', 0.05)))
        p.agitator_pid_kd.setValue(float(getattr(a, 'pid_kd', 0.00)))
        idx = p.agitator_control_mode.findData(getattr(a, 'mode', 'manual'))
        p.agitator_control_mode.setCurrentIndex(idx if idx >= 0 else 0)
        p.refresh_agitator_control_ui()
