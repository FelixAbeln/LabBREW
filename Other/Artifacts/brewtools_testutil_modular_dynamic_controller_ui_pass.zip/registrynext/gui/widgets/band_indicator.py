from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QWidget


class BandIndicator(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(22)
        self.setMinimumWidth(180)
        self.value = None
        self.setpoint = 0.0
        self.deadband = 1.0

    def set_values(self, value, setpoint, deadband):
        self.value = value
        self.setpoint = float(setpoint)
        self.deadband = max(float(deadband), 1e-9)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = self.rect().adjusted(6, 5, -6, -5)
        if r.width() <= 0 or r.height() <= 0:
            return

        # Base line
        mid_y = r.center().y()
        p.setPen(QPen(QColor('#9aa0a6'), 2))
        p.drawLine(r.left(), mid_y, r.right(), mid_y)

        if self.value is None:
            return

        left_band = self.setpoint - self.deadband
        right_band = self.setpoint + self.deadband
        span = max(self.deadband * 4.0, abs(self.value - self.setpoint) * 1.2, 1e-6)
        min_v = self.setpoint - span
        max_v = self.setpoint + span

        def x_for(v: float) -> int:
            frac = (v - min_v) / (max_v - min_v)
            frac = max(0.0, min(1.0, frac))
            return int(r.left() + frac * r.width())

        xl = x_for(left_band)
        xc = x_for(self.setpoint)
        xr = x_for(right_band)
        xv = x_for(float(self.value))

        # Band region
        p.fillRect(xl, mid_y - 5, max(2, xr - xl), 10, QColor('#dbeafe'))

        # Band markers + setpoint
        p.setPen(QPen(QColor('#6b7280'), 2))
        p.drawLine(xl, mid_y - 8, xl, mid_y + 8)
        p.drawLine(xr, mid_y - 8, xr, mid_y + 8)
        p.setPen(QPen(QColor('#111827'), 2))
        p.drawLine(xc, mid_y - 10, xc, mid_y + 10)

        # Value marker color based on zone
        if self.value < left_band:
            color = QColor('#2563eb')
        elif self.value > right_band:
            color = QColor('#dc2626')
        else:
            color = QColor('#16a34a')

        p.setPen(QPen(color, 3))
        p.drawLine(xv, mid_y - 12, xv, mid_y + 12)
        p.setBrush(color)
        p.drawEllipse(xv - 4, mid_y - 4, 8, 8)
