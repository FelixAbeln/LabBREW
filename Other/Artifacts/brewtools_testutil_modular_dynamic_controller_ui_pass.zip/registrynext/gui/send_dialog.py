from __future__ import annotations

import can
from typing import Dict
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFormLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QSpinBox,
    QStackedWidget, QVBoxLayout, QWidget
)
from brewtools_can import BrewtoolsCanId, CanFrame, MsgType, NodeType, Priority
from brewtools_can.bodies import FloatBody, NodeIdBody, RawBody
from brewtools_can.domain import CalibrationCmd

from state import DeviceKey, DeviceState
from helpers import float_to_hex_le, format_node_type, hex_bytes, parse_hex_bytes, u32_to_hex_be
from services.integrations.can import build_start_measurement_frame


class FloatPrompt(QDialog):
    def __init__(self, parent=None, title="Enter float"):
        super().__init__(parent)
        self.setWindowTitle(title)
        lay = QVBoxLayout(self)
        self.spin = QDoubleSpinBox()
        self.spin.setDecimals(6)
        self.spin.setRange(-1e9, 1e9)
        self.spin.setValue(0.0)
        ok = QPushButton("Insert")
        lay.addWidget(self.spin)
        lay.addWidget(ok)
        ok.clicked.connect(self.accept)

    def value(self) -> float:
        return float(self.spin.value())
    
class SendDialog(QDialog):
    def __init__(self, parent, devices: Dict[DeviceKey, DeviceState], channel: int, bitrate: int):
        super().__init__(parent)
        self.setWindowTitle("Send Brewtools CAN")
        self.devices = devices
        self.channel = channel
        self.bitrate = bitrate
        self.resize(760, 560)

        root = QVBoxLayout(self)

        # ---- Top: device + template ----
        top = QGroupBox("Target & message")
        top_l = QFormLayout(top)

        self.device_combo = QComboBox()
        self._device_keys: list[DeviceKey] = []
        for k, st in sorted(self.devices.items(), key=lambda kv: (kv[0][0], kv[0][1])):
            k = tuple(k)
            label = f"{format_node_type(st.sender_node_type)} (sec {st.node_id})"
            self.device_combo.addItem(label, k)  # store DeviceKey
            self._device_keys.append(k)

        self.expert = QCheckBox("Expert mode (show config/write commands)")
        self.expert.setChecked(False)

        self.kind_combo = QComboBox()
        self._populate_kinds()

        top_l.addRow("Device", self.device_combo)
        top_l.addRow("Send type", self.kind_combo)
        top_l.addRow("", self.expert)

        root.addWidget(top)

        # ---- Middle: stacked forms ----
        self.stack = QStackedWidget()
        root.addWidget(self.stack)

        # Page 0: Float measurement
        self.page_float = QWidget()
        fl = QFormLayout(self.page_float)
        self.float_msgtype = QComboBox()
        self.float_msgtype.addItems([
            "Temperature", "Pressure", "Density", "Level", "RPM", "Min", "Max"
        ])
        self.float_sub = QSpinBox(); self.float_sub.setRange(0, 255)
        self.float_value = QDoubleSpinBox()
        self.float_value.setDecimals(6)
        self.float_value.setRange(-1e9, 1e9)
        fl.addRow("Value type", self.float_msgtype)
        fl.addRow("subIndex", self.float_sub)
        fl.addRow("value", self.float_value)
        self.stack.addWidget(self.page_float)

        # Page: Calibration float
        self.page_cal_float = QWidget()
        cl = QFormLayout(self.page_cal_float)
        self.cal_sub = QSpinBox(); self.cal_sub.setRange(0, 255)
        self.cal_value = QDoubleSpinBox()
        self.cal_value.setDecimals(6)
        self.cal_value.setRange(-1e9, 1e9)
        cl.addRow("subIndex", self.cal_sub)
        cl.addRow("calibration value", self.cal_value)
        self.stack.addWidget(self.page_cal_float)

        # Page 1: Percent control (0-100%)
        self.page_percent = QWidget()
        pl = QFormLayout(self.page_percent)
        self.percent_sub = QSpinBox(); self.percent_sub.setRange(0, 255)
        self.percent_value = QSpinBox(); self.percent_value.setRange(0, 100)
        pl.addRow("subIndex", self.percent_sub)
        pl.addRow("Duty Cycle (0-100)", self.percent_value)
        self.stack.addWidget(self.page_percent)

        # Page 3: Node ID update (dangerous)
        self.page_nodeid = QWidget()
        nl = QFormLayout(self.page_nodeid)
        self.nodeid_old = QSpinBox(); self.nodeid_old.setRange(0, 7)
        self.nodeid_new = QLineEdit()
        self.nodeid_new.setPlaceholderText("e.g. 42 or 0x2A (u32)")
        self.nodeid_new.setText("42")
        self.nodeid_sub = QSpinBox(); self.nodeid_sub.setRange(0, 255)

        # helper button to fill bytes preview (we encode directly anyway)
        nl.addRow("old sec id", self.nodeid_old)
        nl.addRow("new node id", self.nodeid_new)
        nl.addRow("subIndex", self.nodeid_sub)
        self.stack.addWidget(self.page_nodeid)

        # Page 4: Raw payload with helpers (calibration/control/etc.)
        self.page_payload = QWidget()
        rl = QFormLayout(self.page_payload)
        self.payload_sub = QSpinBox(); self.payload_sub.setRange(0, 255)
        self.payload_hex = QLineEdit(); self.payload_hex.setPlaceholderText("e.g. AA 55 01")
        btnrow = QHBoxLayout()
        self.btn_ins_float = QPushButton("Float → bytes")
        self.btn_ins_u32 = QPushButton("u32 → bytes (BE)")
        self.btn_clear = QPushButton("Clear")
        btnrow.addWidget(self.btn_ins_float)
        btnrow.addWidget(self.btn_ins_u32)
        btnrow.addWidget(self.btn_clear)
        rl.addRow("subIndex", self.payload_sub)
        rl.addRow("payload bytes", self.payload_hex)
        rl.addRow("", btnrow)
        self.stack.addWidget(self.page_payload)

        # Page 5: Raw frame (arb id + data)
        self.page_raw = QWidget()
        rr = QFormLayout(self.page_raw)
        self.raw_arb = QLineEdit(); self.raw_arb.setPlaceholderText("e.g. 0x0820400C")
        self.raw_data = QLineEdit(); self.raw_data.setPlaceholderText("e.g. 00 00 00 A4 41")
        rr.addRow("arb_id", self.raw_arb)
        rr.addRow("data bytes", self.raw_data)
        self.stack.addWidget(self.page_raw)

        # Page 6: StartMeas
        self.page_startmeas = QWidget()
        sm = QFormLayout(self.page_startmeas)
        self.stack.addWidget(self.page_startmeas)

        # ---- Preview ----
        prev = QGroupBox("Preview")
        pv = QVBoxLayout(prev)
        self.preview_lbl = QLabel("—")
        self.preview_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        pv.addWidget(self.preview_lbl)
        root.addWidget(prev)

        # ---- Bottom buttons ----
        bottom = QHBoxLayout()
        self.btn_send = QPushButton("Send")
        self.btn_close = QPushButton("Close")
        bottom.addWidget(self.btn_send)
        bottom.addWidget(self.btn_close)
        root.addLayout(bottom)

        # wiring
        self.btn_close.clicked.connect(self.close)
        self.btn_send.clicked.connect(self.on_send)

        self.kind_combo.currentIndexChanged.connect(self._on_kind_changed)
        self.expert.toggled.connect(self._on_expert_toggled)

        # update preview on edits
        for w in [self.device_combo, self.kind_combo, self.float_msgtype, self.float_sub, self.float_value,
                  self.cal_sub, self.cal_value,
                  self.percent_sub, self.percent_value, self.nodeid_old, self.nodeid_new, self.nodeid_sub,
                  self.payload_sub, self.payload_hex, self.raw_arb, self.raw_data]:
            if hasattr(w, "valueChanged"):
                w.valueChanged.connect(self.update_preview)
            if hasattr(w, "textChanged"):
                w.textChanged.connect(self.update_preview)
            if hasattr(w, "currentIndexChanged"):
                w.currentIndexChanged.connect(self.update_preview)

        self.btn_ins_float.clicked.connect(self._insert_float_bytes)
        self.btn_ins_u32.clicked.connect(self._insert_u32_bytes)
        self.btn_clear.clicked.connect(lambda: self.payload_hex.setText(""))

        self._on_kind_changed()
        self.update_preview()

    def _populate_kinds(self):
        self.kind_combo.clear()
        self.kind_combo.addItem("Measurement: float (TEMP/PRESS/DENS/LEVEL/RPM/MIN/MAX)", "float")
        self.kind_combo.addItem("PWM: percent (0–100%)", "percent")
        self.kind_combo.addItem("Calibration float (OG/PRESS)", "cal_float")
        self.kind_combo.addItem("Start measurement", "start_meas")
        if self.expert.isChecked():
            self.kind_combo.addItem("NodeIdUpdate (subIndex + u32 BE) [dangerous]", "nodeid")
            self.kind_combo.addItem("Custom Calibration Payload", "cal_payload")
            self.kind_combo.addItem("Raw frame (arb_id + bytes)", "raw")

    def _on_expert_toggled(self, _checked: bool):
        cur = self.kind_combo.currentData()
        self._populate_kinds()
        # try to restore selection
        idx = self.kind_combo.findData(cur)
        if idx >= 0:
            self.kind_combo.setCurrentIndex(idx)
        else:
            self.kind_combo.setCurrentIndex(0)

    def _on_kind_changed(self):
        kind = self.kind_combo.currentData()
        page_map = {
            "float": 0,
            "cal_float": 1,
            "percent": 2,
            "nodeid": 3,
            "cal_payload": 4,
            "raw": 5,
            "start_meas": 6,
        }
        idx = page_map.get(kind, 0)
        if 0 <= idx < self.stack.count():
            self.stack.setCurrentIndex(idx)
        self.update_preview()

    def _open_bus(self) -> can.Bus:
        # Keep python-can for actual I/O
        return can.Bus(interface="kvaser", channel=self.channel, bitrate=self.bitrate,
                       receive_own_messages=True, single_handle=False)

    def _selected_device(self) -> DeviceState:
        key = self.device_combo.currentData()
        if isinstance(key, list):
            key = tuple(key)
        return self.devices[key]

    def build_message(self) -> Tuple[int, bytes]:
        """
        Return (arb_id, data) for current UI selection.
        """
        kind = self.kind_combo.currentData()

        if kind == "raw":
            arb_txt = self.raw_arb.text().strip()
            if not arb_txt:
                raise ValueError("Enter an arbitration ID (e.g. 0x0820400C).")

            arb_id = int(arb_txt, 0)

            data_txt = self.raw_data.text().strip()
            data = parse_hex_bytes(data_txt) if data_txt else b""

            return arb_id, data

        dev = self._selected_device()

        if kind == "float":
            name = self.float_msgtype.currentText()
            msg_map = {
                "Temperature": MsgType.MSG_TYPE_TEMPERATURE,
                "Pressure": MsgType.MSG_TYPE_PRESSURE,
                "Density": MsgType.MSG_TYPE_DENSITY,
                "Level": MsgType.MSG_TYPE_LEVEL,
                "RPM": MsgType.MSG_TYPE_RPM,
                "Min": MsgType.MSG_TYPE_MIN,
                "Max": MsgType.MSG_TYPE_MAX,
            }
            msg_type = msg_map[name]
            can_id = BrewtoolsCanId(
                priority=Priority.MEDIUM,
                sender_node_type=dev.sender_node_type,
                receiver_node_type=NodeType.NODE_TYPE_PLC,  # adjust if you want selectable receiver
                secondary_node_id=dev.node_id,
                msg_type=msg_type,
            )
            body = FloatBody(subindex=int(self.float_sub.value()), value=float(self.float_value.value()))
            frame = CanFrame(can_id=can_id, body=body)
            return frame.to_can()

        if kind == "percent":
            # encode percent as one byte after subIndex
            can_id = BrewtoolsCanId(
                priority=Priority.MEDIUM,
                sender_node_type=NodeType.NODE_TYPE_PLC,
                receiver_node_type=dev.sender_node_type,
                secondary_node_id=dev.node_id,
                msg_type=MsgType.MSG_TYPE_PWM,  # if your enum uses different name, adjust
            )
            sub = int(self.percent_sub.value())
            pct = int(self.percent_value.value())
            body = RawBody(subindex=sub, raw=bytes([pct & 0xFF]))
            frame = CanFrame(can_id=can_id, body=body)
            return frame.to_can()

        if kind == "nodeid":
            old = int(self.nodeid_old.value())
            new_text = self.nodeid_new.text().strip()
            if not new_text:
                raise ValueError("Please enter a new node id (u32).")
            new_id = int(new_text, 0)
            if not (0 <= new_id <= 0xFFFFFFFF):
                raise ValueError("new node id must be 0..4294967295")
            sub = int(self.nodeid_sub.value())

            can_id = BrewtoolsCanId(
                priority=Priority.MEDIUM,
                sender_node_type=NodeType.NODE_TYPE_PLC,
                receiver_node_type=dev.sender_node_type,
                secondary_node_id=old,
                msg_type=MsgType.MSG_TYPE_NODE_ID,
            )
            body = NodeIdBody(subindex=sub, new_node_id=new_id)
            frame = CanFrame(can_id=can_id, body=body)
            return frame.to_can()
        
        if kind == "cal_float":
            dev = self._selected_device()
            can_id = BrewtoolsCanId(
                priority=Priority.MEDIUM,
                sender_node_type=NodeType.NODE_TYPE_PLC,
                receiver_node_type=dev.sender_node_type,
                secondary_node_id=dev.node_id,
                msg_type=MsgType.MSG_TYPE_CALIBRATION_CMD,  # your calibration command
                )
            body = FloatBody(subindex=int(self.cal_sub.value()), value=float(self.cal_value.value()))
            frame = CanFrame(can_id=can_id, body=body)
            return frame.to_can()

        if kind == "cal_payload":
            sub = int(self.payload_sub.value())
            raw = parse_hex_bytes(self.payload_hex.text())
            can_id = BrewtoolsCanId(
                priority=Priority.MEDIUM,
                sender_node_type=NodeType.NODE_TYPE_PLC,
                receiver_node_type=dev.sender_node_type,
                secondary_node_id=dev.node_id,
                msg_type=MsgType.MSG_TYPE_CALIBRATION_CMD,  # or make selectable
            )
            body = RawBody(subindex=sub, raw=raw)
            frame = CanFrame(can_id=can_id, body=body)
            return frame.to_can()
        
        if kind == "start_meas":
            dev = self._selected_device()
            can_id = BrewtoolsCanId(
                priority=Priority.MEDIUM,
                sender_node_type=NodeType.NODE_TYPE_PLC,
                receiver_node_type=dev.sender_node_type,
                secondary_node_id=dev.node_id,
                msg_type=MsgType.MSG_TYPE_START_MEASUREMENT_CMD,
                )
            frame = CanFrame(can_id=can_id, body=RawBody(subindex=0, raw=0))
            return frame.to_can()

    def update_preview(self):
        try:
            arb_id, data = self.build_message()
            self.preview_lbl.setText(f"ID=0x{int(arb_id):08X} (EXT)  DLC={len(data)}  DATA={hex_bytes(data)}")
            self.btn_send.setEnabled(True)
        except Exception as e:
            self.preview_lbl.setText(f"⚠ {e}")
            self.btn_send.setEnabled(False)

    def _insert_float_bytes(self):
        dlg = FloatPrompt(self, title="Insert float → bytes (little-endian)")
        if dlg.exec():
            self.payload_hex.setText(float_to_hex_le(dlg.value()))

    def _insert_u32_bytes(self):
        # uses nodeid_new if filled, else prompts by using payload box current as int?
        txt = self.nodeid_new.text().strip()
        if not txt:
            QMessageBox.warning(self, "u32 → bytes", "Enter a u32 in the NodeIdUpdate new node id field.")
            return
        v = int(txt, 0)
        self.payload_hex.setText(u32_to_hex_be(v))

    def on_send(self):
        try:
            arb_id, data = self.build_message()
            msg = can.Message(arbitration_id=int(arb_id), data=data, is_extended_id=True)

            bus = self._open_bus()
            try:
                bus.send(msg)
            finally:
                bus.shutdown()

            QMessageBox.information(self, "Sent", f"Sent:\nID=0x{int(arb_id):08X}\nDATA={hex_bytes(data)}")

        except Exception as e:
            QMessageBox.critical(self, "Send failed", str(e))

