from __future__ import annotations


class StartupValidation:
    def __init__(self, window):
        self.window = window

    def run(self) -> None:
        w = self.window
        w.source_controller.refresh_control_sources()
        w.source_controller.refresh_twin_sources()
        w.intent_dispatcher.refresh_footer()
        w.brew_controller.set_status('Ready. Select PSU port, choose CAN voltage, power the rail, then connect CAN.')
        w.validation_controller.validate_current(decorate=True, show_status=False)
