from __future__ import annotations


class StartupSettingsApplier:
    def __init__(self, window):
        self.window = window

    def run(self) -> None:
        self.window.settings_loader.apply()
