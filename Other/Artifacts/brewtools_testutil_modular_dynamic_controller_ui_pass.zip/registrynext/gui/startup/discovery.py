from __future__ import annotations


class StartupDiscovery:
    def __init__(self, window):
        self.window = window

    def run(self) -> None:
        w = self.window
        w.brew_controller.populate_psu_ports()
        w.brew_controller.populate_channels()
        w.relay_controller.populate_relay_targets()
