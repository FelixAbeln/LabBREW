from __future__ import annotations

from gui.session import RuntimeEventSubscriber, WindowTimers


class MainWindowSession:
    """Coordinates window-scoped runtime subscriptions and timer behaviors."""

    def __init__(self, window):
        self.window = window
        self.event_subscriber = RuntimeEventSubscriber(window)
        self.timers = WindowTimers(window)

    def bind_runtime_events(self) -> None:
        self.event_subscriber.bind()

    def start(self) -> None:
        self.timers.start()

    def stop(self) -> None:
        self.timers.stop()

    def initial_refresh(self) -> None:
        self.window.source_controller.refresh_control_sources()
        self.window.runtime_bridge.update_agitator_runtime()
        self.window.source_controller.refresh_twin_sources()
        self.window.intent_dispatcher.refresh_all(force=True)

    def update_confirm_button_state(self, awaiting_confirmation: bool) -> None:
        self.timers.update_confirm_button_state(awaiting_confirmation)
