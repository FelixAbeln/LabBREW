from __future__ import annotations

from state import SafetyRule


class SafetyRulesController:
    """Owns editable GUI-side safety rule state independent of MainWindow."""

    def __init__(self) -> None:
        self._rules: list[SafetyRule] = []

    def get_rules(self) -> list[SafetyRule]:
        return self._rules

    def set_rules(self, rules: list[SafetyRule]) -> None:
        self._rules = list(rules)

    def load_from_settings(self, settings_rules) -> None:
        self._rules = [
            SafetyRule(
                name=r.name,
                enabled=r.enabled,
                signal_key=r.signal_key,
                operator=r.operator,
                threshold=r.threshold,
                threshold_low=r.threshold_low,
                threshold_high=r.threshold_high,
                stale_for_s=r.stale_for_s,
                actions=list(r.actions),
            )
            for r in (settings_rules or [])
        ]
