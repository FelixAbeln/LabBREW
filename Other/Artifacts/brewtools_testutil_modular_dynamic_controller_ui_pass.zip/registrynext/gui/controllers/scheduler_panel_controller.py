from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QMessageBox

from gui.ui_helpers import find_data_index


class SchedulerPanelController:
    """Owns scheduler workbook UI workflows and scheduler-side picker state."""

    def __init__(self, window):
        self.window = window

    def set_status(self, message: str) -> None:
        self.window.commands.set_status_message(str(message))

    def refresh_scheduler_sheet_combo(self, sheet_names: list[str], target: str = '') -> None:
        self.window.ui_state.loading_scheduler_ui = True
        try:
            combo = self.window.scheduler_panel.scheduler_sheet
            combo.blockSignals(True)
            combo.clear()
            if target and target not in sheet_names:
                combo.addItem(target)
            for name in sheet_names:
                combo.addItem(name)
            if combo.count() == 0:
                combo.addItem('')
            idx = find_data_index(combo, None)
            if target:
                idx = combo.findText(target)
            combo.setCurrentIndex(idx if idx >= 0 else 0)
            combo.blockSignals(False)
        finally:
            self.window.ui_state.loading_scheduler_ui = False

    def create_schedule_template(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self.window,
            'Create schedule template',
            'fermentation_schedule_template.xlsx',
            'Excel Workbook (*.xlsx)',
        )
        if not path:
            return
        result = self.window.commands.export_scheduler_template(path)
        if result.ok:
            final_path = str(result.payload or path)
            self.window.scheduler_panel.scheduler_path.setText(final_path)
            self.window.scheduler_panel.scheduler_file_status.setText(f'Template created: {Path(final_path).name}')
            self.window.config_controller.save_settings()
            return
        QMessageBox.critical(self.window, 'Template error', result.message)
