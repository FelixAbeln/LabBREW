from __future__ import annotations

from PySide6.QtWidgets import QMessageBox

from helpers import list_kvaser_channels, list_serial_ports
from gui.send_dialog import SendDialog


class BrewPanelController:
    """Owns Brew tab device/session discovery and command workflows."""

    def __init__(self, window):
        self.window = window

    def set_status(self, message: str) -> None:
        self.window.commands.set_status_message(str(message))

    def populate_channels(self) -> None:
        combo = self.window.brew_panel.channel_combo
        current = combo.currentData()
        combo.clear()
        bitrate = int(self.window.brew_panel.bitrate.value())
        channels = list_kvaser_channels(bitrate)
        for ch, label in channels:
            combo.addItem(label, ch)
        if current is not None:
            idx = combo.findData(current)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        self.window.config_controller.save_settings()
        self.set_status(f'Channels refreshed: {len(channels)} found (bitrate hint {bitrate}).')

    def populate_psu_ports(self) -> None:
        combo = self.window.brew_panel.psu_port_combo
        current = combo.currentData()
        combo.clear()
        for device, label in list_serial_ports():
            combo.addItem(label, device)
        if current is not None:
            idx = combo.findData(current)
            if idx >= 0:
                combo.setCurrentIndex(idx)
        self.window.config_controller.save_settings()
        self.set_status('PSU ports refreshed.')

    def toggle_psu_power(self) -> None:
        self.window.config_controller.save_settings_to_state()
        self.window.commands.toggle_psu_power()

    def poll_psu_measurements(self) -> None:
        self.window.commands.poll_psu_measurements()

    def toggle_can_connection(self) -> None:
        self.window.config_controller.save_settings_to_state()
        self.window.commands.toggle_can_connection()

    def open_send_dialog(self) -> None:
        snap = self.window.queries.snapshot()
        if not snap.devices:
            QMessageBox.information(self.window, 'No devices', 'No devices discovered yet. Connect and wait for traffic.')
            return
        dlg = SendDialog(
            self.window,
            snap.devices,
            int(self.window.brew_panel.channel_combo.currentData()),
            int(self.window.brew_panel.bitrate.value()),
        )
        dlg.exec()
