from __future__ import annotations


class RelayPanelController:
    """Owns relay target discovery and relay-session actions for the Relay tab."""

    def __init__(self, window):
        self.window = window

    def set_status(self, message: str) -> None:
        self.window.commands.set_status_message(str(message))

    def populate_relay_targets(self) -> None:
        relay_host = self.window.relay_panel.relay_host
        current = relay_host.currentText().strip()
        relay_host.blockSignals(True)
        relay_host.clear()
        targets = self.window.commands.discover_relay_targets()
        for info in targets:
            relay_host.addItem(getattr(info, 'label', str(info)), getattr(info, 'host', str(info)))
        if current:
            idx = relay_host.findData(current)
            if idx >= 0:
                relay_host.setCurrentIndex(idx)
            else:
                relay_host.setEditText(current)
        elif self.window.settings.relay.host:
            relay_host.setEditText(self.window.settings.relay.host)
        relay_host.blockSignals(False)
        self.window.config_controller.save_settings()
        self.set_status(f'Relay targets refreshed: {len(targets)} available.')

    def toggle_relay_connection(self) -> None:
        self.window.config_controller.save_settings_to_state()
        self.window.commands.toggle_relay_connection()
