from __future__ import annotations


class WindowSourceController:
    """Small composition wrapper over panel-specific source controllers."""

    def __init__(self, control_sources, twin_sources):
        self.control_sources = control_sources
        self.twin_sources = twin_sources

    def selected_or_pending_source_key(self, combo, pending):
        return self.control_sources.selected_or_pending_source_key(combo, pending)

    def refresh_control_sources(self) -> None:
        self.control_sources.refresh()

    def refresh_twin_sources(self) -> None:
        self.twin_sources.refresh()

    def refresh_all_sources(self) -> None:
        self.refresh_control_sources()
        self.refresh_twin_sources()
