from __future__ import annotations


class TwinSourcesController:
    """Owns twin-specific source refresh/rebinding work."""

    def __init__(self, window):
        self.window = window

    def refresh(self) -> None:
        self.window.twin_panel.refresh_sources()
