from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QPushButton, QVBoxLayout, QWidget, QComboBox


def normalize_signal_key(value) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)) and len(value) == 2:
        try:
            return f"sensor:temperature:{int(value[0])}:{int(value[1])}"
        except Exception:
            return None
    return None


def find_data_index(combo: QComboBox, target) -> int:
    norm_target = normalize_signal_key(target)
    for i in range(combo.count()):
        item_data = combo.itemData(i)
        if normalize_signal_key(item_data) == norm_target:
            return i
        if norm_target is None and item_data == target:
            return i
    return -1


def create_collapsible_section(title: str, content: QWidget, expanded: bool = True) -> QWidget:
    container = QWidget()
    layout = QVBoxLayout(container)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(4)

    button = QPushButton()
    button.setCheckable(True)
    button.setChecked(expanded)
    button.setFlat(True)
    button.setCursor(Qt.PointingHandCursor)
    button.setStyleSheet('text-align: left; font-weight: bold; padding: 4px 6px;')

    def apply_state(checked: bool) -> None:
        button.setText(f"{'▾' if checked else '▸'} {title}")
        content.setVisible(checked)

    button.toggled.connect(apply_state)
    apply_state(expanded)

    layout.addWidget(button)
    layout.addWidget(content)
    container.toggle_button = button
    container.content_widget = content
    return container


def set_output_badge(label: QLabel, active: bool, active_text: str = 'ON', inactive_text: str = 'OFF') -> None:
    label.setText(active_text if active else inactive_text)
    if active:
        label.setStyleSheet('QLabel { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; border-radius: 4px; padding: 6px; }')
    else:
        label.setStyleSheet('QLabel { background-color: #e8edf3; color: #4a5568; font-weight: bold; border: 1px solid #cbd5e0; border-radius: 4px; padding: 6px; }')


def make_output_badge(text: str) -> QLabel:
    label = QLabel(text)
    label.setAlignment(Qt.AlignCenter)
    label.setMinimumWidth(72)
    set_output_badge(label, False, text, text)
    return label


def refresh_binding_combo(combo: QComboBox, items, selected) -> None:
    if combo.view().isVisible():
        return
    item_values = [value for _, value in items]
    current_values = [combo.itemData(i) for i in range(combo.count())]
    current_selected = combo.currentData()
    needs_rebuild = combo.count() == 0 or current_values != item_values
    needs_reselect = current_selected != selected
    if not (needs_rebuild or needs_reselect):
        return
    combo.blockSignals(True)
    combo.clear()
    for label, value in items:
        combo.addItem(label, value)
    idx = find_data_index(combo, selected)
    if idx >= 0:
        combo.setCurrentIndex(idx)
    elif selected:
        combo.addItem(f'Saved binding (waiting): {selected}', selected)
        combo.setCurrentIndex(combo.count() - 1)
    else:
        combo.setCurrentIndex(0)
    combo.blockSignals(False)
