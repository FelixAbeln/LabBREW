from __future__ import annotations

from dataclasses import dataclass

from application.config_models import (
    AgitatorConfigModel,
    ControllerConfigModel,
    RelayConfigModel,
    SafetyConfigModel,
    SafetyRuleConfigModel,
    SchedulerConfigModel,
    SchedulerStepConfigModel,
    TwinConfigModel,
)
from gui.panel_field_models import (
    ControlPanelFormState,
    RelayPanelFormState,
    SafetyPanelFormState,
    SchedulerPanelFormState,
    TwinPanelFormState,
)


@dataclass(frozen=True)
class ControlPanelConfigAdapter:
    form: ControlPanelFormState

    def temp_controller(self) -> ControllerConfigModel:
        return ControllerConfigModel(
            enabled=self.form.temp_enabled,
            source_key=self.form.temp_source_key,
            setpoint=self.form.temp_setpoint,
            deadband=self.form.temp_deadband,
        )

    def pressure_controller(self) -> ControllerConfigModel:
        return ControllerConfigModel(
            enabled=self.form.pressure_enabled,
            source_key=self.form.pressure_source_key,
            setpoint=self.form.pressure_setpoint,
            deadband=self.form.pressure_deadband,
            allow_add_gas=self.form.pressure_allow_add_gas,
        )

    def agitator(self) -> AgitatorConfigModel:
        return AgitatorConfigModel(
            enabled=self.form.agitator_enabled,
            target=self.form.agitator_target,
            on=self.form.agitator_on,
            duty_cycle=self.form.agitator_duty_cycle,
            mode=self.form.agitator_mode,
            speed_setpoint_rpm=self.form.agitator_speed_setpoint_rpm,
            pid_kp=self.form.agitator_pid_kp,
            pid_ki=self.form.agitator_pid_ki,
            pid_kd=self.form.agitator_pid_kd,
        )


@dataclass(frozen=True)
class RelayPanelConfigAdapter:
    form: RelayPanelFormState

    def relay(self) -> RelayConfigModel:
        return RelayConfigModel(
            host=self.form.host,
            tcp_port=self.form.tcp_port,
            assignments=dict(self.form.assignments),
            auto_enabled=dict(self.form.auto_enabled),
            manual_states=dict(self.form.manual_states),
        )


@dataclass(frozen=True)
class SafetyPanelConfigAdapter:
    form: SafetyPanelFormState
    rules: list[object]

    def safety(self) -> SafetyConfigModel:
        return SafetyConfigModel(
            enabled=self.form.enabled,
            stale_timeout_s=self.form.stale_timeout_s,
            min_switch_time_s=self.form.min_switch_time_s,
            require_can_connected=self.form.require_can_connected,
            require_psu_power=self.form.require_psu_power,
            require_relays_connected=self.form.require_relays_connected,
            max_temperature_enabled=self.form.max_temperature_enabled,
            max_temperature_c=self.form.max_temperature_c,
            max_pressure_enabled=self.form.max_pressure_enabled,
            max_pressure_bar=self.form.max_pressure_bar,
            power_off_psu_on_trip=self.form.power_off_psu_on_trip,
            all_relays_off_on_trip=self.form.all_relays_off_on_trip,
            rules=[
                SafetyRuleConfigModel(
                    name=r.name,
                    enabled=r.enabled,
                    signal_key=r.signal_key,
                    operator=r.operator,
                    threshold=r.threshold,
                    threshold_low=r.threshold_low,
                    threshold_high=r.threshold_high,
                    stale_for_s=r.stale_for_s,
                    actions=list(r.actions),
                )
                for r in self.rules
            ],
            safe_outputs=dict(self.form.safe_outputs),
        )


@dataclass(frozen=True)
class SchedulerPanelConfigAdapter:
    form: SchedulerPanelFormState
    scheduler_steps: list[object]

    def scheduler(self) -> SchedulerConfigModel:
        return SchedulerConfigModel(
            enabled=self.form.enabled,
            workbook_path=self.form.workbook_path,
            sheet_name=self.form.sheet_name,
            auto_start=self.form.auto_start,
            startup_sequence_enabled=self.form.startup_sequence_enabled,
            startup_auto_connect_relays=self.form.startup_auto_connect_relays,
            startup_auto_connect_can=self.form.startup_auto_connect_can,
            startup_auto_power_psu=self.form.startup_auto_power_psu,
            startup_auto_load_twin=self.form.startup_auto_load_twin,
            startup_delay_s=self.form.startup_delay_s,
            startup_show_advanced=self.form.startup_show_advanced,
            steps=[
                SchedulerStepConfigModel(
                    index=step.index,
                    enabled=step.enabled,
                    name=step.name,
                    temperature_setpoint=step.temperature_setpoint,
                    temperature_ramp_per_s=step.temperature_ramp_per_s,
                    pressure_setpoint=step.pressure_setpoint,
                    pressure_ramp_per_s=step.pressure_ramp_per_s,
                    allow_add_gas=step.allow_add_gas,
                    wait_type=step.wait_type,
                    wait_source=step.wait_source,
                    operator=step.operator,
                    threshold=step.threshold,
                    threshold_low=step.threshold_low,
                    threshold_high=step.threshold_high,
                    duration_s=step.duration_s,
                    hold_for_s=step.hold_for_s,
                    valid_sources=list(step.valid_sources),
                    require_confirmation=step.require_confirmation,
                    confirmation_message=step.confirmation_message,
                    agitator_on=step.agitator_on,
                    agitator_duty_cycle=step.agitator_duty_cycle,
                )
                for step in self.scheduler_steps
            ],
        )


@dataclass(frozen=True)
class TwinPanelConfigAdapter:
    form: TwinPanelFormState

    def twin(self) -> TwinConfigModel:
        return TwinConfigModel(
            enabled=self.form.enabled,
            fmu_path=self.form.fmu_path,
            input_bindings=dict(self.form.input_bindings),
        )
