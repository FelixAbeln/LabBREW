from __future__ import annotations

from PySide6.QtCore import QTimer


class WindowTimers:
    """Owns timer-driven GUI behaviors for the main window session."""

    def __init__(self, window):
        self.window = window
        self._confirm_blink_state = False

        self.confirm_blink_timer = QTimer(window)
        self.confirm_blink_timer.setInterval(700)
        self.confirm_blink_timer.timeout.connect(self._toggle_confirm_blink)

        self.twin_refresh_timer = QTimer(window)
        self.twin_refresh_timer.setInterval(250)
        self.twin_refresh_timer.timeout.connect(self._poll_twin_runtime)

    def start(self) -> None:
        self.twin_refresh_timer.start()

    def stop(self) -> None:
        if self.confirm_blink_timer.isActive():
            self.confirm_blink_timer.stop()
        if self.twin_refresh_timer.isActive():
            self.twin_refresh_timer.stop()

    def update_confirm_button_state(self, awaiting_confirmation: bool) -> None:
        button = self.window.scheduler_panel.btn_scheduler_confirm
        if awaiting_confirmation:
            button.setText('Confirm Step')
            if not self.confirm_blink_timer.isActive():
                self._confirm_blink_state = False
                self.confirm_blink_timer.start()
                self._toggle_confirm_blink()
        else:
            if self.confirm_blink_timer.isActive():
                self.confirm_blink_timer.stop()
            self._confirm_blink_state = False
            button.setText('Confirm / Continue')
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _toggle_confirm_blink(self) -> None:
        panel = self.window.queries.scheduler_panel()
        button = self.window.scheduler_panel.btn_scheduler_confirm
        if not panel.awaiting_confirmation:
            if self.confirm_blink_timer.isActive():
                self.confirm_blink_timer.stop()
            self._confirm_blink_state = False
            button.setText('Confirm / Continue')
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')
            return
        self._confirm_blink_state = not self._confirm_blink_state
        button.setText('Confirm Step')
        if self._confirm_blink_state:
            button.setStyleSheet('QPushButton { background-color: #2e7d32; color: white; font-weight: bold; border: 1px solid #1b5e20; padding: 4px 10px; }')
        else:
            button.setStyleSheet('QPushButton { font-weight: bold; padding: 4px 10px; }')

    def _poll_twin_runtime(self) -> None:
        self.window.intent_dispatcher.refresh_twin_panel()
        self.window.intent_dispatcher.refresh_footer()
