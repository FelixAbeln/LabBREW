from __future__ import annotations

from PySide6.QtWidgets import QMessageBox


class RuntimeEventSubscriber:
    """Connects core/runtime events to window-level GUI actions."""

    def __init__(self, window):
        self.window = window

    def bind(self) -> None:
        events = self.window.events
        events.status.connect(self._on_status_event)
        events.cycle_completed.connect(self._on_runtime_cycle_completed)
        events.command_failed.connect(self._show_runtime_error)
        events.frame_decoded.connect(self.window.runtime_bridge.append_frame_log)
        events.footer_changed.connect(self.window.intent_dispatcher.refresh_footer)
        events.device_rows_changed.connect(self.window.intent_dispatcher.refresh_table)
        events.control_changed.connect(self.window.intent_dispatcher.refresh_control_panel)
        events.safety_changed.connect(self.window.intent_dispatcher.refresh_safety_panel)
        events.twin_changed.connect(self.window.intent_dispatcher.refresh_twin_panel)
        events.scheduler_changed.connect(self.window.intent_dispatcher.refresh_scheduler_panel)
        events.relay_changed.connect(self.window.intent_dispatcher.refresh_relay_panel)
        events.signal_registry_changed.connect(self._on_signal_registry_changed)

    def _on_status_event(self, message: str) -> None:
        self.window.statusBar().showMessage(str(message))
        self.window.intent_dispatcher.refresh_footer()

    def _on_signal_registry_changed(self) -> None:
        self.window.source_controller.refresh_control_sources()
        self.window.source_controller.refresh_twin_sources()

    def _on_runtime_cycle_completed(self) -> None:
        self.window.runtime_bridge.sync_runtime_targets()

    def _show_runtime_error(self, title: str, message: str) -> None:
        QMessageBox.critical(self.window, title, message)
