from __future__ import annotations

from gui.presenters import (
    ControlPanelPresenter,
    DeviceTablePresenter,
    FooterPresenter,
    RelayPanelPresenter,
    SafetyPanelPresenter,
    SchedulerPanelPresenter,
    TwinPanelPresenter,
)


class FooterRefreshDispatcher:
    def __init__(self, window):
        self.presenter = FooterPresenter(window, window.queries)

    def refresh(self) -> None:
        self.presenter.refresh()


class DeviceTableRefreshDispatcher:
    def __init__(self, window):
        self.presenter = DeviceTablePresenter(window, window.queries)

    def refresh(self) -> None:
        self.presenter.refresh_table()


class ControlRefreshDispatcher:
    def __init__(self, window):
        self.presenter = ControlPanelPresenter(window, window.queries)

    def refresh(self) -> None:
        self.presenter.refresh()


class SafetyRefreshDispatcher:
    def __init__(self, window):
        self.presenter = SafetyPanelPresenter(window, window.queries)

    def refresh(self) -> None:
        self.presenter.refresh()


class TwinRefreshDispatcher:
    def __init__(self, window):
        self.presenter = TwinPanelPresenter(window, window.queries)

    def refresh(self) -> None:
        self.presenter.refresh()


class SchedulerRefreshDispatcher:
    def __init__(self, window):
        self.presenter = SchedulerPanelPresenter(window, window.queries)

    def refresh(self) -> None:
        self.presenter.refresh()


class RelayRefreshDispatcher:
    def __init__(self, window):
        self.presenter = RelayPanelPresenter(window, window.queries)

    def refresh(self) -> None:
        self.presenter.refresh()
