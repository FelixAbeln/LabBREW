from __future__ import annotations

from PySide6.QtWidgets import QLabel, QGroupBox, QPlainTextEdit, QSizePolicy, QVBoxLayout, QWidget


class LogPanel(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        info = QLabel('System and safety events are listed here to keep the Safety tab focused on rules and actions.')
        info.setWordWrap(True)
        layout.addWidget(info)
        event_group = QGroupBox('Safety / system event log')
        event_layout = QVBoxLayout(event_group)
        self.event_log = QPlainTextEdit()
        self.event_log.setReadOnly(True)
        self.event_log.setMaximumBlockCount(500)
        self.event_log.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        event_layout.addWidget(self.event_log)
        layout.addWidget(event_group, 1)
