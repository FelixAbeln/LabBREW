from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from application.config_models import SafetyRuleConfigModel
from gui.panel_facades import SafetyPanelFacade


class SafetyPanel(QWidget):
    def __init__(self, facade: SafetyPanelFacade, parent: QWidget | None = None):
        super().__init__(parent)
        self.facade = facade
        self.safety_action_checks: dict[str, QCheckBox] = {}
        layout = QVBoxLayout(self)
        safety_info = QLabel('Build safety as dynamic rules: if a signal crosses a threshold, goes stale, or changes state, the selected safety actions fire. Connected-state signals are also published so you can make rules like CAN disconnected → safe outputs or pressure high → vent.')
        safety_info.setWordWrap(True)
        layout.addWidget(safety_info)

        safety_group = QGroupBox()
        safety_form = QFormLayout(safety_group)
        self.safety_enabled = QCheckBox('Enable safety service')
        self.safety_stale_timeout = QDoubleSpinBox()
        self.safety_stale_timeout.setRange(0.1, 120.0)
        self.safety_stale_timeout.setDecimals(1)
        self.safety_stale_timeout.setSuffix(' s')
        self.safety_min_switch = QDoubleSpinBox()
        self.safety_min_switch.setRange(0.0, 120.0)
        self.safety_min_switch.setDecimals(1)
        self.safety_min_switch.setSuffix(' s')
        self.safety_state = QLabel('OK')
        self.safety_effective = QLabel('—')
        self.safety_actions = QLabel('—')
        safety_form.addRow('', self.safety_enabled)
        safety_form.addRow('Signal stale timeout', self.safety_stale_timeout)
        safety_form.addRow('Minimum switch time', self.safety_min_switch)
        safety_form.addRow('Safety state', self.safety_state)
        safety_form.addRow('Effective outputs', self.safety_effective)
        safety_form.addRow('Active actions', self.safety_actions)
        layout.addWidget(facade.create_collapsible_section('Safety service', safety_group, expanded=False))

        self.safety_require_can = QCheckBox('Require CAN connected')
        self.safety_require_psu = QCheckBox('Require PSU power on')
        self.safety_require_relays = QCheckBox('Require relays connected')
        self.safety_max_temp_enabled = QCheckBox('Trip on max temperature')
        self.safety_max_temp = QDoubleSpinBox()
        self.safety_max_pressure_enabled = QCheckBox('Trip on max pressure')
        self.safety_max_pressure = QDoubleSpinBox()

        safe_out_group = QGroupBox()
        safe_grid = QGridLayout(safe_out_group)
        self.safe_heat = QCheckBox('HEAT on for Safe outputs profile')
        self.safe_cool = QCheckBox('COOL on for Safe outputs profile')
        self.safe_add_gas = QCheckBox('ADD GAS on for Safe outputs profile')
        self.safe_remove_gas = QCheckBox('REMOVE GAS on for Safe outputs profile')
        self.safe_psu_off = QCheckBox('Power OFF PSU action available')
        self.safe_all_relays_off = QCheckBox('All relays OFF action available')
        self.safe_agitator = QCheckBox('AGITATOR on for Safe outputs profile')
        safe_grid.addWidget(self.safe_heat, 0, 0)
        safe_grid.addWidget(self.safe_cool, 0, 1)
        safe_grid.addWidget(self.safe_add_gas, 1, 0)
        safe_grid.addWidget(self.safe_remove_gas, 1, 1)
        safe_grid.addWidget(self.safe_psu_off, 2, 0)
        safe_grid.addWidget(self.safe_all_relays_off, 2, 1)
        safe_grid.addWidget(self.safe_agitator, 3, 0)
        layout.addWidget(facade.create_collapsible_section('Safety actions profile', safe_out_group, expanded=False))

        rules_group = QGroupBox('Dynamic safety rules')
        rules_layout = QVBoxLayout(rules_group)
        self.safety_rules_table = QTableWidget(0, 5)
        self.safety_rules_table.setHorizontalHeaderLabels(['On', 'Rule', 'Signal', 'Condition', 'Actions'])
        self.safety_rules_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.safety_rules_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.safety_rules_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.safety_rules_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.safety_rules_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.safety_rules_table.verticalHeader().setVisible(False)
        self.safety_rules_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.safety_rules_table.setEditTriggers(QTableWidget.NoEditTriggers)
        rules_layout.addWidget(self.safety_rules_table)

        editor_group = QGroupBox('Rule editor')
        editor_layout = QGridLayout(editor_group)
        self.safety_rule_enabled = QCheckBox('Enabled')
        self.safety_rule_enabled.setChecked(True)
        self.safety_rule_name = QLineEdit()
        self.safety_signal_combo = QComboBox()
        self.safety_signal_combo.setEditable(True)
        self.safety_operator = QComboBox()
        self.safety_operator.addItems(list(facade.operator_keys))
        self._safety_value_label = QLabel('Value')
        self._safety_low_label = QLabel('Low')
        self._safety_high_label = QLabel('High')
        self._safety_time_label = QLabel('Time s')
        self.safety_threshold = QDoubleSpinBox()
        self.safety_threshold.setRange(-1_000_000.0, 1_000_000.0)
        self.safety_threshold.setDecimals(4)
        self.safety_threshold_low = QDoubleSpinBox()
        self.safety_threshold_low.setRange(-1_000_000.0, 1_000_000.0)
        self.safety_threshold_low.setDecimals(4)
        self.safety_threshold_high = QDoubleSpinBox()
        self.safety_threshold_high.setRange(-1_000_000.0, 1_000_000.0)
        self.safety_threshold_high.setDecimals(4)
        self.safety_threshold_high.setValue(1.0)
        self.safety_stale_for = QDoubleSpinBox()
        self.safety_stale_for.setRange(0.1, 3600.0)
        self.safety_stale_for.setDecimals(1)
        self.safety_stale_for.setSuffix(' s')
        action_group = QGroupBox('Actions')
        action_grid = QGridLayout(action_group)
        for idx, (action_key, label) in enumerate(facade.action_labels.items()):
            cb = QCheckBox(label)
            self.safety_action_checks[action_key] = cb
            action_grid.addWidget(cb, idx // 2, idx % 2)
        editor_layout.addWidget(QLabel('Rule name'), 0, 0)
        editor_layout.addWidget(self.safety_rule_name, 0, 1)
        editor_layout.addWidget(self.safety_rule_enabled, 0, 2)
        editor_layout.addWidget(QLabel('Signal key'), 1, 0)
        editor_layout.addWidget(self.safety_signal_combo, 1, 1, 1, 2)
        editor_layout.addWidget(QLabel('Operator'), 2, 0)
        editor_layout.addWidget(self.safety_operator, 2, 1)
        editor_layout.addWidget(self._safety_value_label, 2, 2)
        editor_layout.addWidget(self.safety_threshold, 2, 3)
        editor_layout.addWidget(self._safety_low_label, 3, 0)
        editor_layout.addWidget(self.safety_threshold_low, 3, 1)
        editor_layout.addWidget(self._safety_high_label, 3, 2)
        editor_layout.addWidget(self.safety_threshold_high, 3, 3)
        editor_layout.addWidget(self._safety_time_label, 4, 0)
        editor_layout.addWidget(self.safety_stale_for, 4, 1)
        editor_layout.addWidget(action_group, 5, 0, 1, 4)
        buttons_row = QHBoxLayout()
        self.btn_safety_rule_add = QPushButton('Add rule')
        self.btn_safety_rule_update = QPushButton('Update selected')
        self.btn_safety_rule_delete = QPushButton('Delete selected')
        self.btn_safety_rule_new = QPushButton('Clear editor')
        buttons_row.addWidget(self.btn_safety_rule_add)
        buttons_row.addWidget(self.btn_safety_rule_update)
        buttons_row.addWidget(self.btn_safety_rule_delete)
        buttons_row.addWidget(self.btn_safety_rule_new)
        buttons_row.addStretch(1)
        editor_layout.addLayout(buttons_row, 6, 0, 1, 4)
        rules_layout.addWidget(editor_group)
        layout.addWidget(rules_group, 1)

    def wire_signals(self) -> None:
        self.safety_enabled.toggled.connect(self.facade.save_settings)
        self.safety_require_can.toggled.connect(self.facade.save_settings)
        self.safety_require_psu.toggled.connect(self.facade.save_settings)
        self.safety_require_relays.toggled.connect(self.facade.save_settings)
        self.safety_stale_timeout.valueChanged.connect(self.facade.save_settings)
        self.safety_min_switch.valueChanged.connect(self.facade.save_settings)
        self.safety_max_temp_enabled.toggled.connect(self.facade.save_settings)
        self.safety_max_temp.valueChanged.connect(self.facade.save_settings)
        self.safety_max_pressure_enabled.toggled.connect(self.facade.save_settings)
        self.safety_max_pressure.valueChanged.connect(self.facade.save_settings)
        self.safe_heat.toggled.connect(self.facade.save_settings)
        self.safe_cool.toggled.connect(self.facade.save_settings)
        self.safe_add_gas.toggled.connect(self.facade.save_settings)
        self.safe_remove_gas.toggled.connect(self.facade.save_settings)
        self.safe_psu_off.toggled.connect(self.facade.save_settings)
        self.safe_all_relays_off.toggled.connect(self.facade.save_settings)
        self.safe_agitator.toggled.connect(self.facade.save_settings)
        self.safety_operator.currentIndexChanged.connect(self.refresh_editor_visibility)
        self.safety_operator.currentIndexChanged.connect(self.facade.save_settings)
        self.safety_signal_combo.currentIndexChanged.connect(self.facade.save_settings)
        self.safety_signal_combo.editTextChanged.connect(self.facade.save_settings)
        self.safety_rule_enabled.toggled.connect(self.facade.save_settings)
        self.safety_rule_name.editingFinished.connect(self.facade.save_settings)
        self.safety_threshold.valueChanged.connect(self.facade.save_settings)
        self.safety_threshold_low.valueChanged.connect(self.facade.save_settings)
        self.safety_threshold_high.valueChanged.connect(self.facade.save_settings)
        self.safety_stale_for.valueChanged.connect(self.facade.save_settings)
        self.safety_rules_table.itemSelectionChanged.connect(self.load_selected_rule_into_editor)
        self.btn_safety_rule_add.clicked.connect(self.add_rule)
        self.btn_safety_rule_update.clicked.connect(self.update_rule)
        self.btn_safety_rule_delete.clicked.connect(self.delete_rule)
        self.btn_safety_rule_new.clicked.connect(self.clear_rule_editor)

    def safety_rule_from_editor(self) -> SafetyRuleConfigModel:
        return SafetyRuleConfigModel(
            name=self.safety_rule_name.text().strip(),
            enabled=self.safety_rule_enabled.isChecked(),
            signal_key=self.safety_signal_combo.currentText().strip(),
            operator=self.safety_operator.currentText().strip() or ">=",
            threshold=float(self.safety_threshold.value()),
            threshold_low=float(self.safety_threshold_low.value()),
            threshold_high=float(self.safety_threshold_high.value()),
            stale_for_s=float(self.safety_stale_for.value()),
            actions=[key for key, cb in self.safety_action_checks.items() if cb.isChecked()],
        )

    def safety_condition_text(self, rule: SafetyRuleConfigModel) -> str:
        operator = str(rule.operator or "").strip()
        if operator in ('in_range', 'out_of_range'):
            return f'{operator} {rule.threshold_low:g}..{rule.threshold_high:g}'
        if operator in ('stale_for', 'valid_for'):
            return f'{operator} {rule.stale_for_s:g}s'
        if operator in ('changed', 'changed_to_true', 'changed_to_false'):
            return operator
        return f'{operator} {rule.threshold:g}'

    def refresh_editor_visibility(self) -> None:
        operator = self.safety_operator.currentText().strip()
        uses_range = operator in ('in_range', 'out_of_range')
        uses_time = operator in ('stale_for', 'valid_for')
        uses_value = operator not in ('stale_for', 'valid_for', 'changed', 'changed_to_true', 'changed_to_false')
        self._safety_value_label.setVisible(uses_value and not uses_range)
        self.safety_threshold.setVisible(uses_value and not uses_range)
        self._safety_low_label.setVisible(uses_range)
        self.safety_threshold_low.setVisible(uses_range)
        self._safety_high_label.setVisible(uses_range)
        self.safety_threshold_high.setVisible(uses_range)
        self._safety_time_label.setVisible(uses_time)
        self.safety_stale_for.setVisible(uses_time)

    def refresh_rules_table(self) -> None:
        active_names = set(self.facade.snapshot_provider().safety_runtime.active_rules)
        rules = self.facade.safety_rules_controller.get_rules()
        self.safety_rules_table.setRowCount(len(rules))
        for row, rule in enumerate(rules):
            enabled_text = '✓' if rule.enabled else '—'
            name_text = rule.name or f'Rule {row + 1}'
            signal_text = rule.signal_key or '—'
            condition_text = self.safety_condition_text(rule)
            actions = [self.facade.action_labels.get(action, action) for action in rule.actions]
            actions_text = ', '.join(actions) if actions else '—'
            values = [enabled_text, name_text, signal_text, condition_text, actions_text]
            for col, text in enumerate(values):
                item = QTableWidgetItem(text)
                if name_text in active_names:
                    item.setBackground(self.facade.palette_provider().alternateBase())
                self.safety_rules_table.setItem(row, col, item)
        self.safety_rules_table.resizeRowsToContents()

    def clear_rule_editor(self) -> None:
        self.safety_rule_enabled.setChecked(True)
        self.safety_rule_name.clear()
        self.safety_signal_combo.setCurrentIndex(-1)
        self.safety_signal_combo.setEditText('')
        self.safety_operator.setCurrentIndex(self.safety_operator.findText('>=') if self.safety_operator.findText('>=') >= 0 else 0)
        self.safety_threshold.setValue(0.0)
        self.safety_threshold_low.setValue(0.0)
        self.safety_threshold_high.setValue(1.0)
        self.safety_stale_for.setValue(max(0.1, self.safety_stale_timeout.value()))
        for cb in self.safety_action_checks.values():
            cb.setChecked(False)
        self.refresh_editor_visibility()

    def load_rule_into_editor(self, row: int) -> None:
        rules = self.facade.safety_rules_controller.get_rules()
        if row < 0 or row >= len(rules):
            return
        rule = rules[row]
        self.safety_rule_enabled.setChecked(rule.enabled)
        self.safety_rule_name.setText(rule.name)
        idx = self.safety_signal_combo.findText(rule.signal_key)
        if idx >= 0:
            self.safety_signal_combo.setCurrentIndex(idx)
        else:
            self.safety_signal_combo.setEditText(rule.signal_key)
        self.safety_operator.setCurrentText(rule.operator)
        self.safety_threshold.setValue(float(rule.threshold or 0.0))
        self.safety_threshold_low.setValue(float(rule.threshold_low or 0.0))
        self.safety_threshold_high.setValue(float(rule.threshold_high or 0.0))
        self.safety_stale_for.setValue(float(rule.stale_for_s or max(0.1, self.safety_stale_timeout.value())))
        for key, cb in self.safety_action_checks.items():
            cb.setChecked(key in rule.actions)
        self.refresh_editor_visibility()

    def load_selected_rule_into_editor(self) -> None:
        self.load_rule_into_editor(self.safety_rules_table.currentRow())

    def add_rule(self) -> None:
        rule = self.safety_rule_from_editor()
        if not rule.signal_key:
            QMessageBox.information(self, 'Safety rule', 'Pick or enter a signal key first.')
            return
        rules = self.facade.safety_rules_controller.get_rules()
        rules.append(rule)
        self.facade.safety_rules_controller.set_rules(rules)
        self.refresh_rules_table()
        self.facade.save_settings()
        self.clear_rule_editor()

    def update_rule(self) -> None:
        row = self.safety_rules_table.currentRow()
        rules = self.facade.safety_rules_controller.get_rules()
        if row < 0 or row >= len(rules):
            QMessageBox.information(self, 'Safety rule', 'Select a rule to update.')
            return
        rules[row] = self.safety_rule_from_editor()
        self.facade.safety_rules_controller.set_rules(rules)
        self.refresh_rules_table()
        self.facade.save_settings()

    def delete_rule(self) -> None:
        row = self.safety_rules_table.currentRow()
        rules = self.facade.safety_rules_controller.get_rules()
        if row < 0 or row >= len(rules):
            QMessageBox.information(self, 'Safety rule', 'Select a rule to delete.')
            return
        rules.pop(row)
        self.facade.safety_rules_controller.set_rules(rules)
        self.refresh_rules_table()
        self.facade.save_settings()
        self.clear_rule_editor()
