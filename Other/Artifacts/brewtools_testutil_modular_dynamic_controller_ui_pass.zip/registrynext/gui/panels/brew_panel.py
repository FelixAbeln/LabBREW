from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QVBoxLayout,
    QWidget,
)

from settings import DEFAULT_CAN_BITRATE, DEFAULT_PSU_VOLTAGE
from gui.panel_facades import BrewPanelFacade


class BrewPanel(QWidget):
    def __init__(self, facade: BrewPanelFacade, parent: QWidget | None = None):
        super().__init__(parent)
        self.facade = facade
        layout = QVBoxLayout(self)

        top = QVBoxLayout()
        psu_row = QHBoxLayout()
        psu_row.addWidget(QLabel('PSU COM:'))
        self.psu_port_combo = QComboBox()
        self.btn_refresh_psu_ports = QPushButton('Refresh Ports')
        psu_row.addWidget(self.psu_port_combo)
        psu_row.addWidget(self.btn_refresh_psu_ports)
        psu_row.addWidget(QLabel('CAN Voltage:'))
        self.psu_voltage = QDoubleSpinBox()
        self.psu_voltage.setRange(0.0, 30.0)
        self.psu_voltage.setDecimals(1)
        self.psu_voltage.setSingleStep(0.1)
        self.psu_voltage.setSuffix(' V')
        self.psu_voltage.setFixedWidth(95)
        self.psu_voltage.setValue(DEFAULT_PSU_VOLTAGE)
        psu_row.addWidget(self.psu_voltage)
        self.btn_psu_toggle = QPushButton('Power ON')
        self.btn_psu_toggle.setCheckable(True)
        self.btn_psu_toggle.setMinimumWidth(110)
        psu_row.addWidget(self.btn_psu_toggle)
        psu_row.addStretch(1)
        top.addLayout(psu_row)

        can_row = QHBoxLayout()
        can_row.addWidget(QLabel('Channel:'))
        self.channel_combo = QComboBox()
        self.btn_refresh_channels = QPushButton('Refresh')
        can_row.addWidget(self.channel_combo)
        can_row.addWidget(self.btn_refresh_channels)
        can_row.addWidget(QLabel('Bitrate:'))
        self.bitrate = QSpinBox()
        self.bitrate.setRange(10_000, 1_000_000)
        self.bitrate.setSingleStep(10_000)
        self.bitrate.setValue(DEFAULT_CAN_BITRATE)
        can_row.addWidget(self.bitrate)
        self.btn_connect = QPushButton('Connect CAN')
        self.btn_connect.setCheckable(True)
        self.btn_connect.setMinimumWidth(110)
        self.btn_send = QPushButton('Send…')
        can_row.addWidget(self.btn_connect)
        can_row.addWidget(self.btn_send)
        can_row.addStretch(1)
        top.addLayout(can_row)
        layout.addLayout(top)

        layout.addWidget(QLabel('Bus devices (latest values)'))
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['Device', 'Node', 'Last seen', 'Status', 'Measurements'])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setWordWrap(True)
        self.table.setStyleSheet(
            'QTableWidget { alternate-background-color: #f6f8fb; gridline-color: #d9dfe8; }'
            'QHeaderView::section { font-weight: bold; padding: 6px; }'
        )
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.Stretch)
        layout.addWidget(self.table)

        layout.addWidget(QLabel('Live decoded messages'))
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)

    def wire_signals(self) -> None:
        self.btn_refresh_psu_ports.clicked.connect(self.facade.populate_psu_ports)
        self.btn_psu_toggle.clicked.connect(self.facade.toggle_psu_power)
        self.btn_refresh_channels.clicked.connect(self.facade.populate_channels)
        self.btn_connect.clicked.connect(self.facade.toggle_can_connection)
        self.btn_send.clicked.connect(self.facade.open_send_dialog)

        self.psu_port_combo.currentIndexChanged.connect(self.facade.save_settings)
        self.psu_voltage.valueChanged.connect(self.facade.save_settings)
        self.channel_combo.currentIndexChanged.connect(self.facade.save_settings)
        self.bitrate.valueChanged.connect(self.facade.on_bitrate_changed)
