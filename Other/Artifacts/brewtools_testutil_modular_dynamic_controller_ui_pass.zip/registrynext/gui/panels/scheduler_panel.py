from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QVBoxLayout,
    QWidget,
)

from gui.panel_facades import SchedulerPanelFacade


class SchedulerPanel(QWidget):
    def __init__(self, facade: SchedulerPanelFacade, parent: QWidget | None = None):
        super().__init__(parent)
        self.facade = facade
        layout = QVBoxLayout(self)
        sched_top = QHBoxLayout()
        self.scheduler_enabled = QCheckBox('Enable scheduler service')
        self.scheduler_auto_start = QCheckBox('Auto-start after load')
        sched_top.addWidget(self.scheduler_enabled)
        sched_top.addWidget(self.scheduler_auto_start)
        sched_top.addStretch(1)
        layout.addLayout(sched_top)

        sched_file_group = QGroupBox('Schedule workbook')
        sched_file_layout = QGridLayout(sched_file_group)
        self.scheduler_path = QLineEdit()
        self.scheduler_path.setPlaceholderText('Select Excel schedule (.xlsx)')
        self.btn_scheduler_browse = QPushButton('Browse…')
        self.btn_scheduler_template = QPushButton('Create Template')
        self.scheduler_sheet = QComboBox()
        self.btn_scheduler_load = QPushButton('Load Schedule')
        self.scheduler_file_status = QLabel('No schedule loaded')
        sched_file_layout.addWidget(QLabel('Workbook:'), 0, 0)
        sched_file_layout.addWidget(self.scheduler_path, 0, 1)
        sched_file_layout.addWidget(self.btn_scheduler_browse, 0, 2)
        sched_file_layout.addWidget(self.btn_scheduler_template, 0, 3)
        sched_file_layout.addWidget(QLabel('Sheet:'), 1, 0)
        sched_file_layout.addWidget(self.scheduler_sheet, 1, 1)
        sched_file_layout.addWidget(self.btn_scheduler_load, 1, 2)
        sched_file_layout.addWidget(self.scheduler_file_status, 1, 3)
        sched_file_layout.setColumnStretch(1, 1)
        layout.addWidget(sched_file_group)

        startup_group = QWidget()
        startup_layout = QVBoxLayout(startup_group)
        startup_layout.setContentsMargins(0, 0, 0, 0)
        self.scheduler_startup_summary = QLabel('Disabled')
        self.scheduler_startup_summary.setWordWrap(True)
        startup_layout.addWidget(self.scheduler_startup_summary)
        self.scheduler_startup_details = QWidget()
        startup_details_layout = QGridLayout(self.scheduler_startup_details)
        self.scheduler_startup_enabled = QCheckBox('Run startup sequence before scheduler starts')
        self.scheduler_startup_connect_relays = QCheckBox('Auto-connect relays')
        self.scheduler_startup_connect_can = QCheckBox('Auto-connect CAN')
        self.scheduler_startup_power_psu = QCheckBox('Auto-power PSU')
        self.scheduler_startup_load_twin = QCheckBox('Auto-load configured FMU')
        self.scheduler_startup_delay = QDoubleSpinBox()
        self.scheduler_startup_delay.setRange(0.0, 120.0)
        self.scheduler_startup_delay.setDecimals(1)
        self.scheduler_startup_delay.setSingleStep(0.5)
        self.scheduler_startup_delay.setSuffix(' s')
        self.scheduler_startup_delay.setValue(3.0)
        startup_details_layout.addWidget(self.scheduler_startup_enabled, 0, 0, 1, 2)
        startup_details_layout.addWidget(self.scheduler_startup_connect_relays, 1, 0)
        startup_details_layout.addWidget(self.scheduler_startup_connect_can, 1, 1)
        startup_details_layout.addWidget(self.scheduler_startup_power_psu, 2, 0)
        startup_details_layout.addWidget(self.scheduler_startup_load_twin, 2, 1)
        startup_details_layout.addWidget(QLabel('Startup settle delay:'), 3, 0)
        startup_details_layout.addWidget(self.scheduler_startup_delay, 3, 1)
        startup_layout.addWidget(self.scheduler_startup_details)
        self.scheduler_startup_section = facade.create_collapsible_section('Startup sequence', startup_group, expanded=False)
        layout.addWidget(self.scheduler_startup_section)

        sched_ctrl = QHBoxLayout()
        self.btn_scheduler_start = QPushButton('Start')
        self.btn_scheduler_pause = QPushButton('Pause')
        self.btn_scheduler_stop = QPushButton('Stop')
        self.btn_scheduler_prev = QPushButton('Previous')
        self.btn_scheduler_next = QPushButton('Next')
        self.btn_scheduler_confirm = QPushButton('Confirm / Continue')
        sched_ctrl.addWidget(self.btn_scheduler_start)
        sched_ctrl.addWidget(self.btn_scheduler_pause)
        sched_ctrl.addWidget(self.btn_scheduler_stop)
        sched_ctrl.addWidget(self.btn_scheduler_prev)
        sched_ctrl.addWidget(self.btn_scheduler_next)
        sched_ctrl.addWidget(self.btn_scheduler_confirm)
        sched_ctrl.addStretch(1)
        layout.addLayout(sched_ctrl)

        sched_status_group = QGroupBox('Scheduler status')
        sched_status_form = QFormLayout(sched_status_group)
        self.scheduler_running_lbl = QLabel('Stopped')
        self.scheduler_current_step_lbl = QLabel('—')
        self.scheduler_elapsed_lbl = QLabel('—')
        self.scheduler_wait_lbl = QLabel('Idle')
        self.scheduler_hold_lbl = QLabel('—')
        self.scheduler_transition_lbl = QLabel('—')
        self.scheduler_confirmation_lbl = QLabel('—')
        self.scheduler_confirmation_lbl.setWordWrap(True)
        sched_status_form.addRow('State', self.scheduler_running_lbl)
        sched_status_form.addRow('Current step', self.scheduler_current_step_lbl)
        sched_status_form.addRow('Step elapsed', self.scheduler_elapsed_lbl)
        sched_status_form.addRow('Waiting reason', self.scheduler_wait_lbl)
        sched_status_form.addRow('Hold time', self.scheduler_hold_lbl)
        sched_status_form.addRow('Confirmation', self.scheduler_confirmation_lbl)
        sched_status_form.addRow('Last transition', self.scheduler_transition_lbl)
        layout.addWidget(sched_status_group)

        self.scheduler_table = QTableWidget(0, 11)
        self.scheduler_table.setHorizontalHeaderLabels(['#', 'Enabled', 'Name', 'Temp SP', 'Pressure SP', 'Gas add', 'Agitator', 'Wait type', 'Wait source', 'Condition', 'Operator confirm'])
        self.scheduler_table.verticalHeader().setVisible(False)
        self.scheduler_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.scheduler_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.scheduler_table.setSelectionMode(QTableWidget.SingleSelection)
        self.scheduler_table.setAlternatingRowColors(True)
        self.scheduler_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.scheduler_table.horizontalHeader().setSectionResizeMode(8, QHeaderView.Stretch)
        self.scheduler_table.horizontalHeader().setSectionResizeMode(9, QHeaderView.Stretch)
        self.scheduler_table.horizontalHeader().setSectionResizeMode(10, QHeaderView.Stretch)
        layout.addWidget(self.scheduler_table, 1)

    def wire_signals(self) -> None:
        self.scheduler_enabled.toggled.connect(self.facade.save_settings)
        self.scheduler_auto_start.toggled.connect(self.facade.save_settings)
        self.scheduler_path.editingFinished.connect(self.facade.save_settings)
        self.scheduler_sheet.currentIndexChanged.connect(self.facade.save_settings)
        self.btn_scheduler_browse.clicked.connect(self.browse_schedule_file)
        self.btn_scheduler_load.clicked.connect(self.load_schedule_file)
        self.btn_scheduler_template.clicked.connect(self.facade.create_schedule_template)
        self.scheduler_startup_enabled.toggled.connect(self.facade.save_settings)
        self.scheduler_startup_connect_relays.toggled.connect(self.facade.save_settings)
        self.scheduler_startup_connect_can.toggled.connect(self.facade.save_settings)
        self.scheduler_startup_power_psu.toggled.connect(self.facade.save_settings)
        self.scheduler_startup_load_twin.toggled.connect(self.facade.save_settings)
        self.scheduler_startup_delay.valueChanged.connect(self.facade.save_settings)
        self.scheduler_startup_section.toggle_button.toggled.connect(self.toggle_startup_details)
        self.btn_scheduler_start.clicked.connect(self.start_scheduler)
        self.btn_scheduler_pause.clicked.connect(self.pause_scheduler)
        self.btn_scheduler_stop.clicked.connect(self.stop_scheduler)
        self.btn_scheduler_prev.clicked.connect(self.scheduler_prev_step)
        self.btn_scheduler_next.clicked.connect(self.scheduler_next_step)
        self.btn_scheduler_confirm.clicked.connect(self.scheduler_confirm_step)

    def toggle_startup_details(self, checked: bool) -> None:
        self.scheduler_startup_details.setVisible(bool(checked))
        self.refresh_startup_summary()
        if not self.facade.ui_state.loading_settings:
            self.facade.save_settings()

    def refresh_startup_summary(self) -> None:
        startup = self.facade.scheduler_startup_status()
        if startup.active:
            self.scheduler_startup_summary.setText(startup.message or 'Startup sequence running')
            return
        if not self.scheduler_startup_enabled.isChecked():
            self.scheduler_startup_summary.setText('Disabled')
            return
        parts = []
        if self.scheduler_startup_connect_relays.isChecked():
            parts.append('Relays')
        if self.scheduler_startup_connect_can.isChecked():
            parts.append('CAN')
        if self.scheduler_startup_power_psu.isChecked():
            parts.append('PSU')
        if self.scheduler_startup_load_twin.isChecked():
            parts.append('FMU load')
        summary = ', '.join(parts) if parts else 'No auto-start actions'
        delay = float(self.scheduler_startup_delay.value())
        self.scheduler_startup_summary.setText(f'{summary} | Delay {delay:.1f} s')

    def browse_schedule_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, 'Select schedule workbook', self.scheduler_path.text().strip(), 'Excel Workbook (*.xlsx *.xlsm)')
        if path:
            self.scheduler_path.setText(path)
            self.facade.save_settings()

    def load_schedule_file(self, auto: bool = False) -> None:
        try:
            result = self.facade.load_scheduler_workbook(
                self.scheduler_path.text().strip(),
                self.scheduler_sheet.currentText().strip(),
            )
            self.facade.refresh_scheduler_sheet_combo(result.sheet_names, result.active_sheet)
            self.scheduler_file_status.setText(result.message)
            self.facade.save_settings_to_state()
            self.facade.refresh_scheduler_panel()
            self.facade.set_status(result.message)
            if not result.ok and not auto:
                QMessageBox.warning(self, 'Schedule load', result.message)
        except Exception as exc:
            if not auto:
                QMessageBox.critical(self, 'Schedule load', str(exc))
            self.scheduler_file_status.setText(f'Load failed: {exc}')
            self.facade.set_status(f'Schedule load failed: {exc}')

    def _run_scheduler_command(self, command, title: str, warn: bool = False, info: bool = False, refresh: bool = False) -> None:
        result = command()
        self.facade.set_status(result.message)
        if refresh:
            self.facade.refresh_scheduler_panel()
        if not result.ok:
            if warn:
                QMessageBox.warning(self, title, result.message)
            elif info:
                QMessageBox.information(self, title, result.message)

    def start_scheduler(self) -> None:
        self.facade.save_settings_to_state()
        self._run_scheduler_command(self.facade.start_scheduler, 'Scheduler', warn=True)

    def pause_scheduler(self) -> None:
        self._run_scheduler_command(self.facade.pause_scheduler, 'Scheduler', warn=True, refresh=True)

    def stop_scheduler(self) -> None:
        self._run_scheduler_command(self.facade.stop_scheduler, 'Scheduler', warn=True)

    def scheduler_prev_step(self) -> None:
        self._run_scheduler_command(self.facade.scheduler_previous_step, 'Scheduler', info=True, refresh=True)

    def scheduler_next_step(self) -> None:
        self._run_scheduler_command(self.facade.scheduler_next_step, 'Scheduler', info=True, refresh=True)

    def scheduler_confirm_step(self) -> None:
        self._run_scheduler_command(self.facade.confirm_scheduler_step, 'Scheduler', info=True, refresh=True)
