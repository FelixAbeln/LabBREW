from __future__ import annotations

from PySide6.QtWidgets import QCheckBox, QComboBox, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QPushButton, QSpinBox, QVBoxLayout, QWidget

from gui.constants import OUTPUT_OPTIONS
from gui.panel_facades import RelayPanelFacade


class RelayPanel(QWidget):
    def __init__(self, facade: RelayPanelFacade, parent: QWidget | None = None):
        super().__init__(parent)
        self.facade = facade
        layout = QVBoxLayout(self)
        relay_top = QHBoxLayout()
        relay_top.addWidget(QLabel('Relay IP / Host:'))
        self.relay_host = QComboBox()
        self.relay_host.setEditable(True)
        self.relay_host.setMinimumWidth(220)
        self.relay_tcp_port = QSpinBox()
        self.relay_tcp_port.setRange(1, 65535)
        self.relay_tcp_port.setValue(502)
        self.relay_tcp_port.setFixedWidth(90)
        self.btn_refresh_relays = QPushButton('Refresh')
        self.btn_relay_connect = QPushButton('Connect Relays')
        self.btn_relay_connect.setCheckable(True)
        self.btn_relay_connect.setMinimumWidth(125)
        relay_top.addWidget(self.relay_host)
        relay_top.addWidget(QLabel('Port:'))
        relay_top.addWidget(self.relay_tcp_port)
        relay_top.addWidget(self.btn_refresh_relays)
        relay_top.addWidget(self.btn_relay_connect)
        relay_top.addStretch(1)
        layout.addLayout(relay_top)

        relay_help = QLabel('Assign virtual outputs to relay channels. Enable Auto to let controllers drive the relay. Disable Auto to use the manual Open/Closed button. Relay state and button color always follow the actual state reported by the relay driver.')
        relay_help.setWordWrap(True)
        layout.addWidget(relay_help)

        relay_group = QGroupBox('Relay channels')
        relay_grid = QGridLayout(relay_group)
        headers = ['Channel', 'Output', 'Auto', 'Manual', 'Active']
        for c, text in enumerate(headers):
            relay_grid.addWidget(QLabel(f'<b>{text}</b>'), 0, c)
        for row, ch in enumerate(range(1, 9), start=1):
            ch_lbl = QLabel(f'Relay {ch}')
            output_combo = QComboBox()
            for text, value in OUTPUT_OPTIONS:
                output_combo.addItem(text, value)
            auto_chk = QCheckBox('Control')
            auto_chk.setChecked(True)
            test_btn = QPushButton('Open')
            test_btn.setCheckable(True)
            test_btn.setMinimumWidth(90)
            active_lbl = facade.make_output_badge('OFF')
            relay_grid.addWidget(ch_lbl, row, 0)
            relay_grid.addWidget(output_combo, row, 1)
            relay_grid.addWidget(auto_chk, row, 2)
            relay_grid.addWidget(test_btn, row, 3)
            relay_grid.addWidget(active_lbl, row, 4)
            facade.relay_channel_rows[ch] = {
                'label': ch_lbl,
                'combo': output_combo,
                'auto': auto_chk,
                'test': test_btn,
                'active': active_lbl,
            }
        relay_grid.setColumnStretch(1, 1)
        layout.addWidget(relay_group)
        layout.addStretch(1)

    def wire_signals(self) -> None:
        self.relay_host.currentIndexChanged.connect(self.facade.save_settings)
        self.relay_host.editTextChanged.connect(self.facade.save_settings)
        self.relay_tcp_port.valueChanged.connect(self.facade.save_settings)
        self.btn_refresh_relays.clicked.connect(self.facade.populate_relay_targets)

        self.btn_relay_connect.clicked.connect(self.facade.toggle_relay_connection)

        for ch, row in self.facade.relay_channel_rows.items():
            row['combo'].currentIndexChanged.connect(self.facade.save_settings)
            row['auto'].toggled.connect(lambda checked, channel=ch: self.on_relay_auto_toggled(channel, checked))
            row['test'].toggled.connect(lambda checked, channel=ch: self.on_relay_test_toggled(channel, checked))

    def on_relay_auto_toggled(self, channel: int, checked: bool) -> None:
        row = self.facade.relay_channel_rows[channel]
        if checked:
            row['test'].setChecked(False)
        self.facade.save_settings()
        self.facade.refresh_relay_panel()

    def on_relay_test_toggled(self, channel: int, checked: bool) -> None:
        self.facade.save_settings()
        result = self.facade.set_relay_manual_state(channel, checked)
        self.facade.refresh_relay_panel()
        self.facade.refresh_footer()
        self.facade.set_status(result.message)
