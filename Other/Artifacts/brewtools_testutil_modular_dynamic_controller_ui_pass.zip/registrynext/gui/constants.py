from __future__ import annotations

OUTPUT_OPTIONS = [
    ('Unassigned', None),
    ('HEAT', 'heat'),
    ('COOL', 'cool'),
    ('ADD GAS', 'add_gas'),
    ('REMOVE GAS', 'remove_gas'),
    ('AGITATOR', 'agitator'),
]

OUTPUT_LABELS = {
    'heat': 'HEAT',
    'cool': 'COOL',
    'add_gas': 'ADD GAS',
    'remove_gas': 'REMOVE GAS',
    'agitator': 'AGITATOR',
}
