from __future__ import annotations

from gui.startup import StartupDiscovery, StartupSettingsApplier, StartupValidation


class MainWindowStartup:
    """Owns startup discovery, persisted settings application, and initial validation."""

    def __init__(self, window):
        self.window = window
        self.discovery = StartupDiscovery(window)
        self.settings = StartupSettingsApplier(window)
        self.validation = StartupValidation(window)

    def apply(self) -> None:
        w = self.window
        w.ui_state.loading_settings = True
        try:
            self.discovery.run()
            self.settings.run()
        finally:
            w.ui_state.loading_settings = False
        self.validation.run()
