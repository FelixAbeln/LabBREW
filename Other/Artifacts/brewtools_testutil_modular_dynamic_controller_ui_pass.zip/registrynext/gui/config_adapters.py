from __future__ import annotations

from application.config_models import ApplicationConfigModel
from gui.panel_config_adapters import (
    ControlPanelConfigAdapter,
    RelayPanelConfigAdapter,
    SafetyPanelConfigAdapter,
    SchedulerPanelConfigAdapter,
    TwinPanelConfigAdapter,
)


class ApplicationConfigBuilder:
    """Collects panel editor/form state and translates it into application-facing config DTOs."""

    def __init__(self, window):
        self.window = window

    def build(self) -> ApplicationConfigModel:
        w = self.window
        brew_form = w.editors.brew.read_form_state()
        control_form = w.editors.control.read_form_state()
        relay_form = w.editors.relay.read_form_state()
        safety_form = w.editors.safety.read_form_state()
        scheduler_form = w.editors.scheduler.read_form_state()
        twin_form = w.editors.twin.read_form_state()

        control = ControlPanelConfigAdapter(control_form)
        relay = RelayPanelConfigAdapter(relay_form)
        safety = SafetyPanelConfigAdapter(safety_form, list(w.safety_rules_controller.get_rules()))
        scheduler = SchedulerPanelConfigAdapter(scheduler_form, list(w.queries.scheduler_steps()))
        twin = TwinPanelConfigAdapter(twin_form)

        return ApplicationConfigModel(
            bitrate=brew_form.bitrate,
            can_channel=brew_form.can_channel,
            can_channel_label=brew_form.can_channel_label,
            psu_com_port=brew_form.psu_com_port,
            voltage=brew_form.voltage,
            temp_controller=control.temp_controller(),
            pressure_controller=control.pressure_controller(),
            agitator=control.agitator(),
            relay=relay.relay(),
            safety=safety.safety(),
            scheduler=scheduler.scheduler(),
            twin=twin.twin(),
        )
