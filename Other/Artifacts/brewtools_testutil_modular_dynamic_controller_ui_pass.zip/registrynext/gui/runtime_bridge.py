from __future__ import annotations


class WindowRuntimeBridge:
    """Owns runtime-side GUI coordination that is not a pure view refresh."""

    def __init__(self, window):
        self.window = window

    def append_frame_log(self, frame, obj) -> None:
        if obj is not None:
            self.window.brew_panel.log.appendPlainText(str(obj))

    def update_agitator_runtime(self) -> None:
        self.window.commands.update_agitator_runtime()

    def sync_runtime_targets(self) -> None:
        snap = self.window.queries.snapshot()
        self.window.ui_state.loading_scheduler_ui = True
        try:
            changed = self.window.control_panel.apply_scheduler_targets(
                snap.controls.temperature.setpoint,
                snap.controls.pressure.setpoint,
                snap.controls.pressure.allow_add_gas,
                snap.controls.agitator.on,
                snap.controls.agitator.duty_cycle,
            )
        finally:
            self.window.ui_state.loading_scheduler_ui = False
        if changed:
            self.window.config_controller.save_settings_to_state(validate=False)
            self.window.intent_dispatcher.refresh_control_panel(force=True)
