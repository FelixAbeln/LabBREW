from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class OperatorDefinition:
    key: str
    meaning: str
    uses_threshold: bool = False
    uses_range: bool = False
    uses_time: bool = False
    example: str = ''


OPERATOR_DEFINITIONS: tuple[OperatorDefinition, ...] = (
    OperatorDefinition('>', 'Value greater than threshold', uses_threshold=True, example='pressure > 1.2'),
    OperatorDefinition('>=', 'Value greater than or equal to threshold', uses_threshold=True, example='temp >= 20'),
    OperatorDefinition('<', 'Value less than threshold', uses_threshold=True, example='ferm_rate < 0.2'),
    OperatorDefinition('<=', 'Value less than or equal to threshold', uses_threshold=True, example='pressure <= 0.8'),
    OperatorDefinition('==', 'Value equal to threshold', uses_threshold=True, example='system:can_connected == 1'),
    OperatorDefinition('!=', 'Value not equal to threshold', uses_threshold=True, example='system:relay_connected != 1'),
    OperatorDefinition('in_range', 'Value inside low..high inclusive', uses_range=True, example='18 <= temp <= 22'),
    OperatorDefinition('out_of_range', 'Value outside low..high inclusive', uses_range=True, example='temp outside 18..22'),
    OperatorDefinition('stale', 'Signal quality is stale or older than timeout', example='sensor stale'),
    OperatorDefinition('invalid', 'Signal is missing, stale, or has no usable value', example='signal invalid'),
    OperatorDefinition('true', 'Signal evaluates true / non-zero', example='system:can_connected true'),
    OperatorDefinition('false', 'Signal evaluates false / zero', example='system:psu_power_on false'),
    OperatorDefinition('valid_for', 'Signal(s) remain valid for the time_s duration', uses_time=True, example='all required signals valid for 30 s'),
)

OPERATOR_KEYS: tuple[str, ...] = tuple(item.key for item in OPERATOR_DEFINITIONS)


def iter_operator_rows() -> Iterable[tuple[str, str, str, str, str]]:
    for item in OPERATOR_DEFINITIONS:
        yield (
            item.key,
            item.meaning,
            'yes' if item.uses_threshold or item.uses_range else 'no',
            'yes' if item.uses_time else 'no',
            item.example,
        )
