from __future__ import annotations

import threading
import time
from typing import Dict, Optional

import can
from PySide6.QtCore import QObject, QThread, Signal
from brewtools_can import BrewtoolsCanId, CanFrame, MsgType, NodeType, Priority
from brewtools_can.bodies import RawBody

from .decode_service import DecodeService


DENSITY_REQUEST_INTERVAL_S = 2.0


def build_agitator_pwm_frame(node_id: int, duty_cycle: float) -> tuple[int, bytes]:
    can_id = BrewtoolsCanId(
        priority=Priority.MEDIUM,
        sender_node_type=NodeType.NODE_TYPE_PLC,
        receiver_node_type=NodeType.NODE_TYPE_AGITATOR_ACTUATOR,
        secondary_node_id=int(node_id),
        msg_type=MsgType.MSG_TYPE_PWM,
    )
    pct = max(0, min(100, int(round(float(duty_cycle)))))
    frame = CanFrame(can_id=can_id, body=RawBody(subindex=0, raw=bytes([pct & 0xFF])))
    return frame.to_can()


def build_start_measurement_frame(node_id: int, receiver_node_type: int | NodeType) -> tuple[int, bytes]:
    """Build a Start Measurement command the same way the send dialog does."""
    can_id = BrewtoolsCanId(
        priority=Priority.MEDIUM,
        sender_node_type=NodeType.NODE_TYPE_PLC,
        receiver_node_type=receiver_node_type,
        secondary_node_id=int(node_id),
        msg_type=MsgType.MSG_TYPE_START_MEASUREMENT_CMD,
    )
    frame = CanFrame(can_id=can_id, body=RawBody(subindex=0, raw=b""))
    return frame.to_can()


class CanRxThread(QThread):
    frame_received = Signal(object, object)
    status = Signal(str)

    def __init__(self, channel: int, bitrate: int, density_interval_s: float = DENSITY_REQUEST_INTERVAL_S, parent=None):
        super().__init__(parent)
        self.channel = channel
        self.bitrate = bitrate
        self._stop = threading.Event()
        self._bus: Optional[can.Bus] = None
        self._bus_lock = threading.RLock()
        self._auto_density_nodes: Dict[int, float] = {}
        self._density_interval_s = max(0.1, float(density_interval_s))

    def stop(self):
        self._stop.set()

    def send_frame(self, arbitration_id: int, data: bytes) -> None:
        with self._bus_lock:
            if self._bus is None:
                raise RuntimeError('CAN bus is not connected.')
            msg = can.Message(arbitration_id=int(arbitration_id), data=data, is_extended_id=True)
            self._bus.send(msg)

    def set_density_request_interval(self, interval_s: float) -> None:
        with self._bus_lock:
            self._density_interval_s = max(0.1, float(interval_s))

    def set_auto_density_for_node(self, node_id: int, enabled: bool = True, interval_s: float | None = None) -> None:
        now = time.monotonic()
        with self._bus_lock:
            if interval_s is not None:
                self._density_interval_s = max(0.1, float(interval_s))
            if enabled:
                self._auto_density_nodes[int(node_id)] = now - self._density_interval_s
            else:
                self._auto_density_nodes.pop(int(node_id), None)

    def clear_auto_density_nodes(self) -> None:
        with self._bus_lock:
            self._auto_density_nodes.clear()

    def _poll_auto_density_requests(self) -> None:
        now = time.monotonic()
        due_nodes: list[int] = []
        with self._bus_lock:
            interval_s = self._density_interval_s
            for node_id, last_sent in list(self._auto_density_nodes.items()):
                if now - last_sent >= interval_s:
                    due_nodes.append(node_id)
                    self._auto_density_nodes[node_id] = now

        for node_id in due_nodes:
            try:
                arb_id, data = build_start_measurement_frame(
                    node_id=node_id,
                    receiver_node_type=NodeType.NODE_TYPE_DENSITY_SENSOR,
                )
                self.send_frame(arb_id, data)
            except Exception as e:
                self.status.emit(f'Auto density request failed for node {node_id}: {e}')

    def run(self):
        try:
            self.status.emit(f"Opening Kvaser: channel={self.channel}, bitrate={self.bitrate}")
            self._bus = can.Bus(interface='kvaser', channel=self.channel, bitrate=self.bitrate)
            self.status.emit('Listening…')
        except Exception as e:
            self.status.emit(f'ERROR opening bus: {e}')
            return

        try:
            while not self._stop.is_set():
                msg = self._bus.recv(timeout=0.10)
                if msg is not None and not msg.is_error_frame:
                    frame = CanFrame.from_can(int(msg.arbitration_id), bytes(msg.data))
                    obj = DecodeService.decode(frame)
                    self.frame_received.emit(frame, obj)
                self._poll_auto_density_requests()
        finally:
            try:
                if self._bus is not None:
                    with self._bus_lock:
                        self._bus.shutdown()
            except Exception:
                pass
            self._bus = None
            self.status.emit('Stopped.')


class CANService(QObject):
    frame_received = Signal(object, object)
    status = Signal(str)
    connection_changed = Signal(bool)

    def __init__(self, parent=None, density_request_interval_s: float = DENSITY_REQUEST_INTERVAL_S):
        super().__init__(parent)
        self._thread: Optional[CanRxThread] = None
        self._auto_density_nodes: set[int] = set()
        self._density_request_interval_s = max(0.1, float(density_request_interval_s))

    @property
    def is_connected(self) -> bool:
        return self._thread is not None and self._thread.isRunning()

    def set_density_request_interval(self, interval_s: float) -> None:
        self._density_request_interval_s = max(0.1, float(interval_s))
        if self._thread is not None:
            self._thread.set_density_request_interval(self._density_request_interval_s)
        self.status.emit(f'Auto density request interval set to {self._density_request_interval_s:.2f} s.')

    def connect_bus(self, channel: int, bitrate: int) -> None:
        if self.is_connected:
            return
        self._thread = CanRxThread(channel, bitrate, density_interval_s=self._density_request_interval_s, parent=self)
        self._thread.frame_received.connect(self.frame_received)
        self._thread.status.connect(self.status)
        self._thread.finished.connect(self._on_finished)
        self._thread.start()
        self.connection_changed.emit(True)

    def disconnect_bus(self) -> None:
        if self._thread is None:
            return
        self._thread.clear_auto_density_nodes()
        self._thread.stop()
        self._thread.wait(1200)
        self._thread = None
        self._auto_density_nodes.clear()
        self.connection_changed.emit(False)

    def send_frame(self, arbitration_id: int, data: bytes) -> None:
        if self._thread is None:
            raise RuntimeError('CAN bus is not connected.')
        self._thread.send_frame(arbitration_id, data)

    def send_agitator_pwm(self, node_id: int, duty_cycle: float) -> None:
        arb_id, data = build_agitator_pwm_frame(node_id=node_id, duty_cycle=duty_cycle)
        self.send_frame(arb_id, data)

    def note_decoded_frame(self, frame: CanFrame, obj: object | None) -> None:
        """Enable periodic density measurement requests after a density sensor shows up."""
        if self._thread is None or obj is None:
            return

        sender_node_type = int(frame.can_id.sender_node_type)
        node_id = int(frame.can_id.secondary_node_id)
        if sender_node_type != int(NodeType.NODE_TYPE_DENSITY_SENSOR):
            return

        if obj.__class__.__name__ != 'TemperatureMeasurement':
            return

        if node_id in self._auto_density_nodes:
            return

        self._auto_density_nodes.add(node_id)
        self._thread.set_auto_density_for_node(node_id, enabled=True, interval_s=self._density_request_interval_s)
        self.status.emit(
            f'Auto density request enabled for density sensor node {node_id} every {self._density_request_interval_s:.2f} s.'
        )

    def _on_finished(self) -> None:
        self._thread = None
        self._auto_density_nodes.clear()
        self.connection_changed.emit(False)
