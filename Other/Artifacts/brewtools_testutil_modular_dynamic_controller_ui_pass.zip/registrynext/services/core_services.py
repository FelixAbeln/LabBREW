from __future__ import annotations

from dataclasses import dataclass

from services.application.config_validation_service import ConfigValidationService
from services.application.settings_mapper_service import SettingsMapperService
from services.core.signal_registry_service import SignalRegistryService


@dataclass
class CoreServices:
    signal_registry_service: SignalRegistryService
    settings_mapper: SettingsMapperService
    config_validation_service: ConfigValidationService
