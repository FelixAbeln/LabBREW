from __future__ import annotations

from typing import Optional

try:
    from PSU.psu import LABPS3005DN, PSUError
except Exception:  # pragma: no cover
    LABPS3005DN = None

    class PSUError(Exception):
        pass


class PSUService:
    def __init__(self) -> None:
        self.psu = None
        self._port: Optional[str] = None

    @property
    def is_available(self) -> bool:
        return LABPS3005DN is not None

    @property
    def is_connected(self) -> bool:
        ser = getattr(self.psu, 'ser', None)
        return ser is not None and getattr(ser, 'is_open', False)

    def ensure_connected(self, port: str):
        if LABPS3005DN is None:
            raise RuntimeError('Could not import PSU.psu. Put psu.py in a PSU subfolder next to this program.')
        if not port:
            raise RuntimeError('Select a PSU COM port first.')
        if self.psu is not None and self._port == port and self.is_connected:
            return self.psu
        self.close()
        self.psu = LABPS3005DN(port)
        self._port = port
        return self.psu

    def power_on(self, port: str, voltage: float) -> None:
        psu = self.ensure_connected(port)
        psu.set_voltage(voltage)
        psu.output_on()

    def power_off(self) -> None:
        if self.psu is not None:
            self.psu.output_off()

    def read_measurements(self) -> tuple[Optional[float], Optional[float]]:
        if self.psu is None or not self.is_connected:
            return None, None
        return float(self.psu.measure_voltage()), float(self.psu.measure_current())

    def close(self) -> None:
        if self.psu is not None:
            try:
                self.psu.close()
            except Exception:
                pass
            self.psu = None
            self._port = None
