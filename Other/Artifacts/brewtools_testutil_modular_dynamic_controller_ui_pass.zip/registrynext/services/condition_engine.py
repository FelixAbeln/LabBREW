from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass(frozen=True)
class ConditionResult:
    met: bool
    status_text: str
    needs_hold: bool = False


def _quality_text(record: Any) -> str:
    return str(getattr(record, 'quality', 'MISSING') or 'MISSING').upper()


def _raw_value(record: Any) -> Any:
    return getattr(record, 'value', None)


def evaluate_signal_condition(
    record: Any,
    operator: str,
    *,
    threshold: Optional[float] = None,
    low: Optional[float] = None,
    high: Optional[float] = None,
) -> ConditionResult:
    op = str(operator or '').strip().lower()
    if record is None:
        return ConditionResult(False, 'MISSING')

    quality = _quality_text(record)
    raw_value = _raw_value(record)

    if op == 'stale':
        return ConditionResult(quality == 'STALE', quality)
    if op == 'invalid':
        return ConditionResult(quality in {'MISSING', 'STALE'} or raw_value is None, quality)
    if op == 'true':
        return ConditionResult(bool(raw_value), str(raw_value))
    if op == 'false':
        return ConditionResult(not bool(raw_value), str(raw_value))
    if op == 'valid_for':
        is_valid = quality == 'GOOD' and raw_value is not None
        return ConditionResult(is_valid, quality if not is_valid else 'GOOD', needs_hold=True)

    if quality in {'MISSING', 'STALE'} or raw_value is None:
        return ConditionResult(False, quality)

    try:
        value = float(raw_value)
    except Exception:
        return ConditionResult(False, 'Non-numeric')

    status = f'{value:.6g}'
    if op == '>':
        return ConditionResult(threshold is not None and value > float(threshold), status)
    if op == '>=':
        return ConditionResult(threshold is not None and value >= float(threshold), status)
    if op == '<':
        return ConditionResult(threshold is not None and value < float(threshold), status)
    if op == '<=':
        return ConditionResult(threshold is not None and value <= float(threshold), status)
    if op in {'==', '='}:
        return ConditionResult(threshold is not None and abs(value - float(threshold)) <= 1e-9, status)
    if op == '!=':
        return ConditionResult(threshold is not None and abs(value - float(threshold)) > 1e-9, status)
    if op == 'in_range':
        return ConditionResult(low is not None and high is not None and float(low) <= value <= float(high), status)
    if op == 'out_of_range':
        return ConditionResult(low is not None and high is not None and not (float(low) <= value <= float(high)), status)

    return ConditionResult(False, 'Unsupported operator')
