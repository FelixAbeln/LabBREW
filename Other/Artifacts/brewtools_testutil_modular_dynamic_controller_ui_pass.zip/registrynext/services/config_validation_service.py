from __future__ import annotations

from application.config_models import ApplicationConfigModel
from application.config_validation import ValidationIssue, ValidationResult
from application.registry import AppRegistry


class ConfigValidationService:
    """Canonical application-level config validator shared by GUI and headless entrypoints."""

    def __init__(self, *, registry: AppRegistry) -> None:
        self.registry = registry

    def validate(self, config: ApplicationConfigModel) -> ValidationResult:
        issues: list[ValidationIssue] = []
        issues.extend(self._validate_brew(config))
        issues.extend(self._validate_control(config))
        issues.extend(self._validate_relay(config))
        issues.extend(self._validate_safety(config))
        issues.extend(self._validate_scheduler(config))
        issues.extend(self._validate_twin(config))
        return ValidationResult(tuple(issues))

    def _validate_brew(self, config: ApplicationConfigModel) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        if int(config.bitrate) <= 0:
            issues.append(ValidationIssue("brew", "bitrate", "CAN bitrate must be greater than 0."))
        if float(config.voltage) <= 0.0:
            issues.append(ValidationIssue("brew", "voltage", "PSU voltage must be greater than 0 V."))
        return issues

    def _validate_signal_key(self, panel: str, field: str, key: str, message: str) -> list[ValidationIssue]:
        if not key:
            return []
        if self.registry.recognizes_signal_key(key):
            return []
        return [ValidationIssue(panel, field, message)]

    def _validate_control(self, config: ApplicationConfigModel) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        temp = config.temp_controller
        pressure = config.pressure_controller
        agitator = config.agitator
        if temp.enabled and not temp.source_key:
            issues.append(ValidationIssue("control", "temp_source_key", "Temperature control needs a source signal."))
        if temp.enabled and temp.source_key:
            issues.extend(self._validate_signal_key("control", "temp_source_key", str(temp.source_key), "Temperature control source uses an unknown signal family."))
        if float(temp.deadband) < 0.0:
            issues.append(ValidationIssue("control", "temp_deadband", "Temperature deadband cannot be negative."))
        if pressure.enabled and not pressure.source_key:
            issues.append(ValidationIssue("control", "pressure_source_key", "Pressure control needs a source signal."))
        if pressure.enabled and pressure.source_key:
            issues.extend(self._validate_signal_key("control", "pressure_source_key", str(pressure.source_key), "Pressure control source uses an unknown signal family."))
        if float(pressure.deadband) < 0.0:
            issues.append(ValidationIssue("control", "pressure_deadband", "Pressure deadband cannot be negative."))
        if agitator.enabled and not agitator.target:
            issues.append(ValidationIssue("control", "agitator_target", "Agitator control needs a target."))
        if agitator.enabled and agitator.target:
            target = str(agitator.target)
            if target != 'relay' and not target.startswith('can:'):
                issues.append(ValidationIssue("control", "agitator_target", "Agitator target is not supported by the registered output targets."))
        if float(agitator.duty_cycle) < 0.0 or float(agitator.duty_cycle) > 100.0:
            issues.append(ValidationIssue("control", "agitator_duty_cycle", "Agitator duty cycle must be between 0 and 100%."))

        seen_instance_ids: set[str] = set()
        for item in getattr(config, 'controller_instances', []) or []:
            item_id = str(getattr(item, 'id', '') or '').strip()
            if not item_id:
                issues.append(ValidationIssue("control", "controller_instances", "Dynamic controllers must have a stable id."))
                continue
            if item_id in seen_instance_ids:
                issues.append(ValidationIssue("control", "controller_instances", f"Dynamic controller id '{item_id}' is duplicated."))
                continue
            seen_instance_ids.add(item_id)
            controller = self.registry.get_controller_definition(getattr(item, 'controller_key', None))
            if controller is None:
                issues.append(ValidationIssue("control", "controller_instances", f"Dynamic controller '{getattr(item, 'id', '?')}' uses unknown controller '{getattr(item, 'controller_key', '')}'."))
                continue
            source_key = str(getattr(item, 'source_key', '') or '')
            if getattr(item, 'enabled', False) and controller.source_families and not source_key:
                issues.append(ValidationIssue("control", "controller_instances", f"Controller '{getattr(item, 'label', item.controller_key)}' needs a source signal."))
            if source_key:
                issues.extend(self._validate_signal_key("control", "controller_instances", source_key, f"Controller '{getattr(item, 'label', item.controller_key)}' uses an unknown signal family."))
            target_key = str(getattr(item, 'target_key', '') or '')
            if target_key and not self.registry.recognizes_output_target_key(target_key):
                issues.append(ValidationIssue("control", "controller_instances", f"Controller '{getattr(item, 'label', item.controller_key)}' target '{target_key}' is not a registered output target."))
            elif target_key:
                family = str(target_key).partition(':')[0]
                if controller.target_families and family not in set(controller.target_families):
                    issues.append(ValidationIssue("control", "controller_instances", f"Controller '{getattr(item, 'label', item.controller_key)}' target '{target_key}' is not compatible with controller '{controller.key}'."))
            if float(getattr(item, 'deadband', 0.0) or 0.0) < 0.0:
                issues.append(ValidationIssue("control", "controller_instances", f"Controller '{getattr(item, 'label', item.controller_key)}' deadband cannot be negative."))

        if agitator.mode == "pid":
            if float(agitator.speed_setpoint_rpm) <= 0.0:
                issues.append(ValidationIssue("control", "agitator_speed_setpoint_rpm", "PID agitator mode needs a positive speed setpoint."))
            for field, value in {
                "agitator_pid_kp": agitator.pid_kp,
                "agitator_pid_ki": agitator.pid_ki,
                "agitator_pid_kd": agitator.pid_kd,
            }.items():
                if float(value) < 0.0:
                    issues.append(ValidationIssue("control", field, "Agitator PID gains cannot be negative."))
        return issues

    def _validate_relay(self, config: ApplicationConfigModel) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        relay = config.relay
        if not str(relay.host).strip():
            issues.append(ValidationIssue("relay", "host", "Relay host cannot be empty."))
        if int(relay.tcp_port) <= 0 or int(relay.tcp_port) > 65535:
            issues.append(ValidationIssue("relay", "tcp_port", "Relay TCP port must be between 1 and 65535."))
        assigned = [str(v).strip() for v in relay.assignments.values() if v]
        duplicates = {v for v in assigned if assigned.count(v) > 1}
        if duplicates:
            issues.append(ValidationIssue("relay", "assignments", f"Relay targets must be unique. Duplicate: {sorted(duplicates)[0]}"))
        return issues

    def _validate_safety(self, config: ApplicationConfigModel) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        safety = config.safety
        if float(safety.stale_timeout_s) <= 0.0:
            issues.append(ValidationIssue("safety", "stale_timeout_s", "Safety stale timeout must be greater than 0 s."))
        if float(safety.min_switch_time_s) < 0.0:
            issues.append(ValidationIssue("safety", "min_switch_time_s", "Minimum switch time cannot be negative."))
        if safety.max_temperature_enabled and float(safety.max_temperature_c) <= 0.0:
            issues.append(ValidationIssue("safety", "max_temperature_c", "Max temperature must be greater than 0 when enabled."))
        if safety.max_pressure_enabled and float(safety.max_pressure_bar) <= 0.0:
            issues.append(ValidationIssue("safety", "max_pressure_bar", "Max pressure must be greater than 0 when enabled."))
        names = [str(r.name).strip() for r in safety.rules if str(r.name).strip()]
        duplicates = {n for n in names if names.count(n) > 1}
        if duplicates:
            issues.append(ValidationIssue("safety", "rules", f"Safety rule names must be unique. Duplicate: {sorted(duplicates)[0]}"))
        for rule in safety.rules:
            if not str(rule.name).strip():
                issues.append(ValidationIssue("safety", "rules", "Safety rules must have a name."))
                break
            if not str(rule.signal_key).strip():
                issues.append(ValidationIssue("safety", "rules", f"Safety rule '{rule.name}' needs a signal source."))
                break
            if not self.registry.has_operator(rule.operator):
                issues.append(ValidationIssue("safety", "rules", f"Safety rule '{rule.name}' uses unknown operator '{rule.operator}'."))
                break
            issues.extend(self._validate_signal_key("safety", "rules", rule.signal_key, f"Safety rule '{rule.name}' uses an unknown signal family."))
            for action in rule.actions:
                if not self.registry.has_safety_action(action):
                    issues.append(ValidationIssue("safety", "rules", f"Safety rule '{rule.name}' uses unknown action '{action}'."))
                    break
        return issues

    def _validate_scheduler(self, config: ApplicationConfigModel) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        scheduler = config.scheduler
        if scheduler.enabled and not str(scheduler.workbook_path).strip():
            issues.append(ValidationIssue("scheduler", "workbook_path", "Scheduler is enabled but no workbook path is set."))
        if scheduler.enabled and not str(scheduler.sheet_name).strip():
            issues.append(ValidationIssue("scheduler", "sheet_name", "Scheduler is enabled but no sheet is selected."))
        if float(scheduler.startup_delay_s) < 0.0:
            issues.append(ValidationIssue("scheduler", "startup_delay_s", "Scheduler startup delay cannot be negative."))
        for index, step in enumerate(scheduler.steps, start=1):
            if not self.registry.has_wait_type(step.wait_type):
                issues.append(ValidationIssue("scheduler", "steps", f"Step {index} uses unknown wait type '{step.wait_type}'."))
                break
            if step.operator and not self.registry.has_operator(step.operator):
                issues.append(ValidationIssue("scheduler", "steps", f"Step {index} uses unknown operator '{step.operator}'."))
                break
            if step.wait_source:
                issues.extend(self._validate_signal_key("scheduler", "steps", step.wait_source, f"Step {index} wait source uses an unknown signal family."))
            for source in step.valid_sources:
                issues.extend(self._validate_signal_key("scheduler", "steps", source, f"Step {index} valid_sources contains an unknown signal family."))
            for action in getattr(step, 'controller_actions', []):
                controller = self.registry.get_controller_definition(action.get('controller_key') if isinstance(action, dict) else getattr(action, 'controller_key', None))
                if controller is None:
                    issues.append(ValidationIssue("scheduler", "steps", f"Step {index} uses unknown controller '{action}'."))
                    break
                field = action.get('field', 'setpoint') if isinstance(action, dict) else getattr(action, 'field', 'setpoint')
                if field not in controller.action_fields:
                    issues.append(ValidationIssue("scheduler", "steps", f"Step {index} uses unsupported field '{field}' for controller '{controller.key}'."))
                    break
        return issues

    def _validate_twin(self, config: ApplicationConfigModel) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        twin = config.twin
        if twin.enabled and not str(twin.fmu_path).strip():
            issues.append(ValidationIssue("twin", "fmu_path", "Twin is enabled but no FMU path is set."))
        for name, binding in twin.input_bindings.items():
            if binding:
                issues.extend(self._validate_signal_key("twin", name, str(binding), f"Twin input '{name}' uses an unknown signal family."))
        return issues
