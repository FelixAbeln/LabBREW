from __future__ import annotations

from brewtools_can import CanFrame, DomainFactory


class DecodeService:
    @staticmethod
    def decode(frame: CanFrame):
        return DomainFactory.build(frame)
