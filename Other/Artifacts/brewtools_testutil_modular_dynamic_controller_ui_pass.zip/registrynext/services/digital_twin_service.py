from __future__ import annotations

import os
import shutil
import tempfile
import time
import threading
import zipfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from state import AppState
from services.signal_registry import signal_lookup

try:
    from fmpy import extract, instantiate_fmu, read_model_description
    _HAS_FMPY = True
except Exception:
    extract = instantiate_fmu = read_model_description = None
    _HAS_FMPY = False


@dataclass
class TwinVariable:
    name: str
    var_type: str
    causality: str
    description: str = ''
    value_reference: Optional[int] = None


class DigitalTwinService:
    """FMU metadata reader and optional runtime executor.

    If fmpy is installed and the FMU supports co-simulation, the service will try
    to instantiate and step the FMU. If not, it falls back to metadata-only mode
    with placeholder outputs.
    """

    STALE_AFTER_S = 10.0

    @staticmethod
    def _normalize_fmu_path(path: str) -> str:
        path = str(path or '').strip()
        if not path:
            return ''
        try:
            # Use a platform-normalized, case-normalized absolute path for stable comparison.
            return os.path.normcase(os.path.normpath(str(Path(path).expanduser().resolve(strict=False))))
        except Exception:
            return os.path.normcase(os.path.normpath(path))

    def __init__(self) -> None:
        self.loaded_fmu_path: str = ''
        self.model_name: str = ''
        self.last_status_text: str = 'No FMU loaded'
        self.input_vars: list[TwinVariable] = []
        self.output_vars: list[TwinVariable] = []

        self._runtime_mode = 'none'   # none | metadata | runtime
        self._unzipdir: Optional[str] = None
        self._model_description = None
        self._fmu = None
        self._sim_time = 0.0
        self._last_eval_monotonic: Optional[float] = None
        self._input_map: dict[str, TwinVariable] = {}
        self._output_map: dict[str, TwinVariable] = {}
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        self._wake_event = threading.Event()
        self._worker: Optional[threading.Thread] = None
        self._snapshot_provider = None
        self._latest_result = {'inputs': {}, 'outputs': {'status_text': 'Idle', 'fmu_name': '—', 'step_count': 0, 'sim_time_s': 0.0, 'last_dt_s': None, 'last_step_age_s': None, 'worker_period_s': 0.25, 'runtime_mode': 'none'}}
        self._step_count = 0
        self._last_dt = None
        self._last_step_wallclock = None
        self._period_s = 0.25


    def start_background(self, snapshot_provider, period_s: float = 0.25) -> None:
        self._snapshot_provider = snapshot_provider
        self._period_s = max(0.05, float(period_s))
        if self._worker is not None and self._worker.is_alive():
            return
        self._stop_event.clear()
        self._wake_event.clear()
        self._worker = threading.Thread(target=self._worker_loop, name='DigitalTwinWorker', daemon=True)
        self._worker.start()

    def stop_background(self) -> None:
        self._stop_event.set()
        self._wake_event.set()
        if self._worker is not None and self._worker.is_alive():
            self._worker.join(timeout=1.0)
        self._worker = None
        self._cleanup_runtime()

    def request_cycle(self) -> None:
        self._wake_event.set()

    def latest_result(self) -> dict:
        with self._lock:
            return {
                'inputs': dict(self._latest_result.get('inputs', {})),
                'outputs': dict(self._latest_result.get('outputs', {})),
            }

    def _worker_loop(self) -> None:
        while not self._stop_event.is_set():
            provider = self._snapshot_provider
            if provider is None:
                self._stop_event.wait(0.25)
                continue
            try:
                snapshot = provider()
                result = self.evaluate(snapshot)
            except Exception as exc:
                result = {
                    'inputs': {},
                    'outputs': {
                        'status_text': f'Twin worker error: {exc}',
                        'fmu_name': self.model_name or '—',
                        'step_count': self._step_count,
                        'sim_time_s': self._sim_time,
                        'last_dt_s': self._last_dt,
                        'last_step_age_s': (time.monotonic() - self._last_step_wallclock) if self._last_step_wallclock else None,
                        'worker_period_s': self._period_s,
                        'runtime_mode': self._runtime_mode,
                    },
                }
            with self._lock:
                self._latest_result = result
            self._wake_event.wait(self._period_s)
            self._wake_event.clear()

    def _cleanup_runtime(self) -> None:
        try:
            if self._fmu is not None:
                try:
                    self._fmu.terminate()
                except Exception:
                    pass
                try:
                    self._fmu.freeInstance()
                except Exception:
                    pass
        finally:
            self._fmu = None
        if self._unzipdir:
            shutil.rmtree(self._unzipdir, ignore_errors=True)
            self._unzipdir = None
        self._model_description = None
        self._runtime_mode = 'none'
        self._sim_time = 0.0
        self._last_eval_monotonic = None
        self._input_map = {}
        self._output_map = {}
        self._step_count = 0
        self._last_dt = None
        self._last_step_wallclock = None

    def _parse_fmu_variables(self, path: Path) -> tuple[str, list[TwinVariable], list[TwinVariable]]:
        with zipfile.ZipFile(path, 'r') as zf:
            xml_bytes = zf.read('modelDescription.xml')
        root = ET.fromstring(xml_bytes)
        model_name = root.attrib.get('modelName') or path.stem
        model_vars = root.find('ModelVariables')
        inputs: list[TwinVariable] = []
        outputs: list[TwinVariable] = []
        if model_vars is None:
            return model_name, inputs, outputs
        for sv in model_vars:
            causality = (sv.attrib.get('causality') or '').strip()
            if causality not in {'input', 'output'}:
                continue
            var_type = 'Unknown'
            if len(sv):
                tag = sv[0].tag
                if '}' in tag:
                    tag = tag.rsplit('}', 1)[1]
                var_type = tag
            vr = sv.attrib.get('valueReference')
            try:
                vr_i = int(vr) if vr is not None else None
            except Exception:
                vr_i = None
            var = TwinVariable(
                name=sv.attrib.get('name', ''),
                var_type=var_type,
                causality=causality,
                description=sv.attrib.get('description', '') or '',
                value_reference=vr_i,
            )
            if causality == 'input':
                inputs.append(var)
            else:
                outputs.append(var)
        return model_name, inputs, outputs

    def _initialize_runtime(self, p: Path) -> None:
        self._cleanup_runtime()
        if not _HAS_FMPY:
            self._runtime_mode = 'metadata'
            self.last_status_text = f'FMU loaded: {p.name} (metadata only - install fmpy for runtime)'
            return

        try:
            self._model_description = read_model_description(str(p))
            cs = getattr(self._model_description, 'coSimulation', None)
            if cs is None:
                self._runtime_mode = 'metadata'
                self.last_status_text = f'FMU loaded: {p.name} (no co-simulation runtime)'
                return

            tmpdir = tempfile.mkdtemp(prefix='brewtools_fmu_')
            self._unzipdir = extract(str(p), unzipdir=tmpdir)
            self._fmu = instantiate_fmu(self._unzipdir, self._model_description, 'CoSimulation')
            self._fmu.setupExperiment(startTime=0.0)
            self._fmu.enterInitializationMode()
            self._fmu.exitInitializationMode()

            self._input_map = {v.name: v for v in self.input_vars if v.value_reference is not None}
            self._output_map = {v.name: v for v in self.output_vars if v.value_reference is not None}
            self._runtime_mode = 'runtime'
            self._sim_time = 0.0
            self._last_eval_monotonic = None
            self._step_count = 0
            self._last_dt = None
            self._last_step_wallclock = None
            self.last_status_text = f'Estimator running ({self.model_name})'
        except Exception as exc:
            self._cleanup_runtime()
            self._runtime_mode = 'metadata'
            self.last_status_text = f'FMU loaded: {p.name} (metadata only, runtime error: {exc})'

    def load_model(self, path: str) -> tuple[bool, str]:
        path = str(path or '').strip()
        normalized_path = self._normalize_fmu_path(path)
        self._cleanup_runtime()
        if not path:
            self.loaded_fmu_path = ''
            self.model_name = ''
            self.last_status_text = 'No FMU loaded'
            self.input_vars = []
            self.output_vars = []
            return False, self.last_status_text
        p = Path(path)
        if not p.exists():
            self.loaded_fmu_path = ''
            self.model_name = ''
            self.input_vars = []
            self.output_vars = []
            self.last_status_text = f'FMU not found: {p.name}'
            return False, self.last_status_text
        if p.suffix.lower() != '.fmu':
            self.loaded_fmu_path = ''
            self.model_name = ''
            self.input_vars = []
            self.output_vars = []
            self.last_status_text = f'Not an FMU file: {p.name}'
            return False, self.last_status_text
        try:
            model_name, inputs, outputs = self._parse_fmu_variables(p)
        except Exception as exc:
            self.loaded_fmu_path = ''
            self.model_name = ''
            self.input_vars = []
            self.output_vars = []
            self.last_status_text = f'Failed to read FMU: {exc}'
            return False, self.last_status_text
        self.loaded_fmu_path = normalized_path
        self.model_name = model_name
        self.input_vars = inputs
        self.output_vars = outputs
        self._initialize_runtime(p)
        if self._runtime_mode != 'runtime' and 'metadata only' not in self.last_status_text.lower():
            self.last_status_text = f'FMU loaded: {p.name} ({len(inputs)} inputs, {len(outputs)} outputs)'
        return True, self.last_status_text

    def input_variables(self) -> list[TwinVariable]:
        return list(self.input_vars)

    def output_variables(self) -> list[TwinVariable]:
        return list(self.output_vars)

    @property
    def runtime_mode(self) -> str:
        return str(self._runtime_mode or 'none')

    def _resolve_binding(self, snapshot: AppState, binding: Optional[str]) -> Optional[float]:
        if not binding:
            return None
        rec = signal_lookup(snapshot).get(str(binding))
        if rec is None or rec.quality in {'STALE', 'MISSING'} or rec.value is None:
            return None
        if isinstance(rec.value, bool):
            return 1.0 if rec.value else 0.0
        try:
            return float(rec.value)
        except Exception:
            return None

    def _placeholder_output(self, name: str, var_type: str, inputs: dict[str, Optional[float]]):
        low = name.lower()
        if var_type.lower() == 'boolean':
            if 'heat' in low:
                return bool(inputs.get('in_enable', 1.0) or 0.0) and bool(inputs.get('in_t_c', 0.0) < inputs.get('in_tsp_c', 0.0)) if inputs.get('in_t_c') is not None and inputs.get('in_tsp_c') is not None else bool(inputs.get('heat_cmd_in', 0.0) or 0.0)
            if 'cool' in low or 'pump' in low:
                return bool(inputs.get('in_enable', 1.0) or 0.0) and bool(inputs.get('in_t_c', 0.0) > inputs.get('in_tsp_c', 0.0)) if inputs.get('in_t_c') is not None and inputs.get('in_tsp_c') is not None else bool(inputs.get('cool_cmd_in', 0.0) or 0.0)
            if 'gas' in low and 'remove' not in low:
                return bool(inputs.get('add_gas_cmd_in', 0.0) or 0.0)
            if 'vent' in low or 'remove' in low:
                return bool(inputs.get('remove_gas_cmd_in', 0.0) or 0.0)
            return False
        if 'temp' in low:
            return inputs.get('in_t_c')
        if 'pressure' in low or 'psp' in low:
            return inputs.get('in_pressure_bar') or inputs.get('in_psp_bar')
        if 'gravity' in low or 'sg' in low:
            return inputs.get('in_gravity_sg')
        if 'level' in low:
            return inputs.get('in_level')
        if 'ventflow' in low:
            return 1.0 if bool(inputs.get('remove_gas_cmd_in', 0.0) or 0.0) else 0.0
        if 'addflow' in low or 'gas' in low:
            return 1.0 if bool(inputs.get('add_gas_cmd_in', 0.0) or 0.0) else 0.0
        return None

    def _set_runtime_inputs(self, inputs: dict[str, Optional[float]]) -> None:
        if self._fmu is None:
            return
        real_vrs, real_vals = [], []
        bool_vrs, bool_vals = [], []
        int_vrs, int_vals = [], []
        for name, value in inputs.items():
            if value is None:
                continue
            meta = self._input_map.get(name)
            if meta is None or meta.value_reference is None:
                continue
            t = (meta.var_type or '').lower()
            if t == 'boolean':
                bool_vrs.append(meta.value_reference)
                bool_vals.append(bool(value))
            elif t in {'integer', 'enumeration'}:
                int_vrs.append(meta.value_reference)
                int_vals.append(int(value))
            else:
                real_vrs.append(meta.value_reference)
                real_vals.append(float(value))
        if real_vrs:
            self._fmu.setReal(real_vrs, real_vals)
        if bool_vrs:
            try:
                self._fmu.setBoolean(bool_vrs, bool_vals)
            except Exception:
                self._fmu.setInteger(bool_vrs, [1 if v else 0 for v in bool_vals])
        if int_vrs:
            self._fmu.setInteger(int_vrs, int_vals)

    def _get_runtime_outputs(self) -> dict:
        outputs = {}
        if self._fmu is None:
            return outputs
        for name, meta in self._output_map.items():
            if meta.value_reference is None:
                outputs[name] = None
                continue
            t = (meta.var_type or '').lower()
            try:
                if t == 'boolean':
                    try:
                        outputs[name] = bool(self._fmu.getBoolean([meta.value_reference])[0])
                    except Exception:
                        outputs[name] = bool(self._fmu.getInteger([meta.value_reference])[0])
                elif t in {'integer', 'enumeration'}:
                    outputs[name] = int(self._fmu.getInteger([meta.value_reference])[0])
                else:
                    outputs[name] = float(self._fmu.getReal([meta.value_reference])[0])
            except Exception:
                outputs[name] = None
        return outputs

    def _missing_bound_inputs(self, cfg, inputs: dict[str, Optional[float]]) -> list[str]:
        missing: list[str] = []
        for var in self.input_vars:
            binding = cfg.input_bindings.get(var.name)
            if not binding:
                continue
            if inputs.get(var.name) is None:
                missing.append(var.name)
        return missing

    def evaluate(self, snapshot: AppState) -> dict:
        cfg = snapshot.twin
        normalized_cfg_path = self._normalize_fmu_path(cfg.fmu_path)
        if cfg.enabled and normalized_cfg_path != self.loaded_fmu_path:
            self.load_model(cfg.fmu_path)

        inputs = {var.name: self._resolve_binding(snapshot, cfg.input_bindings.get(var.name)) for var in self.input_vars}

        if not cfg.enabled:
            outputs = {var.name: None for var in self.output_vars}
            outputs.update({'status_text': 'Disabled', 'fmu_name': self.model_name or '—', 'step_count': self._step_count, 'sim_time_s': self._sim_time, 'last_dt_s': self._last_dt, 'last_step_age_s': (time.monotonic() - self._last_step_wallclock) if self._last_step_wallclock else None, 'worker_period_s': self._period_s, 'runtime_mode': self._runtime_mode})
            return {'inputs': inputs, 'outputs': outputs}

        outputs = {}
        status = self.last_status_text
        missing_inputs = self._missing_bound_inputs(cfg, inputs)

        if cfg.enabled and self._runtime_mode == 'runtime' and self._fmu is not None:
            if missing_inputs:
                self._last_eval_monotonic = None
                missing_preview = ', '.join(missing_inputs[:3])
                if len(missing_inputs) > 3:
                    missing_preview += ', ...'
                status = f'FMU waiting for valid inputs ({missing_preview})'
                self.last_status_text = status
            else:
                try:
                    now = time.monotonic()
                    dt = 0.1 if self._last_eval_monotonic is None else max(0.02, min(1.0, now - self._last_eval_monotonic))
                    self._last_eval_monotonic = now
                    self._set_runtime_inputs(inputs)
                    self._fmu.doStep(currentCommunicationPoint=self._sim_time, communicationStepSize=dt)
                    self._sim_time += dt
                    self._step_count += 1
                    self._last_dt = dt
                    self._last_step_wallclock = now
                    outputs = self._get_runtime_outputs()
                    status = f'Estimator running ({self.model_name})'
                    self.last_status_text = status
                except Exception as exc:
                    self._cleanup_runtime()
                    self._runtime_mode = 'metadata'
                    status = f'FMU runtime failed; metadata only ({exc})'
                    self.last_status_text = status

        if not outputs:
            if cfg.enabled and self.loaded_fmu_path:
                if self._runtime_mode == 'metadata':
                    status = self.last_status_text or f'Metadata only ({self.model_name})'
                elif missing_inputs:
                    pass
                else:
                    status = f'Estimator running ({self.model_name})'
            elif cfg.enabled and not self.loaded_fmu_path:
                status = 'Enabled, waiting for FMU'
            outputs = {var.name: self._placeholder_output(var.name, var.var_type, inputs) for var in self.output_vars}

        outputs.update({'status_text': status, 'fmu_name': self.model_name or '—', 'step_count': self._step_count, 'sim_time_s': self._sim_time, 'last_dt_s': self._last_dt, 'last_step_age_s': (time.monotonic() - self._last_step_wallclock) if self._last_step_wallclock else None, 'worker_period_s': self._period_s, 'runtime_mode': self._runtime_mode})
        return {'inputs': inputs, 'outputs': outputs}
