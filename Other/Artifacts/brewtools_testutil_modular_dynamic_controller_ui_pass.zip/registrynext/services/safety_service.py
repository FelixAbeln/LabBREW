from __future__ import annotations

from typing import Any
import time

from state import AppState, SafetyRule
from services.signal_registry import signal_lookup
from services.condition_engine import evaluate_signal_condition


ACTION_LABELS = {
    'safe_outputs': 'Safe outputs profile',
    'all_off': 'All virtual outputs off',
    'vent': 'Vent pressure',
    'disable_heat': 'Disable heat',
    'disable_cool': 'Disable cool',
    'disable_add_gas': 'Disable add gas',
    'disable_remove_gas': 'Disable remove gas',
    'disable_agitator': 'Disable agitator',
    'pause_scheduler': 'Pause scheduler',
    'stop_scheduler': 'Stop scheduler',
    'power_off_psu': 'Power off PSU',
    'relays_off': 'All relays off',
}


class SafetyService:
    def __init__(self) -> None:
        self._hold_started: dict[str, float | None] = {}

    def evaluate(self, snapshot: AppState) -> dict[str, Any]:
        outputs = {
            'heat': bool(snapshot.controls.heat_cool.output_a),
            'cool': bool(snapshot.controls.heat_cool.output_b),
            'add_gas': bool(snapshot.controls.gas.output_a),
            'remove_gas': bool(snapshot.controls.gas.output_b),
            'agitator': bool(snapshot.controls.agitator.enabled and snapshot.controls.agitator.on),
        }
        if not snapshot.safety.enabled:
            return {
                'tripped': False,
                'reason': 'Safety disabled',
                'active_rules': [],
                'active_actions': [],
                'effective_outputs': outputs,
                'request_pause_scheduler': False,
                'request_stop_scheduler': False,
                'request_power_off_psu': False,
                'force_relays_off': False,
            }

        records = signal_lookup(snapshot)
        active_rules: list[str] = []
        active_actions: list[str] = []

        for rule in snapshot.safety.rules:
            if not rule.enabled or not str(rule.signal_key or '').strip():
                continue
            triggered, _detail = self._rule_triggered(rule, records)
            if not triggered:
                continue
            active_rules.append(rule.name or rule.signal_key)
            for action in rule.actions:
                if action and action not in active_actions:
                    active_actions.append(action)

        effective = dict(outputs)
        for action in active_actions:
            if action == 'safe_outputs':
                effective = dict(snapshot.safety.safe_outputs)
            elif action == 'all_off':
                effective = {k: False for k in effective}
            elif action == 'vent':
                effective['add_gas'] = False
                effective['remove_gas'] = True
            elif action == 'disable_heat':
                effective['heat'] = False
            elif action == 'disable_cool':
                effective['cool'] = False
            elif action == 'disable_add_gas':
                effective['add_gas'] = False
            elif action == 'disable_remove_gas':
                effective['remove_gas'] = False
            elif action == 'disable_agitator':
                effective['agitator'] = False

        reason = 'OK'
        if active_rules:
            reason = '; '.join(active_rules)

        return {
            'tripped': bool(active_rules),
            'reason': reason,
            'active_rules': active_rules,
            'active_actions': [ACTION_LABELS.get(a, a) for a in active_actions],
            'effective_outputs': effective,
            'request_pause_scheduler': 'pause_scheduler' in active_actions,
            'request_stop_scheduler': 'stop_scheduler' in active_actions,
            'request_power_off_psu': 'power_off_psu' in active_actions,
            'force_relays_off': 'relays_off' in active_actions,
        }

    def _rule_triggered(self, rule: SafetyRule, records: dict[str, Any]) -> tuple[bool, str]:
        rec = records.get(str(rule.signal_key or ''))
        rule_key = f"{rule.signal_key}|{rule.name}|{rule.operator}"
        if rec is None:
            self._hold_started.pop(rule_key, None)
            return False, 'Unknown signal'
        op = str(rule.operator or '>').strip().lower()
        now = time.monotonic()
        result = evaluate_signal_condition(
            rec,
            op,
            threshold=rule.threshold,
            low=rule.threshold_low,
            high=rule.threshold_high,
        )
        if result.needs_hold:
            hold_need = max(0.0, float(rule.stale_for_s or 0.0))
            if not result.met:
                self._hold_started.pop(rule_key, None)
                return False, result.status_text
            started = self._hold_started.get(rule_key)
            if started is None:
                self._hold_started[rule_key] = now
                started = now
            held = max(0.0, now - started)
            return held >= hold_need, f'{held:.1f}/{hold_need:.1f}s'
        self._hold_started.pop(rule_key, None)
        return result.met, result.status_text
