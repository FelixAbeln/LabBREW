from __future__ import annotations

from dataclasses import dataclass

from services.integrations.can import CANService
from services.integrations.psu import PSUService


@dataclass
class IntegrationServices:
    can_service: CANService
    psu_service: PSUService
