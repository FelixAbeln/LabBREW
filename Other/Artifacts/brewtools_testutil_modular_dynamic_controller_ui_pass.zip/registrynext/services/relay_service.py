from __future__ import annotations

from typing import Optional

try:
    from RELAY.relay import RelayBoard, RelayError, auto_find_relays
except Exception:  # pragma: no cover
    RelayBoard = None
    auto_find_relays = None
    class RelayError(Exception):
        pass


class RelayService:
    def __init__(self) -> None:
        self.board = None
        self._host: Optional[str] = None
        self._port: Optional[int] = None

    @property
    def is_available(self) -> bool:
        return RelayBoard is not None

    @property
    def is_connected(self) -> bool:
        return self.board is not None and bool(getattr(self.board, 'is_connected', False))

    def discover_targets(self):
        if auto_find_relays is None:
            return []
        return auto_find_relays()

    def connect(self, host: str, port: int):
        if RelayBoard is None:
            raise RuntimeError('Could not import RELAY.relay. Put relay.py in a RELAY subfolder next to this program.')
        host = (host or '').strip()
        port = int(port)
        if self.board is not None and self._host == host and self._port == port and self.is_connected:
            return self.board
        self.close()
        self.board = RelayBoard(host=host, port=port)
        if hasattr(self.board, 'connect'):
            self.board.connect()
        self._host = host
        self._port = port
        return self.board

    def disconnect(self) -> None:
        self.close()

    def available_channels(self) -> list[int]:
        if self.board is None:
            return list(range(1, 9))
        return list(self.board.available_channels())

    def set_channel(self, channel: int, value: bool) -> None:
        if not self.is_connected or self.board is None:
            return
        self.board.set_channel(int(channel), bool(value))

    def apply_channel_states(self, desired_states: dict[int, bool]) -> None:
        if not self.is_connected or self.board is None:
            return
        for channel, value in desired_states.items():
            self.board.set_channel(int(channel), bool(value))

    def states(self) -> dict[int, bool]:
        if not self.is_connected or self.board is None:
            return {}
        return self.board.all_states()

    def close(self) -> None:
        if self.board is not None:
            try:
                self.board.close()
            except Exception:
                pass
            self.board = None
        self._host = None
        self._port = None
