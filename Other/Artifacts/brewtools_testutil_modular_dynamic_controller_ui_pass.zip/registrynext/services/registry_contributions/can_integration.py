from __future__ import annotations

from application.registry import AppRegistry, OutputTargetDefinition


def register_can_integration(registry: AppRegistry) -> None:
    registry.register_output_target(OutputTargetDefinition(
        key='can.agitator_pwm',
        label='CAN agitator PWM output',
        family='can',
        value_kinds=('percent', 'rpm', 'bool'),
        notes='CAN transport output for agitator duty cycle or PID speed control.',
    ))
