from __future__ import annotations

from application.registry import AppRegistry, SafetyActionDefinition

SAFETY_ACTIONS = {
    'safe_outputs': 'Safe outputs profile',
    'all_off': 'All virtual outputs off',
    'vent': 'Vent pressure',
    'disable_heat': 'Disable heat',
    'disable_cool': 'Disable cool',
    'disable_add_gas': 'Disable add gas',
    'disable_remove_gas': 'Disable remove gas',
    'disable_agitator': 'Disable agitator',
    'pause_scheduler': 'Pause scheduler',
    'stop_scheduler': 'Stop scheduler',
    'power_off_psu': 'Power off PSU',
    'relays_off': 'All relays off',
}


def register_safety_feature(registry: AppRegistry) -> None:
    for key, label in SAFETY_ACTIONS.items():
        registry.register_safety_action(SafetyActionDefinition(key=key, label=label))
