from __future__ import annotations

import time
from typing import Optional

from application.registry import AppRegistry, SignalProviderDefinition
from helpers import format_node_type
from services.signal_registry import SignalRecord, make_signal_key
from state import AppState


def register_system_signal_family(registry: AppRegistry) -> None:
    registry.register_signal_provider(SignalProviderDefinition(
        key='system.runtime_signals',
        label='Runtime/system/discovered measurement signals',
        families=('sensor', 'system', 'psu'),
        provider=_system_signal_records,
    ))


def _system_signal_records(snapshot: AppState) -> list[SignalRecord]:
    now = time.time()
    stale_after = max(0.1, float(snapshot.safety.stale_timeout_s))
    records: list[SignalRecord] = []

    def quality(last_seen: Optional[float]) -> str:
        if last_seen is None:
            return 'MISSING'
        return 'GOOD' if (now - float(last_seen)) <= stale_after else 'STALE'

    for key, st in sorted(snapshot.devices.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        q = quality(st.last_seen)
        try:
            base = f'{format_node_type(st.sender_node_type)} #{st.node_id}'
        except Exception:
            base = f'{st.sender_node_type}:{st.node_id}'
        if st.temperature is not None:
            records.append(SignalRecord(make_signal_key('sensor','temperature',*key), f'{base} — Temperature', st.temperature, q, '°C'))
        if st.pressure is not None:
            records.append(SignalRecord(make_signal_key('sensor','pressure',*key), f'{base} — Pressure', st.pressure, q, 'bar'))
        if st.density is not None:
            records.append(SignalRecord(make_signal_key('sensor','density',*key), f'{base} — Density', st.density, q, ''))
        if st.level is not None:
            records.append(SignalRecord(make_signal_key('sensor','level',*key), f'{base} — Level', st.level, q, ''))
        if st.rpm is not None:
            records.append(SignalRecord(make_signal_key('sensor','rpm',*key), f'{base} — RPM', st.rpm, q, 'rpm'))
    records.extend([
        SignalRecord('system:can_connected', 'System — CAN connected', snapshot.can_connected, 'GOOD', ''),
        SignalRecord('system:psu_power_on', 'System — PSU power on', snapshot.psu_power_on, 'GOOD', ''),
        SignalRecord('system:relay_connected', 'System — Relays connected', snapshot.relay.connected, 'GOOD', ''),
        SignalRecord('system:scheduler_running', 'System — Scheduler running', snapshot.scheduler_runtime.running, 'GOOD', ''),
        SignalRecord('system:scheduler_paused', 'System — Scheduler paused', snapshot.scheduler_runtime.paused, 'GOOD', ''),
        SignalRecord('system:twin_enabled', 'System — Twin enabled', snapshot.twin.enabled, 'GOOD', ''),
        SignalRecord('system:twin_loaded', 'System — Twin loaded', bool(snapshot.twin_runtime.outputs.get('runtime_mode', 'none') != 'none' or snapshot.twin_runtime.outputs.get('fmu_name')), 'GOOD', ''),
        SignalRecord('psu:measured_voltage', 'PSU — Measured voltage', snapshot.psu_measured_voltage, 'GOOD' if snapshot.psu_measured_voltage is not None else 'MISSING', 'V'),
        SignalRecord('psu:measured_current', 'PSU — Measured current', snapshot.psu_measured_current, 'GOOD' if snapshot.psu_measured_current is not None else 'MISSING', 'A'),
    ])
    return records
