from __future__ import annotations

from application.registry import AppRegistry, OutputTargetProviderDefinition, OutputTargetRecord, SignalProviderDefinition
from services.signal_registry import SignalRecord, make_signal_key
from state import AppState


RELAY_ASSIGNMENT_TARGETS = (
    OutputTargetRecord('relay_assignment:heat', 'Relay assignment — HEAT', 'relay_assignment', 'bool', ('temperature','deadband','pid'), ''),
    OutputTargetRecord('relay_assignment:cool', 'Relay assignment — COOL', 'relay_assignment', 'bool', ('temperature','deadband','pid'), ''),
    OutputTargetRecord('relay_assignment:add_gas', 'Relay assignment — ADD GAS', 'relay_assignment', 'bool', ('pressure','deadband','pid'), ''),
    OutputTargetRecord('relay_assignment:remove_gas', 'Relay assignment — REMOVE GAS', 'relay_assignment', 'bool', ('pressure','deadband','pid'), ''),
    OutputTargetRecord('relay_assignment:agitator', 'Relay assignment — AGITATOR', 'relay_assignment', 'bool', ('agitator','deadband','pid'), ''),
)


def register_relay_feature(registry: AppRegistry) -> None:
    registry.register_signal_provider(SignalProviderDefinition(
        key='relay.channel_states',
        label='Relay channel state signals',
        families=('relay',),
        provider=_relay_signal_records,
    ))
    registry.register_output_target_provider(OutputTargetProviderDefinition(
        key='relay.assignment_targets',
        label='Relay assignment targets',
        families=('relay_assignment',),
        provider=_relay_assignment_targets,
    ))


def _relay_signal_records(snapshot: AppState) -> list[SignalRecord]:
    records: list[SignalRecord] = []
    for ch in range(1, max(1, snapshot.relay.channel_count) + 1):
        records.append(SignalRecord(make_signal_key('relay', ch), f'Relay {ch} state', snapshot.relay.channel_states.get(ch, False), 'GOOD' if snapshot.relay.connected else 'MISSING', ''))
    return records


def _relay_assignment_targets(snapshot: AppState) -> list[OutputTargetRecord]:
    return list(RELAY_ASSIGNMENT_TARGETS)
