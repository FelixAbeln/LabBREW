from __future__ import annotations

from application.registry import AppRegistry, OperatorDefinition, WaitTypeDefinition
from services.operator_definitions import OPERATOR_DEFINITIONS

WAIT_TYPES = {
    'elapsed_time': 'Advance after time_s seconds elapse for the active step.',
    'signal': 'Advance when wait_source satisfies the selected operator, optionally held for time_s seconds.',
    'all_valid': 'Advance when all valid_sources remain good continuously for time_s seconds.',
}


def register_scheduler_feature(registry: AppRegistry) -> None:
    for item in OPERATOR_DEFINITIONS:
        registry.register_operator(OperatorDefinition(
            key=item.key,
            meaning=item.meaning,
            uses_threshold_or_range=bool(item.uses_threshold or item.uses_range),
            uses_time=bool(item.uses_time),
            example=item.example,
        ))
    for key, meaning in WAIT_TYPES.items():
        registry.register_wait_type(WaitTypeDefinition(key=key, meaning=meaning))
