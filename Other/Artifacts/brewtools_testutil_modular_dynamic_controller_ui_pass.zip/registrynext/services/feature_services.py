from __future__ import annotations

from dataclasses import dataclass

from services.features.control import DeadbandControlService
from services.features.twin import DigitalTwinService
from services.features.relay import RelayService
from services.features.safety import SafetyService
from services.features.scheduler import SchedulerService
from services.application.scheduler_template_service import SchedulerTemplateService


@dataclass
class FeatureServices:
    control_service: DeadbandControlService
    safety_service: SafetyService
    digital_twin_service: DigitalTwinService
    relay_service: RelayService
    scheduler_service: SchedulerService
    scheduler_template_service: SchedulerTemplateService
