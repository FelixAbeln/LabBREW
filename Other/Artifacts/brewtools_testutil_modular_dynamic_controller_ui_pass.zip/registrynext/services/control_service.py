from __future__ import annotations

from typing import Optional
import time

from state import AppState
from services.signal_registry import signal_lookup


class AgitatorPidController:
    def __init__(self) -> None:
        self._integral = 0.0
        self._last_error: Optional[float] = None
        self._last_ts: Optional[float] = None
        self._last_output = 0.0

    def reset(self) -> None:
        self._integral = 0.0
        self._last_error = None
        self._last_ts = None
        self._last_output = 0.0

    def compute(self, *, enabled: bool, mode: str, is_can_target: bool, requested_on: bool, allowed: bool, manual_duty: float, speed_setpoint_rpm: float, rpm_feedback: Optional[float], kp: float, ki: float, kd: float) -> tuple[float, bool]:
        effective_on = bool(enabled and requested_on and allowed)
        manual_duty = max(0.0, min(100.0, float(manual_duty)))
        if not effective_on:
            self.reset()
            return 0.0, False
        if (mode or 'manual') != 'pid' or not is_can_target:
            self.reset()
            return manual_duty, False
        target_rpm = max(0.0, float(speed_setpoint_rpm))
        if target_rpm <= 0.0:
            self.reset()
            return 0.0, True
        now = time.monotonic()
        dt = 0.0 if self._last_ts is None else max(1e-3, min(1.0, now - self._last_ts))
        self._last_ts = now
        if rpm_feedback is None:
            measured = 0.0
            # Until feedback arrives, use the base/start duty as an open-loop seed.
            self._last_output = manual_duty
            return manual_duty, True
        measured = max(0.0, float(rpm_feedback))
        error = target_rpm - measured
        derivative = 0.0 if self._last_error is None or dt <= 0.0 else (error - self._last_error) / dt
        proposed_integral = self._integral + (error * dt if dt > 0.0 else 0.0)
        p_term = float(kp) * error
        i_term = float(ki) * proposed_integral
        d_term = float(kd) * derivative
        output = manual_duty + p_term + i_term + d_term
        unclamped = output
        output = max(0.0, min(100.0, output))
        # Anti-windup: only accept the new integral if we are not saturating further into a limit.
        if not ((unclamped > 100.0 and error > 0.0) or (unclamped < 0.0 and error < 0.0)):
            self._integral = max(-1000.0, min(1000.0, proposed_integral))
        # Small kick on startup so the actuator gets moving if feedback is near zero.
        startup_floor = manual_duty if manual_duty > 0.0 else 10.0
        if measured < 1.0 and output < startup_floor and target_rpm > 0.0:
            output = startup_floor
        self._last_error = error
        self._last_output = output
        return output, True


class DeadbandControlService:
    def __init__(self) -> None:
        self._last_switch_ts = {
            'temperature': 0.0,
            'pressure': 0.0,
        }
        self._last_outputs = {
            'temperature': (False, False),
            'pressure': (False, False),
        }
        self.agitator_pid = AgitatorPidController()

    @staticmethod
    def _resolve_value(snapshot: AppState, source_key: Optional[object], value_name: str, stale_after_s: float):
        if source_key is None:
            return None, 'Unassigned'
        rec = signal_lookup(snapshot).get(str(source_key))
        if rec is None:
            return None, 'Waiting for sensor'
        if rec.quality == 'STALE':
            return None, 'Stale'
        if rec.quality == 'MISSING':
            return None, 'Waiting for sensor'
        if rec.value is None:
            return None, 'No signal'
        try:
            return float(rec.value), None
        except Exception:
            return None, 'No signal'

    @staticmethod
    def _eval_deadband(process_value: Optional[float], setpoint: float, deadband: float):
        if process_value is None:
            return False, False, 'No signal'
        half = max(deadband / 2.0, 1e-9)
        if process_value < setpoint - half:
            return True, False, 'Below band'
        if process_value > setpoint + half:
            return False, True, 'Above band'
        return False, False, 'In band'

    def _apply_min_switch(self, name: str, out_a: bool, out_b: bool, min_switch_s: float):
        prev = self._last_outputs[name]
        now = time.time()
        if (out_a, out_b) != prev and (now - self._last_switch_ts[name]) < max(0.0, min_switch_s):
            return prev
        if (out_a, out_b) != prev:
            self._last_outputs[name] = (out_a, out_b)
            self._last_switch_ts[name] = now
        return out_a, out_b

    def evaluate_deadband_controller(self, snapshot: AppState, *, source_key, measurement_kind: str, setpoint: float, deadband: float, stale_after: float, allow_output_a: bool = True):
        pv, issue = self._resolve_value(snapshot, source_key, measurement_kind, stale_after)
        if issue is not None:
            return {
                'process_value': pv,
                'output_a': False,
                'output_b': False,
                'state_text': issue,
            }
        output_a, output_b, state_text = self._eval_deadband(pv, setpoint, deadband)
        if not allow_output_a:
            output_a = False
            if output_b:
                state_text = 'Above band (natural pressure only)'
            elif state_text == 'Below band':
                state_text = 'Below band (add gas disabled)'
        return {
            'process_value': pv,
            'output_a': output_a,
            'output_b': output_b,
            'state_text': state_text,
        }

    def evaluate(self, snapshot: AppState):
        stale_after = snapshot.safety.stale_timeout_s
        min_switch = snapshot.safety.min_switch_time_s

        temp_cfg = snapshot.controls.temperature
        pressure_cfg = snapshot.controls.pressure

        if temp_cfg.enabled:
            pv, temp_issue = self._resolve_value(snapshot, temp_cfg.source_key, 'temperature', stale_after)
            if temp_issue is not None:
                heat, cool, state_text = False, False, temp_issue
            else:
                heat, cool, state_text = self._eval_deadband(pv, temp_cfg.setpoint, temp_cfg.deadband)
        else:
            pv, heat, cool, state_text = None, False, False, 'Disabled'

        if pressure_cfg.enabled:
            ppv, pressure_issue = self._resolve_value(snapshot, pressure_cfg.source_key, 'pressure', stale_after)
            if pressure_issue is not None:
                add_gas, remove_gas, pstate = False, False, pressure_issue
            else:
                add_gas, remove_gas, pstate = self._eval_deadband(ppv, pressure_cfg.setpoint, pressure_cfg.deadband)
                if not pressure_cfg.allow_add_gas:
                    add_gas = False
                    if remove_gas:
                        pstate = 'Above band (natural pressure only)'
                    elif pstate == 'Below band':
                        pstate = 'Below band (add gas disabled)'
        else:
            ppv, add_gas, remove_gas, pstate = None, False, False, 'Disabled'

        heat, cool = self._apply_min_switch('temperature', heat, cool, min_switch)
        add_gas, remove_gas = self._apply_min_switch('pressure', add_gas, remove_gas, min_switch)

        return {
            'temperature': {
                'process_value': pv,
                'output_a': heat,
                'output_b': cool,
                'state_text': state_text,
            },
            'pressure': {
                'process_value': ppv,
                'output_a': add_gas,
                'output_b': remove_gas,
                'state_text': pstate,
            },
        }
