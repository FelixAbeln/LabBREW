from services.registry_contributions.twin_feature import register_twin_feature

__all__ = ['register_twin_feature']
