from services.registry_contributions.control_feature import register_control_feature

__all__ = ['register_control_feature']
