from services.registry_contributions.scheduler_feature import register_scheduler_feature

__all__ = ['register_scheduler_feature']
