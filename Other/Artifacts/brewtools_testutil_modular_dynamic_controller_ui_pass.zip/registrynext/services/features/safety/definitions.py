from services.registry_contributions.safety_feature import register_safety_feature

__all__ = ['register_safety_feature']
