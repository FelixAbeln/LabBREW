from services.safety_service import SafetyService

__all__ = ['SafetyService']
