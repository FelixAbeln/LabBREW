from services.registry_contributions.relay_feature import register_relay_feature

__all__ = ['register_relay_feature']
