from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

from openpyxl import load_workbook

from state import AppState, SchedulerControllerAction, SchedulerStep
from services.signal_registry import signal_lookup
from services.operator_definitions import OPERATOR_KEYS
from services.condition_engine import evaluate_signal_condition


def _parse_ramp_cell(value):
    if value in (None, ''):
        return None, None
    if isinstance(value, (int, float)):
        return float(value), None
    txt = str(value).strip()
    if not txt:
        return None, None
    if ':' in txt:
        left, right = txt.split(':', 1)
        try:
            target = float(left.strip())
        except Exception:
            return None, None
        try:
            rate = abs(float(right.strip()))
        except Exception:
            rate = None
        return target, rate
    try:
        return float(txt), None
    except Exception:
        return None, None


def _parse_optional_bool(value):
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    txt = str(value).strip().lower()
    if txt in {'', '-', 'default', 'inherit'}:
        return None
    if txt in {'1', 'true', 'yes', 'y', 'on'}:
        return True
    if txt in {'0', 'false', 'no', 'n', 'off'}:
        return False
    return None


def _parse_agitator_cell(value):
    if value in (None, ''):
        return None, None
    b = _parse_optional_bool(value)
    if b is not None:
        return bool(b), (0.0 if not b else None)
    try:
        duty = float(value)
    except Exception:
        return None, None
    duty = max(0.0, min(100.0, duty))
    return duty > 0.0, duty


def _normalize_wait_type(value: str) -> str:
    txt = str(value or 'elapsed_time').strip().lower()
    if txt in {'signal_threshold', 'threshold', 'twin_threshold'}:
        return 'signal'
    if txt in {'valid_all', 'valid'}:
        return 'all_valid'
    if txt in {'time', 'duration'}:
        return 'elapsed_time'
    return txt or 'elapsed_time'


def _parse_controller_value(value_text: str):
    b = _parse_optional_bool(value_text)
    if b is not None:
        return b
    try:
        return float(value_text)
    except Exception:
        return value_text


def _parse_controller_action_entry(text: str) -> SchedulerControllerAction | None:
    raw = str(text or '').strip()
    if not raw:
        return None
    parts = [part.strip() for part in raw.split(':')]
    if len(parts) < 2:
        return None
    target = parts[0]
    value_text = parts[1]
    ramp = None
    if len(parts) >= 3 and parts[2] not in {'', '-'}:
        try:
            ramp = abs(float(parts[2]))
        except Exception:
            ramp = None
    controller_key, dot, field = target.partition('.')
    controller_key = controller_key.strip()
    if not controller_key:
        return None
    if not field:
        field = 'command' if controller_key == 'agitator' else 'setpoint'
    return SchedulerControllerAction(
        controller_key=controller_key,
        field=field or 'setpoint',
        value=_parse_controller_value(value_text),
        ramp_per_s=ramp,
        raw_value=value_text,
    )


def _parse_controller_actions_cell(value) -> list[SchedulerControllerAction]:
    if value in (None, ''):
        return []
    text = str(value).replace('\n', ';')
    actions: list[SchedulerControllerAction] = []
    for chunk in text.split(';'):
        action = _parse_controller_action_entry(chunk)
        if action is not None:
            actions.append(action)
    return actions


def _merge_controller_actions(explicit_actions: list[SchedulerControllerAction], *, temp_target, temp_ramp, pressure_target, pressure_ramp, allow_add_gas, agitator_on, agitator_duty) -> list[SchedulerControllerAction]:
    merged: dict[tuple[str, str], SchedulerControllerAction] = {}
    for action in explicit_actions:
        merged[(action.controller_key, action.field)] = action
    if temp_target is not None:
        merged[('temperature', 'setpoint')] = SchedulerControllerAction('temperature', 'setpoint', temp_target, temp_ramp, str(temp_target))
    if pressure_target is not None:
        merged[('pressure', 'setpoint')] = SchedulerControllerAction('pressure', 'setpoint', pressure_target, pressure_ramp, str(pressure_target))
    if allow_add_gas is not None:
        merged[('pressure', 'allow_add_gas')] = SchedulerControllerAction('pressure', 'allow_add_gas', bool(allow_add_gas), None, str(allow_add_gas))
    if agitator_duty is not None:
        merged[('agitator', 'command')] = SchedulerControllerAction('agitator', 'command', float(agitator_duty), None, str(agitator_duty))
    elif agitator_on is not None:
        merged[('agitator', 'command')] = SchedulerControllerAction('agitator', 'command', bool(agitator_on), None, str(agitator_on))
    return list(merged.values())


@dataclass
class ScheduleLoadResult:
    ok: bool
    message: str
    sheet_names: list[str]
    active_sheet: str
    steps: list[SchedulerStep]


class SchedulerService:
    def __init__(self) -> None:
        self._steps: list[SchedulerStep] = []
        self._workbook_path = ''
        self._sheet_name = ''
        self._running = False
        self._paused = False
        self._current_step_index = -1
        self._awaiting_confirmation = False
        self._confirmation_message = ''
        self._step_started_monotonic: Optional[float] = None
        self._hold_started_monotonic: Optional[float] = None
        self._last_transition = ''
        self._sheet_names: list[str] = []
        self._action_ramp_starts: dict[tuple[str, str], Optional[float]] = {}

    @property
    def steps(self) -> list[SchedulerStep]:
        return [SchedulerStep(**vars(step)) for step in self._steps]

    @property
    def workbook_path(self) -> str:
        return self._workbook_path

    @property
    def sheet_name(self) -> str:
        return self._sheet_name

    @property
    def sheet_names(self) -> list[str]:
        return list(self._sheet_names)

    def load_workbook(self, path: str, sheet_name: str = '') -> ScheduleLoadResult:
        path = str(path or '').strip()
        if not path:
            self._steps = []
            self._workbook_path = ''
            self._sheet_name = ''
            self._sheet_names = []
            return ScheduleLoadResult(False, 'No schedule file selected', [], '', [])
        wb = load_workbook(path, data_only=True)
        self._sheet_names = list(wb.sheetnames)
        if not self._sheet_names:
            self._steps = []
            return ScheduleLoadResult(False, 'Workbook has no sheets', [], '', [])
        target_sheet = sheet_name if sheet_name in wb.sheetnames else wb.sheetnames[0]
        ws = wb[target_sheet]
        header_cells = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), None)
        if not header_cells:
            self._steps = []
            return ScheduleLoadResult(False, 'Schedule sheet is empty', self.sheet_names, target_sheet, [])
        headers = [str(v).strip() if v is not None else '' for v in header_cells]
        header_map = {h.lower(): i for i, h in enumerate(headers) if h}

        def cell(row, name, default=None):
            idx = header_map.get(name.lower())
            if idx is None or idx >= len(row):
                return default
            value = row[idx]
            return default if value is None else value

        def as_bool(value, default=False):
            if value is None:
                return default
            if isinstance(value, bool):
                return value
            txt = str(value).strip().lower()
            if txt in {'1', 'true', 'yes', 'y', 'on'}:
                return True
            if txt in {'0', 'false', 'no', 'n', 'off'}:
                return False
            return default

        def as_float(value):
            if value in (None, ''):
                return None
            try:
                return float(value)
            except Exception:
                return None

        steps: list[SchedulerStep] = []
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=0):
            if not any(v not in (None, '') for v in row):
                continue
            valid_sources_raw = cell(row, 'valid_sources', '')
            valid_sources = [part.strip() for part in str(valid_sources_raw or '').split(',') if part.strip()]
            temp_target, temp_ramp = _parse_ramp_cell(cell(row, 'temp_sp', cell(row, 'temperature_setpoint')))
            pressure_target, pressure_ramp = _parse_ramp_cell(cell(row, 'pressure_sp', cell(row, 'pressure_setpoint')))
            explicit_actions = _parse_controller_actions_cell(cell(row, 'controller_actions', ''))
            step = SchedulerStep(
                index=int(cell(row, 'index', row_idx) or row_idx),
                enabled=as_bool(cell(row, 'enabled', True), True),
                name=str(cell(row, 'step_name', cell(row, 'name', f'Step {row_idx + 1}')) or f'Step {row_idx + 1}'),
                temperature_setpoint=temp_target,
                temperature_ramp_per_s=temp_ramp if temp_ramp is not None else as_float(cell(row, 'temp_ramp_per_s', cell(row, 'temperature_ramp_per_s'))),
                pressure_setpoint=pressure_target,
                pressure_ramp_per_s=pressure_ramp if pressure_ramp is not None else as_float(cell(row, 'pressure_ramp_per_s', cell(row, 'pressure_ramp_per_s'))),
                allow_add_gas=_parse_optional_bool(cell(row, 'allow_add_gas')),
                wait_type=_normalize_wait_type(cell(row, 'wait_type', 'elapsed_time')),
                wait_source=str(cell(row, 'wait_source', '') or '').strip(),
                operator=str(cell(row, 'operator', '>=') or '>=').strip(),
                threshold=as_float(cell(row, 'threshold')),
                threshold_low=as_float(cell(row, 'threshold_low')),
                threshold_high=as_float(cell(row, 'threshold_high')),
                duration_s=(as_float(cell(row, 'duration_s')) if as_float(cell(row, 'duration_s')) is not None else as_float(cell(row, 'time_s'))),
                hold_for_s=max(0.0, (as_float(cell(row, 'hold_for_s')) if as_float(cell(row, 'hold_for_s')) is not None else (as_float(cell(row, 'time_s')) or 0.0))),
                valid_sources=valid_sources,
                require_confirmation=as_bool(cell(row, 'require_confirmation', False), False),
                confirmation_message=str(cell(row, 'confirmation_message', '') or '').strip(),
                agitator_on=_parse_optional_bool(cell(row, 'agitator_on')),
                agitator_duty_cycle=as_float(cell(row, 'agitator_duty_cycle')),
                controller_actions=list(explicit_actions),
            )
            step.operator = step.operator.lower()
            if step.operator not in OPERATOR_KEYS:
                step.operator = '>=' if step.wait_type == 'signal' else ('valid_for' if step.wait_type == 'all_valid' else step.operator)
            if step.wait_type == 'elapsed_time' and step.duration_s is None:
                step.duration_s = max(0.0, float(step.hold_for_s or 0.0))
            elif step.wait_type in {'signal', 'all_valid'} and (step.hold_for_s is None or float(step.hold_for_s) == 0.0):
                step.hold_for_s = max(0.0, float(step.duration_s or 0.0))
            if step.confirmation_message:
                step.require_confirmation = True
            ag_on, ag_duty = _parse_agitator_cell(cell(row, 'agitator'))
            if ag_on is not None:
                step.agitator_on = ag_on
            if ag_duty is not None:
                step.agitator_duty_cycle = ag_duty
            elif step.agitator_on is False:
                step.agitator_duty_cycle = 0.0
            step.controller_actions = _merge_controller_actions(
                step.controller_actions,
                temp_target=step.temperature_setpoint,
                temp_ramp=step.temperature_ramp_per_s,
                pressure_target=step.pressure_setpoint,
                pressure_ramp=step.pressure_ramp_per_s,
                allow_add_gas=step.allow_add_gas,
                agitator_on=step.agitator_on,
                agitator_duty=step.agitator_duty_cycle,
            )
            steps.append(step)
        self._steps = steps
        self._workbook_path = path
        self._sheet_name = target_sheet
        self.stop()
        return ScheduleLoadResult(True, f'Loaded schedule: {len(steps)} step(s)', self.sheet_names, target_sheet, self.steps)

    def start(self) -> tuple[bool, str]:
        if not self._steps:
            self._running = False
            self._paused = False
            self._current_step_index = -1
            return False, 'No schedule loaded'
        self._running = True
        self._paused = False
        self._current_step_index = self._first_enabled_step_index()
        self._step_started_monotonic = None
        self._hold_started_monotonic = None
        self._action_ramp_starts = {}
        self._awaiting_confirmation = False
        self._confirmation_message = ''
        self._last_transition = f'Started {self._step_display_name(self._current_step_index)}' if self._current_step_index >= 0 else 'Started'
        return self._current_step_index >= 0, self._last_transition

    def stop(self) -> None:
        self._running = False
        self._paused = False
        self._current_step_index = -1
        self._step_started_monotonic = None
        self._hold_started_monotonic = None
        self._action_ramp_starts = {}
        self._awaiting_confirmation = False
        self._confirmation_message = ''

    def pause(self) -> None:
        if self._running:
            self._paused = True

    def resume(self) -> None:
        if self._running:
            self._paused = False

    def next_step(self) -> tuple[bool, str]:
        nxt = self._next_enabled_step_index(self._current_step_index)
        if nxt < 0:
            return False, 'No next step'
        self._activate_step(nxt, manual=True)
        return True, self._last_transition

    def previous_step(self) -> tuple[bool, str]:
        prev = self._previous_enabled_step_index(self._current_step_index)
        if prev < 0:
            return False, 'No previous step'
        self._activate_step(prev, manual=True)
        return True, self._last_transition

    def confirm_step(self) -> tuple[bool, str]:
        if not self._running or not (0 <= self._current_step_index < len(self._steps)):
            return False, 'Scheduler is not running a step'
        if not self._awaiting_confirmation:
            return False, 'Current step is not waiting for confirmation'
        current_name = self._step_display_name(self._current_step_index)
        nxt = self._next_enabled_step_index(self._current_step_index)
        self._awaiting_confirmation = False
        self._confirmation_message = ''
        self._hold_started_monotonic = None
        if nxt >= 0:
            self._activate_step(nxt)
            return True, self._last_transition
        self._running = False
        self._paused = False
        self._current_step_index = -1
        self._step_started_monotonic = None
        self._last_transition = f'Completed schedule at {current_name}'
        return True, self._last_transition

    def _first_enabled_step_index(self) -> int:
        for i, step in enumerate(self._steps):
            if step.enabled:
                return i
        return -1

    def _next_enabled_step_index(self, current: int) -> int:
        for i in range(current + 1, len(self._steps)):
            if self._steps[i].enabled:
                return i
        return -1

    def _previous_enabled_step_index(self, current: int) -> int:
        for i in range(max(-1, current - 1), -1, -1):
            if self._steps[i].enabled:
                return i
        return -1

    def _step_display_name(self, index: int) -> str:
        if index < 0 or index >= len(self._steps):
            return 'Idle'
        step = self._steps[index]
        return step.name or f'Step {index + 1}'

    def _activate_step(self, index: int, manual: bool = False) -> None:
        self._current_step_index = index
        self._step_started_monotonic = None
        self._hold_started_monotonic = None
        self._action_ramp_starts = {}
        self._awaiting_confirmation = False
        self._confirmation_message = ''
        action = 'Manually selected' if manual else 'Advanced to'
        self._last_transition = f'{action} {self._step_display_name(index)}'

    def _condition_met(self, snapshot: AppState, step: SchedulerStep) -> tuple[bool, str]:
        now = time.monotonic()
        if self._step_started_monotonic is None:
            self._step_started_monotonic = now
        step_elapsed = max(0.0, now - self._step_started_monotonic)
        lookup = signal_lookup(snapshot)

        if step.valid_sources:
            invalid = []
            for key in step.valid_sources:
                rec = lookup.get(key)
                if rec is None or rec.quality != 'GOOD' or rec.value is None:
                    invalid.append(key)
            if invalid:
                self._hold_started_monotonic = None
                preview = ', '.join(invalid[:3])
                if len(invalid) > 3:
                    preview += ', ...'
                return False, f'Waiting for valid signals: {preview}'

        wtype = (step.wait_type or 'elapsed_time').strip().lower()
        if wtype in {'elapsed_time', 'time', 'duration'}:
            need = max(0.0, float(step.duration_s or 0.0))
            return step_elapsed >= need, f'Elapsed {step_elapsed:.1f}/{need:.1f} s'

        if wtype == 'signal':
            rec = lookup.get(step.wait_source)
            op = (step.operator or '>=').strip().lower()
            if rec is None:
                self._hold_started_monotonic = None
                return False, f'Waiting for signal: {step.wait_source or "(unset)"}'
            result = evaluate_signal_condition(
                rec,
                op,
                threshold=step.threshold,
                low=step.threshold_low,
                high=step.threshold_high,
            )
            met = result.met
            status_text = result.status_text
            if status_text in {'MISSING', 'STALE'} and not met and op not in {'stale', 'invalid', 'false'}:
                self._hold_started_monotonic = None
                return False, f'Waiting for signal: {step.wait_source or "(unset)"}'
            if status_text == 'Non-numeric' and not met:
                self._hold_started_monotonic = None
                return False, f'Non-numeric signal: {step.wait_source}'
            if not met:
                self._hold_started_monotonic = None
                if op == 'in_range':
                    return False, f'Waiting for {step.wait_source} in [{step.threshold_low}, {step.threshold_high}], now {status_text}'
                if op == 'out_of_range':
                    return False, f'Waiting for {step.wait_source} outside [{step.threshold_low}, {step.threshold_high}], now {status_text}'
                return False, f'Waiting for {step.wait_source} {step.operator}, now {status_text}'
            hold = max(0.0, float(step.hold_for_s or 0.0))
            if hold <= 0.0:
                return True, f'Condition met: {step.wait_source}'
            if self._hold_started_monotonic is None:
                self._hold_started_monotonic = now
            held = max(0.0, now - self._hold_started_monotonic)
            return held >= hold, f'{step.wait_source} stable {held:.1f}/{hold:.1f} s'

        if wtype == 'all_valid':
            sources = step.valid_sources or ([step.wait_source] if step.wait_source else [])
            if not sources:
                return True, 'No valid sources configured'
            invalid = []
            for key in sources:
                rec = lookup.get(key)
                if rec is None or rec.quality != 'GOOD' or rec.value is None:
                    invalid.append(key)
            if invalid:
                self._hold_started_monotonic = None
                preview = ', '.join(invalid[:3])
                if len(invalid) > 3:
                    preview += ', ...'
                return False, f'Waiting for valid signals: {preview}'
            hold = max(0.0, float(step.hold_for_s or 0.0))
            if hold <= 0.0:
                return True, 'All required signals valid'
            if self._hold_started_monotonic is None:
                self._hold_started_monotonic = now
            held = max(0.0, now - self._hold_started_monotonic)
            return held >= hold, f'All signals valid {held:.1f}/{hold:.1f} s'

        return False, f'Unknown wait_type: {step.wait_type}'


    def _ramp_value(self, start: Optional[float], target: Optional[float], rate_per_s: Optional[float], elapsed_s: float) -> Optional[float]:
        if target is None:
            return None
        if start is None or rate_per_s is None or rate_per_s <= 0:
            return target
        delta = target - start
        max_move = abs(rate_per_s) * max(0.0, elapsed_s)
        if abs(delta) <= max_move:
            return target
        return start + max_move if delta > 0 else start - max_move

    def _controller_field_value(self, snapshot: AppState, controller_key: str, field: str):
        if controller_key == 'temperature' and field == 'setpoint':
            return snapshot.controls.temperature.setpoint
        if controller_key == 'pressure' and field == 'setpoint':
            return snapshot.controls.pressure.setpoint
        if controller_key == 'pressure' and field == 'allow_add_gas':
            return snapshot.controls.pressure.allow_add_gas
        if controller_key == 'agitator' and field == 'command':
            return snapshot.controls.agitator.duty_cycle if snapshot.controls.agitator.on else False
        return None

    def _active_controller_actions_for_step(self, snapshot: AppState, step: SchedulerStep, elapsed_s: float) -> list[SchedulerControllerAction]:
        actions: list[SchedulerControllerAction] = []
        for action in step.controller_actions:
            value = action.value
            if action.field == 'setpoint' and isinstance(value, (int, float)) and action.ramp_per_s not in (None, 0):
                key = (action.controller_key, action.field)
                if key not in self._action_ramp_starts:
                    start = self._controller_field_value(snapshot, action.controller_key, action.field)
                    self._action_ramp_starts[key] = float(start) if isinstance(start, (int, float)) else None
                value = self._ramp_value(self._action_ramp_starts.get(key), float(value), action.ramp_per_s, elapsed_s)
            actions.append(SchedulerControllerAction(
                controller_key=action.controller_key,
                field=action.field,
                value=value,
                ramp_per_s=action.ramp_per_s,
                raw_value=action.raw_value,
            ))
        return actions

    def _legacy_targets_from_actions(self, actions: list[SchedulerControllerAction]) -> tuple[Optional[float], Optional[float], Optional[bool], Optional[bool], Optional[float]]:
        temp_value = None
        pressure_value = None
        allow_add_gas = None
        agitator_on = None
        agitator_duty = None
        for action in actions:
            if action.controller_key == 'temperature' and action.field == 'setpoint' and isinstance(action.value, (int, float)):
                temp_value = float(action.value)
            elif action.controller_key == 'pressure' and action.field == 'setpoint' and isinstance(action.value, (int, float)):
                pressure_value = float(action.value)
            elif action.controller_key == 'pressure' and action.field == 'allow_add_gas' and isinstance(action.value, bool):
                allow_add_gas = bool(action.value)
            elif action.controller_key == 'agitator' and action.field == 'command':
                if isinstance(action.value, bool):
                    agitator_on = bool(action.value)
                    agitator_duty = 0.0 if not agitator_on else None
                elif isinstance(action.value, (int, float)):
                    agitator_duty = float(action.value)
                    agitator_on = agitator_duty > 0.0
        return temp_value, pressure_value, allow_add_gas, agitator_on, agitator_duty

    def evaluate(self, snapshot: AppState) -> dict:
        now = time.monotonic()
        loaded = bool(self._steps)
        current_name = ''
        current_elapsed = 0.0
        waiting_reason = 'Idle'
        active_temp = None
        active_press = None
        active_allow_add_gas = None
        active_agitator_on = None
        active_agitator_duty = None
        active_controller_actions: list[SchedulerControllerAction] = []
        if self._running and not self._paused and 0 <= self._current_step_index < len(self._steps):
            step = self._steps[self._current_step_index]
            current_name = self._step_display_name(self._current_step_index)
            if self._step_started_monotonic is None:
                self._step_started_monotonic = now
            current_elapsed = max(0.0, now - self._step_started_monotonic)
            active_controller_actions = self._active_controller_actions_for_step(snapshot, step, current_elapsed)
            active_temp, active_press, active_allow_add_gas, active_agitator_on, active_agitator_duty = self._legacy_targets_from_actions(active_controller_actions)
            met, waiting_reason = self._condition_met(snapshot, step)
            if met:
                if step.require_confirmation:
                    if not self._awaiting_confirmation:
                        self._awaiting_confirmation = True
                        self._confirmation_message = step.confirmation_message.strip() or f'Confirm before advancing from {current_name}'
                        self._last_transition = f'Waiting for confirmation at {current_name}'
                    waiting_reason = self._confirmation_message
                else:
                    nxt = self._next_enabled_step_index(self._current_step_index)
                    if nxt >= 0:
                        self._activate_step(nxt)
                        step = self._steps[self._current_step_index]
                        current_name = self._step_display_name(self._current_step_index)
                        active_controller_actions = self._active_controller_actions_for_step(snapshot, step, 0.0)
                        active_temp, active_press, active_allow_add_gas, active_agitator_on, active_agitator_duty = self._legacy_targets_from_actions(active_controller_actions)
                        waiting_reason = f'Entered {current_name}'
                        current_elapsed = 0.0
                    else:
                        self._running = False
                        self._paused = False
                        self._awaiting_confirmation = False
                        self._confirmation_message = ''
                        self._last_transition = f'Completed schedule at {current_name}'
                        waiting_reason = 'Schedule complete'
            elif self._awaiting_confirmation:
                self._awaiting_confirmation = False
                self._confirmation_message = ''
        elif self._running and self._paused:
            waiting_reason = 'Paused'
            if 0 <= self._current_step_index < len(self._steps):
                step = self._steps[self._current_step_index]
                current_name = self._step_display_name(self._current_step_index)
                if self._step_started_monotonic is not None:
                    current_elapsed = max(0.0, now - self._step_started_monotonic)
                active_controller_actions = self._active_controller_actions_for_step(snapshot, step, current_elapsed)
            active_temp, active_press, active_allow_add_gas, active_agitator_on, active_agitator_duty = self._legacy_targets_from_actions(active_controller_actions)
        else:
            waiting_reason = 'Stopped' if loaded else 'No schedule loaded'

        hold_elapsed = max(0.0, now - self._hold_started_monotonic) if self._hold_started_monotonic is not None else 0.0
        return {
            'running': self._running,
            'paused': self._paused,
            'current_step_index': self._current_step_index,
            'current_step_name': current_name,
            'current_step_started_at_monotonic': self._step_started_monotonic,
            'current_step_elapsed_s': current_elapsed,
            'waiting_reason': waiting_reason,
            'last_transition': self._last_transition,
            'hold_elapsed_s': hold_elapsed,
            'schedule_loaded': loaded,
            'awaiting_confirmation': self._awaiting_confirmation,
            'confirmation_message': self._confirmation_message,
            'active_temperature_setpoint': active_temp,
            'active_pressure_setpoint': active_press,
            'active_allow_add_gas': active_allow_add_gas,
            'active_agitator_on': active_agitator_on,
            'active_agitator_duty_cycle': active_agitator_duty,
            'active_controller_actions': active_controller_actions,
            'steps': self.steps,
            'sheet_names': self.sheet_names,
            'workbook_path': self._workbook_path,
            'sheet_name': self._sheet_name,
        }
