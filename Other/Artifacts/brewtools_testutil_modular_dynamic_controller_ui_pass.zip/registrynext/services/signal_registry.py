from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from state import AppState


@dataclass
class SignalRecord:
    key: str
    label: str
    value: Any
    quality: str = "GOOD"
    unit: str = ""


def make_signal_key(kind: str, *parts: object) -> str:
    return ':'.join([kind, *[str(p) for p in parts]])


_active_service = None


def configure_signal_registry_service(service) -> None:
    global _active_service
    _active_service = service


def build_signal_registry(snapshot: AppState):
    if _active_service is None:
        return []
    return _active_service.build_signal_registry(snapshot)


def signal_lookup(snapshot: AppState):
    if _active_service is None:
        return {}
    return _active_service.signal_lookup(snapshot)
