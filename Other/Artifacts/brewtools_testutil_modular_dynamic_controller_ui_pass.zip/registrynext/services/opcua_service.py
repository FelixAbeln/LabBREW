from __future__ import annotations

import math
import threading
import time
from typing import Any, Dict, Optional, Tuple

try:  # Preferred modern implementation
    from asyncua.sync import Server  # type: ignore
    _BACKEND = 'asyncua'
except Exception:  # pragma: no cover
    try:  # Legacy fallback if the project already uses python-opcua
        from opcua import Server  # type: ignore
        _BACKEND = 'python-opcua'
    except Exception:  # pragma: no cover
        Server = None  # type: ignore
        _BACKEND = 'missing'

from helpers import format_node_type
from state import AppState, DeviceState

DeviceKey = Tuple[int, int]


class OPCUAService:
    def __init__(
        self,
        endpoint: str = 'opc.tcp://0.0.0.0:4840/brewtools/',
        namespace_uri: str = 'urn:brewtools:testutil',
        server_name: str = 'Brewtools CAN Test Utility',
    ) -> None:
        self.endpoint = endpoint
        self.namespace_uri = namespace_uri
        self.server_name = server_name

        self._server = None
        self._idx: Optional[int] = None
        self._root = None
        self._system = None
        self._devices = None
        self._system_nodes: Dict[str, Any] = {}
        self._device_nodes: Dict[DeviceKey, Dict[str, Any]] = {}
        self._started = False
        self._lock = threading.RLock()

    @property
    def backend_name(self) -> str:
        return _BACKEND

    @property
    def is_available(self) -> bool:
        return Server is not None

    @property
    def is_running(self) -> bool:
        return self._started

    def start(self) -> None:
        with self._lock:
            if self._started:
                return
            if Server is None:
                raise RuntimeError(
                    'OPC UA backend not installed. Install with: pip install asyncua'
                )

            self._server = Server()
            self._server.set_endpoint(self.endpoint)
            self._server.set_server_name(self.server_name)
            self._idx = self._server.register_namespace(self.namespace_uri)

            objects = self._server.nodes.objects
            self._root = objects.add_object(self._idx, 'Brewtools')
            self._system = self._root.add_object(self._idx, 'System')
            self._devices = self._root.add_object(self._idx, 'Devices')

            self._system_nodes = {
                'CANConnected': self._system.add_variable(self._idx, 'CANConnected', False),
                'CANChannel': self._system.add_variable(self._idx, 'CANChannel', ''),
                'CANBitrate': self._system.add_variable(self._idx, 'CANBitrate', 0),
                'PSUPort': self._system.add_variable(self._idx, 'PSUPort', ''),
                'PSUPowerOn': self._system.add_variable(self._idx, 'PSUPowerOn', False),
                'PSUSetVoltage': self._system.add_variable(self._idx, 'PSUSetVoltage', 0.0),
                'PSUMeasuredVoltage': self._system.add_variable(self._idx, 'PSUMeasuredVoltage', float('nan')),
                'PSUMeasuredCurrent': self._system.add_variable(self._idx, 'PSUMeasuredCurrent', float('nan')),
                'LastStatusMessage': self._system.add_variable(self._idx, 'LastStatusMessage', ''),
                'DeviceCount': self._system.add_variable(self._idx, 'DeviceCount', 0),
                'UnixTime': self._system.add_variable(self._idx, 'UnixTime', 0.0),
            }

            self._server.start()
            self._started = True

    def stop(self) -> None:
        with self._lock:
            if not self._started:
                return
            try:
                self._server.stop()
            finally:
                self._server = None
                self._idx = None
                self._root = None
                self._system = None
                self._devices = None
                self._system_nodes.clear()
                self._device_nodes.clear()
                self._started = False

    def publish_snapshot(self, snapshot: AppState) -> None:
        with self._lock:
            if not self._started:
                return

            self._set_node_value(self._system_nodes['CANConnected'], bool(snapshot.can_connected))
            self._set_node_value(self._system_nodes['CANChannel'], snapshot.can_channel_label or '')
            self._set_node_value(self._system_nodes['CANBitrate'], int(snapshot.can_bitrate))
            self._set_node_value(self._system_nodes['PSUPort'], snapshot.psu_port or '')
            self._set_node_value(self._system_nodes['PSUPowerOn'], bool(snapshot.psu_power_on))
            self._set_node_value(self._system_nodes['PSUSetVoltage'], float(snapshot.psu_set_voltage))
            self._set_node_value(self._system_nodes['PSUMeasuredVoltage'], self._float_or_nan(snapshot.psu_measured_voltage))
            self._set_node_value(self._system_nodes['PSUMeasuredCurrent'], self._float_or_nan(snapshot.psu_measured_current))
            self._set_node_value(self._system_nodes['LastStatusMessage'], snapshot.last_status_message or '')
            self._set_node_value(self._system_nodes['DeviceCount'], len(snapshot.devices))
            self._set_node_value(self._system_nodes['UnixTime'], time.time())

            for key, dev in snapshot.devices.items():
                nodes = self._ensure_device_nodes(key, dev)
                status = self._device_status(time.time() - dev.last_seen)
                self._set_node_value(nodes['DeviceType'], format_node_type(dev.sender_node_type))
                self._set_node_value(nodes['NodeId'], int(dev.node_id))
                self._set_node_value(nodes['Status'], status)
                self._set_node_value(nodes['LastSeenEpoch'], float(dev.last_seen))
                self._set_node_value(nodes['LastSeenIso'], time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(dev.last_seen)))
                self._set_node_value(nodes['Temperature_C'], self._float_or_nan(dev.temperature))
                self._set_node_value(nodes['Pressure_bar'], self._float_or_nan(dev.pressure))
                self._set_node_value(nodes['Density'], self._float_or_nan(dev.density))
                self._set_node_value(nodes['Level'], self._float_or_nan(dev.level))
                self._set_node_value(nodes['RPM'], self._float_or_nan(dev.rpm))
                self._set_node_value(nodes['Min'], self._float_or_nan(dev.min_val))
                self._set_node_value(nodes['Max'], self._float_or_nan(dev.max_val))
                self._set_node_value(nodes['Measurements'], self._format_measurements(dev))

    def _ensure_device_nodes(self, key: DeviceKey, dev: DeviceState) -> Dict[str, Any]:
        nodes = self._device_nodes.get(key)
        if nodes is not None:
            return nodes
        if self._devices is None or self._idx is None:
            raise RuntimeError('OPC UA server folders are not initialized')

        folder_name = self._device_folder_name(dev)
        folder = self._devices.add_object(self._idx, folder_name)
        nodes = {
            'folder': folder,
            'DeviceType': folder.add_variable(self._idx, 'DeviceType', format_node_type(dev.sender_node_type)),
            'NodeId': folder.add_variable(self._idx, 'NodeId', int(dev.node_id)),
            'Status': folder.add_variable(self._idx, 'Status', 'Unknown'),
            'LastSeenEpoch': folder.add_variable(self._idx, 'LastSeenEpoch', 0.0),
            'LastSeenIso': folder.add_variable(self._idx, 'LastSeenIso', ''),
            'Temperature_C': folder.add_variable(self._idx, 'Temperature_C', float('nan')),
            'Pressure_bar': folder.add_variable(self._idx, 'Pressure_bar', float('nan')),
            'Density': folder.add_variable(self._idx, 'Density', float('nan')),
            'Level': folder.add_variable(self._idx, 'Level', float('nan')),
            'RPM': folder.add_variable(self._idx, 'RPM', float('nan')),
            'Min': folder.add_variable(self._idx, 'Min', float('nan')),
            'Max': folder.add_variable(self._idx, 'Max', float('nan')),
            'Measurements': folder.add_variable(self._idx, 'Measurements', ''),
        }
        self._device_nodes[key] = nodes
        return nodes

    @staticmethod
    def _set_node_value(node: Any, value: Any) -> None:
        node.set_value(value)

    @staticmethod
    def _float_or_nan(value: Optional[float]) -> float:
        if value is None:
            return float('nan')
        try:
            return float(value)
        except Exception:
            return float('nan')

    @staticmethod
    def _device_status(age_s: float) -> str:
        if age_s <= 3.0:
            return 'Online'
        if age_s <= 10.0:
            return 'Idle'
        return 'Stale'

    @staticmethod
    def _device_folder_name(dev: DeviceState) -> str:
        base = format_node_type(dev.sender_node_type).replace(' ', '_')
        return f'{base}_{dev.node_id}'

    @staticmethod
    def _format_measurements(dev: DeviceState) -> str:
        parts = []
        if dev.pressure is not None and not math.isnan(dev.pressure):
            parts.append(f'Pressure {dev.pressure:.3f} bar')
        if dev.density is not None and not math.isnan(dev.density):
            parts.append(f'Density {dev.density:.6f}')
        if dev.temperature is not None and not math.isnan(dev.temperature):
            parts.append(f'Temp {dev.temperature:.1f} C')
        if dev.level is not None and not math.isnan(dev.level):
            parts.append(f'Level {dev.level:.3f}')
        if dev.rpm is not None and not math.isnan(dev.rpm):
            parts.append(f'RPM {dev.rpm:.1f}')
        if dev.min_val is not None and not math.isnan(dev.min_val):
            parts.append(f'Min {dev.min_val:.3f}')
        if dev.max_val is not None and not math.isnan(dev.max_val):
            parts.append(f'Max {dev.max_val:.3f}')
        return ' | '.join(parts) if parts else ''
