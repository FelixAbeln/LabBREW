from __future__ import annotations

import json
from dataclasses import dataclass
from urllib import request

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QComboBox,
)

from .template_exporter import ScheduleTemplateExporter, TemplateExportOptions


@dataclass(slots=True)
class ApiClient:
    base_url: str

    def get(self, path: str) -> dict:
        with request.urlopen(f"{self.base_url}{path}", timeout=3.0) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def post(self, path: str, payload: dict | None = None) -> dict:
        data = json.dumps(payload or {}).encode("utf-8")
        req = request.Request(f"{self.base_url}{path}", data=data, headers={"Content-Type": "application/json"}, method="POST")
        with request.urlopen(req, timeout=5.0) as resp:
            return json.loads(resp.read().decode("utf-8"))


class MainWindow(QMainWindow):
    GREEN = "#1f9d55"
    GREEN_BRIGHT = "#22c55e"
    YELLOW = "#eab308"
    BLUE = "#2563eb"
    RED = "#dc2626"
    GRAY = "#6b7280"

    def __init__(self, api: ApiClient) -> None:
        super().__init__()
        self.api = api
        self.template_exporter = ScheduleTemplateExporter()
        self._primary_mode = "start"
        self._blink_on = False
        self._last_status: dict = {}

        self.setWindowTitle("FCS Scheduler Client")
        root = QWidget()
        layout = QVBoxLayout(root)

        top_group = QGroupBox("Workbook")
        top = QGridLayout(top_group)
        self.workbook_path = QLineEdit()
        self.btn_browse = QPushButton("Browse…")
        self.btn_load = QPushButton("Load workbook")
        self.template_mode = QComboBox()
        self.template_mode.addItems(["Blank template", "Test routine template"])
        self.btn_export_template = QPushButton("Export template")
        top.addWidget(QLabel("Workbook"), 0, 0)
        top.addWidget(self.workbook_path, 0, 1)
        top.addWidget(self.btn_browse, 0, 2)
        top.addWidget(self.btn_load, 0, 3)
        top.addWidget(QLabel("Template mode"), 1, 0)
        top.addWidget(self.template_mode, 1, 1)
        top.addWidget(self.btn_export_template, 1, 2, 1, 2)
        top.setColumnStretch(1, 1)
        layout.addWidget(top_group)

        ctrl = QHBoxLayout()
        self.btn_primary = QPushButton("Start")
        self.btn_stop = QPushButton("Stop")
        self.btn_prev = QPushButton("Previous")
        self.btn_next = QPushButton("Next")
        for btn in [self.btn_primary, self.btn_stop, self.btn_prev, self.btn_next]:
            ctrl.addWidget(btn)
        layout.addLayout(ctrl)

        self.confirm_banner = QLabel("")
        self.confirm_banner.setVisible(False)
        self.confirm_banner.setWordWrap(True)
        self.confirm_banner.setAlignment(Qt.AlignCenter)
        self.confirm_banner.setStyleSheet(
            "QLabel { background: #ecfdf5; color: #166534; border: 2px solid #22c55e; "
            "border-radius: 8px; padding: 10px; font-weight: 600; }"
        )
        layout.addWidget(self.confirm_banner)

        status_group = QGroupBox("Runtime status")
        status_form = QFormLayout(status_group)
        self.state_lbl = QLabel("—")
        self.phase_lbl = QLabel("—")
        self.step_lbl = QLabel("—")
        self.elapsed_lbl = QLabel("—")
        self.hold_lbl = QLabel("—")
        self.wait_lbl = QLabel("—")
        self.confirm_lbl = QLabel("—")
        self.transition_lbl = QLabel("—")
        status_form.addRow("State", self.state_lbl)
        status_form.addRow("Phase", self.phase_lbl)
        status_form.addRow("Current step", self.step_lbl)
        status_form.addRow("Step elapsed", self.elapsed_lbl)
        status_form.addRow("Hold elapsed", self.hold_lbl)
        status_form.addRow("Waiting", self.wait_lbl)
        status_form.addRow("Confirmation", self.confirm_lbl)
        status_form.addRow("Last transition", self.transition_lbl)
        layout.addWidget(status_group)

        self.tabs = QTabWidget()
        self.startup_table = QTableWidget(0, 8)
        self.startup_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.plan_table = QTableWidget(0, 8)
        self.plan_table.setHorizontalHeaderLabels(["#", "Enabled", "Name", "Actions", "Wait", "Source", "Criteria", "Confirm"])
        self.tabs.addTab(self.startup_table, "StartupRoutine")
        self.tabs.addTab(self.plan_table, "Plan")
        layout.addWidget(self.tabs)

        self.events = QTextEdit()
        self.events.setReadOnly(True)
        layout.addWidget(self.events)

        self.setCentralWidget(root)
        self._wire()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_status)
        self.timer.start(1000)

        self.blink_timer = QTimer(self)
        self.blink_timer.timeout.connect(self._toggle_confirm_blink)
        self.blink_timer.start(500)

        self.refresh_status()

    def _wire(self) -> None:
        self.btn_browse.clicked.connect(self.browse_workbook)
        self.btn_load.clicked.connect(self.load_schedule)
        self.btn_export_template.clicked.connect(self.export_template)
        self.btn_primary.clicked.connect(self._handle_primary_button)
        self.btn_stop.clicked.connect(lambda: self._post("/run/stop"))
        self.btn_prev.clicked.connect(lambda: self._post("/run/previous"))
        self.btn_next.clicked.connect(lambda: self._post("/run/next"))

    def browse_workbook(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select schedule workbook", self.workbook_path.text().strip(), "Excel Workbook (*.xlsx *.xlsm)")
        if path:
            self.workbook_path.setText(path)

    def export_template(self) -> None:
        suggested_name = "fcs_test_routine_template.xlsx" if self.template_mode.currentIndex() == 1 else "fcs_schedule_template.xlsx"
        path, _ = QFileDialog.getSaveFileName(self, "Export schedule template", suggested_name, "Excel Workbook (*.xlsx)")
        if not path:
            return
        try:
            options = TemplateExportOptions(include_examples=True, include_test_routine=self.template_mode.currentIndex() == 1)
            exported = self.template_exporter.export(path, options)
            self.workbook_path.setText(str(exported))
            QMessageBox.information(self, "Template exported", f"Template written to:\n{exported}")
            QMessageBox.information(self, "Template exported", f"Template written to:\n{exported}")
        except Exception as exc:
            QMessageBox.critical(self, "Template export failed", str(exc))

    def load_schedule(self) -> None:
        self._post("/schedule/load", {"workbook_path": self.workbook_path.text().strip()}, refresh=True)

    def refresh_status(self) -> None:
        try:
            status = self.api.get("/status")
            self._last_status = status
        except Exception as exc:
            self.state_lbl.setText(f"Disconnected ({exc})")
            self.confirm_banner.setVisible(False)
            self._set_primary_button(mode="start", enabled=False)
            return

        self.state_lbl.setText(str(status.get("state", "—")))
        self.phase_lbl.setText(str(status.get("phase", "—")))
        idx = status.get("current_step_index", -1)
        name = status.get("current_step_name", "")
        self.step_lbl.setText(f"{idx} | {name}")
        self.elapsed_lbl.setText(f"{float(status.get('step_elapsed_s', 0.0)):.1f} s")
        self.hold_lbl.setText(f"{float(status.get('hold_elapsed_s', 0.0)):.1f} s")
        self.wait_lbl.setText(str(status.get("wait_reason", "—")))
        self.confirm_lbl.setText(str(status.get("confirmation_message", "—")))
        self.transition_lbl.setText(str(status.get("last_transition", "—")))
        self._fill_table(self.startup_table, status.get("startup_steps", []))
        self._fill_table(self.plan_table, status.get("plan_steps", []))
        self.events.setPlainText("\n".join(status.get("event_log", [])))
        self._refresh_run_controls(status)

    def _refresh_run_controls(self, status: dict) -> None:
        state = str(status.get("state", "idle"))
        awaiting = bool(status.get("awaiting_confirmation", False))
        confirm_msg = str(status.get("confirmation_message", "") or "")

        if awaiting or state == "waiting_confirmation":
            message = confirm_msg or "Waiting for operator confirmation"
            self.confirm_banner.setText(message)
            self.confirm_banner.setVisible(True)
            self._set_primary_button(mode="confirm", enabled=True)
        else:
            self.confirm_banner.setVisible(False)
            if state == "paused":
                self._set_primary_button(mode="resume", enabled=True)
            elif state in {"running", "startup"}:
                self._set_primary_button(mode="pause", enabled=True)
            elif state in {"idle", "completed", "stopped"}:
                has_plan = bool(status.get("plan_steps"))
                self._set_primary_button(mode="start", enabled=has_plan)
            else:
                self._set_primary_button(mode="start", enabled=False)

        active = state in {"running", "startup", "paused", "waiting_confirmation"}
        self.btn_stop.setEnabled(active)
        self.btn_prev.setEnabled(active)
        self.btn_next.setEnabled(active)

    def _set_primary_button(self, *, mode: str, enabled: bool) -> None:
        if self._primary_mode != mode:
            self._blink_on = False
        self._primary_mode = mode
        self.btn_primary.setEnabled(enabled)

        if mode == "start":
            self.btn_primary.setText("Start")
            self._apply_button_style(self.btn_primary, self.GREEN)
        elif mode == "pause":
            self.btn_primary.setText("Pause")
            self._apply_button_style(self.btn_primary, self.BLUE)
        elif mode == "resume":
            self.btn_primary.setText("Resume")
            self._apply_button_style(self.btn_primary, self.YELLOW, text_color="#111827")
        elif mode == "confirm":
            self.btn_primary.setText("Confirm")
            color = self.GREEN_BRIGHT if self._blink_on else self.GREEN
            self._apply_button_style(self.btn_primary, color)
        else:
            self.btn_primary.setText("Action")
            self._apply_button_style(self.btn_primary, self.GRAY)

    def _toggle_confirm_blink(self) -> None:
        if self._primary_mode != "confirm":
            return
        self._blink_on = not self._blink_on
        self._set_primary_button(mode="confirm", enabled=self.btn_primary.isEnabled())

    def _apply_button_style(self, button: QPushButton, bg: str, *, text_color: str = "white") -> None:
        button.setStyleSheet(
            f"QPushButton {{ background-color: {bg}; color: {text_color}; border: none; border-radius: 8px; padding: 10px 18px; font-weight: 700; }}"
            "QPushButton:disabled { background-color: #d1d5db; color: #6b7280; }"
        )

    def _handle_primary_button(self) -> None:
        route = {
            "start": "/run/start",
            "pause": "/run/pause",
            "resume": "/run/resume",
            "confirm": "/run/confirm",
        }.get(self._primary_mode)
        if route:
            self._post(route)

    def _fill_table(self, table: QTableWidget, steps: list[dict]) -> None:
        table.setRowCount(len(steps))
        active_index = self._last_status.get("current_step_index", -1)
        active_phase = self._last_status.get("phase", "")
        table_phase = "startup" if table is self.startup_table else "plan"
        for row, step in enumerate(steps):
            actions = "; ".join(action.get("display_text", "") for action in step.get("controller_actions", []))
            criteria = self._criteria_text(step)
            values = [
                step.get("index", row),
                step.get("enabled", True),
                step.get("name", ""),
                actions,
                step.get("wait_type", ""),
                step.get("wait_source", ""),
                criteria,
                step.get("confirmation_message", "") or step.get("require_confirmation", False),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if active_phase == table_phase and step.get("index", row) == active_index:
                    item.setBackground(Qt.yellow)
                table.setItem(row, col, item)
        table.resizeColumnsToContents()

    def _criteria_text(self, step: dict) -> str:
        wait_type = step.get("wait_type", "")
        if wait_type == "signal":
            operator = step.get("operator", "")
            if operator in {"in_range", "out_of_range"}:
                return f"{operator} [{step.get('threshold_low', '')}, {step.get('threshold_high', '')}] hold={step.get('hold_for_s', 0)}s"
            return f"{operator} {step.get('threshold', '')} hold={step.get('hold_for_s', 0)}s"
        if wait_type == "all_valid":
            return f"{', '.join(step.get('valid_sources', []))} hold={step.get('hold_for_s', 0)}s"
        return f"{step.get('duration_s', 0)}s"

    def _post(self, path: str, payload: dict | None = None, *, refresh: bool = True) -> None:
        try:
            result = self.api.post(path, payload)
            if refresh:
                self.refresh_status()
            if not result.get("ok", True):
                QMessageBox.warning(self, "FCS service", str(result.get("message", "Unknown error")))
        except Exception as exc:
            QMessageBox.critical(self, "FCS service", str(exc))


def run_ui(base_url: str = "http://127.0.0.1:8769") -> int:
    app = QApplication([])
    window = MainWindow(ApiClient(base_url=base_url.rstrip("/")))
    window.resize(1280, 860)
    window.show()
    return app.exec()
