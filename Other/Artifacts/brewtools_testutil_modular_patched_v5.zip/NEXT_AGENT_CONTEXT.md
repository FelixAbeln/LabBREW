# Latest pass
- Enabled generic PID controllers to target CAN agitator nodes through the same `agitator_target:can:<node>` registry path used by the legacy agitator controller.
- Added PID output clamps (`output_min` / `output_max`) plus a base/start duty in the operator-defined controller dialog so operators can define actuator endstops instead of assuming full 0-100% travel.
- Removed relay/boolean targets from generic PID registration and UI exposure so PID no longer pretends to support on/off outputs.
- Updated runtime PID evaluation to require a CAN actuator target and clamp the commanded duty cycle before CAN transmit.

Why this helps:
- Operators can now use discovered CAN actuator nodes with generic PID without falling back to the dedicated agitator legacy flow.
- Min/max output behaves like configurable endstops, which is safer for actuators that should not run across the full duty-cycle range.
- Registry and UI are now more honest: deadband controllers can drive bool outputs, PID controllers drive numeric CAN outputs.

Still not fully fixed:
- The dedicated legacy agitator panel and runtime path still exist and overlap conceptually with generic PID + CAN actuator control.
- The operator-defined dialog is still a shared form; it is better than before, but controller-type-specific editors or plugin UIs are still the cleaner long-term direction.
- A central real-time signal store/module-owned UI model is still a good target architecture once legacy controller paths are trimmed further.

# Next agent context

## Current objective
Make controller inventory genuinely operator-defined. The UI should display and edit dynamic controller instances that the operator creates, instead of forcing the codebase to guess a fixed set of controllers.

## What was just fixed
- Restored `StateStore.set_scheduler_runtime()` in `state.py`.
- Audited all `state_store.set_*` call sites and verified there are no remaining missing setter methods on `StateStore`.
- Previous fix restoring `set_controller_instances()`, `set_safety_config()`, `set_safety_runtime()`, `set_twin_config()`, `set_twin_runtime()`, and `set_scheduler_config()` still stands.
- Dynamic-controller dialog still excludes legacy dedicated controllers: `temperature`, `pressure`, and `agitator`.

## Important current stance
- Dynamic inventory should be centered on generic controller types such as deadband / PI(PID).
- Agitator is **not** wanted as a dynamic controller type. Leave it on the dedicated legacy path until that whole path is either removed or intentionally reworked. Do not create new dynamic agitator flows.
- The recent startup errors were caused by incomplete `StateStore` surface restoration during refactor, not by the dynamic-controller concept itself.

## Verified baseline
- `state_store.set_*` call audit is clean: every referenced setter currently exists on `StateStore`.
- That means the next failures, if any, are more likely to be ordinary runtime/UI issues than another missing state API of the same pattern.

## Best next steps
1. Boot the app and confirm the controller inventory table is populated from `AppState.controller_instances` only.
2. Trace any UI code that still synthesizes a built-in controller list instead of querying configured controller instances.
3. Remove or isolate legacy built-in assumptions where safe, especially around control-panel composition, query adapters, and refresh flows.
4. Keep updating `REFACTOR_STATUS.md` after each pass so the migration trail stays readable.

## Watch-outs
- Scheduler compatibility still has legacy temperature/pressure/agitator columns. That is okay for now; avoid breaking workbook loading while cleaning up the live dynamic-controller path.
- Registry still contains dedicated controller definitions for legacy flows because some UI/runtime lookups depend on them. Excluding them from the operator-defined dialog is intentional for now.
- Prefer small traceable deletions over another wide refactor that leaves half-moved or duplicate state methods behind.

## 2026-03-17 incremental handoff
Startup was still failing after the `StateStore` setter restore because `services/runtime_service.py` had two more refactor holes: `_apply_dynamic_numeric_outputs()` and `_evaluate_dynamic_pid_instance()` were referenced but missing. Those are now restored.

### What was patched
- `AppRuntimeService._evaluate_dynamic_pid_instance(...)`
- `AppRuntimeService._apply_dynamic_numeric_outputs(...)`
- `AppRuntimeService.desired_relay_states(...)` now tolerates both legacy relay assignment keys and new `relay_assignment:*` keys, plus bool fallbacks from numeric outputs.

### What to check next
1. Remove remaining legacy relay assignment key drift so everything uses one canonical key shape end-to-end.
2. Decide whether generic PID should stay limited to duty-cycle style targets only; right now relay targets are treated as on/off when duty > 0.
3. Remove registry/UI/runtime remnants of the dedicated agitator controller once migration is complete.
4. Add a smoke test that instantiates `AppCore()` and verifies `evaluate_scheduler()` + `evaluate_controls()` run without missing-method crashes.


## 2026-03-17 patch
- Previous patch series fixed missing `StateStore` setters and runtime helpers, but the GUI still crashed because `gui/panels/control_panel.py` was truncated.
- This patch restores the operator-defined controller group and row actions so `ControlPanel` can build successfully.
- Next focus: remove remaining legacy built-in controller rendering/assumptions and make the dynamic inventory the primary UI path.
- Sanity checks already done: `python -m py_compile gui/panels/control_panel.py` and `python -m compileall -q .`.
