from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QLabel,
    QHBoxLayout,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from gui.panel_facades import ControlPanelFacade
from gui.widgets.band_indicator import BandIndicator


class ControlPanel(QWidget):
    def __init__(self, facade: ControlPanelFacade, parent: QWidget | None = None):
        super().__init__(parent)
        self.facade = facade
        layout = QVBoxLayout(self)
        expl = QLabel('Assign discovered channels to deadband controllers. Outputs stay virtual for now so they can later be mapped to relays, PLC tags, or OPC UA consumers.')
        expl.setWordWrap(True)
        layout.addWidget(expl)
        ctrl_grid = QGridLayout()
        ctrl_grid.addWidget(self._build_temperature_group(), 0, 0)
        ctrl_grid.addWidget(self._build_pressure_group(), 0, 1)
        ctrl_grid.addWidget(self._build_agitator_group(), 1, 0, 1, 2)
        ctrl_grid.setColumnStretch(0, 1)
        ctrl_grid.setColumnStretch(1, 1)
        layout.addLayout(ctrl_grid)
        io_group = QGroupBox('Virtual control outputs')
        io_layout = QGridLayout(io_group)
        self.lbl_heat = facade.make_output_badge('HEAT')
        self.lbl_cool = facade.make_output_badge('COOL')
        self.lbl_add_gas = facade.make_output_badge('ADD GAS')
        self.lbl_remove_gas = facade.make_output_badge('REMOVE GAS')
        self.lbl_agitator = facade.make_output_badge('AGITATOR')
        io_layout.addWidget(self.lbl_heat, 0, 0)
        io_layout.addWidget(self.lbl_cool, 0, 1)
        io_layout.addWidget(self.lbl_add_gas, 1, 0)
        io_layout.addWidget(self.lbl_remove_gas, 1, 1)
        io_layout.addWidget(self.lbl_agitator, 2, 0)
        layout.addWidget(io_group)
        layout.addWidget(self._build_dynamic_controllers_group())
        layout.addStretch(1)

    def _build_temperature_group(self) -> QGroupBox:
        group = QGroupBox('Temperature deadband controller')
        form = QFormLayout(group)
        self.temp_ctrl_enabled = QCheckBox('Enabled')
        self.temp_source_combo = QComboBox()
        self.temp_setpoint = QDoubleSpinBox()
        self.temp_setpoint.setRange(-50.0, 300.0)
        self.temp_setpoint.setDecimals(1)
        self.temp_setpoint.setSuffix(' °C')
        self.temp_deadband = QDoubleSpinBox()
        self.temp_deadband.setRange(0.1, 50.0)
        self.temp_deadband.setDecimals(1)
        self.temp_deadband.setSuffix(' °C')
        self.temp_pv = QLabel('—')
        self.temp_state = QLabel('Disabled')
        self.temp_band = BandIndicator()
        form.addRow('', self.temp_ctrl_enabled)
        form.addRow('Temperature source', self.temp_source_combo)
        form.addRow('Setpoint', self.temp_setpoint)
        form.addRow('Deadband', self.temp_deadband)
        form.addRow('Process value', self.temp_pv)
        form.addRow('Controller state', self.temp_state)
        form.addRow('Band', self.temp_band)
        return group

    def _build_pressure_group(self) -> QGroupBox:
        group = QGroupBox('Pressure deadband controller')
        form = QFormLayout(group)
        self.pressure_ctrl_enabled = QCheckBox('Enabled')
        self.pressure_source_combo = QComboBox()
        self.pressure_setpoint = QDoubleSpinBox()
        self.pressure_setpoint.setRange(0.0, 10.0)
        self.pressure_setpoint.setDecimals(3)
        self.pressure_setpoint.setSuffix(' bar')
        self.pressure_deadband = QDoubleSpinBox()
        self.pressure_deadband.setRange(0.001, 5.0)
        self.pressure_deadband.setDecimals(3)
        self.pressure_deadband.setSuffix(' bar')
        self.pressure_allow_add_gas = QCheckBox('Allow regulator to add gas')
        self.pressure_allow_add_gas.setChecked(True)
        self.pressure_pv = QLabel('—')
        self.pressure_state = QLabel('Disabled')
        self.pressure_band = BandIndicator()
        form.addRow('', self.pressure_ctrl_enabled)
        form.addRow('Pressure source', self.pressure_source_combo)
        form.addRow('Setpoint', self.pressure_setpoint)
        form.addRow('Deadband', self.pressure_deadband)
        form.addRow('', self.pressure_allow_add_gas)
        form.addRow('Process value', self.pressure_pv)
        form.addRow('Controller state', self.pressure_state)
        form.addRow('Band', self.pressure_band)
        return group

    def _build_agitator_group(self) -> QGroupBox:
        group = QGroupBox('Agitator control')
        form = QFormLayout(group)
        self.agitator_enabled = QCheckBox('Enabled')
        self.agitator_target_combo = QComboBox()
        self.agitator_target_combo.setEditable(False)
        self.agitator_on = QCheckBox('Run agitator')
        self.agitator_mode_lbl = QLabel('Output')
        self.agitator_control_mode = QComboBox()
        self.agitator_control_mode.addItem('Manual duty', 'manual')
        self.agitator_control_mode.addItem('Speed PID', 'pid')
        self.agitator_command_lbl = QLabel('Duty cycle')
        self.agitator_duty = QDoubleSpinBox()
        self.agitator_duty.setRange(0.0, 100.0)
        self.agitator_duty.setDecimals(1)
        self.agitator_duty.setSuffix(' %')
        self.agitator_duty.setValue(100.0)
        self.agitator_speed_setpoint = QDoubleSpinBox()
        self.agitator_speed_setpoint.setRange(0.0, 5000.0)
        self.agitator_speed_setpoint.setDecimals(1)
        self.agitator_speed_setpoint.setSuffix(' rpm')
        self.agitator_speed_setpoint.setValue(120.0)
        self.agitator_pid_kp = QDoubleSpinBox(); self.agitator_pid_kp.setRange(0.0, 10.0); self.agitator_pid_kp.setDecimals(3); self.agitator_pid_kp.setSingleStep(0.01); self.agitator_pid_kp.setValue(0.30)
        self.agitator_pid_ki = QDoubleSpinBox(); self.agitator_pid_ki.setRange(0.0, 10.0); self.agitator_pid_ki.setDecimals(3); self.agitator_pid_ki.setSingleStep(0.01); self.agitator_pid_ki.setValue(0.05)
        self.agitator_pid_kd = QDoubleSpinBox(); self.agitator_pid_kd.setRange(0.0, 10.0); self.agitator_pid_kd.setDecimals(3); self.agitator_pid_kd.setSingleStep(0.01); self.agitator_pid_kd.setValue(0.00)
        self.agitator_rpm = QLabel('—')
        self.agitator_commanded = QLabel('—')
        self.agitator_state = QLabel('Disabled')
        form.addRow('', self.agitator_enabled)
        form.addRow(self.agitator_mode_lbl, self.agitator_target_combo)
        form.addRow('', self.agitator_on)
        form.addRow('Control mode', self.agitator_control_mode)
        form.addRow(self.agitator_command_lbl, self.agitator_duty)
        form.addRow('Speed setpoint', self.agitator_speed_setpoint)
        form.addRow('PID Kp', self.agitator_pid_kp)
        form.addRow('PID Ki', self.agitator_pid_ki)
        form.addRow('PID Kd', self.agitator_pid_kd)
        form.addRow('Speed feedback', self.agitator_rpm)
        form.addRow('Commanded duty', self.agitator_commanded)
        form.addRow('State', self.agitator_state)
        return group


    def apply_scheduler_targets(
        self,
        temp_sp: float | None,
        pressure_sp: float | None,
        allow_add_gas: bool | None = None,
        agitator_on: bool | None = None,
        agitator_duty: float | None = None,
    ) -> bool:
        changed = False
        if temp_sp is not None and abs(self.temp_setpoint.value() - float(temp_sp)) > 1e-9:
            self.temp_setpoint.setValue(float(temp_sp))
            changed = True
        if pressure_sp is not None and abs(self.pressure_setpoint.value() - float(pressure_sp)) > 1e-9:
            self.pressure_setpoint.setValue(float(pressure_sp))
            changed = True
        if allow_add_gas is not None and self.pressure_allow_add_gas.isChecked() != bool(allow_add_gas):
            self.pressure_allow_add_gas.setChecked(bool(allow_add_gas))
            changed = True
        if agitator_on is not None and self.agitator_on.isChecked() != bool(agitator_on):
            self.agitator_on.setChecked(bool(agitator_on))
            changed = True
        if agitator_duty is not None and abs(self.agitator_duty.value() - float(agitator_duty)) > 1e-9:
            self.agitator_duty.setValue(float(agitator_duty))
            changed = True
        return changed

    def wire_signals(self) -> None:
        self.temp_ctrl_enabled.toggled.connect(self.facade.save_settings)
        self.temp_source_combo.currentIndexChanged.connect(self._on_temp_source_changed)
        self.temp_source_combo.currentIndexChanged.connect(self.facade.save_settings)
        self.temp_setpoint.valueChanged.connect(self.facade.save_settings)
        self.temp_deadband.valueChanged.connect(self.facade.save_settings)
        self.pressure_ctrl_enabled.toggled.connect(self.facade.save_settings)
        self.pressure_source_combo.currentIndexChanged.connect(self._on_pressure_source_changed)
        self.pressure_source_combo.currentIndexChanged.connect(self.facade.save_settings)
        self.pressure_setpoint.valueChanged.connect(self.facade.save_settings)
        self.pressure_deadband.valueChanged.connect(self.facade.save_settings)
        self.pressure_allow_add_gas.toggled.connect(self.facade.save_settings)

        self.agitator_enabled.toggled.connect(self.refresh_agitator_control_ui)
        self.agitator_enabled.toggled.connect(self.facade.save_settings)
        self.agitator_target_combo.currentIndexChanged.connect(self.refresh_agitator_control_ui)
        self.agitator_target_combo.currentIndexChanged.connect(self.facade.save_settings)
        self.agitator_on.toggled.connect(self.refresh_agitator_control_ui)
        self.agitator_on.toggled.connect(self.facade.save_settings)
        self.agitator_control_mode.currentIndexChanged.connect(self.refresh_agitator_control_ui)
        self.agitator_control_mode.currentIndexChanged.connect(self.facade.save_settings)
        self.agitator_duty.valueChanged.connect(self.facade.save_settings)
        self.agitator_speed_setpoint.valueChanged.connect(self.facade.save_settings)
        self.agitator_pid_kp.valueChanged.connect(self.facade.save_settings)
        self.agitator_pid_ki.valueChanged.connect(self.facade.save_settings)
        self.agitator_pid_kd.valueChanged.connect(self.facade.save_settings)
        self.btn_add_controller.clicked.connect(self.facade.open_add_controller_dialog)
        self.btn_edit_controller.clicked.connect(self._on_edit_dynamic_controller)
        self.btn_remove_controller.clicked.connect(self._on_remove_dynamic_controller)

    def _on_temp_source_changed(self, *args) -> None:
        if self.facade.ui_state.control_combo_sync_block:
            return
        self.facade.ui_state.set_pending_temp_source_key(self.facade.normalize_signal_key(self.temp_source_combo.currentData()))

    def _on_pressure_source_changed(self, *args) -> None:
        if self.facade.ui_state.control_combo_sync_block:
            return
        self.facade.ui_state.set_pending_pressure_source_key(self.facade.normalize_signal_key(self.pressure_source_combo.currentData()))

    def refresh_agitator_control_ui(self, *args) -> None:
        target = str(self.agitator_target_combo.currentData() or self.facade.get_agitator_target() or 'relay')
        is_can = target.startswith('can:')
        enabled = self.agitator_enabled.isChecked()
        mode = str(self.agitator_control_mode.currentData() or 'manual')
        if not is_can and mode == 'pid':
            self.agitator_control_mode.blockSignals(True)
            self.agitator_control_mode.setCurrentIndex(self.agitator_control_mode.findData('manual'))
            self.agitator_control_mode.blockSignals(False)
            mode = 'manual'
        self.agitator_mode_lbl.setText('Output')
        self.agitator_control_mode.setEnabled(enabled and is_can)
        pid_active = enabled and is_can and mode == 'pid'
        self.agitator_command_lbl.setText('Duty cycle' if not pid_active else 'Base/start duty')
        self.agitator_duty.setEnabled(enabled and is_can)
        self.agitator_speed_setpoint.setEnabled(pid_active)
        self.agitator_pid_kp.setEnabled(pid_active)
        self.agitator_pid_ki.setEnabled(pid_active)
        self.agitator_pid_kd.setEnabled(pid_active)
        if pid_active:
            self.agitator_duty.setToolTip('PID mode uses this as the base/start duty and then trims around it.')
            self.agitator_speed_setpoint.setToolTip('PID mode will drive duty cycle toward this RPM setpoint.')
        elif is_can:
            self.agitator_duty.setToolTip('CAN agitator mode uses duty cycle percent as the command.')
        else:
            self.agitator_duty.setToolTip('Relay agitator mode is simple on/off. Duty cycle and PID are ignored.')

    def _build_dynamic_controllers_group(self) -> QGroupBox:
        group = QGroupBox('Operator-defined controllers')
        layout = QVBoxLayout(group)
        desc = QLabel('Create PI or deadband controller instances from discovered signals and available output targets. The table reflects the live controller inventory from state.')
        desc.setWordWrap(True)
        layout.addWidget(desc)
        self.dynamic_controller_table = QTableWidget(0, 9)
        self.dynamic_controller_table.setHorizontalHeaderLabels([
            'Label', 'Type', 'Enabled', 'Source', 'Target', 'Setpoint', 'Deadband', 'Ramp/s', 'Extra'
        ])
        self.dynamic_controller_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.dynamic_controller_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.dynamic_controller_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.dynamic_controller_table.verticalHeader().setVisible(False)
        self.dynamic_controller_table.setAlternatingRowColors(True)
        layout.addWidget(self.dynamic_controller_table)

        btn_row = QHBoxLayout()
        self.btn_add_controller = QPushButton('Add controller')
        self.btn_edit_controller = QPushButton('Edit selected')
        self.btn_remove_controller = QPushButton('Remove selected')
        btn_row.addWidget(self.btn_add_controller)
        btn_row.addWidget(self.btn_edit_controller)
        btn_row.addWidget(self.btn_remove_controller)
        btn_row.addStretch(1)
        layout.addLayout(btn_row)
        return group

    def _selected_dynamic_controller_id(self) -> str:
        table = getattr(self, 'dynamic_controller_table', None)
        if table is None:
            return ''
        row = table.currentRow()
        if row < 0:
            return ''
        item = table.item(row, 0)
        return str(item.data(0x0100) or '') if item is not None else ''

    def _on_edit_dynamic_controller(self) -> None:
        instance_id = self._selected_dynamic_controller_id()
        if instance_id:
            self.facade.open_edit_controller_dialog(instance_id)

    def _on_remove_dynamic_controller(self) -> None:
        instance_id = self._selected_dynamic_controller_id()
        if instance_id:
            self.facade.remove_controller(instance_id)

    def refresh_dynamic_controller_table(self, rows) -> None:
        table = getattr(self, 'dynamic_controller_table', None)
        if table is None:
            return
        rows = list(rows or [])
        selected_id = self._selected_dynamic_controller_id()
        table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            values = [
                str(getattr(row, 'label', '') or ''),
                str(getattr(row, 'controller_key', '') or getattr(row, 'kind', '') or ''),
                'Yes' if bool(getattr(row, 'enabled', False)) else 'No',
                str(getattr(row, 'source_key', '') or ''),
                str(getattr(row, 'target_key', '') or ''),
                self._format_number(getattr(row, 'setpoint', None), getattr(row, 'unit', '') or ''),
                self._format_number(getattr(row, 'deadband', None), getattr(row, 'unit', '') or ''),
                self._format_number(getattr(row, 'ramp_per_s', None), ''),
                str(getattr(row, 'extra_summary', '') or ''),
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(value)
                if c == 0:
                    item.setData(0x0100, str(getattr(row, 'id', '') or ''))
                table.setItem(r, c, item)
        table.resizeColumnsToContents()
        if selected_id:
            for r, row in enumerate(rows):
                if str(getattr(row, 'id', '') or '') == selected_id:
                    table.selectRow(r)
                    break
        self.btn_edit_controller.setEnabled(bool(rows))
        self.btn_remove_controller.setEnabled(bool(rows))

    @staticmethod
    def _format_number(value, unit: str = '') -> str:
        if value is None:
            return '—'
        try:
            num = float(value)
        except Exception:
            return str(value)
        if abs(num) >= 100 or float(num).is_integer():
            text = f'{num:.0f}'
        elif abs(num) >= 10:
            text = f'{num:.1f}'
        else:
            text = f'{num:.3f}'.rstrip('0').rstrip('.')
        return f'{text} {unit}'.rstrip()
