
from __future__ import annotations

from dataclasses import asdict
import uuid

from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout,
    QHBoxLayout, QLineEdit, QMessageBox, QVBoxLayout
)

from application.config_models import ControllerInstanceConfigModel

LEGACY_CONTROLLER_KEYS = {'temperature', 'pressure', 'agitator'}


class ControllerInventoryController:
    def __init__(self, window):
        self.window = window

    def _signal_options(self, controller_key: str):
        definition = self.window.queries.controller_definitions()
        selected = next((d for d in definition if d.key == controller_key), None)
        families = set(getattr(selected, 'source_families', ()) or ())
        opts = []
        for rec in self.window.queries.signal_records():
            family = str(rec.key).partition(':')[0]
            if not families or family in families:
                opts.append((rec.label, rec.key))
        return opts

    def _target_options(self, controller_key: str):
        return [(rec.label, rec.key) for rec in self.window.queries.output_targets_for_controller(controller_key)]

    def open_add_dialog(self) -> None:
        dlg = _ControllerInstanceDialog(self.window, self.window.queries, None)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            result = self.window.commands.add_controller_instance(dlg.to_model(), persist=True)
            self.window.commands.set_status_message(result.message)
            self.window.core.apply_settings(self.window.core.settings)

    def open_edit_dialog(self, instance_id: str) -> None:
        current = next((c for c in self.window.queries.configured_controllers() if c.id == instance_id), None)
        if current is None:
            self.window.commands.set_status_message(f"Controller '{instance_id}' was not found.")
            return
        dlg = _ControllerInstanceDialog(self.window, self.window.queries, current)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            result = self.window.commands.update_controller_instance(dlg.to_model(instance_id=current.id), persist=True)
            self.window.commands.set_status_message(result.message)
            self.window.core.apply_settings(self.window.core.settings)

    def remove_instance(self, instance_id: str) -> None:
        answer = QMessageBox.question(self.window, 'Remove controller', f"Remove controller '{instance_id}'?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        result = self.window.commands.remove_controller_instance(instance_id, persist=True)
        self.window.commands.set_status_message(result.message)
        self.window.core.apply_settings(self.window.core.settings)


class _ControllerInstanceDialog(QDialog):
    def __init__(self, parent, queries, current):
        super().__init__(parent)
        self.setWindowTitle('Operator-defined controller')
        self.queries = queries
        self.current = current
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.enabled = QCheckBox('Enabled')
        self.kind = QComboBox()
        for item in self.queries.controller_definitions():
            if item.key in LEGACY_CONTROLLER_KEYS:
                continue
            self.kind.addItem(f"{item.label} ({item.kind})", item.key)
        self.label = QLineEdit()
        self.source = QComboBox()
        self.target = QComboBox()
        self.setpoint = QDoubleSpinBox(); self.setpoint.setRange(-100000, 100000); self.setpoint.setDecimals(3)
        self.deadband = QDoubleSpinBox(); self.deadband.setRange(0, 100000); self.deadband.setDecimals(3)
        self.ramp = QDoubleSpinBox(); self.ramp.setRange(0, 100000); self.ramp.setDecimals(4); self.ramp.setSpecialValueText('Instant'); self.ramp.setValue(0.0)
        self.kp = QDoubleSpinBox(); self.kp.setRange(0, 1000); self.kp.setDecimals(3); self.kp.setValue(0.30)
        self.ki = QDoubleSpinBox(); self.ki.setRange(0, 1000); self.ki.setDecimals(3); self.ki.setValue(0.05)
        self.kd = QDoubleSpinBox(); self.kd.setRange(0, 1000); self.kd.setDecimals(3); self.kd.setValue(0.00)
        self.min_output = QDoubleSpinBox(); self.min_output.setRange(0, 100); self.min_output.setDecimals(2); self.min_output.setSuffix(' %'); self.min_output.setValue(0.0)
        self.max_output = QDoubleSpinBox(); self.max_output.setRange(0, 100); self.max_output.setDecimals(2); self.max_output.setSuffix(' %'); self.max_output.setValue(100.0)
        self.base_output = QDoubleSpinBox(); self.base_output.setRange(0, 100); self.base_output.setDecimals(2); self.base_output.setSuffix(' %'); self.base_output.setValue(10.0)
        self.side = QComboBox(); self.side.addItem('Primary (A)', 'a'); self.side.addItem('Secondary (B)', 'b')
        form.addRow('', self.enabled)
        form.addRow('Type', self.kind)
        form.addRow('Label', self.label)
        form.addRow('Source', self.source)
        form.addRow('Target', self.target)
        form.addRow('Setpoint', self.setpoint)
        form.addRow('Deadband', self.deadband)
        form.addRow('Ramp / s', self.ramp)
        form.addRow('PID Kp', self.kp)
        form.addRow('PID Ki', self.ki)
        form.addRow('PID Kd', self.kd)
        form.addRow('Min output', self.min_output)
        form.addRow('Max output', self.max_output)
        form.addRow('Base/start output', self.base_output)
        form.addRow('Output side', self.side)
        lay.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)
        self.kind.currentIndexChanged.connect(self._refresh_options)
        if current is not None:
            idx = self.kind.findData(current.controller_key)
            if idx >= 0:
                self.kind.setCurrentIndex(idx)
            self.enabled.setChecked(bool(current.enabled))
            self.label.setText(current.label)
            self.setpoint.setValue(float(current.setpoint))
            self.deadband.setValue(float(current.deadband))
            extra = dict(getattr(current, 'extra', {}) or {})
            self.kp.setValue(float(extra.get('kp', 0.30) or 0.30))
            self.ki.setValue(float(extra.get('ki', 0.05) or 0.05))
            self.kd.setValue(float(extra.get('kd', 0.00) or 0.00))
            self.min_output.setValue(float(extra.get('output_min', 0.0) or 0.0))
            self.max_output.setValue(float(extra.get('output_max', 100.0) or 100.0))
            self.base_output.setValue(float(extra.get('manual_duty', 10.0) or 10.0))
        self._refresh_options()
        if current is not None:
            self._select_data(self.source, current.source_key)
            self._select_data(self.target, current.target_key)

    def _select_data(self, combo, value):
        for i in range(combo.count()):
            if combo.itemData(i) == value:
                combo.setCurrentIndex(i)
                return

    def _refresh_options(self):
        controller_key = self.kind.currentData()
        source_current = self.source.currentData()
        target_current = self.target.currentData()
        self.source.clear(); self.target.clear()
        for label, key in [(r.label, r.key) for r in self.queries.signal_records() if str(r.key).partition(':')[0] in set((self.queries.controller_definitions()[self.kind.currentIndex()].source_families or ()))] if self.kind.currentIndex() >= 0 else []:
            self.source.addItem(label, key)
        for rec in self.queries.output_targets_for_controller(controller_key):
            self.target.addItem(rec.label, rec.key)
        self._select_data(self.source, source_current)
        self._select_data(self.target, target_current)
        is_pid = controller_key == 'pid'
        self.kp.setEnabled(is_pid); self.ki.setEnabled(is_pid); self.kd.setEnabled(is_pid)
        self.min_output.setEnabled(is_pid); self.max_output.setEnabled(is_pid); self.base_output.setEnabled(is_pid)
        self.deadband.setEnabled(not is_pid)
        self.side.setEnabled(not is_pid)
        if is_pid:
            self.side.setToolTip('PID drives a numeric CAN output, so A/B side selection is not used.')
        else:
            self.side.setToolTip('Select which deadband side drives the chosen target.')

    def to_model(self, instance_id=None):
        controller_key = str(self.kind.currentData() or '')
        output_min = float(self.min_output.value())
        output_max = float(self.max_output.value())
        if output_max < output_min:
            output_min, output_max = output_max, output_min
        extra = {'target_side': str(self.side.currentData() or 'a')}
        if controller_key == 'pid':
            extra = {
                'kp': float(self.kp.value()),
                'ki': float(self.ki.value()),
                'kd': float(self.kd.value()),
                'output_min': output_min,
                'output_max': output_max,
                'manual_duty': float(self.base_output.value()),
            }
        return ControllerInstanceConfigModel(
            id=str(instance_id or uuid.uuid4().hex[:8]),
            controller_key=controller_key,
            label=self.label.text().strip() or controller_key,
            enabled=self.enabled.isChecked(),
            source_key=self.source.currentData(),
            target_key=str(self.target.currentData() or ''),
            setpoint=float(self.setpoint.value()),
            deadband=float(self.deadband.value()),
            ramp_per_s=(None if self.ramp.value() <= 0.0 else float(self.ramp.value())),
            extra=extra,
        )
