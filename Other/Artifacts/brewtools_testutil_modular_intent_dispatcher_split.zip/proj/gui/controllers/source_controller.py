from __future__ import annotations

from gui.ui_helpers import find_data_index, normalize_signal_key


class WindowSourceController:
    """Owns signal-source discovery, combo reconciliation, and related cross-panel source refreshes."""

    def __init__(self, window):
        self.window = window

    def selected_or_pending_source_key(self, combo, pending):
        data_key = normalize_signal_key(combo.currentData())
        if data_key is not None:
            return data_key
        return normalize_signal_key(pending)

    def refresh_control_sources(self) -> None:
        temp_sources = []
        pressure_sources = []
        all_sources = []
        for rec in self.window.queries.signal_records():
            all_sources.append((rec.label, rec.key))
            if rec.key.startswith('sensor:temperature:'):
                temp_sources.append((rec.label, rec.key))
            elif rec.key.startswith('sensor:pressure:'):
                pressure_sources.append((rec.label, rec.key))

        self.window.ui_state.control_combo_sync_block = True
        try:
            self._refresh_control_source_combo(
                self.window.control_panel.temp_source_combo,
                'temperature',
                temp_sources,
                self.window.ui_state.pending_temp_source_key,
                'last_temp_source_keys',
            )
            self._refresh_control_source_combo(
                self.window.control_panel.pressure_source_combo,
                'pressure',
                pressure_sources,
                self.window.ui_state.pending_pressure_source_key,
                'last_pressure_source_keys',
            )
            safety_target = (
                self.window.safety_panel.safety_signal_combo.currentData()
                or self.window.safety_panel.safety_signal_combo.currentText().strip()
            )
            self._refresh_control_source_combo(
                self.window.safety_panel.safety_signal_combo,
                'safety signal',
                all_sources,
                safety_target,
                'last_safety_signal_keys',
            )
            self._refresh_agitator_target_combo()
        finally:
            self.window.ui_state.control_combo_sync_block = False

        self.window.config_controller.save_settings_to_state()
        self.window.intent_dispatcher.refresh_control_panel()
        self.window.intent_dispatcher.refresh_safety_panel()

    def refresh_twin_sources(self) -> None:
        self.window.twin_panel.refresh_sources()

    def refresh_all_sources(self) -> None:
        self.refresh_control_sources()
        self.refresh_twin_sources()

    def _agitator_target_options(self):
        options = [('Relay virtual output (AGITATOR)', 'relay')]
        snap_sources = self.window.queries.snapshot()
        for st in sorted(snap_sources.devices.values(), key=lambda st: st.node_id):
            if int(st.sender_node_type) == 6:
                label = f'CAN agitator node {st.node_id}'
                if st.rpm is not None:
                    label += f' — RPM {st.rpm:.1f}'
                options.append((label, f'can:{int(st.node_id)}'))
        return options

    def _refresh_agitator_target_combo(self) -> None:
        target = str(getattr(self.window.settings.agitator, 'target', 'relay') or 'relay')
        combo = self.window.control_panel.agitator_target_combo
        current = combo.currentData() if combo.count() else target
        options = self._agitator_target_options()
        keys = [str(data) for _, data in options]
        if combo.view().isVisible():
            return
        needs_rebuild = combo.count() == 0 or keys != self.window.ui_state.last_agitator_target_keys
        current_norm = str(current or 'relay')
        target_norm = current_norm if current_norm in keys else str(target or 'relay')
        if not needs_rebuild and str(combo.currentData() or 'relay') == target_norm:
            return
        self.window.ui_state.last_agitator_target_keys = list(keys)
        combo.blockSignals(True)
        combo.clear()
        if target_norm not in keys:
            combo.addItem('Saved agitator output (waiting for CAN)', target_norm)
        for label, data in options:
            combo.addItem(label, data)
        idx = find_data_index(combo, target_norm)
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        combo.blockSignals(False)
        self.window.control_panel.refresh_agitator_control_ui()

    def _refresh_control_source_combo(self, combo, measurement: str, sources, target, cache_attr: str) -> None:
        if combo.view().isVisible():
            return
        norm_target = normalize_signal_key(target)
        source_keys = [normalize_signal_key(k) for _, k in sources]
        last_keys = getattr(self.window.ui_state, cache_attr, [])
        current_key = normalize_signal_key(combo.currentData())
        needs_rebuild = combo.count() == 0 or source_keys != last_keys
        needs_reselect = current_key != norm_target
        if not (needs_rebuild or needs_reselect):
            return

        setattr(self.window.ui_state, cache_attr, list(source_keys))
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(f'— Select discovered {measurement} channel —', None)
        if norm_target is not None and norm_target not in source_keys:
            combo.addItem(f'Saved {measurement} source (waiting for CAN)', norm_target)
        for label, key in sources:
            combo.addItem(label, normalize_signal_key(key))
        idx = find_data_index(combo, norm_target)
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        combo.blockSignals(False)
