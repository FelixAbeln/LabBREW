from __future__ import annotations

from gui.presenters import MainWindowRefreshCoordinator


class WindowIntentDispatcher:
    """Owns intent-level GUI refresh dispatch for the window."""

    def __init__(self, window):
        self.window = window
        self.refresh = MainWindowRefreshCoordinator(window, window.queries)

    def refresh_footer(self, *, force: bool = False) -> bool:
        self.refresh.footer.refresh()
        return True

    def refresh_table(self, *, force: bool = False) -> bool:
        self.refresh.devices.refresh_table()
        return True

    def refresh_control_panel(self, *, force: bool = False) -> bool:
        self.refresh.control.refresh()
        return True

    def refresh_safety_panel(self, *, force: bool = False) -> bool:
        self.refresh.safety.refresh()
        return True

    def refresh_twin_panel(self, *, force: bool = False) -> bool:
        self.refresh.twin.refresh()
        return True

    def refresh_scheduler_panel(self, *, force: bool = False) -> bool:
        self.refresh.scheduler.refresh()
        return True

    def refresh_relay_panel(self, *, force: bool = False) -> bool:
        self.refresh.relays.refresh()
        return True

    def refresh_sources(self) -> None:
        self.window.source_controller.refresh_all_sources()

    def refresh_all(self, *, force: bool = False) -> None:
        self.refresh_footer(force=force)
        self.refresh_table(force=force)
        self.refresh_control_panel(force=force)
        self.refresh_safety_panel(force=force)
        self.refresh_twin_panel(force=force)
        self.refresh_scheduler_panel(force=force)
        self.refresh_relay_panel(force=force)
